#!/usr/bin/env python3
"""
BOT HOST PANEL - sell your store bot.
Buyer opens the website, enters Access Key + Bot Token + Admin ID -> bot is hosted on this VPS instantly.
Owner dashboard: total revenue / users / orders of every hosted bot, start/stop/restart, keys, expiry.
"""
import os
import re
import sys
import time
import hmac
import signal
import secrets
import sqlite3
import threading
import subprocess
from pathlib import Path
from datetime import datetime, timedelta, timezone

import requests
from flask import Flask, request, session, redirect, jsonify, Response

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
BOTS = BASE / "bots"
TEMPLATE = BASE / "storebot_template.py"
DATA.mkdir(exist_ok=True)
BOTS.mkdir(exist_ok=True)
PANEL_DB = DATA / "panel.db"
IST_MIN = 330


def load_env(path: Path):
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


load_env(BASE / "panel.env")
PANEL_PASSWORD = os.getenv("PANEL_PASSWORD", "")
PANEL_HOST = os.getenv("PANEL_HOST", "0.0.0.0")
PANEL_PORT = int(os.getenv("PANEL_PORT", "8000"))
BRAND = os.getenv("BRAND", "Bot Host")
DEFAULT_DAYS = int(os.getenv("DEFAULT_DAYS", "30"))
FIRST_BOT_PORT = 9000

if not PANEL_PASSWORD or len(PANEL_PASSWORD) < 6:
    sys.exit("PANEL_PASSWORD missing (min 6 chars). Put it in panel.env:  PANEL_PASSWORD=yourpassword")

key_file = DATA / "secret.key"
if not key_file.exists():
    key_file.write_text(secrets.token_hex(32))
    os.chmod(key_file, 0o600)

app = Flask(__name__)
app.secret_key = key_file.read_text().strip()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  PERMANENT_SESSION_LIFETIME=timedelta(days=7), MAX_CONTENT_LENGTH=20_000)

_dblock = threading.Lock()


# ─────────────────────────── panel database ───────────────────────────
def pdb(sql: str, params=(), fetch=None):
    with _dblock:
        con = sqlite3.connect(PANEL_DB, timeout=20)
        con.row_factory = sqlite3.Row
        try:
            cur = con.execute(sql, params)
            if fetch == "one":
                r = cur.fetchone()
                return dict(r) if r else None
            if fetch == "all":
                return [dict(r) for r in cur.fetchall()]
            con.commit()
            return cur.lastrowid if fetch == "id" else cur.rowcount
        finally:
            con.close()


pdb("""CREATE TABLE IF NOT EXISTS bots (
    id INTEGER PRIMARY KEY AUTOINCREMENT, tg_id INTEGER UNIQUE, username TEXT, name TEXT,
    token TEXT NOT NULL, admin_ids TEXT NOT NULL, port INTEGER, pid INTEGER,
    desired INTEGER DEFAULT 1, expires_at TEXT, key_code TEXT, created_at TEXT)""")
pdb("""CREATE TABLE IF NOT EXISTS keys (
    code TEXT PRIMARY KEY, days INTEGER NOT NULL, note TEXT, created_at TEXT, used_by INTEGER, used_at TEXT)""")


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def ts(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def parse_ts(s):
    try:
        return datetime.strptime(s, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None


def is_expired(b) -> bool:
    e = parse_ts(b.get("expires_at"))
    return bool(e and e < now_utc())


# ─────────────────────────── process manager ───────────────────────────
PROCS = {}   # bot id -> Popen (only for bots started by this panel run)
_fail_times = {}


def bot_dir(bid: int) -> Path:
    return BOTS / str(bid)


def pid_alive(pid) -> bool:
    if not pid:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    try:   # zombie = dead
        stat = Path(f"/proc/{pid}/stat").read_text()
        if stat.rsplit(")", 1)[1].split()[0] == "Z":
            return False
    except Exception:
        pass
    return True


def is_running(b) -> bool:
    p = PROCS.get(b["id"])
    if p is not None:
        if p.poll() is None:
            return True
        PROCS.pop(b["id"], None)
        return False
    pid = b.get("pid")
    if not pid_alive(pid):
        return False
    try:   # make sure the pid really is this bot (pid reuse safety)
        return os.readlink(f"/proc/{pid}/cwd") == str(bot_dir(b["id"]))
    except Exception:
        return True


def write_bot_files(b):
    d = bot_dir(b["id"])
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(d, 0o700)
    link = d / "storebot.py"
    if link.is_symlink() or link.exists():
        link.unlink()
    try:
        link.symlink_to(TEMPLATE)    # one template for all bots: update it once, restart all
    except OSError:
        link.write_bytes(TEMPLATE.read_bytes())
    env = d / ".env"
    env.write_text(
        f"BOT_TOKEN={b['token']}\nADMIN_IDS={b['admin_ids']}\nDB_NAME=store.db\nWEBAPP_PORT={b['port']}\n"
        f"STORE_NAME={(b.get('name') or 'My Store')[:40]}\nSUPPORT_USERNAME=@{b.get('username') or 'support'}\n"
        f"SEED_DEMO=0\n", encoding="utf-8")
    os.chmod(env, 0o600)


def start_bot(b) -> bool:
    if is_running(b):
        return True
    if is_expired(b):
        return False
    write_bot_files(b)
    d = bot_dir(b["id"])
    log = open(d / "bot.log", "ab")
    env = {k: v for k, v in os.environ.items() if k in ("PATH", "HOME", "LANG", "LC_ALL", "TZ")}
    env["PYTHONUNBUFFERED"] = "1"
    p = subprocess.Popen([sys.executable, "storebot.py"], cwd=d, stdout=log, stderr=subprocess.STDOUT,
                         stdin=subprocess.DEVNULL, start_new_session=True, env=env)
    log.close()
    PROCS[b["id"]] = p
    pdb("UPDATE bots SET pid = ?, desired = 1 WHERE id = ?", (p.pid, b["id"]))
    return True


def stop_bot(b, keep_desired=False):
    if not keep_desired:
        pdb("UPDATE bots SET desired = 0 WHERE id = ?", (b["id"],))
    pid = (PROCS.get(b["id"]).pid if PROCS.get(b["id"]) else None) or b.get("pid")
    if pid and is_running(b):
        try:
            os.killpg(pid, signal.SIGTERM)
        except OSError:
            pass
        for _ in range(40):
            time.sleep(0.2)
            p = PROCS.get(b["id"])
            if p is not None:
                p.poll()
            if not pid_alive(pid) or (p is not None and p.poll() is not None):
                break
        else:
            try:
                os.killpg(pid, signal.SIGKILL)
            except OSError:
                pass
    PROCS.pop(b["id"], None)
    pdb("UPDATE bots SET pid = NULL WHERE id = ?", (b["id"],))


def get_bot(bid: int):
    return pdb("SELECT * FROM bots WHERE id = ?", (bid,), "one")


def watchdog():
    """Every 10s: stop expired bots, restart crashed bots, keep logs small."""
    while True:
        try:
            for b in pdb("SELECT * FROM bots", fetch="all"):
                running = is_running(b)
                if is_expired(b):
                    if running:
                        stop_bot(b, keep_desired=True)
                    continue
                if b["desired"] and not running:
                    recent = [t for t in _fail_times.get(b["id"], []) if time.time() - t < 600]
                    if len(recent) >= 6:      # crash loop: give up, owner sees "crashed"
                        pdb("UPDATE bots SET desired = 0 WHERE id = ?", (b["id"],))
                        _fail_times[b["id"]] = []
                        continue
                    recent.append(time.time())
                    _fail_times[b["id"]] = recent
                    start_bot(b)
                lg = bot_dir(b["id"]) / "bot.log"
                try:
                    if lg.exists() and lg.stat().st_size > 5_000_000:
                        os.truncate(lg, 0)
                except OSError:
                    pass
        except Exception as e:
            print("watchdog error:", e, flush=True)
        time.sleep(10)


# ─────────────────────────── per-bot statistics ───────────────────────────
_stat_cache = {}


def bot_stats(bid: int) -> dict:
    c = _stat_cache.get(bid)
    if c and time.time() - c[0] < 4:
        return c[1]
    st = {"users": 0, "orders": 0, "revenue": 0.0, "today": 0.0, "today_orders": 0, "deposits": 0.0}
    f = bot_dir(bid) / "store.db"
    if f.exists():
        try:
            con = sqlite3.connect(f"file:{f}?mode=ro", uri=True, timeout=3)
            mod = f"+{IST_MIN} minutes"
            st["users"] = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            r = con.execute("SELECT COUNT(*), COALESCE(SUM(price),0) FROM orders WHERE status='completed'").fetchone()
            st["orders"], st["revenue"] = r[0], float(r[1])
            r = con.execute("SELECT COUNT(*), COALESCE(SUM(price),0) FROM orders WHERE status='completed' "
                            "AND DATE(created_at, ?) = DATE('now', ?)", (mod, mod)).fetchone()
            st["today_orders"], st["today"] = r[0], float(r[1])
            st["deposits"] = float(con.execute("SELECT COALESCE(SUM(amount),0) FROM transactions "
                                               "WHERE status='approved'").fetchone()[0])
            con.close()
        except Exception:
            pass
    _stat_cache[bid] = (time.time(), st)
    return st


def status_of(b) -> str:
    if is_expired(b):
        return "expired"
    if is_running(b):
        return "running"
    return "crashed" if b["desired"] else "stopped"


def all_bots_view():
    out = []
    for b in pdb("SELECT * FROM bots ORDER BY id DESC", fetch="all"):
        s = bot_stats(b["id"])
        e = parse_ts(b["expires_at"])
        left = None
        if e:
            left = round((e - now_utc()).total_seconds() / 86400, 1)
        out.append({
            "id": b["id"], "username": b["username"], "name": b["name"], "status": status_of(b),
            "admin_ids": b["admin_ids"], "created": b["created_at"], "expires": b["expires_at"],
            "days_left": left, "key": b["key_code"], **s})
    return out


# ─────────────────────────── deploy ───────────────────────────
TOKEN_RE = re.compile(r"^\d{6,12}:[A-Za-z0-9_-]{30,50}$")
ADMIN_RE = re.compile(r"^\d{5,15}(,\d{5,15})*$")


def tg_call(token: str, method: str):
    r = requests.get(f"https://api.telegram.org/bot{token}/{method}", timeout=15)
    return r.json()


def create_bot(token: str, admin_ids: str, days: int, key_code=None):
    """-> (ok, message, bot dict or None)"""
    token = (token or "").strip()
    admin_ids = re.sub(r"\s+", "", admin_ids or "")
    if not TOKEN_RE.match(token):
        return False, "Bot token is not valid. Copy it again from @BotFather.", None
    if not ADMIN_RE.match(admin_ids):
        return False, "Admin ID must be numbers only (your Telegram user ID). Use commas for more than one.", None
    try:
        me = tg_call(token, "getMe")
    except Exception:
        return False, "Could not reach Telegram. Try again in a minute.", None
    if not me.get("ok"):
        return False, "Telegram rejected this token. Check it in @BotFather.", None
    info = me["result"]
    if pdb("SELECT id FROM bots WHERE tg_id = ?", (info["id"],), "one"):
        return False, "This bot is already hosted here.", None
    try:
        tg_call(token, "deleteWebhook")      # polling needs the webhook cleared
    except Exception:
        pass
    port = FIRST_BOT_PORT + (pdb("SELECT COALESCE(MAX(id),0)+1 AS n FROM bots", fetch="one")["n"])
    expires = ts(now_utc() + timedelta(days=days)) if days and days > 0 else None
    bid = pdb("INSERT INTO bots (tg_id, username, name, token, admin_ids, port, desired, expires_at, key_code, created_at) "
              "VALUES (?,?,?,?,?,?,1,?,?,?)",
              (info["id"], info.get("username"), info.get("first_name"), token, admin_ids, port, expires,
               key_code, ts(now_utc())), "id")
    b = get_bot(bid)
    start_bot(b)
    return True, f"@{info.get('username')} is live.", b


# ─────────────────────────── security helpers ───────────────────────────
_login_fails = {}
_deploy_hits = {}


def client_ip() -> str:
    return request.headers.get("X-Forwarded-For", request.remote_addr or "?").split(",")[0].strip()


def rate_ok(store: dict, ip: str, limit: int, window: int) -> bool:
    now = time.time()
    hits = [t for t in store.get(ip, []) if now - t < window]
    store[ip] = hits
    return len(hits) < limit


def authed() -> bool:
    return session.get("auth") is True


def csrf_ok() -> bool:
    t = request.headers.get("X-CSRF", "")
    return bool(t) and hmac.compare_digest(t, session.get("csrf", ""))


def guard():
    """Returns an error response, or None if the request is an authenticated owner request."""
    if not authed():
        return jsonify(ok=False, message="Please login again."), 401
    if request.method == "POST" and not csrf_ok():
        return jsonify(ok=False, message="Session expired. Refresh the page."), 403
    return None


@app.after_request
def headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Cache-Control"] = "no-store"
    return resp


# ─────────────────────────── routes: public ───────────────────────────
@app.get("/")
def landing():
    return Response(LANDING.replace("__BRAND__", BRAND), mimetype="text/html")


@app.post("/api/deploy")
def api_deploy():
    ip = client_ip()
    if not rate_ok(_deploy_hits, ip, 8, 3600):
        return jsonify(ok=False, message="Too many attempts. Try again later."), 429
    _deploy_hits[ip].append(time.time())
    j = request.get_json(silent=True) or {}
    code = re.sub(r"\s+", "", str(j.get("key", ""))).upper()
    k = pdb("SELECT * FROM keys WHERE code = ?", (code,), "one")
    if not k or k["used_by"] is not None:
        return jsonify(ok=False, message="Access key is invalid or already used."), 400
    if pdb("UPDATE keys SET used_by = -1 WHERE code = ? AND used_by IS NULL", (code,)) == 0:
        return jsonify(ok=False, message="Access key is invalid or already used."), 400
    ok, msg, b = create_bot(j.get("token", ""), j.get("admin", ""), k["days"], code)
    if not ok:
        pdb("UPDATE keys SET used_by = NULL WHERE code = ? AND used_by = -1", (code,))
        return jsonify(ok=False, message=msg), 400
    pdb("UPDATE keys SET used_by = ?, used_at = ? WHERE code = ?", (b["id"], ts(now_utc()), code))
    return jsonify(ok=True, message=msg, username=b["username"], days=k["days"])


# ─────────────────────────── routes: owner ───────────────────────────
@app.route("/admin/login", methods=["GET", "POST"])
def login():
    err = ""
    if request.method == "POST":
        ip = client_ip()
        if not rate_ok(_login_fails, ip, 5, 600):
            err = "Too many wrong tries. Wait 10 minutes."
        elif hmac.compare_digest(request.form.get("password", ""), PANEL_PASSWORD):
            session.clear()
            session.permanent = True
            session["auth"] = True
            session["csrf"] = secrets.token_hex(16)
            return redirect("/admin")
        else:
            _login_fails[ip].append(time.time())
            err = "Wrong password."
    return Response(LOGIN.replace("__BRAND__", BRAND).replace("__ERR__", err), mimetype="text/html")


@app.get("/admin/logout")
def logout():
    session.clear()
    return redirect("/admin/login")


@app.get("/admin")
def dashboard():
    if not authed():
        return redirect("/admin/login")
    return Response(DASH.replace("__BRAND__", BRAND).replace("__CSRF__", session["csrf"])
                    .replace("__DEFDAYS__", str(DEFAULT_DAYS)), mimetype="text/html")


@app.get("/api/stats")
def api_stats():
    g = guard()
    if g:
        return g
    bots = all_bots_view()
    tot = {
        "bots": len(bots), "running": sum(1 for b in bots if b["status"] == "running"),
        "users": sum(b["users"] for b in bots), "orders": sum(b["orders"] for b in bots),
        "revenue": sum(b["revenue"] for b in bots), "today": sum(b["today"] for b in bots),
        "deposits": sum(b["deposits"] for b in bots),
    }
    keys = pdb("SELECT code, days, note, created_at, used_by FROM keys ORDER BY created_at DESC LIMIT 60", fetch="all")
    return jsonify(ok=True, totals=tot, bots=bots, keys=keys)


@app.post("/api/bot/<int:bid>/<action>")
def api_bot_action(bid, action):
    g = guard()
    if g:
        return g
    b = get_bot(bid)
    if not b:
        return jsonify(ok=False, message="Bot not found."), 404
    j = request.get_json(silent=True) or {}
    if action == "start":
        if is_expired(b):
            return jsonify(ok=False, message="Plan expired. Extend it first.")
        _fail_times[bid] = []
        start_bot(b)
        return jsonify(ok=True, message="Started.")
    if action == "stop":
        stop_bot(b)
        return jsonify(ok=True, message="Stopped.")
    if action == "restart":
        stop_bot(b, keep_desired=True)
        _fail_times[bid] = []
        pdb("UPDATE bots SET desired = 1 WHERE id = ?", (bid,))
        start_bot(get_bot(bid))
        return jsonify(ok=True, message="Restarted.")
    if action == "extend":
        try:
            days = int(j.get("days", 30))
        except (TypeError, ValueError):
            return jsonify(ok=False, message="Enter days as a number."), 400
        if not -3650 <= days <= 3650 or days == 0:
            return jsonify(ok=False, message="Days must be between -3650 and 3650."), 400
        e = parse_ts(b["expires_at"]) or now_utc()
        base = max(e, now_utc()) if days > 0 else e
        pdb("UPDATE bots SET expires_at = ? WHERE id = ?", (ts(base + timedelta(days=days)), bid))
        nb = get_bot(bid)
        if not is_expired(nb):
            pdb("UPDATE bots SET desired = 1 WHERE id = ?", (bid,))
            _fail_times[bid] = []
            start_bot(get_bot(bid))
        return jsonify(ok=True, message=f"Plan changed by {days} day(s).")
    if action == "lifetime":
        pdb("UPDATE bots SET expires_at = NULL, desired = 1 WHERE id = ?", (bid,))
        start_bot(get_bot(bid))
        return jsonify(ok=True, message="Lifetime plan set.")
    if action == "delete":
        stop_bot(b)
        pdb("DELETE FROM bots WHERE id = ?", (bid,))
        import shutil
        shutil.rmtree(bot_dir(bid), ignore_errors=True)
        return jsonify(ok=True, message="Bot deleted.")
    return jsonify(ok=False, message="Unknown action."), 400


@app.get("/api/bot/<int:bid>/log")
def api_bot_log(bid):
    g = guard()
    if g:
        return g
    f = bot_dir(bid) / "bot.log"
    if not f.exists():
        return jsonify(ok=True, log="(no log yet)")
    with open(f, "rb") as fh:
        fh.seek(0, 2)
        fh.seek(max(0, fh.tell() - 9000))
        txt = fh.read().decode("utf-8", "replace")
    txt = re.sub(r"bot\d+:[A-Za-z0-9_-]+", "bot<token>", txt)     # never show tokens
    return jsonify(ok=True, log="\n".join(txt.splitlines()[-70:]))


@app.post("/api/deploy_owner")
def api_deploy_owner():
    g = guard()
    if g:
        return g
    j = request.get_json(silent=True) or {}
    try:
        days = int(j.get("days", DEFAULT_DAYS))
    except (TypeError, ValueError):
        days = DEFAULT_DAYS
    ok, msg, b = create_bot(j.get("token", ""), j.get("admin", ""), days)
    return jsonify(ok=ok, message=msg), (200 if ok else 400)


@app.post("/api/keys")
def api_keys():
    g = guard()
    if g:
        return g
    j = request.get_json(silent=True) or {}
    try:
        days = int(j.get("days", DEFAULT_DAYS))
        count = max(1, min(int(j.get("count", 1)), 50))
    except (TypeError, ValueError):
        return jsonify(ok=False, message="Days and count must be numbers."), 400
    if not 1 <= days <= 3650:
        return jsonify(ok=False, message="Days must be 1 to 3650."), 400
    note = str(j.get("note", ""))[:60]
    made = []
    for _ in range(count):
        code = "-".join(secrets.token_hex(2).upper() for _ in range(3))
        pdb("INSERT INTO keys (code, days, note, created_at) VALUES (?,?,?,?)", (code, days, note, ts(now_utc())))
        made.append(code)
    return jsonify(ok=True, message=f"{count} key(s) created.", codes=made)


@app.post("/api/keys/<code>/delete")
def api_key_delete(code):
    g = guard()
    if g:
        return g
    pdb("DELETE FROM keys WHERE code = ? AND used_by IS NULL", (code.upper(),))
    return jsonify(ok=True, message="Key removed.")


@app.post("/api/restart_all")
def api_restart_all():
    g = guard()
    if g:
        return g
    n = 0
    for b in pdb("SELECT * FROM bots WHERE desired = 1", fetch="all"):
        if is_expired(b):
            continue
        stop_bot(b, keep_desired=True)
        pdb("UPDATE bots SET desired = 1 WHERE id = ?", (b["id"],))
        start_bot(get_bot(b["id"]))
        n += 1
    return jsonify(ok=True, message=f"{n} bot(s) restarted with the latest template.")


# ─────────────────────────── pages ───────────────────────────
CSS = r"""
:root{--bg:#07090f;--s1:#0f1320;--s2:#161c2f;--line:#232b43;--tx:#eef1f8;--mu:#8b93ab;--ac:#c6ff3d;--red:#ff5d6c;--amber:#ffb020;--blue:#5b8cff}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;color:var(--tx);font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;-webkit-font-smoothing:antialiased}
body{min-height:100vh;padding:0 16px 40px;background:radial-gradient(90% 40% at 100% 0,rgba(91,140,255,.18),transparent 60%),radial-gradient(70% 34% at 0 10%,rgba(198,255,61,.09),transparent 62%),var(--bg)}
button,input,select{font:inherit;color:inherit}
.wrap{max-width:980px;margin:0 auto}
.top{display:flex;align-items:center;gap:10px;padding:16px 0}
.logo{width:38px;height:38px;border-radius:12px;background:var(--ac);color:#0b1200;display:grid;place-items:center;font-weight:900}
.top b{font-size:17px;flex:1}
a.mini,.mini{border:1px solid var(--line);background:var(--s1);color:var(--mu);border-radius:11px;padding:8px 12px;font-size:12.5px;font-weight:700;cursor:pointer;text-decoration:none}
.card{background:var(--s1);border:1px solid var(--line);border-radius:20px;padding:16px;margin-bottom:14px}
h2{margin:0 0 12px;font-size:15px}
.inp{width:100%;border:1.5px solid var(--line);background:var(--s2);border-radius:13px;padding:13px;font-size:15px;font-weight:600;outline:0;margin-bottom:10px}
.inp:focus{border-color:var(--ac)}
.big{width:100%;border:0;border-radius:14px;padding:14px;background:var(--ac);color:#0b1200;font-weight:800;font-size:15px;cursor:pointer}
.big:disabled{opacity:.5}
.msg{margin-top:10px;font-size:13px;font-weight:600;min-height:18px}
.msg.err{color:#ff9aa4}.msg.ok{color:var(--ac)}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:14px}
@media(min-width:700px){.grid{grid-template-columns:repeat(4,1fr)}}
.stat{background:var(--s1);border:1px solid var(--line);border-radius:18px;padding:14px}
.stat small{display:block;color:var(--mu);font-size:11px;font-weight:700;letter-spacing:.8px;text-transform:uppercase}
.stat b{display:block;font-size:24px;margin-top:6px;font-variant-numeric:tabular-nums}
.stat.hot b{color:var(--ac)}
.stat i{font-style:normal;color:var(--mu);font-size:12px}
.bots{display:grid;gap:12px}
@media(min-width:760px){.bots{grid-template-columns:1fr 1fr}}
.bot{background:var(--s1);border:1px solid var(--line);border-radius:20px;padding:15px}
.bh{display:flex;align-items:center;gap:10px;margin-bottom:12px}
.bh b{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.badge{font-size:11px;font-weight:800;border-radius:999px;padding:4px 10px}
.running{background:rgba(198,255,61,.14);color:var(--ac)}.stopped{background:rgba(139,147,171,.18);color:var(--mu)}
.crashed,.expired{background:rgba(255,93,108,.15);color:#ff9aa4}
.mm{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}
.mm div{background:var(--s2);border-radius:12px;padding:9px}
.mm small{display:block;color:var(--mu);font-size:10.5px;font-weight:700}.mm b{font-size:15px}
.bar{height:6px;background:var(--s2);border-radius:9px;overflow:hidden;margin-bottom:12px}
.bar span{display:block;height:100%;background:var(--ac)}
.meta{color:var(--mu);font-size:12px;margin-bottom:10px;font-weight:600}
.acts{display:flex;flex-wrap:wrap;gap:7px}
.acts button{border:1px solid var(--line);background:var(--s2);border-radius:10px;padding:8px 11px;font-size:12.5px;font-weight:700;cursor:pointer}
.acts .g{color:var(--ac)}.acts .r{color:#ff9aa4}
.keyrow{display:flex;align-items:center;gap:8px;padding:9px 0;border-top:1px solid var(--line);font-size:13px;font-weight:600}
.keyrow code{flex:1;font-size:14px;letter-spacing:.5px}.keyrow span{color:var(--mu);font-size:12px}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
pre{background:#05070c;border:1px solid var(--line);border-radius:12px;padding:12px;font-size:11.5px;line-height:1.5;max-height:55vh;overflow:auto;white-space:pre-wrap;word-break:break-all}
.modal{position:fixed;inset:0;background:rgba(0,0,0,.7);display:none;align-items:center;justify-content:center;padding:16px;z-index:9}
.modal.on{display:flex}.modal .card{width:100%;max-width:640px;margin:0}
.toast{position:fixed;left:50%;bottom:24px;transform:translate(-50%,20px);background:#fff;color:#0b1200;padding:10px 16px;border-radius:12px;font-size:13px;font-weight:700;opacity:0;pointer-events:none;transition:.25s;z-index:20;max-width:90vw}
.toast.on{opacity:1;transform:translate(-50%,0)}
"""

LANDING = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>__BRAND__</title><style>""" + CSS + r"""
.hero{text-align:center;padding:26px 0 18px}.hero h1{margin:0 0 8px;font-size:28px;letter-spacing:-.5px}.hero p{margin:0;color:var(--mu);font-size:14px;line-height:1.55}
.steps{color:var(--mu);font-size:12.5px;line-height:1.7;margin:4px 2px 14px}.steps b{color:var(--tx)}
.done{display:none;text-align:center}.done h2{font-size:22px;color:var(--ac)}
</style></head><body><div class="wrap" style="max-width:480px">
<div class="hero"><div class="logo" style="margin:0 auto 14px;width:52px;height:52px;font-size:22px">B</div>
<h1>Launch your store bot</h1><p>Enter your details. Your bot goes live in seconds, no server needed.</p></div>
<div class="card" id="form">
<div class="steps"><b>1.</b> Create a bot in @BotFather and copy its token<br><b>2.</b> Get your numeric ID from @userinfobot<br><b>3.</b> Paste everything below</div>
<input class="inp" id="key" placeholder="Access key  (XXXX-XXXX-XXXX)" autocomplete="off" autocapitalize="characters">
<input class="inp" id="token" placeholder="Bot token" autocomplete="off" spellcheck="false">
<input class="inp" id="admin" placeholder="Admin Telegram ID" inputmode="numeric" autocomplete="off">
<button class="big" id="go">Launch my bot</button><div class="msg" id="msg"></div></div>
<div class="card done" id="done"><h2>Your bot is live</h2><p id="dt" style="color:var(--mu);font-size:14px;line-height:1.6"></p>
<a class="big" id="open" style="display:block;text-decoration:none;margin-top:14px" href="#">Open my bot</a></div>
</div><script>
const $=i=>document.getElementById(i);
$("go").onclick=async()=>{const m=$("msg");m.className="msg";m.textContent="";$("go").disabled=true;$("go").textContent="Launching…";
 try{const r=await fetch("/api/deploy",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({key:$("key").value,token:$("token").value.trim(),admin:$("admin").value})});
 const j=await r.json();
 if(j.ok){$("form").style.display="none";$("done").style.display="block";$("open").href="https://t.me/"+j.username;$("open").textContent="Open @"+j.username;
  $("dt").textContent="Send /start to your bot, then open Admin Panel to add products, UPI ID and payment settings. Plan: "+j.days+" days."}
 else{m.className="msg err";m.textContent=j.message||"Something went wrong."}}
 catch(e){m.className="msg err";m.textContent="No connection. Try again."}
 $("go").disabled=false;$("go").textContent="Launch my bot"};
</script></body></html>"""

LOGIN = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Login</title><style>""" + CSS + r"""</style></head>
<body><div class="wrap" style="max-width:380px;padding-top:12vh"><div class="logo" style="margin:0 auto 18px;width:52px;height:52px;font-size:22px">B</div>
<div class="card"><h2>__BRAND__ - Owner login</h2><form method="post"><input class="inp" type="password" name="password" placeholder="Panel password" autofocus>
<button class="big">Login</button><div class="msg err">__ERR__</div></form></div></div></body></html>"""

DASH = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>__BRAND__ Dashboard</title><style>""" + CSS + r"""</style></head>
<body><div class="wrap">
<div class="top"><div class="logo">B</div><b>__BRAND__</b><button class="mini" id="rall">Restart all</button><a class="mini" href="/admin/logout">Logout</a></div>

<div class="grid" id="tot"></div>

<div class="card"><h2>Revenue by bot</h2><div id="rev" class="meta">Loading…</div></div>

<div class="card"><h2>Host a bot (owner)</h2>
<input class="inp" id="o_token" placeholder="Bot token" autocomplete="off" spellcheck="false">
<div class="row2"><input class="inp" id="o_admin" placeholder="Admin Telegram ID" inputmode="numeric"><input class="inp" id="o_days" placeholder="Days" inputmode="numeric" value="__DEFDAYS__"></div>
<button class="big" id="o_go">Host bot now</button><div class="msg" id="o_msg"></div></div>

<div class="card"><h2>Access keys (give to buyers)</h2>
<div class="row2"><input class="inp" id="k_days" placeholder="Plan days" inputmode="numeric" value="__DEFDAYS__"><input class="inp" id="k_count" placeholder="How many" inputmode="numeric" value="1"></div>
<input class="inp" id="k_note" placeholder="Note (buyer name, optional)"><button class="big" id="k_go">Create key(s)</button>
<div class="msg" id="k_msg"></div><div id="keys"></div></div>

<h2 style="margin:6px 4px 10px">Hosted bots</h2><div class="bots" id="bots"></div>
</div>

<div class="modal" id="lm"><div class="card"><h2 id="lt">Logs</h2><pre id="lp"></pre><button class="big" id="lc" style="margin-top:12px">Close</button></div></div>
<div class="toast" id="toast"></div>
<script>
const CSRF="__CSRF__", $=i=>document.getElementById(i);
const esc=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const inr=n=>"₹"+Number(n||0).toLocaleString("en-IN",{maximumFractionDigits:0});
let tt;function toast(s){const e=$("toast");e.textContent=s;e.classList.add("on");clearTimeout(tt);tt=setTimeout(()=>e.classList.remove("on"),2600)}
async function api(url,body){const r=await fetch(url,{method:body===undefined?"GET":"POST",headers:{"Content-Type":"application/json","X-CSRF":CSRF},body:body===undefined?undefined:JSON.stringify(body)});
 if(r.status===401){location.href="/admin/login";return {ok:false}}return r.json()}
function stat(l,v,s,hot){return '<div class="stat'+(hot?' hot':'')+'"><small>'+l+'</small><b>'+v+'</b>'+(s?'<i>'+s+'</i>':'')+'</div>'}
function render(d){
 const t=d.totals;
 $("tot").innerHTML=stat("Total revenue",inr(t.revenue),"today "+inr(t.today),1)+stat("Total bots",t.bots,t.running+" running")+stat("Total users",t.users.toLocaleString("en-IN"),"all bots")+stat("Total orders",t.orders.toLocaleString("en-IN"),"deposits "+inr(t.deposits));
 const mx=Math.max(1,...d.bots.map(b=>b.revenue));
 $("rev").innerHTML=d.bots.length?d.bots.slice().sort((a,b)=>b.revenue-a.revenue).map(b=>'<div style="margin-bottom:10px"><div style="display:flex;justify-content:space-between;color:var(--tx);font-size:13px"><span>@'+esc(b.username)+'</span><b>'+inr(b.revenue)+'</b></div><div class="bar" style="margin:5px 0 0"><span style="width:'+(b.revenue/mx*100)+'%"></span></div></div>').join(""):"No bots yet.";
 $("bots").innerHTML=d.bots.map(b=>{
  const left=b.expires?(b.days_left>=0?Math.ceil(b.days_left)+" days left":"expired"):"lifetime";
  return '<div class="bot"><div class="bh"><b>@'+esc(b.username)+'</b><span class="badge '+b.status+'">'+b.status+'</span></div>'+
  '<div class="mm"><div><small>REVENUE</small><b>'+inr(b.revenue)+'</b></div><div><small>USERS</small><b>'+b.users+'</b></div><div><small>ORDERS</small><b>'+b.orders+'</b></div>'+
  '<div><small>TODAY</small><b>'+inr(b.today)+'</b></div><div><small>DEPOSITS</small><b>'+inr(b.deposits)+'</b></div><div><small>PLAN</small><b style="font-size:12.5px">'+left+'</b></div></div>'+
  '<div class="meta">Admin ID: '+esc(b.admin_ids)+(b.key?' · key '+esc(b.key):'')+'</div>'+
  '<div class="acts"><button class="g" data-a="start" data-id="'+b.id+'">Start</button><button data-a="restart" data-id="'+b.id+'">Restart</button><button data-a="stop" data-id="'+b.id+'">Stop</button>'+
  '<button data-a="log" data-id="'+b.id+'">Logs</button><button data-a="extend" data-id="'+b.id+'">+ Days</button><button data-a="lifetime" data-id="'+b.id+'">Lifetime</button><button class="r" data-a="delete" data-id="'+b.id+'" data-n="'+esc(b.username)+'">Delete</button></div></div>'}).join("")||'<div class="meta">No bots hosted yet. Host one above or give a key to a buyer.</div>';
 $("keys").innerHTML=d.keys.map(k=>'<div class="keyrow"><code>'+esc(k.code)+'</code><span>'+k.days+'d'+(k.note?' · '+esc(k.note):'')+'</span>'+
  (k.used_by?'<span>used</span>':'<button class="mini" data-copy="'+esc(k.code)+'">Copy</button><button class="mini" data-kdel="'+esc(k.code)+'">✕</button>')+'</div>').join("");
}
async function load(){const d=await api("/api/stats");if(d.ok)render(d)}
document.addEventListener("click",async e=>{
 const c=e.target.closest("[data-copy]");if(c){navigator.clipboard&&navigator.clipboard.writeText(c.dataset.copy);toast("Key copied");return}
 const kd=e.target.closest("[data-kdel]");if(kd){await api("/api/keys/"+kd.dataset.kdel+"/delete",{});load();return}
 const b=e.target.closest("[data-a]");if(!b)return;const id=b.dataset.id,a=b.dataset.a;
 if(a==="log"){const j=await api("/api/bot/"+id+"/log");$("lt").textContent="Logs";$("lp").textContent=j.log||"";$("lm").classList.add("on");$("lp").scrollTop=1e9;return}
 let body={};
 if(a==="delete"){if(!confirm("Delete @"+b.dataset.n+" and ALL its data (users, orders)? This cannot be undone."))return}
 if(a==="extend"){const v=prompt("Add how many days? (negative to remove)","30");if(!v)return;body={days:parseInt(v,10)}}
 b.disabled=true;const j=await api("/api/bot/"+id+"/"+a,body);toast(j.message||"Done");load()});
$("lc").onclick=()=>$("lm").classList.remove("on");
$("rall").onclick=async()=>{if(!confirm("Restart every hosted bot with the latest template?"))return;const j=await api("/api/restart_all",{});toast(j.message);load()};
$("o_go").onclick=async()=>{const m=$("o_msg");m.className="msg";m.textContent="Starting…";$("o_go").disabled=true;
 const j=await api("/api/deploy_owner",{token:$("o_token").value.trim(),admin:$("o_admin").value,days:parseInt($("o_days").value,10)||0});
 m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";if(j.ok){$("o_token").value="";$("o_admin").value=""}$("o_go").disabled=false;load()};
$("k_go").onclick=async()=>{const m=$("k_msg");const j=await api("/api/keys",{days:parseInt($("k_days").value,10),count:parseInt($("k_count").value,10),note:$("k_note").value});
 m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";load()};
load();setInterval(load,8000);
</script></body></html>"""


def main():
    if not TEMPLATE.exists():
        sys.exit("storebot_template.py is missing next to app.py")
    threading.Thread(target=watchdog, daemon=True).start()
    print(f"Panel running on http://{PANEL_HOST}:{PANEL_PORT}   (owner: /admin)", flush=True)
    from werkzeug.serving import make_server
    srv = make_server(PANEL_HOST, PANEL_PORT, app, threaded=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
