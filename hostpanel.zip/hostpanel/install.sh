#!/usr/bin/env bash
# One-time setup:  bash install.sh
set -e
cd "$(dirname "$0")"
DIR="$(pwd)"
command -v python3 >/dev/null || { echo "python3 not found. Install it first: apt install -y python3 python3-venv"; exit 1; }
[ -d venv ] || python3 -m venv venv
./venv/bin/pip install -q --upgrade pip
./venv/bin/pip install -q flask "python-telegram-bot[job-queue]" requests qrcode pillow
if [ ! -f panel.env ]; then
  read -r -s -p "Choose a PANEL PASSWORD (min 6 chars): " PW; echo
  read -r -p "Brand name shown on the website [Bot Host]: " BR; BR="${BR:-Bot Host}"
  printf 'PANEL_PASSWORD=%s\nPANEL_PORT=8000\nBRAND=%s\nDEFAULT_DAYS=30\n' "$PW" "$BR" > panel.env
  chmod 600 panel.env
fi
if [ "$(id -u)" = "0" ] && command -v systemctl >/dev/null; then
  cat > /etc/systemd/system/bothost.service <<UNIT
[Unit]
Description=Bot Host Panel
After=network-online.target
[Service]
WorkingDirectory=$DIR
ExecStart=$DIR/venv/bin/python $DIR/app.py
Restart=always
RestartSec=3
# keep hosted bots alive when only the panel restarts
KillMode=process
[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload
  systemctl enable --now bothost
  sleep 2
  systemctl --no-pager --lines=5 status bothost || true
else
  echo "Not root: starting with nohup instead."
  nohup ./venv/bin/python app.py > panel.log 2>&1 &
  sleep 2; tail -n 5 panel.log
fi
IP=$(curl -s -4 ifconfig.me 2>/dev/null || echo YOUR_VPS_IP)
echo
echo "Website : http://$IP:8000/"
echo "Owner   : http://$IP:8000/admin"
echo "(open port 8000 in your VPS firewall:  ufw allow 8000)"
