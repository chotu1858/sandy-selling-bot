#!/usr/bin/env python3
# ============================================================
#  DIGITAL STORE BOT  (Python port for the Bot Host panel)
# ------------------------------------------------------------
#  ORIGINAL PROJECT / DEVELOPER CREDIT (must stay intact)
#    Project   : digital product selling (PHP source code)
#    Developer : @VishalCodeVerse
#    YouTube   : @VishalCodeVerse
#    Telegram  : https://t.me/Vishalcodeverse
#    (c) VishalCodeVerse. All Rights Reserved.
#  This file is a Python conversion of the original bot.php so it can be
#  hosted by the multi-script Bot Host panel. Features are kept the same.
# ============================================================
import os
import re
import json
import time
import html
import random
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from urllib.parse import quote_plus
from concurrent.futures import ThreadPoolExecutor

import requests

BASE = os.path.dirname(os.path.abspath(__file__))
IST = timezone(timedelta(hours=5, minutes=30))


# ============================================================
# ENV / CONFIG  (the panel writes .env in the bot folder)
# ============================================================
def load_env(path):
    try:
        for line in open(path, encoding="utf-8").read().splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
    except OSError:
        pass


load_env(os.path.join(BASE, ".env"))
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
_ADMIN_IDS = [x.strip() for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()]
ADMIN_ID = _ADMIN_IDS[0] if _ADMIN_IDS else ""          # the owner (first id)
FAMPAY_URL = "https://famapi-sas5.onrender.com"
STORE_NAME = os.getenv("STORE_NAME", "") or "Digital Store"
SUPPORT_USER = os.getenv("SUPPORT_USERNAME", "") or "@YourSupportUsername"
DB_FILE = os.path.join(BASE, os.getenv("DB_NAME", "store.db"))
API = "https://api.telegram.org/bot" + BOT_TOKEN

try:
    THEME = json.load(open(os.getenv("THEME_FILE", ""), encoding="utf-8"))
    if not isinstance(THEME, dict):
        THEME = {}
except Exception:
    THEME = {}


# ============================================================
# SMALL PHP-LIKE HELPERS
# ============================================================
def now():
    return datetime.now(IST)


def d_my():
    return now().strftime("%d %b %Y")


def d_myhm():
    return now().strftime("%d %b %Y %H:%M")


def php_int(v):
    m = re.match(r"\s*([+-]?\d+)", str(v))
    return int(m.group(1)) if m else 0


def php_float(v):
    m = re.match(r"\s*([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)", str(v))
    return float(m.group(1)) if m else 0.0


def num(v):
    """95.0 -> 95 (PHP prints whole numbers without .0)"""
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return v


def esc(s):
    return html.escape(str(s), quote=False)


def rid(prefix, digits=6, lo=10, hi=99):
    return prefix + str(int(time.time()))[-digits:] + str(random.randint(lo, hi))


def log_err(msg):
    try:
        with open(os.path.join(BASE, "bot_error.log"), "a", encoding="utf-8") as f:
            f.write(now().strftime("%Y-%m-%d %H:%M:%S") + " | " + msg + "\n")
        if os.path.getsize(os.path.join(BASE, "bot_error.log")) > 2_000_000:
            os.truncate(os.path.join(BASE, "bot_error.log"), 0)
    except OSError:
        pass
    print(msg, flush=True)


# ============================================================
# DATA (JSON files, same layout as the PHP bot)
# ============================================================
DATA = os.path.join(BASE, "data")
os.makedirs(DATA, exist_ok=True)
_save_lock = threading.RLock()
BAL = threading.RLock()                       # protects balance / stock changes
FILES = ["balances", "orders", "temp", "users", "settings", "categories", "products", "payments", "used_utrs"]


def load_json(name):
    p = os.path.join(DATA, name + ".json")
    try:
        j = json.load(open(p, encoding="utf-8"))
        return j if isinstance(j, dict) else {}
    except Exception:
        return {}


settings = load_json("settings")
balances = load_json("balances")
users = load_json("users")
orders = load_json("orders")
products = load_json("products")
categories = load_json("categories")
payments = load_json("payments")
used_utrs = load_json("used_utrs")
temp = load_json("temp")


def save_json(name, _data=None):
    data = globals()[name]
    p = os.path.join(DATA, name + ".json")
    with _save_lock:
        try:
            tmp = p + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            os.replace(tmp, p)
        except OSError:
            log_err("FAILED write: " + name)


_DEFAULTS = {
    "currency": "₹", "usdt_rate": 95,
    "auto_api_key": "YOUR_API_KEY",
    "auto_api_url": FAMPAY_URL, "auto_api_path": None,
    "usdt_address": "", "usdt_network": "TRC20", "use_usdt": True, "use_manual": True,
    "welcome_text": "", "welcome_media": None,
    "auto_upi": "yourupi@upi", "auto_name": "DigitalStore", "use_auto": True,
    "proof_link": "https://t.me/YourProofChannel",
    "howto_link": "https://t.me/YourHowToVideo",
    "support_user": SUPPORT_USER,
    "payment_methods": {},
    "log_channel": "",
    "admins": [],
    "banned": [],
    "maintenance": False,
    "maintenance_msg": "🛠 <b>Bot Under Maintenance</b>\n\n━━━━━━━━━━━\n\n⚠️ The bot is currently <b>under maintenance</b>.\n\n⏳ Please try again in a few minutes.\n\n🙏 Thank you for your patience!",
    "use_button_colors": True,
    "custom_buttons": [],
    "button_toggles": {"shop": True, "orders": True, "profile": True, "addbal": True, "proof": True, "howto": True, "support": True},
}


def init_data():
    changed = False
    for k, v in _DEFAULTS.items():
        if k not in settings:
            settings[k] = json.loads(json.dumps(v))
            changed = True
    if settings.get("auto_api_url") in ("https://vcgatewaypro.com/fampay.php", ""):
        settings["auto_api_url"] = FAMPAY_URL
        settings["auto_api_path"] = None
        changed = True
    if not settings.get("_brand_removed"):
        if str(settings.get("support_user", "")).lower() == "@sandyxbihari":
            settings["support_user"] = SUPPORT_USER
        settings["_brand_removed"] = True
        changed = True
    if isinstance(settings.get("payment_methods"), list):          # PHP saved an empty list
        settings["payment_methods"] = {}
        changed = True
    for aid in _ADMIN_IDS[1:]:                                      # extra panel admin ids become admins
        if aid not in [str(x) for x in settings["admins"]]:
            settings["admins"].append(aid)
            changed = True
    if changed:
        save_json("settings")
    for n in FILES:
        if not os.path.exists(os.path.join(DATA, n + ".json")):
            save_json(n)


# ============================================================
# STATS MIRROR (lets the panel dashboard count users / orders / money)
# ============================================================
def mirror(sql, params=()):
    try:
        con = sqlite3.connect(DB_FILE, timeout=5)
        con.execute(sql, params)
        con.commit()
        con.close()
    except sqlite3.Error:
        pass


def mirror_init():
    try:
        con = sqlite3.connect(DB_FILE, timeout=5)
        con.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT, joined TEXT)")
        con.execute("CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, user_id INTEGER, price REAL, status TEXT, created_at TEXT)")
        con.execute("CREATE TABLE IF NOT EXISTS transactions (id TEXT PRIMARY KEY, user_id INTEGER, amount REAL, status TEXT, created_at TEXT)")
        con.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
        for uid, u in users.items():
            con.execute("INSERT OR IGNORE INTO users (id, name, joined) VALUES (?,?,?)", (int(uid), str(u.get("name", "")), str(u.get("join", ""))))
        for oid, o in orders.items():
            con.execute("INSERT OR IGNORE INTO orders VALUES (?,?,?,?,?)",
                        (oid, int(o.get("user", 0) or 0), float(o.get("price", 0) or 0), "completed", _iso_from_date(o.get("date"))))
        for pid, p in payments.items():
            con.execute("INSERT OR REPLACE INTO transactions VALUES (?,?,?,?,?)",
                        (pid, int(p.get("user", 0) or 0), float(p.get("amount", 0) or 0), str(p.get("status", "")), _iso_from_date(p.get("date"))))
        con.commit()
        con.close()
    except (sqlite3.Error, ValueError):
        pass


def _iso_from_date(s):
    try:
        d = datetime.strptime(str(s), "%d %b %Y %H:%M").replace(tzinfo=IST)
        return d.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def utc_now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


# ============================================================
# HELPERS: AUTH / BAN / MAINTENANCE
# ============================================================
def is_owner(u):
    return str(u) == str(ADMIN_ID)


def is_admin(u):
    if str(u) == str(ADMIN_ID):
        return True
    return str(u) in [str(x) for x in settings.get("admins", [])]


def is_banned(u):
    return str(u) in [str(x) for x in settings.get("banned", [])]


def is_maint():
    return bool(settings.get("maintenance"))


def btn_on(key):
    return bool(settings.get("button_toggles", {}).get(key))


# ============================================================
# STATE HELPERS
# ============================================================
def set_state(uid, s, extra=None):
    d = {"waiting": s}
    d.update(extra or {})
    temp[str(uid)] = d
    save_json("temp")


def clear_state(uid):
    temp[str(uid)] = {"waiting": ""}
    save_json("temp")


def get_state(uid):
    return temp.get(str(uid), {}).get("waiting", "") or ""


def get_extra(uid, k):
    return temp.get(str(uid), {}).get(k)


def advance(uid, s, **upd):
    """Move to a new state but keep every extra collected so far."""
    d = dict(temp.get(str(uid), {}))
    d.update(upd)
    d["waiting"] = s
    temp[str(uid)] = d
    save_json("temp")


def norm_link(s):
    s = str(s or "").strip()
    if s.startswith("@") and len(s) > 1:
        return "https://t.me/" + s[1:]
    if s.lower().startswith(("t.me/", "telegram.me/")):
        return "https://" + s
    return s


_media_msgs = {}


def _mid_of(res):
    try:
        r = json.loads(res).get("result")
        if isinstance(r, dict):
            return r.get("message_id")
    except (ValueError, TypeError, AttributeError):
        pass
    return None


def send_media_group(c, items):
    media = [{"type": m["type"], "media": m["id"]} for m in items[:10]]
    res = tg("sendMediaGroup", {"chat_id": c, "media": json.dumps(media)})
    ids = []
    try:
        for m in json.loads(res).get("result", []):
            ids.append(m["message_id"])
    except (ValueError, TypeError, AttributeError, KeyError):
        pass
    return ids


def clear_media_msgs(c, uid):
    for m in _media_msgs.pop(str(uid), []):
        del_msg(c, m)


# ============================================================
# HTTP / TELEGRAM API
# ============================================================
SESSION = requests.Session()


def _fix(params):
    out = {}
    for k, v in params.items():
        if v is None:
            continue
        out[k] = 1 if v is True else (0 if v is False else v)
    return out


def http_post(url, data, timeout=20):
    try:
        return SESSION.post(url, data=_fix(data) if isinstance(data, dict) else data, timeout=(8, timeout)).text
    except requests.RequestException:
        return None


def http_get(url, timeout=25):
    try:
        return requests.get(url, timeout=(8, timeout), allow_redirects=True).text
    except requests.RequestException:
        return None


def ok(res):
    if not res:
        return False
    try:
        j = json.loads(res)
        if isinstance(j, dict):
            return j.get("ok") is True or "not modified" in str(j.get("description", "")).lower()
    except ValueError:
        pass
    return '"ok":true' in res.lower() or "not modified" in res.lower()


def tg(method, params):
    res = http_post(API + "/" + method, params, 20)
    if res is None:
        log_err("TG " + method + " FAILED")
        return None
    if ok(res):
        return res
    try:
        j = json.loads(res)
    except ValueError:
        j = {}
    if not isinstance(j, dict):
        j = {}
    desc = j.get("description") or res[:200]
    log_err("TG " + method + ": " + str(desc))
    if params.get("reply_markup") and "style" in str(desc).lower():
        try:
            rm = json.loads(params["reply_markup"])
        except ValueError:
            rm = {}
        had = False
        for row in rm.get("inline_keyboard", []):
            for b in row:
                if "style" in b:
                    del b["style"]
                    had = True
        if had:
            params = dict(params, reply_markup=json.dumps(rm))
            if settings.get("use_button_colors"):
                settings["use_button_colors"] = False
                save_json("settings")
            return tg(method, params)
    return res


def _cut(t):
    return t[:3997] + "..." if len(t) > 4000 else t


def send_msg(c, t, kb=None):
    p = {"chat_id": c, "text": _cut(t), "parse_mode": "HTML", "disable_web_page_preview": True}
    if kb:
        p["reply_markup"] = kb
    return tg("sendMessage", p)


def smart_reply(c, mid, t, kb=None):
    if mid <= 0:
        return send_msg(c, t, kb)
    t = _cut(t)
    p = {"chat_id": c, "message_id": mid, "text": t, "parse_mode": "HTML", "disable_web_page_preview": True}
    if kb:
        p["reply_markup"] = kb
    r = tg("editMessageText", p)
    if ok(r):
        return r
    p2 = {"chat_id": c, "message_id": mid, "caption": t, "parse_mode": "HTML"}
    if kb:
        p2["reply_markup"] = kb
    r2 = tg("editMessageCaption", p2)
    if ok(r2):
        return r2
    tg("deleteMessage", {"chat_id": c, "message_id": mid})
    return send_msg(c, t, kb)


def _send_media(method, field, c, f, cap, kb=None):
    d = {"chat_id": c, field: f, "caption": cap, "parse_mode": "HTML"}
    if kb:
        d["reply_markup"] = kb
    return tg(method, d)


def send_photo(c, p, cap, kb=None):
    return _send_media("sendPhoto", "photo", c, p, cap, kb)


def send_video(c, v, cap, kb=None):
    return _send_media("sendVideo", "video", c, v, cap, kb)


def send_doc(c, d, cap, kb=None):
    return _send_media("sendDocument", "document", c, d, cap, kb)


def send_voice(c, v, cap, kb=None):
    return _send_media("sendVoice", "voice", c, v, cap, kb)


def answer_cb_fast(cid):
    return http_post(API + "/answerCallbackQuery", {"callback_query_id": cid}, 2)


def del_msg(c, mid):
    if mid > 0:
        return tg("deleteMessage", {"chat_id": c, "message_id": mid})
    return None


def send_qr_photo(c, upi, cap, kb):
    enc = quote_plus(upi)
    for u in ("https://quickchart.io/qr?text=%s&size=500&margin=2" % enc,
              "https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=%s" % enc):
        if ok(send_photo(c, u, cap, kb)):
            return True
    return False


# ============================================================
# BUTTON BUILDER
# ============================================================
def is_url(s):
    return isinstance(s, str) and s.startswith(("http://", "https://", "tg://"))


def _one(b, use_color):
    bu = {"text": b[0]}
    if len(b) > 1 and b[1] is not None:
        if is_url(b[1]):
            bu["url"] = b[1]
        else:
            bu["callback_data"] = b[1]
    if use_color and len(b) > 2 and b[2]:
        bu["style"] = b[2]
    return bu


def btn(rows):
    use_color = bool(settings.get("use_button_colors"))
    k = []
    for r in rows:
        if not isinstance(r, (list, tuple)) or not r:
            continue
        if isinstance(r[0], (list, tuple)):
            k.append([_one(b, use_color) for b in r if isinstance(b, (list, tuple))])
        else:
            k.append([_one(r, use_color)])
    return json.dumps({"inline_keyboard": k})


# ============================================================
# THEME (panel feature): welcome text + main-menu button labels
# ============================================================
WELCOME_DEFAULT = ("✨ <b>WELCOME BACK,</b> <b>{name}</b> ✨\n━━━━━━━━━━━\n\n🏪 <b>{store_upper}</b>\n<i>Your Trusted Digital Marketplace</i>\n\n"
                   "━━━━━━━━━━━\n⭐ <b>WHY CHOOSE US</b>\n\n🛍 Premium Digital Products\n⚡ Lightning-Fast Delivery\n🛡 100% Secure Payments\n"
                   "💎 Best Prices Guaranteed\n💬 24/7 Real Support\n\n━━━━━━━━━━━\n💰 <b>Your Balance:</b> {currency}{balance}\n━━━━━━━━━━━")
MENU_DEFAULT = {"shop": ("🛒 Shop Now", "success"), "orders": ("📦 My Orders", "primary"), "profile": ("👤 Profile", "primary"),
                "addbal": ("💰 Add Fund", "success"), "proof": ("📄 Payment Proof", "primary"),
                "howto": ("📖 How To Use", "primary"), "support": ("💬 Support", "primary")}


def mb(key):
    d_text, d_style = MENU_DEFAULT[key]
    t = (THEME.get("buttons") or {}).get(key) or {}
    text = t.get("text") if isinstance(t.get("text"), str) and t.get("text") else d_text
    style = t.get("style") if isinstance(t.get("style"), str) else d_style
    return [text, key, style]


# ============================================================
# USER UI
# ============================================================
def render_welcome(uid, name):
    cur = settings["currency"]
    bal = balances.get(str(uid), 0)
    custom = settings.get("welcome_text")
    if isinstance(custom, str) and custom.strip():
        tpl = custom
    elif isinstance(THEME.get("welcome"), str) and THEME.get("welcome"):
        tpl = THEME.get("welcome")
    else:
        tpl = WELCOME_DEFAULT
    return (tpl.replace("{name}", esc(name)).replace("{store_upper}", esc(STORE_NAME.upper())).replace("{store}", esc(STORE_NAME))
               .replace("{currency}", str(cur)).replace("{balance}", str(num(bal))))


def show_main_menu(c, mid, uid, name):
    msg = render_welcome(uid, name)
    rows = []
    if btn_on("shop"):
        rows.append([mb("shop")])
    row2 = []
    if btn_on("orders"):
        row2.append(mb("orders"))
    if btn_on("profile"):
        row2.append(mb("profile"))
    if row2:
        rows.append(row2)
    row3 = []
    if btn_on("addbal"):
        row3.append(mb("addbal"))
    if btn_on("proof"):
        row3.append(mb("proof"))
    if row3:
        rows.append(row3)
    row4 = []
    if btn_on("howto"):
        row4.append(mb("howto"))
    if btn_on("support"):
        row4.append(mb("support"))
    if row4:
        rows.append(row4)
    for cb in settings.get("custom_buttons", []):
        if cb.get("enabled"):
            rows.append([[cb["label"], cb["url"], "primary"]])
    kb = btn(rows)
    wm = settings.get("welcome_media")
    if isinstance(wm, dict) and wm.get("id"):
        sender = send_video if wm.get("type") == "video" else send_photo
        if mid > 0:
            del_msg(c, mid)
        if len(msg) <= 1024:
            r = sender(c, wm["id"], msg, kb)
            if ok(r):
                return r
            return send_msg(c, msg, kb)
        sender(c, wm["id"], "")
        return send_msg(c, msg, kb)
    return smart_reply(c, mid, msg, kb)


def show_categories(c, mid):
    if len(categories) == 0:
        smart_reply(c, mid, "🛒 <b>Shop</b>\n━━━━━━━━━━━\n\n❌ No categories available.", btn([[["⬅️ Back", "back", "danger"]]]))
        return
    msg = "🛒 <b>STORE — SHOP</b>\n━━━━━━━━━━━\n\n📱 Select a category to browse:"
    kb = [[[cat["name"], "cat_" + i, "primary"]] for i, cat in categories.items()]
    kb.append([["⬅️ Back", "back", "danger"]])
    smart_reply(c, mid, msg, btn(kb))


def show_products(c, mid, cid):
    cur = settings["currency"]
    cn = categories.get(cid, {}).get("name", "Category")
    lst = {i: p for i, p in products.items() if str(p.get("cat", "")) == cid}
    if len(lst) == 0:
        smart_reply(c, mid, "🛒 <b>%s</b>\n━━━━━━━━━━━\n\n❌ No products available." % cn, btn([[["⬅️ Back", "backshop", "danger"]]]))
        return
    msg = "🛒 <b>%s</b>\n━━━━━━━━━━━\n\n📦 Select a product to view details:" % cn
    kb = [[["%s • %s%s" % (p["name"], cur, p["price"]), "buy_" + i, "primary"]] for i, p in lst.items()]
    kb.append([["⬅️ Back", "backshop", "danger"]])
    smart_reply(c, mid, msg, btn(kb))


def show_product_detail(c, mid, uid, pid):
    if pid not in products:
        smart_reply(c, mid, "❌ Not found", btn([[["⬅️ Back", "backshop", "danger"]]]))
        return
    p = products[pid]
    cur = settings["currency"]
    bal = balances.get(str(uid), 0)
    stock = p.get("stock", -1)
    st = "♾ Unlimited" if stock == -1 else ("✅ %s left" % stock if stock > 0 else "❌ Out of Stock")
    msg = ("🛍 <b>%s</b>\n━━━━━━━━━━━\n\n📝 <b>Description:</b>\n%s\n\n━━━━━━━━━━━\n💵 <b>Price:</b> %s%s\n📊 <b>Stock:</b> %s\n"
           % (p["name"], p["description"], cur, p["price"], st))
    if p.get("vip_link"):
        msg += "👑 <b>VIP Channel:</b> Included\n"
    msg += "👛 <b>Your Balance:</b> %s%s\n━━━━━━━━━━━\n⚡ <i>Instant delivery after purchase</i>" % (cur, num(bal))
    kb = []
    if stock != 0:
        if bal >= p["price"]:
            kb.append([["✅ Buy Now", "confirmbuy_" + pid, "success"]])
        else:
            kb.append([["💰 Add Fund", "addbal", "success"]])
    kb.append([["⬅️ Back", "backshop", "danger"]])
    kb = btn(kb)
    media = [m for m in (p.get("media") or []) if isinstance(m, dict) and m.get("id")]
    if not media:
        smart_reply(c, mid, msg, kb)
        return
    clear_media_msgs(c, uid)
    if mid > 0:
        del_msg(c, mid)
    sender = lambda m: send_video if m.get("type") == "video" else send_photo
    if len(media) == 1 and len(msg) <= 1024:
        r = sender(media[0])(c, media[0]["id"], msg, kb)
        if ok(r):
            return
        send_msg(c, msg, kb)
        return
    ids = []
    if len(media) == 1:
        i = _mid_of(sender(media[0])(c, media[0]["id"], ""))
        if i:
            ids.append(i)
    else:
        ids = send_media_group(c, media)
    _media_msgs[str(uid)] = ids
    send_msg(c, msg, kb)


def do_purchase(c, mid, uid, pid):
    if pid not in products:
        smart_reply(c, mid, "❌ Not found", btn([[["⬅️ Back", "backshop", "danger"]]]))
        return
    cur = settings["currency"]
    with BAL:
        p = products[pid]
        bal = balances.get(str(uid), 0)
        if bal < p["price"]:
            smart_reply(c, mid, "❌ <b>Insufficient Balance</b>\n━━━━━━━━━━━\nPrice: %s%s\nBalance: %s%s" % (cur, p["price"], cur, num(bal)),
                        btn([[["💰 Add Fund", "addbal", "success"], ["⬅️ Back", "backshop", "danger"]]]))
            return
        if p.get("stock", -1) == 0:
            smart_reply(c, mid, "❌ <b>Out of Stock!</b>", btn([[["⬅️ Back", "backshop", "danger"]]]))
            return
        balances[str(uid)] = bal - p["price"]
        save_json("balances")
        if p.get("stock", -1) > 0:
            products[pid]["stock"] = p["stock"] - 1
            save_json("products")
        oid = "ORD" + str(int(time.time()))[-8:] + str(random.randint(100, 999))
        nowt = d_myhm()
        orders[oid] = {"user": uid, "product_id": pid, "product_name": p["name"], "price": p["price"], "status": "Delivered", "date": nowt}
        save_json("orders")
        newbal = balances[str(uid)]
        stock_now = products[pid].get("stock", -1)
    mirror("INSERT OR REPLACE INTO orders VALUES (?,?,?,?,?)", (oid, int(uid), float(p["price"]), "completed", utc_now()))
    u = users.get(str(uid), {})
    uname = esc(u.get("name", "User"))
    un = "@" + esc(u["username"]) if u.get("username") else "N/A"
    send_msg(ADMIN_ID, "🔔 <b>NEW PURCHASE</b>\n━━━━━━━━━━━\n👤 <b>Buyer:</b> %s\n🔗 <b>Username:</b> %s\n🆔 <b>User ID:</b> <code>%s</code>\n━━━━━━━━━━━\n"
             "📦 <b>Product:</b> %s\n🔖 <b>Product ID:</b> <code>%s</code>\n💵 <b>Price:</b> %s%s\n📊 <b>Stock Left:</b> %s\n━━━━━━━━━━━\n"
             "🧾 <b>Order ID:</b> <code>%s</code>\n📅 <b>Date:</b> %s\n⏰ <b>Time:</b> %s IST\n💰 <b>Balance:</b> %s%s"
             % (uname, un, uid, p["name"], pid, cur, p["price"], "♾" if stock_now == -1 else stock_now, oid, d_my(), now().strftime("%H:%M"), cur, num(newbal)))
    if settings.get("log_channel"):
        send_msg(settings["log_channel"], "💎 <b>NEW ORDER RECEIVED</b> 💎\n━━━━━━━━━━━\n\n📦 <b>Product:</b> %s\n💵 <b>Price:</b> %s%s\n👤 <b>Buyer ID:</b> <code>%s</code>\n"
                 "📅 <b>Date:</b> %s\n⏰ <b>Time:</b> %s IST\n\n━━━━━━━━━━━\n✅ Auto Delivered" % (p["name"], cur, p["price"], uid, d_my(), now().strftime("%H:%M")))
    head = ("✅ <b>ORDER DELIVERED SUCCESSFULLY!</b>\n━━━━━━━━━━━\n\n🎉 Thank you for your purchase!\n\n📦 <b>Product:</b> %s\n💵 <b>Price:</b> %s%s\n"
            "🧾 <b>Order ID:</b> <code>%s</code>\n📅 <b>Date:</b> %s IST\n\n━━━━━━━━━━━\n" % (p["name"], cur, p["price"], oid, nowt))
    vip = norm_link(p.get("vip_link") or "")
    krows = []
    if is_url(vip):
        krows.append([["👑 Join VIP Channel", vip, "success"]])
    krows.append([["📦 My Orders", "orders", "primary"], ["⬅️ Menu", "back", "danger"]])
    kb = btn(krows)
    typ, content = p.get("delivery_type"), p.get("delivery_content")
    if typ == "text":
        smart_reply(c, mid, head + "🎁 <b>Your Delivery:</b>\n\n" + str(content), kb)
    else:
        smart_reply(c, mid, head + "🎁 <b>Your Delivery:</b> (see below)", btn([[["⬅️ Menu", "back", "danger"]]]))
        cap = "🎁 <b>Order: %s</b>" % p["name"]
        if typ == "photo":
            send_photo(c, content, cap, kb)
        elif typ == "video":
            send_video(c, content, cap, kb)
        elif typ == "document":
            send_doc(c, content, cap, kb)
        elif typ == "voice":
            send_voice(c, content, cap, kb)


def show_orders(c, mid, uid):
    cur = settings["currency"]
    mine = {i: o for i, o in orders.items() if str(o.get("user", 0)) == str(uid)}
    if len(mine) == 0:
        smart_reply(c, mid, "📦 <b>My Orders</b>\n━━━━━━━━━━━\n\n❌ You have no orders yet.", btn([[["🛒 Shop", "shop", "success"], ["⬅️ Menu", "back", "danger"]]]))
        return
    msg = "📦 <b>MY ORDERS (%d)</b>\n━━━━━━━━━━━\n\n" % len(mine)
    i = 1
    for oid, o in reversed(list(mine.items())):
        msg += "%d. <b>Product ID:</b> <code>%s</code>\n 💵 Price: %s%s\n 📅 Date: %s IST\n 🆔 Order: <code>%s</code>\n ✅ Status: %s\n\n" % (
            i, o.get("product_id", "N/A"), cur, o["price"], o["date"], oid, o["status"])
        i += 1
        if i > 10:
            msg += "<i>...and more</i>"
            break
    smart_reply(c, mid, msg, btn([[["⬅️ Menu", "back", "danger"]]]))


def show_profile(c, mid, uid):
    cur = settings["currency"]
    u = users.get(str(uid), {})
    n, j = esc(u.get("name", "User")), u.get("join", d_my())
    b = balances.get(str(uid), 0)
    t = sum(1 for o in orders.values() if str(o.get("user", 0)) == str(uid))
    msg = ("👤 <b>MY PROFILE</b>\n━━━━━━━━━━━\n\n👹 <b>Name:</b> %s\n🆔 <b>User ID:</b> <code>%s</code>\n📅 <b>Member Since:</b> %s\n"
           "💰 <b>Balance:</b> %s%s\n🛒 <b>Total Orders:</b> %s\n━━━━━━━━━━━" % (n, uid, j, cur, num(b), t))
    smart_reply(c, mid, msg, btn([[["🛒 Shop", "shop", "success"], ["📦 Orders", "orders", "primary"]], [["⬅️ Menu", "back", "danger"]]]))


def show_proof(c, mid):
    smart_reply(c, mid, "📄 <b>Payment Proofs</b>\n━━━━━━━━━━━\n\n🔗 <a href='%s'>Click Here</a>" % settings["proof_link"], btn([[["⬅️ Menu", "back", "danger"]]]))


def show_howto(c, mid):
    smart_reply(c, mid, "📖 <b>How To Use</b>\n━━━━━━━━━━━\n\n1️⃣ Add Fund\n2️⃣ Choose Product\n3️⃣ Instant Delivery\n\n🔗 <a href='%s'>Watch Tutorial</a>" % settings["howto_link"],
                btn([[["⬅️ Menu", "back", "danger"]]]))


def show_support(c, mid):
    u = settings["support_user"]
    smart_reply(c, mid, "💬 <b>Support</b>\n━━━━━━━━━━━\n\n🔗 <a href='https://t.me/%s'>%s</a>\n\n24/7 Available" % (u.lstrip("@"), u), btn([[["⬅️ Menu", "back", "danger"]]]))


# ============================================================
# ADD FUND
# ============================================================
def show_add_fund(c, mid, uid):
    methods = settings["payment_methods"]
    msg = "💰 <b>Add Fund</b>\n━━━━━━━━━━━\n\nChoose payment method:"
    manual_on = bool(settings.get("use_manual", True))
    kb = [[["💳 " + pm["name"], "pm_" + i, "primary"]] for i, pm in methods.items()] if manual_on else []
    if settings["use_auto"]:
        kb.append([["⚡ Automatic UPI", "auto_pay", "success"]])
    if usdt_ready():
        kb.append([["💲 USDT (%s)" % (settings.get("usdt_network") or "TRC20"), "usdt_pay", "primary"]])
    kb.append([["⬅️ Menu", "back", "danger"]])
    if (len(methods) == 0 or not manual_on) and not settings["use_auto"] and not usdt_ready():
        msg = "💰 <b>Add Fund</b>\n━━━━━━━━━━━\n\n❌ No payment methods available."
    smart_reply(c, mid, msg, btn(kb))


def select_manual_pm(c, mid, pmid):
    methods = settings["payment_methods"]
    if pmid not in methods:
        smart_reply(c, mid, "❌ Not found", btn([[["⬅️ Back", "addbal", "danger"]]]))
        return
    pm = methods[pmid]
    msg = "💳 <b>%s</b>\n━━━━━━━━━━━\n\n" % pm["name"] + ("📝 %s\n\n" % pm["description"] if pm.get("description") else "") + "💳 <b>UPI ID:</b>\n<code>%s</code>" % pm.get("upi_id", "")
    kb = btn([[["✅ Continue", "manual_amt_" + pmid, "success"]], [["⬅️ Back", "addbal", "danger"]]])
    if pm.get("qr_url"):
        tg("deleteMessage", {"chat_id": c, "message_id": mid})
        r = send_photo(c, pm["qr_url"], msg, kb)
        if not ok(r):
            send_msg(c, msg, kb)
    else:
        smart_reply(c, mid, msg, kb)


def start_manual_amount(c, mid, uid, pmid):
    if pmid not in settings["payment_methods"]:
        smart_reply(c, mid, "❌ Not found", btn([[["⬅️ Back", "addbal", "danger"]]]))
        return
    set_state(uid, "man_amount", {"pm_id": pmid})
    cur = settings["currency"]
    smart_reply(c, mid, "💰 <b>Enter Amount</b>\n━━━━━━━━━━━\n\nMin: %s1 • Max: %s100000" % (cur, cur), btn([[["⬅️ Cancel", "addbal", "danger"]]]))


def process_manual_amount(c, uid, pmid, amount):
    cur = settings["currency"]
    if amount < 1 or amount > 100000:
        send_msg(c, "❌ Invalid amount (%s1-%s100000)" % (cur, cur), btn([[["⬅️ Back", "addbal", "danger"]]]))
        return
    pm = settings["payment_methods"].get(pmid)
    if not pm:
        send_msg(c, "❌ Method not found", btn([[["⬅️ Back", "addbal", "danger"]]]))
        return
    set_state(uid, "man_ss", {"pm_id": pmid, "amount": amount})
    send_msg(c, "💰 <b>Amount: %s%s</b>\n━━━━━━━━━━━\n\n💳 Pay to:\n<code>%s</code>\n\n📸 Upload payment screenshot.\n\n⚠️ Photo only. /cancel to abort."
             % (cur, amount, pm.get("upi_id", "")), btn([[["⬅️ Cancel", "addbal", "danger"]]]))


def submit_manual_payment(c, uid, photo_id):
    pmid, amount = get_extra(uid, "pm_id"), get_extra(uid, "amount")
    if not pmid or not amount:
        send_msg(c, "❌ Session expired", btn([[["⬅️ Back", "addbal", "danger"]]]))
        return
    set_state(uid, "man_utr", {"pm_id": pmid, "amount": amount, "photo": photo_id})
    send_msg(c, "✅ <b>Screenshot received!</b>\n━━━━━━━━━━━\n\n🔢 <b>Enter UTR / Transaction ID</b>\n\nExample: <code>1234567890123</code>", btn([[["❌ Cancel", "addbal", "danger"]]]))


# ============================================================
# USDT PAYMENT  (QR is generated automatically from the wallet address)
# ============================================================
def usdt_ready():
    return bool(settings.get("use_usdt")) and bool(str(settings.get("usdt_address", "")).strip())


def start_usdt_payment(c, mid, uid):
    cur = settings["currency"]
    if not usdt_ready():
        smart_reply(c, mid, "❌ USDT payment not available", btn([[["⬅️ Back", "addbal", "danger"]]]))
        return
    net = settings.get("usdt_network") or "TRC20"
    set_state(uid, "usdt_amount")
    smart_reply(c, mid, "💲 <b>USDT Payment (%s)</b>\n━━━━━━━━━━━\n\n💵 Enter amount in <b>%s</b> to add\n\n📈 Rate: 1 USDT = %s%s\nMin: %s1 • Max: %s100000"
                % (esc(net), cur, cur, num(settings["usdt_rate"]), cur, cur), btn([[["⬅️ Back", "addbal", "danger"]]]))


def process_usdt_amount(c, uid, amount):
    cur = settings["currency"]
    if amount < 1 or amount > 100000:
        send_msg(c, "❌ Invalid amount (%s1-%s100000)" % (cur, cur))
        return
    rate = php_float(settings.get("usdt_rate", 0))
    if rate <= 0 or not usdt_ready():
        send_msg(c, "❌ USDT payment not available", btn([[["⬅️ Back", "addbal", "danger"]]]))
        return
    usdt = round(amount / rate, 2)
    if usdt < 0.01:
        send_msg(c, "❌ Amount too small for USDT.")
        return
    addr = str(settings["usdt_address"]).strip()
    net = settings.get("usdt_network") or "TRC20"
    msg = ("💲 <b>USDT Payment</b>\n━━━━━━━━━━━\n\n💵 <b>Credit:</b> %s%s\n💰 <b>Send exactly:</b> <code>%.2f</code> USDT\n🌐 <b>Network:</b> %s\n\n"
           "📬 <b>Wallet Address:</b>\n<code>%s</code>\n\n📱 <b>Steps:</b>\n1️⃣ Scan QR / copy address\n2️⃣ Send USDT on <b>%s</b> network only\n"
           "3️⃣ Upload payment screenshot, then TXID\n\n⚠️ Wrong network = funds lost."
           % (cur, amount, usdt, esc(net), esc(addr), esc(net)))
    kb = btn([[["⬅️ Cancel", "addbal", "danger"]]])
    if not send_qr_photo(c, addr, msg, kb):
        send_msg(c, msg + "\n\n⚠️ QR couldn't load. Use the address above.", kb)
    set_state(uid, "usdt_ss", {"amount": amount, "usdt": usdt})


def submit_usdt_proof(c, uid, ph):
    if not get_extra(uid, "amount"):
        send_msg(c, "❌ Session expired", btn([[["⬅️ Back", "addbal", "danger"]]]))
        return
    advance(uid, "usdt_txid", photo=ph)
    send_msg(c, "✅ <b>Screenshot received!</b>\n━━━━━━━━━━━\n\n🔗 <b>Send TXID / Transaction Hash</b>", btn([[["❌ Cancel", "addbal", "danger"]]]))


def process_usdt_txid(c, uid, text):
    cur = settings["currency"]
    cancel = btn([[["❌ Cancel", "addbal", "danger"]]])
    txid = re.sub(r"\s", "", text)
    if len(txid) < 10:
        send_msg(c, "❌ <b>Invalid TXID</b>\n\nSend the full transaction hash.", cancel)
        return
    low = txid.lower()
    if any(str(p.get("utr", "")).lower() == low and p.get("status") in ("pending", "approved") for p in payments.values()):
        send_msg(c, "❌ <b>TXID already used!</b>", cancel)
        return
    ph, amount, usdt = get_extra(uid, "photo"), get_extra(uid, "amount"), get_extra(uid, "usdt")
    if not ph or not amount:
        send_msg(c, "❌ Session expired", btn([[["⬅️ Back", "addbal", "danger"]]]))
        return
    method = "USDT (%s)" % (settings.get("usdt_network") or "TRC20")
    oid = "USD" + str(int(time.time()))[-8:] + str(random.randint(100, 999))
    payments[oid] = {"user": uid, "amount": amount, "usdt_amount": usdt, "method": method, "method_id": "usdt", "screenshot": ph,
                     "utr": txid, "status": "pending", "type": "usdt", "date": d_myhm()}
    save_json("payments")
    mirror("INSERT OR REPLACE INTO transactions VALUES (?,?,?,?,?)", (oid, int(uid), float(amount), "pending", utc_now()))
    clear_state(uid)
    send_msg(c, "✅ <b>PAYMENT SUBMITTED</b>\n━━━━━━━━━━━\n\n💰 <b>Amount:</b> %s%s\n💲 <b>USDT:</b> %.2f\n🌐 <b>Method:</b> %s\n🔗 <b>TXID:</b> <code>%s</code>\n"
             "🆔 <b>Order ID:</b> <code>%s</code>\n\n━━━━━━━━━━━\n⏳ <i>Verification in progress...</i>\n🙏 Please wait for admin approval."
             % (cur, amount, usdt, esc(method), esc(txid), oid), btn([[["⬅️ Menu", "back", "danger"]]]))
    uname = esc(users.get(str(uid), {}).get("name", "User"))
    admin_msg = ("🔔 <b>NEW USDT PAYMENT</b>\n━━━━━━━━━━━\n\n👤 %s\n🆔 <code>%s</code>\n💰 %s%s\n💲 %.2f USDT\n🌐 %s\n🔗 TXID: <code>%s</code>\n🆔 <code>%s</code>\n📅 %s IST"
                 % (uname, uid, cur, amount, usdt, esc(method), esc(txid), oid, d_myhm()))
    send_photo(ADMIN_ID, ph, admin_msg, btn([[["✅ Approve", "approve_" + oid, "success"], ["❌ Reject", "reject_" + oid, "danger"]]]))


# ============================================================
# AUTO PAYMENT
# ============================================================
def start_auto_payment(c, mid, uid):
    cur = settings["currency"]
    if not settings["use_auto"]:
        smart_reply(c, mid, "❌ Auto payment disabled", btn([[["⬅️ Back", "addbal", "danger"]]]))
        return
    set_state(uid, "auto_amount")
    smart_reply(c, mid, "⚡ <b>Automatic UPI Payment</b>\n━━━━━━━━━━━\n\n💵 Enter Amount\n\nMin: %s1 • Max: %s100000" % (cur, cur), btn([[["⬅️ Back", "addbal", "danger"]]]))


def process_auto_amount(c, uid, amount):
    cur = settings["currency"]
    if amount < 1 or amount > 100000:
        send_msg(c, "❌ Invalid amount (%s1-%s100000)" % (cur, cur))
        return
    upi, name = settings["auto_upi"], settings["auto_name"]
    upi_string = "upi://pay?pa=%s&pn=%s&am=%s&cu=INR" % (upi, name, amount)
    msg = ("⚡ <b>Automatic Payment</b>\n━━━━━━━━━━━\n\n💵 <b>Amount:</b> %s%s\n💳 <b>UPI ID:</b>\n<code>%s</code>\n\n📱 <b>Steps:</b>\n"
           "1️⃣ Scan QR / Pay to UPI\n2️⃣ Enter UTR after payment\n\n⏰ Complete within 10 minutes" % (cur, amount, upi))
    kb = btn([[["✅ I've Paid - Enter UTR", "utr_prompt", "success"]], [["⬅️ Cancel", "addbal", "danger"]]])
    if not send_qr_photo(c, upi_string, msg, kb):
        send_msg(c, msg + "\n\n⚠️ QR couldn't load. Use UPI ID above.", kb)
    set_state(uid, "auto_utr", {"amount": amount})


def clean_utr(s):
    return re.sub(r"[^A-Za-z0-9]", "", str(s).strip()).upper()


def process_auto_utr(c, uid, utr_raw):
    cur = settings["currency"]
    amount = get_extra(uid, "amount")
    if not amount:
        send_msg(c, "❌ Session expired", btn([[["⬅️ Back", "addbal", "danger"]]]))
        return
    utr = clean_utr(utr_raw)
    if len(utr) < 6:
        send_msg(c, "❌ <b>Invalid UTR</b>\n\nMin 6 alphanumeric characters.", btn([[["⬅️ Back", "addbal", "danger"]]]))
        return
    if utr in used_utrs:
        send_msg(c, "❌ <b>UTR already used!</b>\n\nThis UTR was used before.", btn([[["⬅️ Back", "addbal", "danger"]]]))
        return
    send_msg(c, "⏳ <b>Verifying UTR...</b>\n\nPlease wait...")
    res = verify_utr(utr, amount, settings["auto_api_key"], settings["auto_api_url"])
    if res.get("type") == "not_found":
        time.sleep(3)
        res = verify_utr(utr, amount, settings["auto_api_key"], settings["auto_api_url"])

    if res.get("ok"):
        with BAL:
            if utr in used_utrs:                      # another request used it while we were verifying
                send_msg(c, "❌ <b>UTR already used!</b>\n\nThis UTR was used before.", btn([[["⬅️ Back", "addbal", "danger"]]]))
                return
            used_utrs[utr] = {"user": uid, "amount": amount, "time": int(time.time())}
            save_json("used_utrs")
            balances[str(uid)] = balances.get(str(uid), 0) + amount
            save_json("balances")
            oid = "AUT" + str(int(time.time()))[-8:] + str(random.randint(100, 999))
            payments[oid] = {"user": uid, "amount": amount, "utr": utr, "status": "approved", "type": "auto", "date": d_myhm()}
            save_json("payments")
            newbal = balances[str(uid)]
        mirror("INSERT OR REPLACE INTO transactions VALUES (?,?,?,?,?)", (oid, int(uid), float(amount), "approved", utc_now()))
        clear_state(uid)
        send_msg(c, "✅ <b>PAYMENT SUCCESSFUL</b>\n━━━━━━━━━━━\n\n🎉 Great! Your payment has been verified automatically.\n\n💰 <b>Amount Credited:</b> %s%s\n🧾 <b>UTR:</b> <code>%s</code>\n"
                 "💵 <b>New Balance:</b> %s%s\n\n━━━━━━━━━━━\n🛒 Ready to shop? Explore our store now!" % (cur, amount, utr, cur, num(newbal)),
                 btn([[["🛒 Shop Now", "shop", "success"], ["⬅️ Menu", "back", "danger"]]]))
        send_msg(ADMIN_ID, "⚡ <b>Auto Payment Success</b>\n━━━━━━━━━━━\n👤 <code>%s</code>\n💰 %s%s\n🆔 <code>%s</code>" % (uid, cur, amount, utr))
        if settings.get("log_channel"):
            send_msg(settings["log_channel"], "💎 <b>NEW DEPOSIT RECEIVED</b> 💎\n━━━━━━━━━━━\n\n🆔 <b>UTR:</b> <code>%s</code>\n💵 <b>Amount:</b> %s%s\n👤 <b>User ID:</b> <code>%s</code>\n"
                     "📅 <b>Date:</b> %s IST\n\n━━━━━━━━━━━\n✅ Auto Verified" % (utr, cur, amount, uid, d_myhm()))
        return

    if res.get("type") == "api_error":
        oid = "AUT" + str(int(time.time()))[-8:] + str(random.randint(100, 999))
        payments[oid] = {"user": uid, "amount": amount, "utr": utr, "status": "pending", "type": "auto_manual", "date": d_myhm()}
        save_json("payments")
        used_utrs[utr] = {"user": uid, "amount": amount, "time": int(time.time())}
        save_json("used_utrs")
        mirror("INSERT OR REPLACE INTO transactions VALUES (?,?,?,?,?)", (oid, int(uid), float(amount), "pending", utc_now()))
        clear_state(uid)
        send_msg(c, "⚠️ <b>Auto verification unavailable</b>\n━━━━━━━━━━━\n\nYour payment is being <b>verified manually</b>.\n\n💰 %s%s\n🆔 UTR: <code>%s</code>\n🧾 ID: <code>%s</code>\n\n⏳ Wait for admin approval."
                 % (cur, amount, utr, oid), btn([[["⬅️ Menu", "back", "danger"]]]))
        uname = esc(users.get(str(uid), {}).get("name", "User"))
        send_msg(ADMIN_ID, "🔔 <b>MANUAL VERIFY NEEDED</b>\n━━━━━━━━━━━\n⚠️ Auto API failed\n👤 %s\n🆔 <code>%s</code>\n💰 %s%s\n🧾 UTR: <code>%s</code>\n🆔 ID: <code>%s</code>\n📅 %s IST"
                 % (uname, uid, cur, amount, utr, oid, d_myhm()), btn([[["✅ Approve", "approve_" + oid, "success"], ["❌ Reject", "reject_" + oid, "danger"]]]))
        return

    send_msg(c, "❌ <b>Transaction Not Found</b>\n━━━━━━━━━━━\n\n%s\n\n💡 Make sure UTR is correct and payment completed." % (res.get("msg") or "Please verify UTR"),
             btn([[["🔄 Try Again", "utr_prompt", "primary"], ["⬅️ Back", "addbal", "danger"]]]))


def _php_str(v):
    if v is True:
        return "1"
    if v is False or v is None:
        return ""
    if isinstance(v, (list, dict)):
        return "Array"
    return str(v)


_SUCCESS = ["true", "1", "yes", "success", "paid", "completed", "approved", "received", "ok", "200"]
_FAIL = ["false", "0", "no", "failed", "failure", "error", "invalid", "pending", "not found", "unpaid", "rejected", "cancelled", "not received"]
_POS = ["success", "received", "paid", "completed", "approved"]


_API_PATHS = ["/verify", "/api/verify", "/verify_utr", "/api/verify_utr", "/check", "/api/check", "/verify-payment", "/api/verify-payment"]


def _fetch(url, timeout=45):
    try:
        r = requests.get(url, timeout=(10, timeout), allow_redirects=True)
        return r.status_code, r.text
    except requests.RequestException:
        return None, None


def _parse_verify(res):
    if res is None or res == "":
        return {"ok": False, "type": "api_error", "msg": "Verification service not reachable."}
    try:
        j = json.loads(res)
    except ValueError:
        j = None
    if isinstance(j, (dict, list)):
        flat = dict(j) if isinstance(j, dict) else {}
        if isinstance(j, dict):
            for key in ("data", "result", "response", "payment", "transaction"):
                if isinstance(j.get(key), dict):
                    flat.update(j[key])
        for k in ("success", "paid", "completed", "verified", "utr_status", "payment_status", "transaction_status"):
            if flat.get(k) is not None:
                v = flat[k]
                if v is True or (isinstance(v, int) and not isinstance(v, bool) and v == 1):
                    return {"ok": True}
                if isinstance(v, str) and v.strip().lower() in _SUCCESS:
                    return {"ok": True}
        for k in ("status", "state", "result", "code", "response_code"):
            if flat.get(k) is not None:
                if _php_str(flat[k]).strip().lower() in _SUCCESS:
                    return {"ok": True}
        m = ""
        for k in ("message", "msg", "response", "remark", "description"):
            if flat.get(k) is not None:
                m = _php_str(flat[k])
                break
        if m != "":
            ml = m.lower()
            has_pos = any(w in ml for w in _POS)
            has_neg = any(w in ml for w in _FAIL)
            if has_pos and not has_neg:
                return {"ok": True}
        return {"ok": False, "type": "not_found", "msg": m if m not in ("", "0") else "Payment not found"}
    low = res.strip().lower().strip("\"'")
    if low in ("success", "ok", "1", "true", "paid", "completed", "received", "yes"):
        return {"ok": True}
    has_pos = any(w in low for w in _POS)
    has_neg = any(w in low for w in _FAIL)
    if has_pos and not has_neg:
        return {"ok": True}
    return {"ok": False, "type": "not_found", "msg": "Payment not found. Please verify UTR."}


def verify_utr(utr, amount, api_key, api_url):
    """FamPay verification. If the saved URL has no path (just the host) the common
    verify paths are tried and the one that works is remembered."""
    if not api_key or api_key == "YOUR_API_KEY":
        return {"ok": False, "type": "api_error", "msg": "Auto API key not configured."}
    if not api_url:
        return {"ok": False, "type": "api_error", "msg": "Auto API URL not configured."}
    utr = clean_utr(utr)
    amt = "%.2f" % float(amount)
    base = api_url.strip().rstrip("/")
    has_path = "?" in base or bool(re.match(r"^https?://[^/]+/.+", base))
    paths = [""] if has_path else list(_API_PATHS)
    known = settings.get("auto_api_path")
    if not has_path and isinstance(known, str) and known in paths:
        paths.remove(known)
        paths.insert(0, known)
    qs = "api_key=%s&key=%s&utr=%s&txn_id=%s&amount=%s" % tuple(quote_plus(x) for x in (api_key, api_key, utr, utr, amt))
    for p in paths:
        url = base + p
        full = url + ("&" if "?" in url else "?") + qs
        log_err("verifyUTR REQ: " + full.replace(quote_plus(api_key), "***"))        # the key is not written to the log
        code, res = _fetch(full)
        log_err("verifyUTR RES [%s]: %s" % (code, str(res)[:1000]))
        if code is None:
            return {"ok": False, "type": "api_error", "msg": "Verification service not reachable."}
        if code in (401, 403):
            return {"ok": False, "type": "api_error", "msg": "API key rejected."}
        if code >= 500:
            return {"ok": False, "type": "api_error", "msg": "Verification service error."}
        if code in (404, 405):
            try:
                j = json.loads(res)
            except ValueError:
                j = None
            if not (isinstance(j, dict) and j and set(j.keys()) != {"detail"}):
                continue                                                         # wrong path, try the next one
        out = _parse_verify(res)
        if p and not has_path and settings.get("auto_api_path") != p:
            settings["auto_api_path"] = p
            save_json("settings")
        return out
    return {"ok": False, "type": "api_error", "msg": "Verification endpoint not found. Set the full API URL in Settings."}


# ============================================================
# ADMIN PANEL
# ============================================================
def _extra_admins():
    return [x for x in settings.get("admins", []) if str(x) != str(ADMIN_ID)]


def show_admin(c, mid, uid):
    cur = settings["currency"]
    pending = sum(1 for p in payments.values() if p.get("status") == "pending")
    banned = len(settings.get("banned", []))
    msg = ("👑 <b>ADMIN CONTROL PANEL</b>\n━━━━━━━━━━━\n\n📊 <b>OVERVIEW</b>\n👥 Users: %d (🚫 Banned: %d)\n📁 Categories: %d\n📦 Products: %d\n⏳ Pending: %d\n"
           "👑 Admins: %d (incl. owner)\n\n━━━━━━━━━━━\n⚙️ <b>CONFIG</b>\n🌍 Currency: %s\n💵 USDT Rate: %s%s\n⚡ Auto: %s\n💳 Manual: %s\n🔧 Maint: %s\n📢 Log: <code>%s</code>"
           % (len(users), banned, len(categories), len(products), pending, len(_extra_admins()) + 1, cur, cur, num(settings["usdt_rate"]),
              "✅ ON" if settings["use_auto"] else "❌ OFF", "✅ ON" if settings.get("use_manual", True) else "❌ OFF", "🔴 ON" if settings["maintenance"] else "🟢 OFF", settings.get("log_channel") or "❌ not set"))
    rows = [
        [["📁 Add Category", "addcat", "primary"], ["🗑 Del Category", "delcat", "danger"]],
        [["📦 Add Product", "addprod", "primary"], ["🗑 Del Product", "delprod", "danger"]],
        [["✏️ Edit Product", "editprod", "primary"], ["👋 Welcome Setup", "welcome_menu", "primary"]],
        [["💳 Payment Methods", "pm_menu", "primary"], ["💰 Approvals (%d)" % pending, "approvals", "success"]],
        [[("✅ Manual Pay: ON" if settings.get("use_manual", True) else "❌ Manual Pay: OFF"), "togglemanual", "success" if settings.get("use_manual", True) else "danger"]],
        [["👥 User List", "userlist", "primary"], ["📊 Statistics", "stats", "primary"]],
        [["🚫 Ban System", "banmenu", "danger"], ["📨 Send PM", "pmuser", "primary"]],
        [["📢 Broadcast", "broadcast", "primary"], ["🔧 Maintenance", "maint", "primary"]],
        [["⚙️ Settings", "settings", "primary"], ["🎨 Button Mgmt", "bmgmt", "primary"]],
        [["💰 Add User Balance", "userbal", "success"], ["📢 Log Channel", "setlogchannel", "primary"]],
    ]
    if is_owner(uid):
        rows.append([["👑 Admin Management", "adminmgmt", "success"]])
    rows.append([["⬅️ Back to Menu", "back", "danger"]])
    smart_reply(c, mid, msg, btn(rows))


def show_cat_delete_list(c, mid):
    if len(categories) == 0:
        smart_reply(c, mid, "❌ No categories", btn([[["⬅️ Back", "backadmin", "danger"]]]))
        return
    kb = [[["❌ " + cat["name"], "delcat_" + i, "danger"]] for i, cat in categories.items()]
    kb.append([["⬅️ Back", "backadmin", "danger"]])
    smart_reply(c, mid, "🗑 <b>Delete category:</b>", btn(kb))


def show_select_cat_for_product(c, mid):
    if len(categories) == 0:
        smart_reply(c, mid, "❌ No categories. Add one first.", btn([[["📁 Add Category", "addcat", "primary"], ["⬅️ Back", "backadmin", "danger"]]]))
        return
    kb = [[[cat["name"], "addprod_cat_" + i, "primary"]] for i, cat in categories.items()]
    kb.append([["⬅️ Back", "backadmin", "danger"]])
    smart_reply(c, mid, "📁 <b>Select Category</b>", btn(kb))


def show_product_delete_list(c, mid):
    if len(products) == 0:
        smart_reply(c, mid, "❌ No products", btn([[["⬅️ Back", "backadmin", "danger"]]]))
        return
    cur = settings["currency"]
    kb = [[["❌ %s • %s%s" % (p["name"], cur, p["price"]), "delprod_" + i, "danger"]] for i, p in products.items()]
    kb.append([["⬅️ Back", "backadmin", "danger"]])
    smart_reply(c, mid, "🗑 <b>Select product to delete:</b>", btn(kb))


def show_product_edit_list(c, mid):
    if len(products) == 0:
        smart_reply(c, mid, "❌ No products", btn([[["⬅️ Back", "backadmin", "danger"]]]))
        return
    cur = settings["currency"]
    kb = [[["✏️ %s • %s%s" % (p["name"], cur, p["price"]), "editprod_" + i, "primary"]] for i, p in products.items()]
    kb.append([["⬅️ Back", "backadmin", "danger"]])
    smart_reply(c, mid, "✏️ <b>Select product to edit:</b>", btn(kb))


def show_product_edit(c, mid, pid, note=""):
    p = products.get(pid)
    if not p:
        smart_reply(c, mid, "❌ Not found", btn([[["⬅️ Back", "editprod", "danger"]]]))
        return
    cur = settings["currency"]
    media = p.get("media") or []
    vip = ("<code>%s</code>" % esc(p["vip_link"])) if p.get("vip_link") else "❌ not set"
    msg = ((note + "\n\n") if note else "") + ("✏️ <b>EDIT PRODUCT</b>\n━━━━━━━━━━━\n\n📦 <b>%s</b>\n💵 Price: %s%s\n👑 <b>VIP Link:</b> %s\n🖼 <b>Media:</b> %d file(s)"
                                               % (esc(p["name"]), cur, p["price"], vip, len(media)))
    kb = btn([
        [["👑 Set VIP Link", "pvip_" + pid, "primary"], ["🗑 Remove VIP", "pvipclr_" + pid, "danger"]],
        [["🖼 Set Media", "pmed_" + pid, "primary"], ["🗑 Clear Media", "pmedclr_" + pid, "danger"]],
        [["⬅️ Back", "editprod", "danger"]],
    ])
    smart_reply(c, mid, msg, kb)


def finish_product(c, uid):
    pid = rid("p")
    stk = get_extra(uid, "stock")
    products[pid] = {"name": get_extra(uid, "name"), "cat": get_extra(uid, "cat"), "price": get_extra(uid, "price"), "description": get_extra(uid, "desc"),
                     "delivery_type": get_extra(uid, "del_type"), "delivery_content": get_extra(uid, "del_content"), "stock": -1 if stk is None else stk,
                     "vip_link": get_extra(uid, "vip") or "", "media": get_extra(uid, "media") or []}
    save_json("products")
    p = products[pid]
    clear_state(uid)
    return send_msg(c, "✅ <b>Product Added!</b>\n\n📦 %s\n👑 VIP: %s\n🖼 Media: %d file(s)" % (p["name"], "✅ set" if p["vip_link"] else "❌ none", len(p["media"])),
                    btn([[["⬅️ Admin", "backadmin", "danger"]]]))


def finish_media_step(c, mid, uid):
    st = get_state(uid)
    if mid > 0:
        del_msg(c, mid)
    if st == "addprod_media":
        return finish_product(c, uid)
    if st == "edit_media":
        pid = get_extra(uid, "pid")
        lst = get_extra(uid, "media") or []
        if pid in products and lst:
            products[pid]["media"] = lst
            save_json("products")
        clear_state(uid)
        return show_product_edit(c, 0, pid, ("✅ %d media saved" % len(lst)) if lst else "ℹ️ No media sent - unchanged")
    return None


def show_welcome_menu(c, mid):
    wm = settings.get("welcome_media")
    has_media = isinstance(wm, dict) and wm.get("id")
    msg = ("👋 <b>WELCOME SETUP</b>\n━━━━━━━━━━━\n\n📝 <b>Text:</b> %s\n🖼 <b>Media:</b> %s\n\n<b>Placeholders:</b>\n"
           "<code>{name}</code> <code>{store}</code> <code>{store_upper}</code> <code>{currency}</code> <code>{balance}</code>"
           % ("✅ Custom" if (settings.get("welcome_text") or "").strip() else "Default", ("✅ " + str(wm.get("type"))) if has_media else "❌ none"))
    kb = btn([
        [["✏️ Set Text", "wl_text", "primary"], ["♻️ Reset Text", "wl_text_reset", "danger"]],
        [["🖼 Set Media", "wl_media", "primary"], ["🗑 Remove Media", "wl_media_del", "danger"]],
        [["👁 Preview", "wl_preview", "success"]],
        [["⬅️ Back", "backadmin", "danger"]],
    ])
    smart_reply(c, mid, msg, kb)


def show_pm_manager(c, mid):
    methods = settings["payment_methods"]
    msg = "💳 <b>Payment Methods</b>\n━━━━━━━━━━━\n\n%d configured\n💳 Manual Pay: %s" % (len(methods), "✅ ON" if settings.get("use_manual", True) else "❌ OFF")
    kb = [[["❌ " + pm["name"], "delpm_" + i, "danger"]] for i, pm in methods.items()]
    kb.append([["➕ Add Payment Method", "addpm", "success"]])
    kb.append([["🔄 Manual Pay: " + ("Turn OFF" if settings.get("use_manual", True) else "Turn ON"), "togglemanual_p", "primary"]])
    kb.append([["⬅️ Back", "backadmin", "danger"]])
    smart_reply(c, mid, msg, btn(kb))


def show_approvals(c, mid):
    cur = settings["currency"]
    pending = {i: p for i, p in payments.items() if p.get("status") == "pending"}
    if len(pending) == 0:
        smart_reply(c, mid, "✅ No pending payments.", btn([[["⬅️ Back", "backadmin", "danger"]]]))
        return
    smart_reply(c, mid, "💰 <b>Pending: %d</b>\n━━━━━━━━━━━\n\nReview below:" % len(pending), btn([[["⬅️ Back", "backadmin", "danger"]]]))
    for i, p in pending.items():
        cap = ("🆔 <code>%s</code>\n👤 <code>%s</code>\n💰 %s%s\n" % (i, p["user"], cur, p["amount"])
               + ("💳 %s\n" % p["method"] if "method" in p else "⚡ Auto\n") + ("💲 %.2f USDT\n" % p["usdt_amount"] if p.get("usdt_amount") else "") + ("🧾 UTR: <code>%s</code>\n" % p["utr"] if "utr" in p else "") + "📅 %s IST" % p["date"])
        k = btn([[["✅ Approve", "approve_" + i, "success"], ["❌ Reject", "reject_" + i, "danger"]]])
        if p.get("screenshot"):
            send_photo(c, p["screenshot"], cap, k)
        else:
            send_msg(c, cap, k)


def approve_payment(c, mid, oid):
    cur = settings["currency"]
    with BAL:
        if oid not in payments or payments[oid].get("status") != "pending":
            smart_reply(c, mid, "❌ Invalid or processed", btn([[["⬅️ Back", "backadmin", "danger"]]]))
            return
        p = payments[oid]
        payments[oid]["status"] = "approved"
        save_json("payments")
        balances[str(p["user"])] = balances.get(str(p["user"]), 0) + p["amount"]
        save_json("balances")
        newbal = balances[str(p["user"])]
    mirror("INSERT OR REPLACE INTO transactions VALUES (?,?,?,?,?)", (oid, int(p["user"]), float(p["amount"]), "approved", utc_now()))
    smart_reply(c, mid, "✅ <b>Approved!</b>\nUser: <code>%s</code>\nAmount: %s%s" % (p["user"], cur, p["amount"]), btn([[["⬅️ Back", "backadmin", "danger"]]]))
    send_msg(p["user"], "✅ <b>PAYMENT APPROVED</b>\n━━━━━━━━━━━\n\n🎉 Great news! Your payment has been approved.\n\n💰 <b>Amount Credited:</b> %s%s\n💵 <b>New Balance:</b> %s%s\n\n━━━━━━━━━━━\n🛒 Start shopping now!"
             % (cur, p["amount"], cur, num(newbal)), btn([[["🛒 Shop Now", "shop", "success"], ["⬅️ Menu", "back", "danger"]]]))
    if settings.get("log_channel"):
        send_msg(settings["log_channel"], "💎 <b>NEW DEPOSIT RECEIVED</b> 💎\n━━━━━━━━━━━\n\n🆔 <b>UTR:</b> <code>%s</code>\n💵 <b>Amount:</b> %s%s\n👤 <b>User ID:</b> <code>%s</code>\n"
                 "📅 <b>Date:</b> %s IST\n\n━━━━━━━━━━━\n✅ Manually Verified" % (p.get("utr", "N/A"), cur, p["amount"], p["user"], d_myhm()))


def reject_payment(c, mid, oid):
    cur = settings["currency"]
    if oid not in payments or payments[oid].get("status") != "pending":
        smart_reply(c, mid, "❌ Invalid or processed", btn([[["⬅️ Back", "backadmin", "danger"]]]))
        return
    p = payments[oid]
    payments[oid]["status"] = "rejected"
    save_json("payments")
    mirror("INSERT OR REPLACE INTO transactions VALUES (?,?,?,?,?)", (oid, int(p["user"]), float(p["amount"]), "rejected", utc_now()))
    smart_reply(c, mid, "❌ <b>Rejected</b>\nUser: <code>%s</code>" % p["user"], btn([[["⬅️ Back", "backadmin", "danger"]]]))
    send_msg(p["user"], "❌ <b>Payment Rejected</b>\n\n%s%s - Please contact support." % (cur, p["amount"]), btn([[["⬅️ Menu", "back", "danger"]]]))


def show_stats(c, mid):
    cur = settings["currency"]
    total_users = len(users)
    banned = len(settings.get("banned", []))
    active = total_users - banned
    total_dep = pending_count = pending_amt = fail_count = 0
    for p in payments.values():
        st = p.get("status", "")
        if st == "approved":
            total_dep += php_int(p.get("amount", 0))
        elif st == "rejected":
            fail_count += 1
        elif st == "pending":
            pending_count += 1
            pending_amt += php_int(p.get("amount", 0))
    total_stock = unl = 0
    for p in products.values():
        s = php_int(p.get("stock", 0))
        if s == -1:
            unl += 1
        else:
            total_stock += s
    msg = ("📊 <b>BOT STATISTICS</b>\n━━━━━━━━━━━\n\n👥 <b>USERS</b>\n• Total: %d\n• Active: %d\n• Banned: %d\n\n"
           "💰 <b>FINANCES</b>\n• Total Deposits: %s%s\n• Pending: %d (%s%s)\n• Failed: %d\n\n"
           "📦 <b>INVENTORY</b>\n• Categories: %d\n• Products: %d\n• Total Stock: %d (♾ %d unlimited)\n• Total Orders: %d\n\n"
           "👑 <b>ADMINS</b>\n• Owner: 1\n• Admins: %d\n\n🔧 <b>STATUS</b>\n• Maintenance: %s\n• Auto Payment: %s"
           % (total_users, active, banned, cur, "{:,}".format(total_dep), pending_count, cur, "{:,}".format(pending_amt), fail_count,
              len(categories), len(products), total_stock, unl, len(orders), len(_extra_admins()),
              "🔴 ON" if settings["maintenance"] else "🟢 OFF", "✅ ON" if settings["use_auto"] else "❌ OFF"))
    smart_reply(c, mid, msg, btn([[["🔄 Refresh", "stats", "primary"], ["⬅️ Back", "backadmin", "danger"]]]))


def show_ban_menu(c, mid):
    msg = "🚫 <b>BAN SYSTEM</b>\n━━━━━━━━━━━\n\nBanned users: %d" % len(settings.get("banned", []))
    smart_reply(c, mid, msg, btn([[["🚫 Ban User", "ban_user", "danger"], ["✅ Unban User", "unban_list", "success"]], [["⬅️ Back", "backadmin", "danger"]]]))


def show_unban_list(c, mid):
    banned = settings.get("banned", [])
    if len(banned) == 0:
        smart_reply(c, mid, "✅ No banned users.", btn([[["⬅️ Back", "banmenu", "danger"]]]))
        return
    kb = []
    for b in banned:
        name = users.get(str(b), {}).get("name", "User")
        kb.append([["✅ Unban: %s (%s)" % (name, b), "unban_" + str(b), "success"]])
    kb.append([["⬅️ Back", "banmenu", "danger"]])
    smart_reply(c, mid, "✅ <b>Unban user:</b>", btn(kb))


_BTN_DEFS = [("shop", "🛒 Shop"), ("orders", "📦 Orders"), ("profile", "👤 Profile"), ("addbal", "💰 Add Fund"), ("proof", "📄 Proof"), ("howto", "📖 HowTo"), ("support", "💬 Support")]


def show_button_mgmt(c, mid):
    msg = "🎨 <b>BUTTON MANAGEMENT</b>\n━━━━━━━━━━━\n\n🎨 Colors: %s\n\n<i>Click button to toggle ON/OFF</i>\n\n" % ("✅ ON" if settings.get("use_button_colors") else "❌ OFF")
    rows, cur = [], []
    for k, label in _BTN_DEFS:
        on = btn_on(k)
        cur.append([("✅ " if on else "❌ ") + label, "btgl_" + k, "success" if on else "danger"])
        if len(cur) == 2:
            rows.append(cur)
            cur = []
    if cur:
        rows.append(cur)
    rows.append([["🎨 Toggle Colors", "togglecolors", "primary"]])
    if settings.get("custom_buttons"):
        msg += "━━━━━━━━━━━\n\n<b>CUSTOM BUTTONS:</b>\n\n"
        for cb in settings["custom_buttons"]:
            on = bool(cb.get("enabled"))
            rows.append([[("✅ " if on else "❌ ") + cb["label"], "bcust_tgl_" + cb["id"], "success" if on else "danger"], ["🗑", "bcust_del_" + cb["id"], "danger"]])
    rows.append([["➕ Add Custom Button", "bcust_add", "success"]])
    rows.append([["⬅️ Back", "backadmin", "danger"]])
    smart_reply(c, mid, msg, btn(rows))


def show_admin_mgmt(c, mid):
    msg = "👑 <b>ADMIN MANAGEMENT</b>\n━━━━━━━━━━━\n\n<b>OWNER:</b>\n<code>%s</code> (permanent)\n\n<b>ADMINS:</b>\n" % ADMIN_ID
    kb = []
    extra = _extra_admins()
    if len(extra) == 0:
        msg += "❌ No additional admins\n"
    else:
        for i, aid in enumerate(extra, 1):
            name = esc(users.get(str(aid), {}).get("name", "Unknown"))
            msg += "%d. %s\n   🆔 <code>%s</code>\n\n" % (i, name, aid)
            kb.append([["🗑 Remove: %s" % name, "admin_del_" + str(aid), "danger"]])
    kb.append([["➕ Add Admin", "admin_add", "success"]])
    kb.append([["⬅️ Back", "backadmin", "danger"]])
    smart_reply(c, mid, msg, btn(kb))


def show_maint_panel(c, mid):
    on = settings["maintenance"]
    msg = ("🔧 <b>MAINTENANCE MODE</b>\n━━━━━━━━━━━\n\n<b>Status:</b> %s\n\n<b>Message shown to users:</b>\n<i>%s</i>\n\n%s"
           % ("🔴 <b>ON</b>" if on else "🟢 <b>OFF</b>", settings["maintenance_msg"],
              "⚠️ Regular users cannot use bot.\nAdmins still have full access." if on else "✅ Bot is fully operational."))
    smart_reply(c, mid, msg, btn([[["🔄 Toggle: " + ("Turn OFF" if on else "Turn ON"), "maint_toggle", "success" if on else "danger"]],
                                  [["✏️ Edit Message", "sets_maintmsg", "primary"]], [["⬅️ Back", "backadmin", "danger"]]]))


def show_user_list(c, mid):
    msg = "👥 <b>Users (%d)</b>\n━━━━━━━━━━━\n\n" % len(users)
    i = 1
    for uid, u in users.items():
        msg += "%d. %s" % (i, esc(u.get("name", "")))
        if u.get("username"):
            msg += " (@%s)" % esc(u["username"])
        msg += "\n   🆔 <code>%s</code>\n\n" % uid
        i += 1
        if i > 30:
            msg += "...and %d more" % (len(users) - 30)
            break
    smart_reply(c, mid, msg, btn([[["⬅️ Back", "backadmin", "danger"]]]))


# ============================================================
# SETTINGS SUBMENU
# ============================================================
def show_settings(c, mid):
    cur = settings["currency"]
    addr = str(settings.get("usdt_address", "")).strip()
    addr_s = (addr[:10] + "..." + addr[-4:]) if len(addr) > 16 else (addr or "not set")
    msg = ("⚙️ <b>BOT SETTINGS</b>\n━━━━━━━━━━━\n\n🌍 <b>Currency Symbol:</b> %s\n💵 <b>USDT Rate:</b> %s%s\n💳 <b>Auto UPI:</b> <code>%s</code>\n"
           "🔑 <b>API Key:</b> <code>%s...</code>\n🌐 <b>API URL:</b> <code>%s</code>\n⚡ <b>Auto Payment:</b> %s\n"
           "💲 <b>USDT Pay:</b> %s • %s • <code>%s</code>\n🎨 <b>Button Colors:</b> %s\n📄 <b>Proof:</b> <code>%s</code>\n"
           "📖 <b>HowTo:</b> <code>%s</code>\n💬 <b>Support:</b> %s"
           % (cur, cur, num(settings["usdt_rate"]), esc(settings["auto_upi"]), esc(settings["auto_api_key"][:15]), esc(settings["auto_api_url"]),
              "✅ ON" if settings["use_auto"] else "❌ OFF", "✅ ON" if settings.get("use_usdt") else "❌ OFF", esc(settings.get("usdt_network") or "TRC20"), esc(addr_s),
              "✅ ON" if settings.get("use_button_colors") else "❌ OFF", esc(settings["proof_link"][:30]), esc(settings["howto_link"][:30]), esc(settings["support_user"])))
    kb = btn([
        [["🌍 Currency Symbol", "sets_currency", "primary"], ["💵 USDT Rate", "sets_usdt", "primary"]],
        [["💳 Auto UPI", "sets_autoupi", "primary"], ["🔑 API Key", "sets_autokey", "primary"]],
        [["🌐 API URL", "sets_autourl", "primary"], ["⚡ Toggle Auto", "toggleauto", "success"]],
        [["💲 USDT Address", "sets_usdtaddr", "primary"], ["🌐 USDT Network", "sets_usdtnet", "primary"]],
        [["💲 Toggle USDT", "toggleusdt", "success"], ["💳 Toggle Manual", "togglemanual_s", "success"]],
        [["🎨 Toggle Colors", "togglecolors", "primary"]],
        [["📄 Proof Link", "sets_proof", "primary"], ["📖 HowTo Link", "sets_howto", "primary"]],
        [["💬 Support User", "sets_support", "primary"], ["👋 Welcome Setup", "welcome_menu", "primary"]],
        [["🔧 Maint. Message", "sets_maintmsg", "primary"]],
        [["⬅️ Back", "backadmin", "danger"]],
    ])
    smart_reply(c, mid, msg, kb)


_CURRENCY_HELP = """🌍 <b>SET GLOBAL CURRENCY SYMBOL</b>
━━━━━━━━━━━

This is the <b>global currency symbol</b> — it will be applied automatically across the entire bot (products, balances, payments, orders — everywhere).

🌐 <b>Supported examples:</b>

₹ India        •  $ USA          •  € Europe
£ UK           •  ¥ Japan        •  ₨ Pakistan
৳ Bangladesh   •  ฿ Thailand     •  ₺ Turkey
₽ Russia       •  ﷼ Saudi Arabia •  د.إ UAE
₦ Nigeria      •  ₱ Philippines  •  ₩ South Korea
₪ Israel       •  ₫ Vietnam      •  ₴ Ukraine
₸ Kazakhstan   •  R$ Brazil      •  A$ Australia
C$ Canada      •  RM Malaysia    •  S$ Singapore
HK$ Hong Kong  •  CHF Switzerland

✏️ Send any currency symbol:"""

_SETTING_MAP = {
    "currency": (_CURRENCY_HELP, "set_currency"),
    "usdt": ("💵 <b>Send USDT Rate (in your currency)</b>", "set_usdt"),
    "autoupi": ("💳 <b>Send Auto UPI ID</b>", "set_auto_upi"),
    "autokey": ("🔑 <b>Send Auto API Key</b>", "set_auto_key"),
    "proof": ("📄 <b>Send Proof Link</b>", "set_proof"),
    "howto": ("📖 <b>Send HowTo Link</b>", "set_howto"),
    "support": ("💬 <b>Send Support Username</b>", "set_support"),
    "maintmsg": ("🔧 <b>Send Maintenance Message</b>", "set_maint_msg"),
    "usdtaddr": ("💲 <b>Send USDT Wallet Address</b>\n\nThe payment QR is generated automatically from this address.", "set_usdt_addr"),
    "usdtnet": ("🌐 <b>Send USDT Network</b>\n\nExample: TRC20 / BEP20 / ERC20", "set_usdt_net"),
    "autourl": ("🌐 <b>Send FamPay API URL</b>\n\nExample: <code>https://famapi-sas5.onrender.com</code>", "set_auto_url"),
}


def handle_setting(c, mid, uid, key):
    if key not in _SETTING_MAP:
        return
    set_state(uid, _SETTING_MAP[key][1])
    smart_reply(c, mid, _SETTING_MAP[key][0], btn([[["❌ Cancel", "settings", "danger"]]]))


# ============================================================
# CALLBACK ROUTER
# ============================================================
def route_callback(c, mid, uid, fname, data):
    clear_media_msgs(c, uid)
    current_state = get_state(uid)
    should_delete = data in ("back", "backshop", "backadmin")
    if current_state and data not in ("utr_prompt", "pmdone"):
        should_delete = True
        clear_state(uid)
    if should_delete and mid > 0:
        del_msg(c, mid)
        mid = 0
    back = lambda t, d: btn([[[t, d, "danger"]]])

    # USER NAV
    if data == "back":
        return show_main_menu(c, mid, uid, fname)
    if data == "shop":
        return show_categories(c, mid)
    if data == "profile":
        return show_profile(c, mid, uid)
    if data == "orders":
        return show_orders(c, mid, uid)
    if data == "proof":
        return show_proof(c, mid)
    if data == "howto":
        return show_howto(c, mid)
    if data == "support":
        return show_support(c, mid)
    if data == "addbal":
        return show_add_fund(c, mid, uid)
    if data == "backshop":
        return show_categories(c, mid)
    if data.startswith("cat_"):
        return show_products(c, mid, data[4:])
    if data.startswith("buy_"):
        return show_product_detail(c, mid, uid, data[4:])
    if data.startswith("confirmbuy_"):
        return do_purchase(c, mid, uid, data[11:])

    # PAYMENT
    if (data.startswith("pm_") and not data.startswith("pm_menu") and not data.startswith("pm_users")) or data.startswith("manual_amt_"):
        if not settings.get("use_manual", True):
            return smart_reply(c, mid, "❌ Manual payment is currently disabled.", back("⬅️ Back", "addbal"))
    if data.startswith("pm_") and not data.startswith("pm_menu") and not data.startswith("pm_users"):
        return select_manual_pm(c, mid, data[3:])
    if data == "auto_pay":
        return start_auto_payment(c, mid, uid)
    if data == "usdt_pay":
        return start_usdt_payment(c, mid, uid)
    if data.startswith("manual_amt_"):
        return start_manual_amount(c, mid, uid, data[11:])
    if data == "utr_prompt":
        amt = get_extra(uid, "amount")
        if not amt:
            return smart_reply(c, mid, "❌ Session expired.", back("⬅️ Back", "addbal"))
        set_state(uid, "auto_utr", {"amount": amt})
        return smart_reply(c, mid, "🔢 <b>Enter UTR / Transaction ID</b>\n\nExample: 1234567890123", btn([[["❌ Cancel", "addbal", "danger"]]]))

    # ADMIN GATE
    if not is_admin(uid):
        return smart_reply(c, mid, "❌ Unknown action", back("⬅️ Menu", "back"))

    if data == "backadmin":
        return show_admin(c, mid, uid)
    if data == "addcat":
        set_state(uid, "addcat")
        return smart_reply(c, mid, "📁 <b>Send Category Name</b>", back("❌ Cancel", "backadmin"))
    if data == "delcat":
        return show_cat_delete_list(c, mid)
    if data.startswith("delcat_"):
        cid = data[7:]
        if cid in categories:
            n = categories.pop(cid)["name"]
            save_json("categories")
            smart_reply(c, mid, "✅ <b>Category deleted:</b> %s" % n, back("⬅️ Admin", "backadmin"))
        return
    if data == "addprod":
        return show_select_cat_for_product(c, mid)
    if data.startswith("addprod_cat_"):
        set_state(uid, "addprod_name", {"cat": data[12:]})
        return smart_reply(c, mid, "📦 <b>Send Product Name</b>", back("❌ Cancel", "backadmin"))
    if data == "delprod":
        return show_product_delete_list(c, mid)
    if data.startswith("delprod_"):
        pid = data[8:]
        if pid in products:
            n = products.pop(pid)["name"]
            save_json("products")
            smart_reply(c, mid, "✅ <b>Product deleted:</b> %s" % n, back("⬅️ Admin", "backadmin"))
        return
    if data == "pm_menu":
        return show_pm_manager(c, mid)
    if data == "addpm":
        set_state(uid, "addpm_name")
        return smart_reply(c, mid, "💳 <b>Send Payment Method Name</b>", back("❌ Cancel", "backadmin"))
    if data.startswith("delpm_"):
        pid = data[6:]
        if pid in settings["payment_methods"]:
            n = settings["payment_methods"].pop(pid)["name"]
            save_json("settings")
            smart_reply(c, mid, "✅ <b>Deleted:</b> %s" % n, back("⬅️ Back", "pm_menu"))
        return
    if data == "approvals":
        return show_approvals(c, mid)
    if data.startswith("approve_"):
        return approve_payment(c, mid, data[8:])
    if data.startswith("reject_"):
        return reject_payment(c, mid, data[7:])

    # PRODUCT EDIT (VIP link / media)
    if data == "editprod":
        return show_product_edit_list(c, mid)
    if data.startswith("editprod_"):
        return show_product_edit(c, mid, data[9:])
    if data.startswith("pvipclr_"):
        pid = data[8:]
        if pid in products:
            products[pid]["vip_link"] = ""
            save_json("products")
        return show_product_edit(c, mid, pid, "✅ VIP link removed")
    if data.startswith("pvip_"):
        pid = data[5:]
        if pid not in products:
            return smart_reply(c, mid, "❌ Not found", back("⬅️ Back", "editprod"))
        set_state(uid, "edit_vip", {"pid": pid})
        return smart_reply(c, mid, "👑 <b>Send VIP Channel Link</b>\n\nExample: <code>https://t.me/+AbCdEf</code> or <code>@channel</code>", back("❌ Cancel", "editprod_" + pid))
    if data.startswith("pmedclr_"):
        pid = data[8:]
        if pid in products:
            products[pid]["media"] = []
            save_json("products")
        return show_product_edit(c, mid, pid, "✅ Media cleared")
    if data.startswith("pmed_"):
        pid = data[5:]
        if pid not in products:
            return smart_reply(c, mid, "❌ Not found", back("⬅️ Back", "editprod"))
        set_state(uid, "edit_media", {"pid": pid, "media": []})
        return smart_reply(c, mid, "🖼 <b>Send Product Media</b>\n\nSend photos / videos (max 10). Press <b>Done</b> after the last one.\n⚠️ Old media will be replaced.", back("❌ Cancel", "editprod_" + pid))
    if data == "pmdone":
        return finish_media_step(c, mid, uid)

    # WELCOME SETUP
    if data == "welcome_menu":
        return show_welcome_menu(c, mid)
    if data == "wl_text":
        set_state(uid, "set_welcome_text")
        return smart_reply(c, mid, "✏️ <b>Send Welcome Text</b>\n━━━━━━━━━━━\n\nHTML allowed: &lt;b&gt;bold&lt;/b&gt; &lt;i&gt;italic&lt;/i&gt;\n\n<b>Placeholders:</b>\n"
                           "<code>{name}</code> <code>{store}</code> <code>{store_upper}</code> <code>{currency}</code> <code>{balance}</code>", back("❌ Cancel", "welcome_menu"))
    if data == "wl_text_reset":
        settings["welcome_text"] = ""
        save_json("settings")
        return show_welcome_menu(c, mid)
    if data == "wl_media":
        set_state(uid, "set_welcome_media")
        return smart_reply(c, mid, "🖼 <b>Send Welcome Photo / Video</b>", back("❌ Cancel", "welcome_menu"))
    if data == "wl_media_del":
        settings["welcome_media"] = None
        save_json("settings")
        return show_welcome_menu(c, mid)
    if data == "wl_preview":
        return show_main_menu(c, 0, uid, fname)
    if data == "togglemanual":
        settings["use_manual"] = not settings.get("use_manual", True)
        save_json("settings")
        return show_admin(c, mid, uid)
    if data == "togglemanual_s":
        settings["use_manual"] = not settings.get("use_manual", True)
        save_json("settings")
        return show_settings(c, mid)
    if data == "togglemanual_p":
        settings["use_manual"] = not settings.get("use_manual", True)
        save_json("settings")
        return show_pm_manager(c, mid)
    if data == "toggleusdt":
        settings["use_usdt"] = not settings.get("use_usdt")
        save_json("settings")
        return show_settings(c, mid)

    # SETTINGS SUBMENU
    if data == "settings":
        return show_settings(c, mid)
    if data.startswith("sets_"):
        return handle_setting(c, mid, uid, data[5:])
    if data == "toggleauto":
        settings["use_auto"] = not settings["use_auto"]
        save_json("settings")
        return show_settings(c, mid)
    if data == "togglecolors":
        settings["use_button_colors"] = not settings.get("use_button_colors")
        save_json("settings")
        return show_settings(c, mid)

    # MAINTENANCE
    if data == "maint":
        return show_maint_panel(c, mid)
    if data == "maint_toggle":
        settings["maintenance"] = not settings["maintenance"]
        save_json("settings")
        return show_maint_panel(c, mid)
    if data == "setlogchannel":
        set_state(uid, "set_log_channel")
        return smart_reply(c, mid, "📢 <b>Send Log Channel ID</b>\n\nExample: <code>-1001234567890</code>\n\n/skip = disable", back("❌ Cancel", "backadmin"))

    # BUTTON MANAGEMENT
    if data == "bmgmt":
        return show_button_mgmt(c, mid)
    if data.startswith("btgl_"):
        key = data[5:]
        settings["button_toggles"][key] = not btn_on(key)
        save_json("settings")
        return show_button_mgmt(c, mid)
    if data.startswith("bcust_tgl_"):
        bid = data[10:]
        for cb in settings["custom_buttons"]:
            if cb["id"] == bid:
                cb["enabled"] = not cb.get("enabled")
                break
        save_json("settings")
        return show_button_mgmt(c, mid)
    if data.startswith("bcust_del_"):
        bid = data[10:]
        settings["custom_buttons"] = [x for x in settings["custom_buttons"] if x["id"] != bid]
        save_json("settings")
        return show_button_mgmt(c, mid)
    if data == "bcust_add":
        if len(settings["custom_buttons"]) >= 8:
            return smart_reply(c, mid, "❌ Max 8 custom buttons allowed.", back("⬅️ Back", "bmgmt"))
        set_state(uid, "add_btn_label")
        return smart_reply(c, mid, "➕ <b>Send Button Label</b>\n\nExample: 📢 Our Channel", back("❌ Cancel", "bmgmt"))

    # STATS
    if data == "stats":
        return show_stats(c, mid)
    if data == "userlist":
        return show_user_list(c, mid)
    if data == "userbal":
        set_state(uid, "adduserbal_id")
        return smart_reply(c, mid, "💰 <b>Send User ID</b>", back("❌ Cancel", "backadmin"))

    # BAN MANAGEMENT
    if data == "banmenu":
        return show_ban_menu(c, mid)
    if data == "ban_user":
        set_state(uid, "ban_user_id")
        return smart_reply(c, mid, "🚫 <b>Send User ID to Ban</b>", back("❌ Cancel", "banmenu"))
    if data == "unban_list":
        return show_unban_list(c, mid)
    if data.startswith("unban_"):
        bid = data[6:]
        settings["banned"] = [x for x in settings["banned"] if str(x) != bid]
        save_json("settings")
        show_unban_list(c, mid)
        send_msg(bid, "✅ <b>You have been unbanned.</b>\n\nYou can now use the bot again.")
        return

    # PM
    if data == "pmuser":
        set_state(uid, "pm_user_id")
        return smart_reply(c, mid, "📨 <b>Send User ID</b>", back("❌ Cancel", "backadmin"))

    # BROADCAST
    if data == "broadcast":
        set_state(uid, "broadcast")
        return smart_reply(c, mid, "📢 <b>Send Broadcast Message</b>\n\nText / Photo / Video / Voice / Document", back("❌ Cancel", "backadmin"))

    # ADMIN MGMT (OWNER ONLY)
    if data == "adminmgmt":
        if not is_owner(uid):
            return smart_reply(c, mid, "❌ Owner only.", back("⬅️ Back", "backadmin"))
        return show_admin_mgmt(c, mid)
    if data == "admin_add":
        if not is_owner(uid):
            return
        set_state(uid, "admin_add_id")
        return smart_reply(c, mid, "👑 <b>Send User ID to make Admin</b>", back("❌ Cancel", "adminmgmt"))
    if data.startswith("admin_del_"):
        if not is_owner(uid):
            return
        aid = data[10:]
        settings["admins"] = [x for x in settings["admins"] if str(x) != aid]
        save_json("settings")
        show_admin_mgmt(c, mid)
        send_msg(aid, "⚠️ <b>Your admin access has been removed.</b>")
        return

    smart_reply(c, mid, "❌ Unknown action", back("⬅️ Menu", "back"))


# ============================================================
# TEXT STATE HANDLER
# ============================================================
_MAP_FIELDS = {"set_currency": "currency", "set_usdt": "usdt_rate", "set_auto_upi": "auto_upi", "set_auto_key": "auto_api_key",
               "set_proof": "proof_link", "set_howto": "howto_link", "set_support": "support_user", "set_maint_msg": "maintenance_msg",
               "set_usdt_addr": "usdt_address", "set_usdt_net": "usdt_network", "set_auto_url": "auto_api_url"}


def photo_id(msg):
    return msg["photo"][-1]["file_id"]


def handle_text_state(c, mid, uid, text):
    state = get_state(uid)
    cur = settings["currency"]
    B = lambda t, d, s="danger": btn([[[t, d, s]]])
    cancel = lambda d: btn([[["❌ Cancel", d, "danger"]]])

    # ========== ADMIN STATES ==========
    if is_admin(uid):
        if state in _MAP_FIELDS:
            f = _MAP_FIELDS[state]
            v = text.strip()
            if f == "usdt_rate":
                n = php_float(v)
                if n <= 0:
                    return send_msg(c, "❌ Invalid rate")
                v = num(n)
            if f == "usdt_network":
                v = v.upper()
            if f == "auto_api_url":
                settings["auto_api_path"] = None
            settings[f] = v
            save_json("settings")
            clear_state(uid)
            return send_msg(c, "✅ <b>Updated!</b>\n\n<code>%s</code>" % esc(v), B("⬅️ Settings", "settings", "primary"))
        if state == "addcat":
            cid = rid("c")
            categories[cid] = {"name": text.strip()}
            save_json("categories")
            clear_state(uid)
            return send_msg(c, "✅ <b>Category added:</b>\n\n" + text.strip(), B("⬅️ Admin", "backadmin"))
        if state == "addprod_name":
            set_state(uid, "addprod_price", {"cat": get_extra(uid, "cat"), "name": text.strip()})
            return send_msg(c, "💰 <b>Send Price</b>", cancel("backadmin"))
        if state == "addprod_price":
            p = php_int(text)
            if p < 1:
                return send_msg(c, "❌ Invalid")
            set_state(uid, "addprod_desc", {"cat": get_extra(uid, "cat"), "name": get_extra(uid, "name"), "price": p})
            return send_msg(c, "📝 <b>Send Description</b>", cancel("backadmin"))
        if state == "addprod_desc":
            set_state(uid, "addprod_delivery", {"cat": get_extra(uid, "cat"), "name": get_extra(uid, "name"), "price": get_extra(uid, "price"), "desc": text.strip()})
            return send_msg(c, "🎁 <b>Send Delivery Content</b>\n\n• Text / Link\n• Photo / Video / Document / Voice", cancel("backadmin"))
        if state == "addprod_delivery":
            set_state(uid, "addprod_stock", {"cat": get_extra(uid, "cat"), "name": get_extra(uid, "name"), "price": get_extra(uid, "price"),
                                             "desc": get_extra(uid, "desc"), "del_type": "text", "del_content": text.strip()})
            return send_msg(c, "📊 <b>Send Stock</b>\n\nNumber or <code>unlimited</code>", cancel("backadmin"))
        if state == "addprod_stock":
            stock = -1 if text.strip().lower() == "unlimited" else max(0, php_int(text))
            advance(uid, "addprod_vip", stock=stock)
            return send_msg(c, "👑 <b>Send VIP Channel Link</b>\n━━━━━━━━━━━\n\nExample: <code>https://t.me/+AbCdEf</code> or <code>@channel</code>\n\n"
                               "Buyers get a <b>Join VIP</b> button after purchase.\n\n/skip = no VIP channel", cancel("backadmin"))
        if state == "addprod_vip":
            v = text.strip()
            if v.lower() == "/skip":
                v = ""
            else:
                v = norm_link(v)
                if not is_url(v):
                    return send_msg(c, "❌ Invalid link. Send https://t.me/... or @channel, or /skip")
            advance(uid, "addprod_media", vip=v, media=[])
            return send_msg(c, "🖼 <b>Send Product Media</b>\n━━━━━━━━━━━\n\nSend multiple photos / videos (max 10) - shown on the product page.\n"
                               "Press <b>Done</b> after the last one.\n\n/skip = no media", cancel("backadmin"))
        if state in ("addprod_media", "edit_media"):
            if text.strip().lower() in ("/done", "/skip"):
                return finish_media_step(c, 0, uid)
            return send_msg(c, "⚠️ Send a <b>photo / video</b>, or /done", btn([[["✅ Done", "pmdone", "success"]], [["❌ Cancel", "backadmin", "danger"]]]))
        if state == "edit_vip":
            pid = get_extra(uid, "pid")
            v = norm_link(text.strip())
            if not is_url(v):
                return send_msg(c, "❌ Invalid link. Send https://t.me/... or @channel")
            if pid in products:
                products[pid]["vip_link"] = v
                save_json("products")
            clear_state(uid)
            return show_product_edit(c, 0, pid, "✅ VIP link saved")
        if state == "set_welcome_text":
            v = text.strip()
            old = settings.get("welcome_text", "")
            settings["welcome_text"] = v
            r = send_msg(c, render_welcome(uid, users.get(str(uid), {}).get("name", "User")))
            if not ok(r):
                settings["welcome_text"] = old
                return send_msg(c, "❌ Invalid HTML - not saved. Fix it and send again.", cancel("welcome_menu"))
            save_json("settings")
            clear_state(uid)
            return send_msg(c, "✅ <b>Welcome text updated!</b> (preview above)", B("⬅️ Welcome", "welcome_menu", "primary"))
        if state == "set_welcome_media":
            if text.strip().lower() in ("/remove", "/skip"):
                settings["welcome_media"] = None
                save_json("settings")
                clear_state(uid)
                return send_msg(c, "✅ <b>Welcome media removed</b>", B("⬅️ Welcome", "welcome_menu", "primary"))
            return send_msg(c, "⚠️ Send a photo or video (or /remove)")
        if state == "addpm_name":
            pmid = rid("pm")
            settings["payment_methods"][pmid] = {"name": text.strip(), "qr_url": "", "upi_id": "", "description": ""}
            save_json("settings")
            set_state(uid, "addpm_qr", {"pm_id": pmid})
            return send_msg(c, "📸 <b>Send QR Photo</b>\n\nOr /skip", cancel("backadmin"))
        if state == "addpm_qr":
            if text.strip().lower() == "/skip":
                set_state(uid, "addpm_upi", {"pm_id": get_extra(uid, "pm_id")})
                send_msg(c, "💳 <b>Send UPI ID</b>", cancel("backadmin"))
            else:
                send_msg(c, "⚠️ Send a photo or /skip")
            return
        if state == "addpm_upi":
            pmid = get_extra(uid, "pm_id")
            settings["payment_methods"][pmid]["upi_id"] = text.strip()
            save_json("settings")
            set_state(uid, "addpm_desc", {"pm_id": pmid})
            return send_msg(c, "📝 <b>Send Description</b>", cancel("backadmin"))
        if state == "addpm_desc":
            pmid = get_extra(uid, "pm_id")
            settings["payment_methods"][pmid]["description"] = text.strip()
            save_json("settings")
            n = settings["payment_methods"][pmid]["name"]
            clear_state(uid)
            return send_msg(c, "✅ <b>Payment method added:</b>\n\n💳 %s" % n, B("⬅️ Admin", "backadmin"))
        if state == "adduserbal_id":
            tid = text.strip()
            if tid not in users:
                return send_msg(c, "❌ User not found")
            set_state(uid, "adduserbal_amt", {"target": tid})
            return send_msg(c, "💰 <b>User:</b> %s\n\nSend amount" % esc(users[tid]["name"]), cancel("backadmin"))
        if state == "adduserbal_amt":
            amt = php_int(text)
            if amt <= 0:
                return send_msg(c, "❌ Invalid amount")
            tid = str(get_extra(uid, "target"))
            with BAL:
                balances[tid] = balances.get(tid, 0) + amt
                save_json("balances")
                newbal = balances[tid]
            clear_state(uid)
            send_msg(c, "✅ <b>%s%s added to</b>\n\n🆔 <code>%s</code>" % (cur, amt, tid), B("⬅️ Admin", "backadmin"))
            send_msg(tid, "💰 <b>Balance Added!</b>\n\n%s%s\n━━━━━━━━━━━\n💵 New Balance: %s%s" % (cur, amt, cur, num(newbal)), B("⬅️ Menu", "back"))
            return
        if state == "add_btn_label":
            set_state(uid, "add_btn_url", {"label": text.strip()})
            return send_msg(c, "🔗 <b>Send Redirect URL</b>\n\nExample: https://t.me/yourchannel", cancel("bmgmt"))
        if state == "add_btn_url":
            url = text.strip()
            if not is_url(url):
                return send_msg(c, "❌ Invalid URL. Must start with http:// or https:// or tg://")
            label = get_extra(uid, "label")
            settings["custom_buttons"].append({"id": rid("cb"), "label": label, "url": url, "enabled": True})
            save_json("settings")
            clear_state(uid)
            return send_msg(c, "✅ <b>Custom Button Added!</b>\n\n%s\n%s" % (label, url), B("⬅️ Button Mgmt", "bmgmt", "primary"))
        if state == "pm_user_id":
            tid = text.strip()
            if tid not in users:
                return send_msg(c, "❌ User not found")
            set_state(uid, "pm_message", {"target": tid})
            return send_msg(c, "📨 <b>Send Message for %s</b>\n\nText / Photo / Video" % esc(users[tid]["name"]), cancel("backadmin"))
        if state == "pm_message":
            tid = get_extra(uid, "target")
            send_msg(tid, "📨 <b>Message from Admin</b>\n\n%s" % text)
            clear_state(uid)
            return send_msg(c, "✅ <b>Message sent to</b> <code>%s</code>" % tid, B("⬅️ Admin", "backadmin"))
        if state == "ban_user_id":
            tid = text.strip()
            if tid not in users:
                return send_msg(c, "❌ User not found")
            if is_admin(tid):
                return send_msg(c, "❌ Cannot ban admin")
            if tid not in [str(x) for x in settings["banned"]]:
                settings["banned"].append(tid)
                save_json("settings")
            clear_state(uid)
            send_msg(c, "🚫 <b>User banned:</b> <code>%s</code>" % tid, B("⬅️ Back", "banmenu"))
            send_msg(tid, "🚫 <b>You have been banned</b> from this bot.")
            return
        if state == "admin_add_id":
            if not is_owner(uid):
                return
            tid = text.strip()
            if tid not in users:
                return send_msg(c, "❌ User not found")
            if tid not in [str(x) for x in settings["admins"]]:
                settings["admins"].append(tid)
                save_json("settings")
            clear_state(uid)
            send_msg(c, "👑 <b>New admin added:</b> <code>%s</code>" % tid, B("⬅️ Admin Mgmt", "adminmgmt", "primary"))
            send_msg(tid, "👑 <b>You are now an admin!</b>\n\nUse /admin to access panel.")
            return
        if state == "set_log_channel":
            v = text.strip()
            if v in ("/skip", "0"):
                settings["log_channel"] = ""
                save_json("settings")
                clear_state(uid)
                return send_msg(c, "✅ <b>Log channel disabled</b>", B("⬅️ Admin", "backadmin"))
            settings["log_channel"] = v
            save_json("settings")
            clear_state(uid)
            send_msg(c, "✅ <b>Log channel set:</b> <code>%s</code>\n\nSending test message..." % esc(v), B("⬅️ Admin", "backadmin"))
            t = send_msg(v, "✅ <b>Log Channel Connected!</b>\n\nAll purchases will appear here.")
            if not ok(t):
                send_msg(c, "⚠️ Test failed. Make sure the bot is an <b>admin</b> in the channel.")
            return
        if state == "broadcast":
            sent = fail = 0
            for tid in list(users.keys()):
                if tid in [str(x) for x in settings["banned"]]:
                    continue
                if ok(send_msg(tid, "📢 <b>Announcement</b>\n\n%s" % text)):
                    sent += 1
                else:
                    fail += 1
                time.sleep(0.04)
            clear_state(uid)
            return send_msg(c, "✅ <b>Broadcast done</b>\n✅ Sent: %d\n❌ Failed: %d" % (sent, fail), B("⬅️ Admin", "backadmin"))

    # ========== USER STATES ==========
    if state == "auto_amount":
        return process_auto_amount(c, uid, php_int(text))
    if state == "auto_utr":
        return process_auto_utr(c, uid, text)
    if state == "man_amount":
        return process_manual_amount(c, uid, get_extra(uid, "pm_id"), php_int(text))
    if state == "man_ss":
        return send_msg(c, "📸 <b>Upload photo</b> as screenshot, or /cancel", B("⬅️ Cancel", "addbal"))
    if state == "usdt_amount":
        return process_usdt_amount(c, uid, php_int(text))
    if state == "usdt_ss":
        return send_msg(c, "📸 <b>Upload photo</b> as screenshot, or /cancel", B("⬅️ Cancel", "addbal"))
    if state == "usdt_txid":
        return process_usdt_txid(c, uid, text)
    if state == "man_utr":
        utr = clean_utr(text)
        if len(utr) < 6:
            return send_msg(c, "❌ <b>Invalid UTR</b>\n\nMin 6 characters. Try again.", cancel("addbal"))
        ph, amount, pmid = get_extra(uid, "photo"), get_extra(uid, "amount"), get_extra(uid, "pm_id")
        if not ph or not amount or not pmid:
            return send_msg(c, "❌ Session expired", B("⬅️ Back", "addbal"))
        pm_name = settings["payment_methods"].get(pmid, {}).get("name", "Unknown")
        oid = "MAN" + str(int(time.time()))[-8:] + str(random.randint(100, 999))
        payments[oid] = {"user": uid, "amount": amount, "method": pm_name, "method_id": pmid, "screenshot": ph, "utr": utr,
                         "status": "pending", "type": "manual", "date": d_myhm()}
        save_json("payments")
        mirror("INSERT OR REPLACE INTO transactions VALUES (?,?,?,?,?)", (oid, int(uid), float(amount), "pending", utc_now()))
        clear_state(uid)
        send_msg(c, "✅ <b>PAYMENT SUBMITTED</b>\n━━━━━━━━━━━\n\n🎉 Your payment has been received successfully.\n\n💰 <b>Amount:</b> %s%s\n💳 <b>Method:</b> %s\n🧾 <b>UTR:</b> <code>%s</code>\n"
                 "🆔 <b>Order ID:</b> <code>%s</code>\n\n━━━━━━━━━━━\n⏳ <i>Verification in progress...</i>\n🙏 Please wait for admin approval." % (cur, amount, pm_name, utr, oid),
                 B("⬅️ Menu", "back"))
        uname = esc(users.get(str(uid), {}).get("name", "User"))
        admin_msg = ("🔔 <b>NEW MANUAL PAYMENT</b>\n━━━━━━━━━━━\n\n👤 %s\n🆔 <code>%s</code>\n💰 %s%s\n💳 %s\n🧾 UTR: <code>%s</code>\n🆔 <code>%s</code>\n📅 %s IST"
                     % (uname, uid, cur, amount, pm_name, utr, oid, d_myhm()))
        send_photo(ADMIN_ID, ph, admin_msg, btn([[["✅ Approve", "approve_" + oid, "success"], ["❌ Reject", "reject_" + oid, "danger"]]]))


# ============================================================
# MEDIA HANDLER
# ============================================================
def handle_media_state(c, mid, uid, msg):
    state = get_state(uid)
    if not state:
        return
    B = lambda t, d: btn([[[t, d, "danger"]]])
    if is_admin(uid):
        if state in ("addprod_media", "edit_media"):
            typ = fid = None
            if "photo" in msg:
                typ, fid = "photo", photo_id(msg)
            elif "video" in msg:
                typ, fid = "video", msg["video"]["file_id"]
            if not typ:
                return send_msg(c, "⚠️ Send a <b>photo / video</b> only (or /done)")
            lst = list(get_extra(uid, "media") or [])
            if len(lst) >= 10:
                return send_msg(c, "⚠️ Max 10 media. Press <b>Done</b>.", btn([[["✅ Done", "pmdone", "success"]]]))
            lst.append({"type": typ, "id": fid})
            advance(uid, state, media=lst)
            return send_msg(c, "✅ <b>Added (%d/10)</b>\n\nSend more or press Done." % len(lst), btn([[["✅ Done", "pmdone", "success"]], [["❌ Cancel", "backadmin", "danger"]]]))
        if state == "set_welcome_media":
            typ = fid = None
            if "photo" in msg:
                typ, fid = "photo", photo_id(msg)
            elif "video" in msg:
                typ, fid = "video", msg["video"]["file_id"]
            if not typ:
                return send_msg(c, "⚠️ Send a photo or video")
            settings["welcome_media"] = {"type": typ, "id": fid}
            save_json("settings")
            clear_state(uid)
            return send_msg(c, "✅ <b>Welcome media saved!</b> (%s)" % typ, B("⬅️ Welcome", "welcome_menu"))
        if state == "addprod_delivery":
            typ = content = None
            if "photo" in msg:
                typ, content = "photo", photo_id(msg)
            elif "video" in msg:
                typ, content = "video", msg["video"]["file_id"]
            elif "document" in msg:
                typ, content = "document", msg["document"]["file_id"]
            elif "voice" in msg:
                typ, content = "voice", msg["voice"]["file_id"]
            if not typ:
                return send_msg(c, "❌ Unsupported")
            set_state(uid, "addprod_stock", {"cat": get_extra(uid, "cat"), "name": get_extra(uid, "name"), "price": get_extra(uid, "price"),
                                             "desc": get_extra(uid, "desc"), "del_type": typ, "del_content": content})
            return send_msg(c, "✅ <b>Saved (%s)</b>\n\n📊 Send stock" % typ, B("❌ Cancel", "backadmin"))
        if state == "addpm_qr" and "photo" in msg:
            pmid = get_extra(uid, "pm_id")
            settings["payment_methods"][pmid]["qr_url"] = photo_id(msg)
            save_json("settings")
            set_state(uid, "addpm_upi", {"pm_id": pmid})
            return send_msg(c, "✅ <b>QR saved</b>\n\n💳 Send UPI ID", B("❌ Cancel", "backadmin"))
        if state == "pm_message":
            tid = get_extra(uid, "target")
            cap = "📨 <b>Message from Admin</b>\n\n" + msg.get("caption", "")
            if "photo" in msg:
                send_photo(tid, photo_id(msg), cap)
            elif "video" in msg:
                send_video(tid, msg["video"]["file_id"], cap)
            elif "document" in msg:
                send_doc(tid, msg["document"]["file_id"], cap)
            clear_state(uid)
            return send_msg(c, "✅ <b>Message sent to</b> <code>%s</code>" % tid, B("⬅️ Admin", "backadmin"))
        if state == "broadcast":
            sent = fail = 0
            cap = "📢 <b>Announcement</b>\n\n" + msg.get("caption", "")
            for tid in list(users.keys()):
                if tid in [str(x) for x in settings["banned"]]:
                    continue
                r = None
                if "photo" in msg:
                    r = send_photo(tid, photo_id(msg), cap)
                elif "video" in msg:
                    r = send_video(tid, msg["video"]["file_id"], cap)
                elif "document" in msg:
                    r = send_doc(tid, msg["document"]["file_id"], cap)
                elif "voice" in msg:
                    r = send_voice(tid, msg["voice"]["file_id"], cap)
                if ok(r):
                    sent += 1
                else:
                    fail += 1
                time.sleep(0.04)
            clear_state(uid)
            return send_msg(c, "✅ <b>Done</b>\n✅ Sent: %d\n❌ Failed: %d" % (sent, fail), B("⬅️ Admin", "backadmin"))
    if state == "man_ss":
        if "photo" in msg:
            submit_manual_payment(c, uid, photo_id(msg))
        else:
            send_msg(c, "⚠️ Photo required.")
        return
    if state == "usdt_ss":
        if "photo" in msg:
            submit_usdt_proof(c, uid, photo_id(msg))
        else:
            send_msg(c, "⚠️ Photo required.")


# ============================================================
# UPDATE HANDLER
# ============================================================
_user_locks = {}
_NAV_FROM_MEDIA = {"shop", "orders", "profile", "addbal", "proof", "howto", "support"}
_ul_guard = threading.Lock()


def user_lock(uid):
    with _ul_guard:
        return _user_locks.setdefault(str(uid), threading.RLock())


def handle_update(upd):
    is_cb = "callback_query" in upd
    if is_cb:
        cb = upd["callback_query"]
        msg0 = cb.get("message") or {}
        chat_id = (msg0.get("chat") or {}).get("id", 0)
        mid = msg0.get("message_id", 0)
        frm = cb.get("from") or {}
        uid = frm.get("id", 0)
        fname, uname = frm.get("first_name", "User"), frm.get("username", "")
        text, data, cb_id, message = "", cb.get("data", "") or "", cb.get("id", ""), {}
    else:
        message = upd.get("message") or {}
        chat_id = (message.get("chat") or {}).get("id", 0)
        mid = message.get("message_id", 0)
        frm = message.get("from") or {}
        uid = frm.get("id", 0)
        fname, uname = frm.get("first_name", "User"), frm.get("username", "")
        text, data, cb_id = message.get("text", "") or "", "", ""
    if not uid:
        return
    with user_lock(uid):
        # MAINTENANCE CHECK (before ban, before anything)
        if is_maint() and not is_admin(uid):
            if is_cb:
                answer_cb_fast(cb_id)
            send_msg(chat_id, settings["maintenance_msg"])
            return
        k = str(uid)
        if k not in balances:
            balances[k] = 0
            save_json("balances")
        if k not in users:
            users[k] = {"name": fname, "username": uname, "join": d_my()}
            save_json("users")
            mirror("INSERT OR IGNORE INTO users (id, name, joined) VALUES (?,?,?)", (int(uid), fname, utc_now()))
        # BAN BLOCK
        if is_banned(uid) and not is_admin(uid):
            if is_cb:
                answer_cb_fast(cb_id)
            send_msg(chat_id, "🚫 <b>Access Denied</b>\n\nYou have been banned from using this bot.\n\n💬 Contact support if you believe this is a mistake.")
            return
        # ROUTING
        if is_cb:
            answer_cb_fast(cb_id)
            if (msg0.get("photo") or msg0.get("video")) and data in _NAV_FROM_MEDIA and mid > 0:
                del_msg(chat_id, mid)
                mid = 0
            route_callback(chat_id, mid, uid, fname, data)
        elif text == "/start":
            show_main_menu(chat_id, 0, uid, fname)
        elif text == "/admin":
            if not is_admin(uid):
                send_msg(chat_id, "❌ Access denied")
            else:
                show_admin(chat_id, 0, uid)
        elif text == "/cancel":
            clear_state(uid)
            send_msg(chat_id, "✅ Cancelled", btn([[["⬅️ Menu", "back", "danger"]]]))
        elif text != "":
            handle_text_state(chat_id, 0, uid, text)
        elif message:
            handle_media_state(chat_id, 0, uid, message)


def safe_handle(updates):
    for u in updates:
        try:
            handle_update(u)
        except Exception as ex:                                  # never let one update kill the bot
            import traceback
            log_err("handler error: %r\n%s" % (ex, traceback.format_exc()))


def _uid_of(u):
    try:
        if "callback_query" in u:
            return u["callback_query"]["from"]["id"]
        return u["message"]["from"]["id"]
    except (KeyError, TypeError):
        return 0


# ============================================================
# MAIN LOOP (long polling; the panel keeps this process alive)
# ============================================================
def main():
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN missing")
    init_data()
    mirror_init()
    r = http_post(API + "/deleteWebhook", {"drop_pending_updates": 1}, 10)
    print("bot started; owner=%s theme=%s" % (ADMIN_ID, os.getenv("THEME", "")), flush=True)
    pool = ThreadPoolExecutor(max_workers=16)
    offset = 0
    while True:
        try:
            resp = SESSION.post(API + "/getUpdates", data={"offset": offset, "timeout": 50, "allowed_updates": json.dumps(["message", "callback_query"])}, timeout=(8, 65))
            j = resp.json()
        except (requests.RequestException, ValueError):
            time.sleep(3)
            continue
        if not j.get("ok"):
            log_err("getUpdates: %s" % str(j)[:200])
            time.sleep(5)
            continue
        groups = {}
        for u in j.get("result", []):
            offset = max(offset, u["update_id"] + 1)
            groups.setdefault(_uid_of(u), []).append(u)            # same user = handled in order
        for g in groups.values():
            pool.submit(safe_handle, g)


if __name__ == "__main__":
    main()
