VC MINI SMM (vcstore)  -  HostPanel script
1) Update:   cd ~/hostpanel && mkdir -p scripts/vcstore && unzip -o ~/vcstore.zip -d scripts/vcstore && bash update.sh
2) Owner /admin -> Scripts -> vcstore should show "ready". Make an access key for it (or "All scripts") and launch a bot.
3) In Telegram open your bot -> /admin (only ADMIN_IDS):
   Providers -> Add (name, API URL, API key, margin, multiplier) -> Import services
   Payments  -> UPI ID, FamPay API key, FamPay base URL, Auto/Manual on-off
   Settings  -> global margin, support, channel, welcome, banner, maintenance
   Tools     -> logo, backup, export, provider balances
4) Users tap "Open SMM" -> Mini App (needs PUBLIC_URL / Cloudflare tunnel set in the host panel).
Mini App API goes through the panel's allowed paths only (/pay, /api/verify, /logo) - no change to app.py needed.
