#!/usr/bin/env python3
"""VC MUSIC - single-session voice studio for the hostpanel.

ONE api_id/api_hash, ONE userbot session, ONE voice chat at a time, everything controlled from the bot.
Flow:  send audio/voice to the bot -> pick a mode / mixer -> Join VC -> Play.
Admin commands:  /start /menu /admin  /join <chat_id|@group>  /setapi <id> <hash>  /setsession <string>  /status
Panel env (.env): BOT_TOKEN ADMIN_IDS STORE_NAME SUPPORT_USERNAME THEME_FILE.  Secrets live in vc_config.json.
"""
import asyncio, html, json, logging, os, shutil, subprocess, sys, itertools

CWD = os.getcwd()
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("vcmusic")


def load_env(path):
    try:
        for line in open(path, encoding="utf-8").read().splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
    except OSError:
        pass


load_env(os.path.join(CWD, ".env"))
TOKEN = os.getenv("BOT_TOKEN", "")
ADMINS = {int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
STORE = os.getenv("STORE_NAME", "VC Music")
SUPPORT = os.getenv("SUPPORT_USERNAME", "@support")
CFG_FILE = os.path.join(CWD, "vc_config.json")
WORK = os.path.join(CWD, "work")
os.makedirs(WORK, exist_ok=True)

try:
    THEME = json.load(open(os.getenv("THEME_FILE", ""), encoding="utf-8"))
except Exception:
    THEME = {}


def T(k, d):
    v = THEME.get(k)
    return v if isinstance(v, str) and v else d


LABELS = {"gain": "🔊 Gain", "loudness": "📢 Loudness", "bass": "🥁 Bass", "treble": "✨ Treble",
          "clarity": "💎 Clarity", "echo": "🌊 Echo", "pitch": "🎼 Pitch"}
LABELS.update(THEME.get("labels") if isinstance(THEME.get("labels"), dict) else {})
DEFAULTS = dict(gain=100, loudness=100, bass=100, treble=100, clarity=100, echo=0, pitch=500)
SETTINGS = dict(DEFAULTS)
MODES = {  # name: (button text, settings)
    "normal": ("🎧 Normal", dict(DEFAULTS)),
    "loud": ("📢 Loud", dict(DEFAULTS, gain=400, loudness=600, bass=300, treble=200, clarity=200)),
    "bass": ("🥁 Bass Boost", dict(DEFAULTS, gain=250, loudness=300, bass=700)),
    "clear": ("💎 Crystal Clear", dict(DEFAULTS, clarity=600, treble=400, gain=150)),
    "echo": ("🌊 Echo Hall", dict(DEFAULTS, echo=500, gain=150)),
    "chip": ("🐿 Chipmunk", dict(DEFAULTS, pitch=800)),
    "deep": ("👹 Deep Voice", dict(DEFAULTS, pitch=200, bass=500)),
    "max": ("🔥 MAX (limited)", dict(DEFAULTS, gain=800, loudness=900, bass=500, treble=300, clarity=300)),
}
STATE = dict(chat=None, chat_title="", audio=None, audio_name="", mode="normal", playing=False, paused=False, volume=100)
_counter = itertools.count(1)


def cfg():
    try:
        return json.load(open(CFG_FILE, encoding="utf-8"))
    except Exception:
        return {}


def save_cfg(c):
    with open(CFG_FILE, "w", encoding="utf-8") as f:
        json.dump(c, f)
    os.chmod(CFG_FILE, 0o600)


def setup_ffmpeg():
    """No root needed: system ffmpeg, or the binary shipped by the imageio-ffmpeg pip package."""
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        real = imageio_ffmpeg.get_ffmpeg_exe()
        bindir = os.path.join(CWD, "bin")
        os.makedirs(bindir, exist_ok=True)
        link = os.path.join(bindir, "ffmpeg")
        if os.path.lexists(link):
            os.unlink(link)
        os.symlink(real, link)
        os.environ["PATH"] = bindir + os.pathsep + os.environ.get("PATH", "")
        return link
    except Exception as e:
        log.error("ffmpeg not found: %s", e)
        return "ffmpeg"


FFMPEG = setup_ffmpeg()


def ensure_pyrogram():
    """Panel installs wheels only; pyrogram needs pyaes (source-only, pure Python) -> install it here once."""
    try:
        import pyrogram  # noqa
        return
    except ImportError:
        pass
    r = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--disable-pip-version-check",
                        "pyaes==1.6.1", "pysocks", "pyrogram==2.0.106"], capture_output=True, text=True)
    if r.returncode != 0:
        log.error("pyrogram install failed: %s", (r.stdout + r.stderr)[-1500:])
        raise SystemExit("pyrogram install failed")


ensure_pyrogram()
from telegram import InlineKeyboardButton, InlineKeyboardMarkup as M, Update
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters
from pyrogram import Client
from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream, AudioQuality

U = None   # the single userbot client
C = None   # its PyTgCalls


def btn(text, cb=None, style="primary", url=None):
    """Coloured button (Bot API 9.4 style: primary blue / success green / danger red)."""
    kw = {"url": url} if url else {"callback_data": cb}
    try:
        return InlineKeyboardButton(text, api_kwargs={"style": style}, **kw)
    except Exception:
        return InlineKeyboardButton(text, **kw)


def build_filter(s):
    f = [f"volume={1 + s['gain'] / 100:.2f}", f"bass=g={s['bass'] / 50:.1f}", f"treble=g={s['treble'] / 50:.1f}",
         f"highpass=f={50 + s['clarity'] / 10:.0f}"]
    if s["loudness"] > 100:
        f.append(f"acompressor=threshold=0.1:ratio={2 + s['loudness'] / 125:.1f}:makeup={1 + s['loudness'] / 250:.1f}")
    if s["echo"]:
        f.append(f"aecho=0.8:0.8:{40 + s['echo'] / 10:.0f}:0.4")
    if s["pitch"] != 500:
        f.append(f"asetrate=48000*{1 + (s['pitch'] - 500) / 2500:.2f},aresample=48000")
    f.append("alimiter=limit=0.9")     # safety cap against clipping / ear damage - keep it
    return ",".join(f)


async def process_audio():
    out = os.path.join(WORK, f"out_{next(_counter)}.wav")
    p = await asyncio.create_subprocess_exec(
        FFMPEG, "-y", "-loglevel", "error", "-i", STATE["audio"], "-vn", "-af", build_filter(SETTINGS),
        "-ar", "48000", "-ac", "2", out, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
    _, err = await p.communicate()
    if p.returncode != 0:
        raise RuntimeError("ffmpeg: " + err.decode(errors="replace")[-300:])
    for old in os.listdir(WORK):          # keep the work folder small
        if old.startswith("out_") and os.path.join(WORK, old) != out:
            try:
                os.remove(os.path.join(WORK, old))
            except OSError:
                pass
    return out


async def play_now():
    out = await process_audio()
    await C.play(STATE["chat"], MediaStream(out, AudioQuality.HIGH, video_flags=MediaStream.Flags.IGNORE))
    STATE["playing"], STATE["paused"] = True, False
    try:
        await C.change_volume_call(STATE["chat"], STATE["volume"])
    except Exception:
        pass


def bar(v):
    n = round(v / 100)
    return T("bar_full", "█") * n + T("bar_empty", "░") * (10 - n)


def status_text():
    vc = html.escape(STATE["chat_title"] or "—")
    au = html.escape(STATE["audio_name"] or "— (send me an audio / voice)")
    mode = MODES[STATE["mode"]][0] if STATE["mode"] in MODES else "🎛 Custom"
    st = "▶️ playing" if STATE["playing"] and not STATE["paused"] else ("⏸ paused" if STATE["paused"] else "⏹ idle")
    return (f"🎙 <b>VC:</b> {vc}\n🎵 <b>Audio:</b> {au}\n🎚 <b>Mode:</b> {mode}\n"
            f"🔊 <b>Volume:</b> {STATE['volume']}%\n📡 <b>State:</b> {st}")


def home_kb():
    return M([
        [btn(T("btn_join", "🎙 Join VC"), "join", "success"), btn(T("btn_leave", "🚪 Leave"), "leave", "danger")],
        [btn(T("btn_play", "▶️ Play"), "play", "success"), btn(T("btn_pause", "⏸ Pause"), "pause", "primary"),
         btn(T("btn_resume", "⏯ Resume"), "resume", "primary")],
        [btn(T("btn_modes", "🎚 Modes"), "modes", "primary"), btn(T("btn_mixer", "🎛 Mixer"), "mix", "primary")],
        [btn("🔉 50%", "vol:50", "primary"), btn("🔊 100%", "vol:100", "success"),
         btn("📢 150%", "vol:150", "primary"), btn("🔥 200%", "vol:200", "danger")],
        [btn(T("btn_support", "💬 Support"), url=f"https://t.me/{SUPPORT.lstrip('@')}")],
    ])


def modes_kb():
    items = list(MODES.items())
    rows = []
    for i in range(0, len(items), 2):
        rows.append([btn(("✅ " if STATE["mode"] == k else "") + v[0], f"mode:{k}", "success" if STATE["mode"] == k else "primary")
                     for k, v in items[i:i + 2]])
    rows.append([btn("⬅️ Back", "home", "danger")])
    return M(rows)


def mix_text():
    rows = "\n".join(f"{LABELS[k]}: <code>{bar(v)}</code> {v}/1000" for k, v in SETTINGS.items())
    return f"{T('panel_title', '🎛 <b>CUSTOM MIX</b>')}\n\n{rows}"


def mix_kb():
    rows = []
    for k, v in SETTINGS.items():
        rows.append([btn("➖", f"s:{k}:-100", "danger"), btn(f"{LABELS[k]} {v}", "noop", "primary"),
                     btn("➕", f"s:{k}:100", "success")])
    rows.append([btn(T("btn_reset", "🔄 Reset"), "reset", "danger"), btn(T("btn_play", "▶️ Apply & Play"), "play", "success")])
    rows.append([btn("⬅️ Back", "home", "primary")])
    return M(rows)


def is_admin(update):
    u = update.effective_user
    return bool(u) and u.id in ADMINS


async def start(update: Update, ctx):
    text = T("welcome", "🎙 <b>{store}</b>").replace("{store}", html.escape(STORE))
    if is_admin(update):
        await update.message.reply_text(f"{text}\n\n{status_text()}", parse_mode="HTML", reply_markup=home_kb())
    else:
        await update.message.reply_text(text, parse_mode="HTML",
                                        reply_markup=M([[btn(T("btn_support", "💬 Support"), url=f"https://t.me/{SUPPORT.lstrip('@')}")]]))


async def menu(update: Update, ctx):
    if is_admin(update):
        await update.message.reply_text(status_text(), parse_mode="HTML", reply_markup=home_kb())


async def setapi(update: Update, ctx):
    if not is_admin(update):
        return
    try:
        i, h = int(ctx.args[0]), ctx.args[1]
    except Exception:
        return await update.message.reply_text("Use: /setapi <api_id> <api_hash>")
    c = cfg(); c.update(api_id=i, api_hash=h); save_cfg(c)
    try:
        await update.message.delete()
    except Exception:
        pass
    await update.effective_chat.send_message("✅ API saved.")


async def setsession(update: Update, ctx):
    if not is_admin(update):
        return
    try:
        s = ctx.args[0]
    except Exception:
        return await update.message.reply_text("Use: /setsession <string_session>")
    c = cfg(); c["session"] = s; save_cfg(c)
    try:
        await update.message.delete()
    except Exception:
        pass
    await update.effective_chat.send_message("✅ Session saved. Restart the bot from the panel now.")


async def status(update: Update, ctx):
    if not is_admin(update):
        return
    c = cfg()
    ok = lambda x: "✅" if x else "❌"
    await update.message.reply_text(f"API {ok(c.get('api_id'))}  Session {ok(c.get('session'))}  Userbot running {ok(C)}\n\n{status_text()}",
                                    parse_mode="HTML")


async def join_cmd(update: Update, ctx):
    if not is_admin(update):
        return
    if not C:
        return await update.message.reply_text("Userbot not running. /setapi + /setsession, then restart the bot.")
    if not ctx.args:
        return await update.message.reply_text("Use: /join <group id or @username>\nThe session account must already be a member of that group.")
    arg = ctx.args[0]
    try:
        chat = await U.get_chat(int(arg) if arg.lstrip("-").isdigit() else arg)
        if STATE["chat"] and STATE["chat"] != chat.id:          # one VC at a time
            try:
                await C.leave_call(STATE["chat"])
            except Exception:
                pass
        await C.play(chat.id)
        STATE.update(chat=chat.id, chat_title=chat.title or str(chat.id), playing=False, paused=False)
        await update.message.reply_text("✅ Joined VC\n\n" + status_text(), parse_mode="HTML", reply_markup=home_kb())
    except Exception as e:
        await update.message.reply_text(f"❌ Could not join: {html.escape(str(e))[:300]}\nMake sure the VC is running and the session account is in that group.")


async def got_audio(update: Update, ctx):
    if not is_admin(update):
        return
    m = update.message
    att = m.voice or m.audio or m.document
    if not att:
        return
    try:
        f = await att.get_file()
        ext = os.path.splitext(f.file_path or "")[1] or ".ogg"
        path = os.path.join(WORK, "input" + ext)
        await f.download_to_drive(path)
    except Exception as e:
        return await m.reply_text(f"❌ Could not download (max 20 MB): {html.escape(str(e))[:200]}")
    STATE["audio"] = path
    STATE["audio_name"] = getattr(att, "file_name", None) or ("voice message" if m.voice else "audio")
    await m.reply_text("✅ Audio received. Pick a mode, then Join VC and Play.\n\n" + status_text(),
                       parse_mode="HTML", reply_markup=home_kb())


async def cb(update: Update, ctx):
    q = update.callback_query
    if not is_admin(update):
        return await q.answer("Admins only", show_alert=True)
    d = q.data

    async def show(text, kb):
        try:
            await q.message.edit_text(text, parse_mode="HTML", reply_markup=kb)
        except Exception:
            pass

    if d == "noop":
        return await q.answer()
    if d == "home":
        await show(status_text(), home_kb()); return await q.answer()
    if d == "modes":
        await show("🎚 <b>Pick a mode</b>\n\n" + status_text(), modes_kb()); return await q.answer()
    if d == "mix":
        await show(mix_text(), mix_kb()); return await q.answer()
    if d == "join":
        return await q.answer("Send: /join <group id or @username>", show_alert=True)
    if d.startswith("mode:"):
        k = d.split(":")[1]
        if k in MODES:
            SETTINGS.clear(); SETTINGS.update(MODES[k][1]); STATE["mode"] = k
        await show("🎚 <b>Pick a mode</b>\n\n" + status_text(), modes_kb())
        if STATE["playing"] and STATE["audio"]:
            try:
                await play_now()
            except Exception as e:
                return await q.answer(str(e)[:150], show_alert=True)
        return await q.answer("Mode set")
    if d == "reset":
        SETTINGS.clear(); SETTINGS.update(DEFAULTS); STATE["mode"] = "normal"
        await show(mix_text(), mix_kb()); return await q.answer("Reset")
    if d.startswith("s:"):
        _, k, step = d.split(":")
        if k in SETTINGS:
            SETTINGS[k] = max(0, min(1000, SETTINGS[k] + int(step)))
            STATE["mode"] = "custom"
        await show(mix_text(), mix_kb())
        return await q.answer()          # sliders apply when you press Play (no re-encode on every tap)
    if d.startswith("vol:"):
        STATE["volume"] = int(d.split(":")[1])
        if STATE["chat"] and C:
            try:
                await C.change_volume_call(STATE["chat"], STATE["volume"])
            except Exception as e:
                await q.answer(str(e)[:150], show_alert=True); return
        await show(status_text(), home_kb()); return await q.answer(f"Volume {STATE['volume']}%")
    # actions that need the VC
    if not C or not STATE["chat"]:
        return await q.answer("First: /join <group id or @username>", show_alert=True)
    try:
        if d == "play":
            if not STATE["audio"]:
                return await q.answer("Send me an audio / voice first", show_alert=True)
            await q.answer("Processing…")
            await play_now()
            await show(status_text(), home_kb())
        elif d == "pause":
            await C.pause(STATE["chat"]); STATE["paused"] = True
            await show(status_text(), home_kb()); await q.answer("Paused")
        elif d == "resume":
            await C.resume(STATE["chat"]); STATE["paused"] = False
            await show(status_text(), home_kb()); await q.answer("Resumed")
        elif d == "leave":
            await C.leave_call(STATE["chat"])
            STATE.update(chat=None, chat_title="", playing=False, paused=False)
            await show(status_text(), home_kb()); await q.answer("Left VC")
    except Exception as e:
        await q.answer(str(e)[:180], show_alert=True)


async def post_init(app):
    global U, C
    c = cfg()
    if not (c.get("api_id") and c.get("session")):
        log.info("Waiting for /setapi and /setsession from the admin")
        return
    try:
        U = Client("vcuser", api_id=int(c["api_id"]), api_hash=c["api_hash"], session_string=c["session"], workdir=CWD)
        await U.start()
        C = PyTgCalls(U)
        await C.start()
        log.info("Userbot ready")
    except Exception as e:
        log.error("Userbot start failed: %s", e)
        U = C = None


async def post_shutdown(app):
    if C and STATE["chat"]:
        try:
            await C.leave_call(STATE["chat"])
        except Exception:
            pass
    if U:
        try:
            await U.stop()
        except Exception:
            pass


def main():
    if not TOKEN:
        raise SystemExit("BOT_TOKEN missing")
    app = Application.builder().token(TOKEN).post_init(post_init).post_shutdown(post_shutdown).build()
    for name, fn in (("start", start), ("menu", menu), ("admin", menu), ("panel", menu), ("setapi", setapi),
                     ("setsession", setsession), ("status", status), ("join", join_cmd)):
        app.add_handler(CommandHandler(name, fn))
    app.add_handler(MessageHandler((filters.VOICE | filters.AUDIO | filters.Document.AUDIO) & filters.ChatType.PRIVATE, got_audio))
    app.add_handler(CallbackQueryHandler(cb))
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
