#!/usr/bin/env python3
"""VC MUSIC BRIDGE - script for the multi-script hostpanel.

Group A voice chat audio -> ffmpeg mixer -> Group B voice chat.
Panel gives:  BOT_TOKEN, ADMIN_IDS, STORE_NAME, SUPPORT_USERNAME, THEME_FILE  (from .env in the bot folder)
Extra secrets (API_ID, API_HASH, two userbot sessions) are kept in vc_config.json inside the bot folder,
set from Telegram by an admin (the panel never overwrites that file):
  /setapi <api_id> <api_hash>
  /setsession a <string_session>      /setsession b <string_session>
Admin commands: /panel  /bridge <chat_A> <chat_B>  /stop  /status
Needs: ffmpeg installed on the server.   Use only in groups where members/admins agreed.
"""
import asyncio, html, json, os, subprocess, logging

BASE = os.path.dirname(os.path.abspath(os.path.realpath(__file__)))
CWD = os.getcwd()          # bot folder (bots/<id>/), the panel runs bot.py from here


def load_env(path):
    try:
        for line in open(path, encoding="utf-8").read().splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
    except OSError:
        pass


load_env(os.path.join(CWD, ".env"))
TOKEN = os.getenv("BOT_TOKEN", "")
ADMINS = {int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
STORE = os.getenv("STORE_NAME", "VC Bridge")
SUPPORT = os.getenv("SUPPORT_USERNAME", "@support")
CFG_FILE = os.path.join(CWD, "vc_config.json")
FIFO = os.path.join(CWD, "vc_out.raw")

try:
    THEME = json.load(open(os.getenv("THEME_FILE", ""), encoding="utf-8"))
except Exception:
    THEME = {}


def T(k, d):
    v = THEME.get(k)
    return v if isinstance(v, str) and v else d


LABELS = {"gain": "🔊 Gain", "loudness": "📢 Loudness", "bass": "🥁 Bass", "treble": "✨ Treble",
          "clarity": "💎 Clarity", "echo": "🌊 Echo", "pitch": "🎼 Pitch"}
LABELS.update(THEME.get("labels") if isinstance(THEME.get("labels"), dict) else {})
DEFAULTS = dict(gain=100, loudness=100, bass=100, treble=100, clarity=100, echo=0, pitch=500)
SETTINGS = dict(DEFAULTS)
STATE = dict(a=None, b=None, ff=None)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("vcmusic")


def cfg():
    try:
        return json.load(open(CFG_FILE, encoding="utf-8"))
    except Exception:
        return {}


def save_cfg(c):
    with open(CFG_FILE, "w", encoding="utf-8") as f:
        json.dump(c, f)
    os.chmod(CFG_FILE, 0o600)


def build_filter(s):
    f = [f"volume={1 + s['gain'] / 100:.2f}", f"bass=g={s['bass'] / 50:.1f}", f"treble=g={s['treble'] / 50:.1f}",
         f"highpass=f={50 + s['clarity'] / 10:.0f}"]
    if s["loudness"] > 100:
        f.append(f"acompressor=threshold=0.1:ratio={2 + s['loudness'] / 125:.1f}:makeup={1 + s['loudness'] / 250:.1f}")
    if s["echo"]:
        f.append(f"aecho=0.8:0.8:{40 + s['echo'] / 10:.0f}:0.4")
    if s["pitch"] != 500:
        f.append(f"asetrate=48000*{1 + (s['pitch'] - 500) / 2500:.2f},aresample=48000")
    f.append("alimiter=limit=0.9")   # safety cap: stops clipping / ear-damaging peaks, keep it
    return ",".join(f)


def start_ffmpeg():
    if STATE["ff"]:
        STATE["ff"].kill()
    if not os.path.exists(FIFO):
        os.mkfifo(FIFO)
    STATE["ff"] = subprocess.Popen(
        ["ffmpeg", "-loglevel", "quiet", "-f", "s16le", "-ar", "48000", "-ac", "1", "-i", "pipe:0",
         "-af", build_filter(SETTINGS), "-f", "s16le", "-ar", "48000", "-ac", "2", "-y", FIFO],
        stdin=subprocess.PIPE)


def bar(v):
    n = round(v / 100)
    return T("bar_full", "█") * n + T("bar_empty", "░") * (10 - n)


def panel_text():
    rows = "\n".join(f"{LABELS[k]}: <code>{bar(v)}</code> {v}/1000" for k, v in SETTINGS.items())
    return f"{T('panel_title', '🎛 <b>CUSTOM MIX</b>')}\n\n{rows}"


from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as M, Update
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes
from pyrogram import Client
from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream, AudioQuality, RecordStream

U, C = {}, {}      # userbots and their PyTgCalls, keys "a" / "b"


def is_admin(update):
    u = update.effective_user
    return bool(u) and u.id in ADMINS


def home_kb():
    return M([[B(T("btn_panel", "🎛 Mix Panel"), callback_data="open"), B(T("btn_stop", "⏹ Stop"), callback_data="stop")],
              [B(T("btn_support", "💬 Support"), url=f"https://t.me/{SUPPORT.lstrip('@')}")]])


def panel_kb():
    rows = []
    for k, v in SETTINGS.items():
        rows.append([B("➖", callback_data=f"s:{k}:-100"), B(f"{LABELS[k]} {v}", callback_data="noop"),
                     B("➕", callback_data=f"s:{k}:100")])
    rows.append([B(T("btn_reset", "🔄 Reset"), callback_data="reset"), B(T("btn_stop", "⏹ Stop"), callback_data="stop")])
    return M(rows)


async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = T("welcome", "🎙 <b>{store}</b>").replace("{store}", html.escape(STORE))
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=home_kb() if is_admin(update) else None)


async def show_panel(update: Update, ctx):
    if is_admin(update):
        await update.message.reply_text(panel_text(), parse_mode="HTML", reply_markup=panel_kb())


async def setapi(update: Update, ctx):
    if not is_admin(update):
        return
    try:
        i, h = int(ctx.args[0]), ctx.args[1]
    except Exception:
        return await update.message.reply_text("Use: /setapi <api_id> <api_hash>")
    c = cfg(); c.update(api_id=i, api_hash=h); save_cfg(c)
    try:
        await update.message.delete()
    except Exception:
        pass
    await update.effective_chat.send_message("✅ API saved. Now /setsession a ... and /setsession b ..., then restart the bot from the panel.")


async def setsession(update: Update, ctx):
    if not is_admin(update):
        return
    try:
        which, s = ctx.args[0].lower(), ctx.args[1]
        assert which in ("a", "b")
    except Exception:
        return await update.message.reply_text("Use: /setsession a <string_session>   (or b)")
    c = cfg(); c["session_" + which] = s; save_cfg(c)
    try:
        await update.message.delete()          # remove the secret from the chat
    except Exception:
        pass
    await update.effective_chat.send_message(f"✅ Session {which.upper()} saved. Restart the bot from the panel after setting both.")


async def status(update: Update, ctx):
    if not is_admin(update):
        return
    c = cfg()
    ok = lambda x: "✅" if x else "❌"
    await update.message.reply_text(
        f"API {ok(c.get('api_id'))}  Session A {ok(c.get('session_a'))}  Session B {ok(c.get('session_b'))}\n"
        f"Userbots running: {ok(len(C) == 2)}   Bridge: {ok(STATE['a'])}")


async def on_frames(_, update):
    frames = getattr(update, "frames", None)
    ff = STATE["ff"]
    if not frames or not ff or ff.poll() is not None:
        return
    for fr in frames:
        try:
            ff.stdin.write(fr.frame)
        except (BrokenPipeError, ValueError):
            break


async def bridge(update: Update, ctx):
    if not is_admin(update):
        return
    if len(C) < 2:
        return await update.message.reply_text("Userbots not running. Set /setapi and both /setsession, then restart the bot.")
    try:
        a, b = int(ctx.args[0]), int(ctx.args[1])
    except Exception:
        return await update.message.reply_text("Use: /bridge <group_A_id> <group_B_id>")
    STATE["a"], STATE["b"] = a, b
    start_ffmpeg()
    await C["a"].play(a)
    await C["a"].record(a, RecordStream(True, AudioQuality.HIGH))
    await C["b"].play(b, MediaStream(FIFO, AudioQuality.HIGH, ffmpeg_parameters="-f s16le -ar 48000 -ac 2"))
    await update.message.reply_text("✅ Bridge ON", reply_markup=panel_kb())


async def do_stop():
    for k in ("a", "b"):
        if STATE[k] and k in C:
            try:
                await C[k].leave_call(STATE[k])
            except Exception:
                pass
        STATE[k] = None
    if STATE["ff"]:
        STATE["ff"].kill()
        STATE["ff"] = None


async def stop(update: Update, ctx):
    if is_admin(update):
        await do_stop()
        await update.message.reply_text("⏹ Bridge OFF")


async def cb(update: Update, ctx):
    q = update.callback_query
    if not is_admin(update):
        return await q.answer("Admins only", show_alert=True)
    d = q.data
    if d == "noop":
        return await q.answer()
    if d == "stop":
        await do_stop()
        return await q.answer("Bridge OFF")
    if d == "open":
        await q.message.reply_text(panel_text(), parse_mode="HTML", reply_markup=panel_kb())
        return await q.answer()
    if d == "reset":
        SETTINGS.update(DEFAULTS)
    elif d.startswith("s:"):
        _, k, step = d.split(":")
        if k in SETTINGS:
            SETTINGS[k] = max(0, min(1000, SETTINGS[k] + int(step)))
    if STATE["a"]:
        start_ffmpeg()      # new filter applied live
    try:
        await q.message.edit_text(panel_text(), parse_mode="HTML", reply_markup=panel_kb())
    except Exception:
        pass
    await q.answer("Updated")


async def post_init(app):
    c = cfg()
    if not (c.get("api_id") and c.get("session_a") and c.get("session_b")):
        log.info("Waiting for /setapi and /setsession from the admin")
        return
    try:
        for k in ("a", "b"):
            U[k] = Client(f"user_{k}", api_id=int(c["api_id"]), api_hash=c["api_hash"],
                          session_string=c["session_" + k], workdir=CWD)
            await U[k].start()
            C[k] = PyTgCalls(U[k])
            await C[k].start()
        C["a"].on_update()(on_frames)
        log.info("Userbots ready")
    except Exception as e:
        log.error("Userbot start failed: %s", e)
        C.clear()


async def post_shutdown(app):
    await do_stop()
    for x in list(U.values()):
        try:
            await x.stop()
        except Exception:
            pass


def main():
    if not TOKEN:
        raise SystemExit("BOT_TOKEN missing")
    app = Application.builder().token(TOKEN).post_init(post_init).post_shutdown(post_shutdown).build()
    for name, fn in (("start", start), ("panel", show_panel), ("setapi", setapi), ("setsession", setsession),
                     ("status", status), ("bridge", bridge), ("stop", stop)):
        app.add_handler(CommandHandler(name, fn))
    app.add_handler(CallbackQueryHandler(cb))
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
