#!/usr/bin/env python3
"""VC MINI SMM  -  premium Telegram SMM panel (Mini App + admin bot) for HostPanel.

Everything is controlled from the bot: send /admin (ADMIN_IDS only).
  - SMM providers (any standard v2 panel API: url + key), import services, margin (global / provider / category / service)
  - Payments: UPI QR (manual approve) + FamPay (FMPay) auto verify, base URL / key editable from the bot
  - Users, balance, bans, per-user discount, coupons, referral, broadcast, backup, maintenance mode and more
The Mini App page is served on WEBAPP_PORT and reached through the HostPanel Cloudflare tunnel (/pay/<bot id>/pay).
"""
import os, io, re, csv, json, time, hmac, base64, hashlib, sqlite3, asyncio, logging, threading, html, shutil
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qsl, quote

import requests
from telegram import (InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup,
                      Update, WebAppInfo)
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters

BASE = os.path.dirname(os.path.abspath(__file__))


def _load_env(path):
    try:
        for line in open(path, encoding="utf-8").read().splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
    except OSError:
        pass


_load_env(os.path.join(BASE, ".env"))
TOKEN = os.getenv("BOT_TOKEN", "")
ADMINS = {int(x) for x in os.getenv("ADMIN_IDS", "").replace(" ", "").split(",") if x.strip().isdigit()}
STORE = os.getenv("STORE_NAME", "VC Mini SMM")
SUPPORT = os.getenv("SUPPORT_USERNAME", "@support")
DB = os.path.join(BASE, os.getenv("DB_NAME", "store.db"))
LOGO = os.path.join(BASE, "logo.jpg")
PORT = int(os.getenv("WEBAPP_PORT", "8080"))
HOST = os.getenv("WEBAPP_HOST", "127.0.0.1")
WEBAPP_URL = os.getenv("WEBAPP_URL", "").strip().rstrip("/")
try:
    THEME = json.load(open(os.getenv("THEME_FILE", ""), encoding="utf-8"))
except Exception:
    THEME = {}
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("vcsmm")
esc = html.escape
LOOP = None
BOT = None
BOT_USER = ""


def TH(k, d=""):
    v = THEME.get(k)
    return v if isinstance(v, str) and v else d


# ───────────────────────── database ─────────────────────────
_lock = threading.RLock()


def _run(sql, args=(), mode="all"):
    with _lock:
        con = sqlite3.connect(DB, timeout=30)
        con.row_factory = sqlite3.Row
        try:
            cur = con.execute(sql, args)
            if mode == "all":
                return [dict(r) for r in cur.fetchall()]
            if mode == "one":
                r = cur.fetchone()
                return dict(r) if r else None
            con.commit()
            return cur.lastrowid if mode == "id" else cur.rowcount
        finally:
            con.close()


def q(sql, args=()):
    return _run(sql, args, "all")


def q1(sql, args=()):
    return _run(sql, args, "one")


def ex(sql, args=()):
    return _run(sql, args, "n")


def exid(sql, args=()):
    return _run(sql, args, "id")


SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users (telegram_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT, balance REAL DEFAULT 0,
  total_spent REAL DEFAULT 0, total_orders INTEGER DEFAULT 0, banned INTEGER DEFAULT 0, discount REAL DEFAULT 0,
  ref_by INTEGER, ref_earn REAL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS providers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, url TEXT, key TEXT, margin REAL,
  mult REAL DEFAULT 1, active INTEGER DEFAULT 1, balance TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, provider_id INTEGER, name TEXT, platform TEXT DEFAULT 'other',
  active INTEGER DEFAULT 1, margin REAL, sort INTEGER DEFAULT 0, UNIQUE(provider_id, name));
CREATE TABLE IF NOT EXISTS services (id INTEGER PRIMARY KEY AUTOINCREMENT, provider_id INTEGER, pid TEXT, cat_id INTEGER, name TEXT,
  rate REAL DEFAULT 0, min INTEGER DEFAULT 1, max INTEGER DEFAULT 1, type TEXT DEFAULT 'Default', refill INTEGER DEFAULT 0,
  cancel INTEGER DEFAULT 0, margin REAL, active INTEGER DEFAULT 1, avail INTEGER DEFAULT 1, descr TEXT DEFAULT '', UNIQUE(provider_id, pid));
CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, service_id INTEGER, provider_id INTEGER,
  provider_order TEXT, link TEXT, quantity INTEGER, price REAL, cost REAL DEFAULT 0, refunded REAL DEFAULT 0, status TEXT DEFAULT 'pending',
  start_count TEXT DEFAULT '', remains TEXT DEFAULT '', comments TEXT DEFAULT '', note TEXT DEFAULT '', refill_at TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, amount REAL, bonus REAL DEFAULT 0,
  mode TEXT, utr TEXT, status TEXT DEFAULT 'pending', approved_by TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE UNIQUE INDEX IF NOT EXISTS ux_utr ON transactions(utr) WHERE utr IS NOT NULL AND status IN ('approved','review');
CREATE TABLE IF NOT EXISTS coupons (code TEXT PRIMARY KEY, amount REAL, max_uses INTEGER, used INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS coupon_log (code TEXT, user_id INTEGER, PRIMARY KEY(code, user_id));
CREATE INDEX IF NOT EXISTS ix_orders_user ON orders(user_id, id);
CREATE INDEX IF NOT EXISTS ix_services_cat ON services(cat_id);
"""


def init_db():
    with _lock:
        con = sqlite3.connect(DB, timeout=30)
        con.executescript(SCHEMA)
        con.commit()
        con.close()


DEFAULTS = {
    "store_name": STORE,
    "welcome": TH("welcome", "🚀 <b>WELCOME TO {store}</b>\n\n👋 Hi {name}! Ready to grow your social media?\n\n"
                  "📱 Open our SMM Panel to explore services.\n🛒 Select your service and place an order.\n"
                  "⚡ Fast &amp; Easy Ordering\n💰 Affordable Prices\n📈 Instagram, Telegram &amp; More Services\n\n"
                  "👇 Tap the button below to open the panel and place your order!"),
    "support": SUPPORT, "channel": "", "developer": "", "announcement": "", "credit": "",
    "global_margin": "30", "min_order": "0", "maintenance": "0", "block_dup": "1", "notify_orders": "1", "notify_users": "1",
    "auto_sync": "1", "low_balance": "0", "ref_percent": "5",
    "upi_id": "", "upi_name": STORE, "fampay_key": os.getenv("FMPAY_API_KEY", ""),
    "fampay_url": os.getenv("FMPAY_BASE_URL", "https://famapi-sas5.onrender.com"),
    "pay_auto_on": "1", "pay_manual_on": "1", "min_deposit": "10", "max_deposit": "50000", "deposit_bonus": "0",
}
_SC = {}


def S(k):
    if k in _SC:
        return _SC[k]
    r = q1("SELECT value FROM settings WHERE key=?", (k,))
    v = r["value"] if r else DEFAULTS.get(k, "")
    _SC[k] = v
    return v


def SF(k, d=0.0):
    try:
        return float(S(k))
    except (TypeError, ValueError):
        return d


def SET(k, v):
    ex("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v)))
    _SC[k] = str(v)


def tglink(v):
    v = (v or "").strip()
    if not v:
        return ""
    if v.startswith("http"):
        return v
    return "https://t.me/" + v.lstrip("@").replace("t.me/", "")


def money(x):
    return f"₹{float(x):,.2f}"


def now_ist():
    return time.strftime("%d %b %H:%M", time.gmtime(time.time() + 19800))


# ───────────────────────── notifications (from any thread) ─────────────────────────
def tg(chat, text, markup=None):
    if not (LOOP and BOT):
        return

    async def _s():
        try:
            await BOT.send_message(chat, text, parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True)
        except Exception as e:
            log.warning("send to %s failed: %s", chat, e)
    asyncio.run_coroutine_threadsafe(_s(), LOOP)


def tg_admins(text, markup=None):
    for a in ADMINS:
        tg(a, text, markup)


# ───────────────────────── users ─────────────────────────
def ensure_user(u, ref=None):
    uid = int(u["id"])
    name = (u.get("first_name") or "") + ((" " + u["last_name"]) if u.get("last_name") else "")
    row = q1("SELECT * FROM users WHERE telegram_id=?", (uid,))
    if row:
        if (row["username"] or "") != (u.get("username") or "") or (row["first_name"] or "") != name:
            ex("UPDATE users SET username=?, first_name=? WHERE telegram_id=?", (u.get("username") or "", name, uid))
            row.update(username=u.get("username") or "", first_name=name)
        return row
    rb = ref if ref and ref != uid and q1("SELECT 1 x FROM users WHERE telegram_id=?", (ref,)) else None
    ex("INSERT OR IGNORE INTO users(telegram_id, username, first_name, ref_by) VALUES(?,?,?,?)", (uid, u.get("username") or "", name, rb))
    if S("notify_users") == "1":
        tg_admins(f"🆕 <b>New user</b>\n{esc(name)} @{esc(u.get('username') or '-')}\n🆔 <code>{uid}</code>")
    return q1("SELECT * FROM users WHERE telegram_id=?", (uid,))


# ───────────────────────── providers (standard SMM v2 API) ─────────────────────────
class ApiErr(Exception):
    pass


def papi(p, **data):
    try:
        r = requests.post(p["url"], data={"key": p["key"], **data}, timeout=60, headers={"User-Agent": "Mozilla/5.0"})
        j = r.json()
    except requests.RequestException as e:
        raise ApiErr(f"network: {e}")
    except ValueError:
        raise ApiErr(f"bad reply (HTTP {r.status_code})")
    if isinstance(j, dict) and j.get("error"):
        raise ApiErr(str(j["error"])[:200])
    return j


PLATFORMS = [("telegram", "Telegram", ["telegram", "tg ", "t.me"]), ("instagram", "Instagram", ["instagram", "insta", " ig "]),
             ("youtube", "YouTube", ["youtube", "yt "]), ("facebook", "Facebook", ["facebook", " fb "]),
             ("twitter", "Twitter / X", ["twitter", "tweet", " x "]), ("tiktok", "TikTok", ["tiktok", "tik tok"]),
             ("whatsapp", "WhatsApp", ["whatsapp"]), ("threads", "Threads", ["threads"]), ("spotify", "Spotify", ["spotify"]),
             ("linkedin", "LinkedIn", ["linkedin"]), ("snapchat", "Snapchat", ["snapchat"]), ("discord", "Discord", ["discord"]),
             ("website", "Website Traffic", ["website", "traffic", "seo"])]
PLAT_NAME = {p[0]: p[1] for p in PLATFORMS}
PLAT_NAME["other"] = "Other"


def detect_platform(*parts):
    t = " " + " ".join(parts).lower() + " "
    for pid, _n, keys in PLATFORMS:
        if any(k in t for k in keys):
            return pid
    return "other"


def import_services(pid):
    p = q1("SELECT * FROM providers WHERE id=?", (pid,))
    lst = papi(p, action="services")
    if not isinstance(lst, list):
        raise ApiErr("services list not returned")
    new = upd = 0
    seen = set()
    for s in lst:
        try:
            sp = str(s["service"])
            cat = (str(s.get("category") or "General")).strip()[:90]
            nm = (str(s.get("name") or sp)).strip()[:200]
            rate = float(s.get("rate") or 0)
            mn, mx = int(float(s.get("min") or 1)), int(float(s.get("max") or 1))
        except (KeyError, ValueError, TypeError):
            continue
        seen.add(sp)
        c = q1("SELECT id FROM categories WHERE provider_id=? AND name=?", (pid, cat))
        cid = c["id"] if c else exid("INSERT INTO categories(provider_id,name,platform) VALUES(?,?,?)", (pid, cat, detect_platform(cat, nm)))
        typ = str(s.get("type") or "Default")
        refill = 1 if s.get("refill") in (True, 1, "1", "true") else 0
        canc = 1 if s.get("cancel") in (True, 1, "1", "true") else 0
        if q1("SELECT id FROM services WHERE provider_id=? AND pid=?", (pid, sp)):
            ex("UPDATE services SET name=?, rate=?, min=?, max=?, type=?, refill=?, cancel=?, avail=1 WHERE provider_id=? AND pid=?",
               (nm, rate, mn, mx, typ, refill, canc, pid, sp))
            upd += 1
        else:
            exid("INSERT INTO services(provider_id,pid,cat_id,name,rate,min,max,type,refill,cancel) VALUES(?,?,?,?,?,?,?,?,?,?)",
                 (pid, sp, cid, nm, rate, mn, mx, typ, refill, canc))
            new += 1
    gone = 0
    for r in q("SELECT id, pid FROM services WHERE provider_id=? AND avail=1", (pid,)):
        if r["pid"] not in seen:
            ex("UPDATE services SET avail=0 WHERE id=?", (r["id"],))
            gone += 1
    return new, upd, gone


# ───────────────────────── pricing ─────────────────────────
SVC_SQL = ("SELECT s.*, c.name cname, c.platform plat, c.active cact, c.margin cm, pr.name prname, pr.margin pm, pr.mult mult, "
           "pr.active pact FROM services s JOIN categories c ON c.id=s.cat_id JOIN providers pr ON pr.id=s.provider_id ")
OK_TYPES = "LOWER(s.type) IN ('default','custom comments')"
LIVE = f"s.active=1 AND s.avail=1 AND c.active=1 AND pr.active=1 AND {OK_TYPES}"


def eff_margin(s):
    for k in ("margin", "cm", "pm"):
        if s.get(k) is not None:
            return float(s[k])
    return SF("global_margin", 30)


def sell_rate(s):
    """selling price per 1000 (before the user's personal discount)"""
    return round(float(s["rate"]) * float(s.get("mult") or 1) * (1 + eff_margin(s) / 100), 4)


def cost_rate(s):
    return float(s["rate"]) * float(s.get("mult") or 1)


HTML = r'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover">
<title>__STORE__</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
:root{--c1:#00d2ff;--c2:#3a6fd8;--n1:#0b1020;--n2:#1a2347;--bg:#f3f5fb;--card:#fff;--ink:#0f172a;--mut:#64748b;--line:#e8ecf4;--ac:#4f46e5;--ok:#16a34a;--warn:#d97706;--bad:#dc2626;--sh:0 8px 30px rgba(15,23,42,.07)}
.dark{--bg:#080c18;--card:#121a30;--ink:#eef2ff;--mut:#8b97b5;--line:#222c4a;--sh:0 8px 30px rgba(0,0,0,.35)}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;background:var(--bg);color:var(--ink);font-family:Poppins,system-ui,-apple-system,Segoe UI,Roboto,sans-serif;font-size:15px}
#app{max-width:560px;margin:0 auto;padding:14px 14px 130px}
h1,h2,h3,p{margin:0}
.ic{display:inline-block;vertical-align:middle;flex:none}
.head{display:flex;align-items:center;gap:10px;padding:6px 2px 14px}
.head .t{font-size:19px;font-weight:700;flex:1;display:flex;align-items:center;gap:10px}
.head .t .ic{color:#3b82f6}
.pill-btn{display:flex;align-items:center;gap:7px;border:0;background:rgba(59,130,246,.12);color:#3b82f6;font:600 13px Poppins;padding:10px 16px;border-radius:14px}
.hero{background:linear-gradient(135deg,var(--n1),var(--n2));color:#fff;border-radius:28px;padding:22px;box-shadow:0 18px 40px rgba(11,16,32,.35);position:relative;overflow:hidden}
.hero:after{content:"";position:absolute;right:-60px;top:-60px;width:180px;height:180px;border-radius:50%;background:radial-gradient(circle,rgba(0,210,255,.25),transparent 70%)}
.who{display:flex;align-items:center;gap:14px;position:relative;z-index:1}
.av{width:62px;height:62px;border-radius:50%;background:#1e293b center/cover;border:3px solid rgba(255,255,255,.18);flex:none;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:24px;position:relative}
.av i{position:absolute;right:0;bottom:2px;width:15px;height:15px;border-radius:50%;background:#22c55e;border:2px solid var(--n1)}
.nm{font-size:17px;font-weight:700;display:flex;align-items:center;gap:6px;line-height:1.2}
.vf{width:18px;height:18px;border-radius:50%;background:#1d9bf0;display:inline-flex;align-items:center;justify-content:center;flex:none}
.tag{display:inline-flex;align-items:center;gap:6px;margin-top:8px;border:1px solid rgba(251,191,36,.5);color:#fbbf24;padding:6px 14px;border-radius:99px;font-size:12px;font-weight:500}
.sep{height:1px;background:rgba(255,255,255,.1);margin:18px 0 14px;position:relative;z-index:1}
.lab{font-size:11px;letter-spacing:.14em;color:#9aa6c4;text-transform:uppercase;position:relative;z-index:1}
.bal{font-size:36px;font-weight:800;letter-spacing:-.5px;position:relative;z-index:1;margin-top:4px}
.sec{display:flex;align-items:center;gap:10px;font-weight:700;font-size:17px;margin:24px 2px 12px}
.sec .ic{color:#8b5cf6}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.pc{background:var(--card);border-radius:22px;padding:22px 10px 18px;text-align:center;box-shadow:var(--sh);font-weight:600;border:1px solid var(--line);transition:.15s}
.pc:active{transform:scale(.96)}
.pc .pi{width:52px;height:52px;margin:0 auto 10px}
.pc small{display:block;color:var(--mut);font-weight:500;font-size:11px;margin-top:2px}
.fast{margin-top:22px;border:1.5px solid #a7f0cc;background:linear-gradient(135deg,#ecfdf5,#d1fae5);border-radius:24px;padding:22px;text-align:center;color:#065f46}
.fast b{display:block;font-size:19px;margin:6px 0}.fast span{font-size:13.5px;opacity:.9;line-height:1.5}
.dark .fast{background:linear-gradient(135deg,#0b2a22,#0e3a2d);border-color:#14533f;color:#6ee7b7}
.card{background:var(--card);border-radius:24px;padding:20px;box-shadow:var(--sh);border:1px solid var(--line);margin-bottom:14px}
.row{display:flex;align-items:center;gap:12px}
.li{display:flex;align-items:center;gap:12px;background:var(--card);border:1px solid var(--line);border-radius:18px;padding:14px;margin-bottom:10px;box-shadow:var(--sh);width:100%;text-align:left;font:inherit;color:inherit}
.li:active{transform:scale(.985)}
.li .g{flex:1;min-width:0}.li .n{font-weight:600;font-size:14px;line-height:1.35}.li .s{color:var(--mut);font-size:12px;margin-top:3px}
.li .pr{font-weight:700;color:var(--c2);font-size:13px;white-space:nowrap;text-align:right}
.btn{width:100%;border:0;border-radius:18px;padding:17px;font:700 17px Poppins;color:#fff;background:linear-gradient(90deg,var(--c1),var(--c2));box-shadow:0 10px 24px rgba(58,111,216,.35);display:flex;align-items:center;justify-content:center;gap:10px;cursor:pointer}
.btn:disabled{opacity:.55}.btn.sm{padding:11px;font-size:14px;border-radius:14px;box-shadow:none}
.btn.ghost{background:transparent;color:var(--mut);box-shadow:none;font-weight:600;font-size:14px;padding:12px}
.fld{display:block;margin:14px 0 8px;color:var(--mut);font-weight:500;font-size:14px}
.inp{width:100%;border:2px solid var(--line);background:var(--bg);color:var(--ink);border-radius:18px;padding:16px 16px;font:600 17px Poppins;outline:none}
.inp:focus{border-color:var(--c2)}textarea.inp{font-size:14px;min-height:110px;resize:vertical}
.pre{position:relative}.pre b{position:absolute;left:18px;top:50%;transform:translateY(-50%);color:var(--c2);font-size:20px}.pre .inp{padding-left:46px}
.seg{display:flex;background:var(--card);border-radius:22px;padding:7px;box-shadow:var(--sh);margin:16px 0;border:1px solid var(--line)}
.seg button{flex:1;border:0;border-radius:16px;padding:14px;background:transparent;color:var(--mut);font:600 16px Poppins;display:flex;gap:9px;align-items:center;justify-content:center}
.seg button.on{background:linear-gradient(90deg,var(--c1),var(--c2));color:#fff;box-shadow:0 8px 20px rgba(58,111,216,.35)}.seg button:disabled{opacity:.4}
.chips{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0 4px}
.chip{border:1.5px solid var(--line);background:var(--card);color:var(--ink);border-radius:99px;padding:8px 15px;font:600 13px Poppins}
.chip:active{background:var(--c2);color:#fff}
.st{display:inline-block;padding:3px 11px;border-radius:99px;font-size:11px;font-weight:700;text-transform:capitalize}
.s-pending{background:#fef3c7;color:#92400e}.s-processing{background:#dbeafe;color:#1d4ed8}.s-completed,.s-approved{background:#dcfce7;color:#166534}
.s-partial{background:#ede9fe;color:#6d28d9}.s-canceled,.s-failed,.s-rejected,.s-expired{background:#fee2e2;color:#b91c1c}.s-review{background:#ffedd5;color:#c2410c}
.oc{background:var(--card);border-radius:22px;padding:16px 16px 16px 18px;margin-bottom:12px;border:1px solid var(--line);box-shadow:var(--sh);border-left:5px solid var(--c2)}
.oc .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;font-size:13px;color:var(--mut);font-weight:600}
.oc .nm2{font-weight:600;font-size:14px;line-height:1.35}.oc .lk{color:var(--mut);font-size:12px;margin:4px 0 10px;word-break:break-all}
.kv{display:flex;gap:16px;flex-wrap:wrap;font-size:12px;color:var(--mut)}.kv b{color:var(--ink);display:block;font-size:14px}
.sk{background:var(--card);border-radius:24px;padding:20px;margin-bottom:14px;border:1px solid var(--line)}
.sk i{display:block;height:14px;border-radius:9px;margin:12px 0;background:linear-gradient(90deg,#e5e9f2 25%,#f3f5fa 50%,#e5e9f2 75%);background-size:200% 100%;animation:sh 1.3s infinite}
.dark .sk i{background:linear-gradient(90deg,#1b2440 25%,#252f52 50%,#1b2440 75%);background-size:200% 100%}
@keyframes sh{to{background-position:-200% 0}}
.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:11px;margin:16px 0}
.stat{background:linear-gradient(160deg,var(--n1),var(--n2));color:#fff;border-radius:22px;padding:18px 8px;text-align:center}
.stat .ic{color:#94a3b8}.stat small{display:block;font-size:10.5px;letter-spacing:.1em;color:#a8b3cf;margin:8px 0 4px;text-transform:uppercase}.stat b{font-size:13.5px}
.link{display:flex;align-items:center;gap:16px;background:var(--card);border-radius:24px;padding:16px;margin-bottom:12px;box-shadow:var(--sh);border:1px solid var(--line);width:100%;font:700 18px Poppins;color:var(--ink);text-align:left}
.link .bx{width:54px;height:54px;border-radius:17px;display:flex;align-items:center;justify-content:center}.link>span{flex:1}.link .ic:last-child{color:#94a3b8}
.foot{text-align:center;color:var(--mut);margin:34px 0 10px;font-size:14px;letter-spacing:.04em}.foot b{display:block;font-size:17px;letter-spacing:.06em;background:linear-gradient(90deg,var(--c1),var(--c2));-webkit-background-clip:text;color:transparent;margin-top:2px}
.heart{color:#ef4444}
#nav{position:fixed;left:0;right:0;bottom:0;z-index:20;display:flex;justify-content:center;pointer-events:none}
#nav .in{pointer-events:auto;width:100%;max-width:560px;background:var(--card);border-radius:30px 30px 0 0;display:flex;padding:16px 6px calc(14px + env(safe-area-inset-bottom));box-shadow:0 -10px 40px rgba(15,23,42,.12);border-top:1px solid var(--line)}
#nav button{flex:1;border:0;background:none;color:var(--mut);font:500 14px Poppins;display:flex;flex-direction:column;align-items:center;gap:4px;position:relative}
#nav button.on{color:var(--ac)}#nav button.on:after{content:"";width:7px;height:7px;border-radius:50%;background:var(--ac);margin-top:3px}#nav button:not(.on):after{content:"";height:10px}
#ov{position:fixed;inset:0;background:rgba(2,6,23,.55);z-index:40;display:none;align-items:flex-end;justify-content:center;backdrop-filter:blur(3px)}
#sheet{background:var(--card);width:100%;max-width:560px;border-radius:28px 28px 0 0;padding:20px 20px calc(24px + env(safe-area-inset-bottom));max-height:92vh;overflow:auto;animation:up .25s}
@keyframes up{from{transform:translateY(60px);opacity:0}}
.grab{width:44px;height:5px;border-radius:9px;background:var(--line);margin:-6px auto 14px}
#toast{position:fixed;top:14px;left:50%;transform:translate(-50%,-90px);background:#0f172a;color:#fff;padding:13px 20px;border-radius:16px;z-index:99;font-weight:600;font-size:14px;transition:.3s;max-width:90%;text-align:center;box-shadow:0 12px 30px rgba(0,0,0,.3)}
#toast.on{transform:translate(-50%,0)}#toast.err{background:#b91c1c}#toast.ok{background:#15803d}
.banner{background:linear-gradient(90deg,#fef3c7,#fde68a);color:#78350f;border-radius:18px;padding:13px 16px;margin-top:16px;font-size:13.5px;font-weight:500;display:flex;gap:10px}
.srch{position:relative;margin-top:16px}.srch .ic{position:absolute;left:16px;top:50%;transform:translateY(-50%);color:var(--mut)}.srch .inp{padding-left:46px;font-size:15px;border-radius:99px}
.qr{display:block;margin:6px auto 12px;width:230px;max-width:70%;border-radius:20px;border:1px solid var(--line);padding:8px;background:#fff}
.steps{display:flex;gap:6px;justify-content:center;margin-bottom:12px}.steps span{height:5px;width:46px;border-radius:9px;background:var(--line)}.steps span.on{background:linear-gradient(90deg,var(--c1),var(--c2))}
.big{text-align:center;font-size:30px;font-weight:800}.cp{display:flex;align-items:center;justify-content:space-between;gap:10px;background:var(--bg);border-radius:14px;padding:12px 14px;font-weight:600;font-size:14px;margin:8px 0}
.done{text-align:center;padding:20px 0}.done .ck{width:84px;height:84px;border-radius:50%;background:#dcfce7;color:#16a34a;margin:0 auto 14px;display:flex;align-items:center;justify-content:center;animation:pop .5s}
@keyframes pop{0%{transform:scale(.3)}70%{transform:scale(1.12)}100%{transform:scale(1)}}
.empty{text-align:center;color:var(--mut);padding:40px 10px;font-size:14px}
.desc{white-space:pre-wrap;font-size:12.5px;color:var(--mut);background:var(--bg);border-radius:14px;padding:11px 13px;margin:10px 0;max-height:130px;overflow:auto}
.tot{display:flex;justify-content:space-between;align-items:center;margin:14px 2px;font-weight:600}.tot b{font-size:22px;color:var(--c2)}
.crumb{display:flex;align-items:center;gap:8px;color:var(--mut);font-size:13px;margin:4px 2px 14px;flex-wrap:wrap}.crumb b{color:var(--ink)}
</style></head><body>
<div id="app"><div id="top"></div><div id="main"></div><div class="foot" id="foot"></div></div>
<div id="nav"><div class="in" id="navin"></div></div>
<div id="ov"><div id="sheet"></div></div><div id="toast"></div>
<script>
const tg=window.Telegram&&Telegram.WebApp;
if(tg){try{tg.ready();tg.expand();tg.setHeaderColor('#1f2937');tg.setBackgroundColor(tg.colorScheme==='dark'?'#080c18':'#f3f5fb');if(tg.colorScheme==='dark')document.documentElement.classList.add('dark')}catch(e){}}
const TH=__THEME__;
{const r=document.documentElement.style;if(TH.c1)r.setProperty('--c1',TH.c1);if(TH.c2)r.setProperty('--c2',TH.c2);if(TH.n1)r.setProperty('--n1',TH.n1);if(TH.n2)r.setProperty('--n2',TH.n2);if(TH.bg&&!document.documentElement.classList.contains('dark'))r.setProperty('--bg',TH.bg)}
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const P={home:'<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',orders:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',wallet:'<path d="M20 12V8a2 2 0 0 0-2-2H4a2 2 0 0 1 0-4h14v4"/><path d="M4 6v12a2 2 0 0 0 2 2h14v-4"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/>',user:'<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',refresh:'<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.5 9a9 9 0 0 1 14.9-3.4L23 10M1 14l4.6 4.4A9 9 0 0 0 20.5 15"/>',search:'<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.7" y2="16.7"/>',copy:'<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',zap:'<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',head:'<path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/>',code:'<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>',mega:'<path d="M3 11v2a1 1 0 0 0 1 1h3l5 4V6L7 10H4a1 1 0 0 0-1 1z"/><path d="M16 8a5 5 0 0 1 0 8"/>',ext:'<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>',chev:'<polyline points="9 18 15 12 9 6"/>',grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',check:'<polyline points="20 6 9 17 4 12"/>',hand:'<path d="M12 2v6M8 6v6a4 4 0 0 0 8 0V6"/><path d="M4 14l3 6h10l3-6"/>',qr:'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3h-3zM20 14v.01M14 20h3M20 17v4"/>',phone:'<rect x="5" y="2" width="14" height="20" rx="3"/><line x1="12" y1="18" x2="12.01" y2="18"/>',gift:'<polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>',chart:'<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',finger:'<path d="M12 11c0 3-1 6-3 8M8 8a5 5 0 0 1 9 3c0 2 0 4-1 6M5 11a7 7 0 0 1 2-5M12 7v.01"/>',tag:'<path d="M20.6 13.4l-7.2 7.2a2 2 0 0 1-2.8 0L2 12V2h10l8.6 8.6a2 2 0 0 1 0 2.8z"/><circle cx="7" cy="7" r="1.5"/>'};
const ic=(n,s=22)=>`<svg class="ic" viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${P[n]||''}</svg>`;
const PCOL={youtube:['#ff0000','▶'],facebook:['#1877f2','f'],twitter:['#111827','𝕏'],tiktok:['#111827','♪'],whatsapp:['#25d366','✆'],threads:['#111827','@'],spotify:['#1db954','♫'],linkedin:['#0a66c2','in'],snapchat:['#fffc00','👻'],discord:['#5865f2','◍'],website:['#6366f1','🌐'],other:['#64748b','★']};
function picon(id,sz=52){
 if(id==='telegram')return `<svg viewBox="0 0 24 24" width="${sz}" height="${sz}"><circle cx="12" cy="12" r="12" fill="#0088cc"/><path d="M17.5 7.2l-1.9 9c-.1.6-.5.8-1 .5l-2.8-2.1-1.4 1.3c-.2.2-.3.3-.6.3l.2-2.9 5.2-4.7c.2-.2 0-.3-.3-.1l-6.5 4.1-2.8-.9c-.6-.2-.6-.6.1-.9l10.9-4.2c.5-.2.9.1.8.6z" fill="#fff"/></svg>`;
 if(id==='instagram')return `<svg viewBox="0 0 24 24" width="${sz}" height="${sz}"><defs><linearGradient id="ig" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#feda75"/><stop offset=".3" stop-color="#fa7e1e"/><stop offset=".55" stop-color="#d62976"/><stop offset=".8" stop-color="#962fbf"/><stop offset="1" stop-color="#4f5bd5"/></linearGradient></defs><rect x="1.5" y="1.5" width="21" height="21" rx="6.5" fill="none" stroke="url(#ig)" stroke-width="2.2"/><circle cx="12" cy="12" r="5" fill="none" stroke="url(#ig)" stroke-width="2.2"/><circle cx="17.6" cy="6.4" r="1.4" fill="#d62976"/></svg>`;
 const c=PCOL[id]||PCOL.other;return `<div style="width:${sz}px;height:${sz}px;border-radius:50%;background:${c[0]};color:${id==='snapchat'?'#000':'#fff'};display:flex;align-items:center;justify-content:center;font-weight:700;font-size:${sz*.42}px">${c[1]}</div>`}
const BASE=location.pathname.replace(/\/pay\/?$/,'');
const S={user:null,cfg:null,plats:[],tab:'home',nav:{lvl:'plats'},w:{mode:'manual',tx:null,done:null},orders:null,deps:null,busy:false};
async function api(a,d={}){try{const r=await fetch(BASE+'/api/verify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({a,init:tg?tg.initData:'',...d})});return await r.json()}catch(e){return{ok:false,msg:'Network error. Check your connection.'}}}
let tt;function toast(m,k){const t=$('#toast');t.textContent=m;t.className='on '+(k||'');clearTimeout(tt);tt=setTimeout(()=>t.className='',2800);try{tg&&tg.HapticFeedback&&(k==='err'?tg.HapticFeedback.notificationOccurred('error'):k==='ok'&&tg.HapticFeedback.notificationOccurred('success'))}catch(e){}}
const fm=n=>Number(n||0).toFixed(4),pr=n=>'₹'+Number(n).toFixed(n<1?4:2),sc=()=>{};
function openL(u){if(!u)return toast('Not set by admin yet','err');try{if(/^https?:\/\/t\.me\//.test(u)&&tg)tg.openTelegramLink(u);else if(tg)tg.openLink(u);else window.open(u,'_blank')}catch(e){window.open(u,'_blank')}}
function copy(t){try{navigator.clipboard.writeText(t);toast('Copied','ok')}catch(e){const i=document.createElement('input');i.value=t;document.body.appendChild(i);i.select();document.execCommand('copy');i.remove();toast('Copied','ok')}}
const skel=n=>Array.from({length:n},()=>'<div class="sk"><i style="width:40%"></i><i style="width:80%"></i><i></i><i style="width:60%"></i></div>').join('');
function nav(){const T=[['home','Home'],['orders','Orders'],['wallet','Wallet'],['user','Profile']];$('#navin').innerHTML=T.map(([k,l])=>{const t=k==='user'?'profile':k;return `<button class="${S.tab===t?'on':''}" onclick="setTab('${t}')">${ic(k,26)}<span>${l}</span></button>`}).join('');
 if(tg){const b=tg.BackButton;if(S.tab==='home'&&S.nav.lvl!=='plats')b.show();else b.hide()}}
function back(){const n=S.nav;if(n.lvl==='svcs')S.nav=n.from==='search'?{lvl:'search',q:n.q,list:n.slist}:{lvl:'cats',plat:n.plat,platName:n.platName,cats:n.cats};else S.nav={lvl:'plats'};render()}
function setTab(t){S.tab=t;if(t==='home')S.nav={lvl:'plats'};if(t==='orders')loadOrders();if(t==='wallet')S.w.tx||loadDeps();render();scrollTo(0,0)}
function head(title,icn,right){$('#top').innerHTML=`<div class="head"><div class="t">${icn?ic(icn,26):''}${title}</div>${right||''}</div>`}
function render(){nav();$('#foot').innerHTML='';({home:rHome,orders:rOrders,wallet:rWallet,profile:rProfile})[S.tab]()}
function hero(){const u=S.user,i=(u.name||'U')[0].toUpperCase();return `<div class="hero"><div class="who"><div class="av" style="${u.photo?`background-image:url('${esc(u.photo)}')`:''}">${u.photo?'':i}<i></i></div><div><div class="nm">${esc(u.name)}<span class="vf">${ic('check',11).replace('currentColor','#fff')}</span></div><div class="tag">✈ Telegram Connected</div></div></div><div class="sep"></div><div class="lab">Available Balance</div><div class="bal">₹ ${fm(u.balance)}</div></div>`}
function rHome(){head('','');$('#top').innerHTML='';const n=S.nav;let h='';
 if(n.lvl==='plats'){h=hero()+(S.cfg.banner?`<div class="banner">📣<div>${esc(S.cfg.banner)}</div></div>`:'')+`<div class="srch">${ic('search',18)}<input class="inp" id="q" placeholder="Search services (e.g. followers, likes)" oninput="srch(this.value)"></div><div id="sres"></div><div id="plist"><div class="sec">${ic('grid',24)}Select Service</div>`+(S.plats.length?`<div class="grid">${S.plats.map(p=>`<button class="pc" style="border:1px solid var(--line);font-family:inherit;color:inherit" onclick="openPlat('${p.id}')"><div class="pi">${picon(p.id)}</div>${esc(p.name)}<small>${p.n} services</small></button>`).join('')}</div>`:`<div class="empty">No services yet.<br>Admin is setting things up.</div>`)+`<div class="fast">${ic('zap',44).replace('currentColor','#10b981')}<b>Fast &amp; Instant Delivery</b><span>All our services are delivered automatically. Choose your platform and start growing today!</span></div></div>`}
 else if(n.lvl==='cats'){h=`<div class="head"><div class="t">${picon(n.plat,34)}${esc(n.platName)}</div></div>`+(n.cats?n.cats.length?n.cats.map(c=>`<button class="li" onclick="openCat(${c.id})"><div class="g"><div class="n">${esc(c.name)}</div><div class="s">${c.n} services</div></div>${ic('chev',20)}</button>`).join(''):'<div class="empty">No categories</div>':skel(3))}
 else if(n.lvl==='svcs'){h=`<div class="head"><div class="t" style="font-size:16px">${esc(n.catName||'Services')}</div></div>`+svcList(n.list)}
 else if(n.lvl==='search'){h=`<div class="head"><div class="t">Search</div></div>`+svcList(n.list)}
 $('#main').innerHTML=h}
function svcList(l){if(!l)return skel(3);if(!l.length)return '<div class="empty">Nothing found</div>';return l.map((s,i)=>`<button class="li" onclick="openSvc(${i})"><div class="g"><div class="n">${esc(s.name)}</div><div class="s">#${s.id} · Min ${s.min} · Max ${s.max}${s.refill?' · ♻ Refill':''}</div></div><div class="pr">${pr(s.rate)}<div class="s" style="font-weight:500">/1000</div></div></button>`).join('')}
async function openPlat(id){const p=S.plats.find(x=>x.id===id);S.nav={lvl:'cats',plat:id,platName:p.name,cats:null};render();scrollTo(0,0);const r=await api('cats',{plat:id});if(r.ok){S.nav.cats=r.cats;render()}else toast(r.msg,'err')}
async function openCat(id){const c=S.nav.cats.find(x=>x.id===id);S.nav={lvl:'svcs',plat:S.nav.plat,platName:S.nav.platName,cats:S.nav.cats,cat:id,catName:c.name,list:null};render();scrollTo(0,0);const r=await api('svcs',{cat:id});if(r.ok){S.nav.list=r.svcs;render()}else toast(r.msg,'err')}
let st;function srch(v){clearTimeout(st);const o=$('#sres'),l=$('#plist');if(v.trim().length<2){o.innerHTML='';l.style.display='';return}st=setTimeout(async()=>{const r=await api('search',{q:v.trim()});if(!r.ok)return;l.style.display='none';S.sl=r.svcs;o.innerHTML=`<div class="sec">${ic('search',22)}Results</div>`+(r.svcs.length?r.svcs.map((s,i)=>`<button class="li" onclick="openSvc(${i},true)"><div class="g"><div class="n">${esc(s.name)}</div><div class="s">#${s.id} · ${esc(s.cat)}</div></div><div class="pr">${pr(s.rate)}</div></button>`).join(''):'<div class="empty">Nothing found</div>')},350)}
function sheet(h){$('#sheet').innerHTML='<div class="grab"></div>'+h;$('#ov').style.display='flex'}
function closeSheet(){$('#ov').style.display='none'}
$('#ov').addEventListener('click',e=>{if(e.target.id==='ov')closeSheet()});
function openSvc(i,fromSearch){const s=(fromSearch?S.sl:S.nav.list)[i];S.cur=s;const cm=s.type==='custom comments';
 sheet(`<div class="row" style="align-items:flex-start"><div style="flex:1"><div style="font-weight:700;font-size:16px;line-height:1.35">${esc(s.name)}</div><div style="color:var(--mut);font-size:12px;margin-top:4px">#${s.id} · ${esc(s.cat||'')}</div></div><div style="text-align:right"><b style="color:var(--c2);font-size:17px">${pr(s.rate)}</b><div style="font-size:11px;color:var(--mut)">per 1000</div></div></div>
 ${s.desc?`<div class="desc">${esc(s.desc)}</div>`:''}
 <label class="fld">Link / Username</label><input class="inp" id="olink" placeholder="https://t.me/yourchannel" autocapitalize="off" autocomplete="off" style="font-size:15px">
 ${cm?`<label class="fld">Comments (one per line)</label><textarea class="inp" id="ocm" oninput="tot()"></textarea>`:`<label class="fld">Quantity (Min ${s.min} · Max ${s.max})</label><input class="inp" id="oq" type="number" inputmode="numeric" placeholder="${s.min}" oninput="tot()"><div class="chips">${[s.min,1000,5000,10000].filter((v,k,a)=>v>=s.min&&v<=s.max&&a.indexOf(v)===k).map(v=>`<button class="chip" onclick="document.getElementById('oq').value=${v};tot()">${v}</button>`).join('')}</div>`}
 <div class="tot"><span>Total<div style="font-size:11px;color:var(--mut);font-weight:500">Balance ${pr(S.user.balance)}${S.user.discount?` · ${S.user.discount}% discount applied`:''}</div></span><b id="otot">₹0</b></div>
 <button class="btn" id="obtn" onclick="doOrder()">Place Order</button>`)}
function qty(){const s=S.cur;if(s.type==='custom comments'){return(($('#ocm')||{}).value||'').split('\n').filter(x=>x.trim()).length}return parseInt(($('#oq')||{}).value)||0}
function tot(){const q=qty();$('#otot').textContent=q?pr(S.cur.rate*q/1000):'₹0'}
async function doOrder(){if(S.busy)return;const s=S.cur,q=qty(),link=$('#olink').value.trim();if(link.length<3)return toast('Enter a valid link','err');if(q<s.min||q>s.max)return toast(`Quantity must be ${s.min} - ${s.max}`,'err');
 if(s.rate*q/1000>S.user.balance+1e-9){closeSheet();toast('Not enough balance. Add funds first.','err');return setTab('wallet')}
 S.busy=true;const b=$('#obtn');b.disabled=true;b.textContent='Placing order...';const r=await api('order',{sid:s.id,link,qty:q,comments:s.type==='custom comments'?$('#ocm').value:''});S.busy=false;
 if(r.ok){S.user.balance=r.balance;S.user.orders++;closeSheet();toast(r.msg,'ok');setTab('orders')}else{b.disabled=false;b.textContent='Place Order';toast(r.msg,'err');if(r.code==='funds'){closeSheet();setTab('wallet')}}}
async function loadOrders(){S.orders=null;rOrders();const r=await api('orders');if(r.ok){S.orders=r.orders;S.user.balance=r.balance}if(S.tab==='orders')rOrders()}
function rOrders(){head('My Order History','orders',`<button class="pill-btn" onclick="loadOrders()">${ic('refresh',18)}Refresh</button>`);
 $('#main').innerHTML=S.orders===null?skel(2):S.orders.length?S.orders.map(o=>`<div class="oc" style="border-left-color:${({completed:'#16a34a',processing:'#3b82f6',pending:'#f59e0b',partial:'#8b5cf6'})[o.status]||'#ef4444'}"><div class="top"><span>#${o.id}</span><span class="st s-${o.status}">${o.status}</span></div><div class="nm2">${esc(o.sname||'Service')}</div><div class="lk">${esc(o.link)}</div><div class="kv"><div>Qty<b>${o.quantity}</b></div><div>Charge<b>${pr(o.price)}</b></div>${o.start_count?`<div>Start<b>${esc(o.start_count)}</b></div>`:''}${o.remains&&o.status!=='completed'?`<div>Remains<b>${esc(o.remains)}</b></div>`:''}${o.refunded>0?`<div>Refunded<b>${pr(o.refunded)}</b></div>`:''}<div>Date<b style="font-size:12px">${esc((o.created_at||'').slice(5,16))}</b></div></div>${o.can_refill?`<button class="btn sm" style="margin-top:12px" onclick="refill(${o.id})">♻ Request Refill</button>`:''}</div>`).join(''):`<div class="empty">${ic('orders',46)}<br><br>No orders yet.<br>Pick a service from Home to start.</div>`}
async function refill(id){const r=await api('refill',{oid:id});toast(r.msg,r.ok?'ok':'err');if(r.ok)loadOrders()}
async function loadDeps(){const r=await api('dep_list');if(r.ok){S.deps=r.list;S.user.balance=r.balance}if(S.tab==='wallet')rWallet()}
function rWallet(){head('My Wallet','wallet');const w=S.w,c=S.cfg;let h=`<div class="hero" style="text-align:center"><div style="color:#cbd5e1;font-size:15px;position:relative;z-index:1">Available Balance</div><div class="bal" style="font-size:40px;margin-top:10px">Rs. ${fm(S.user.balance)}</div></div>`;
 if(w.done){h+=`<div class="card done"><div class="ck">${ic('check',44)}</div><h3>${esc(w.done.title)}</h3><p style="color:var(--mut);margin-top:6px;font-size:14px">${esc(w.done.msg)}</p><button class="btn sm" style="margin-top:18px" onclick="S.w.done=null;rWallet()">OK</button></div>`}
 else if(w.tx){const t=w.tx;h+=`<div class="card" style="margin-top:16px"><div class="steps"><span class="on"></span><span class="${t.sent?'on':''}"></span></div><div class="big">₹${Number(t.amount).toFixed(2)}</div><p style="text-align:center;color:var(--mut);font-size:13px;margin:4px 0 10px">Scan with any UPI app and pay the exact amount</p>${t.qr?`<img class="qr" src="${t.qr}" alt="QR">`:''}<div class="cp"><span>${esc(t.upi)}</span><button class="chip" onclick="copy('${esc(t.upi)}')">Copy UPI ID</button></div><button class="btn sm" onclick="location.href='${esc(t.link)}'">${ic('phone',18)}Open UPI App</button>
 <label class="fld">After paying, enter UTR / Transaction ID</label><input class="inp" id="utr" placeholder="12-digit UTR" inputmode="text" autocapitalize="characters" style="font-size:16px" ${t.review?'disabled':''}>
 ${t.review?`<div class="banner" style="background:#dbeafe;color:#1e3a8a">⏳ <div>Waiting for admin approval. Balance will be added automatically.</div></div>`:`<button class="btn" style="margin-top:14px" id="vbtn" onclick="sendUtr()">${t.mode==='auto'?ic('zap',20)+'Verify Payment':ic('check',20)+'Submit for Approval'}</button>`}
 <button class="btn ghost" onclick="S.w.tx=null;clearInterval(S.poll);rWallet()">Cancel</button></div>`}
 else{const au=c.auto_on,ma=c.manual_on;if(!au&&!ma)h+=`<div class="card" style="margin-top:16px"><div class="empty">Deposits are not available right now.<br>Please contact support.</div></div>`;else{if(w.mode==='auto'&&!au)w.mode='manual';if(w.mode==='manual'&&!ma)w.mode='auto';
 h+=`<div class="seg"><button class="${w.mode==='manual'?'on':''}" ${ma?'':'disabled'} onclick="S.w.mode='manual';rWallet()">${ic('hand',20)}Manual</button><button class="${w.mode==='auto'?'on':''}" ${au?'':'disabled'} onclick="S.w.mode='auto';rWallet()">${ic('zap',20)}Auto</button></div>
 <div class="card" style="text-align:center"><div style="color:#3b82f6;margin-bottom:8px">${ic('phone',54)}</div><h3 style="font-size:21px">UPI Deposit</h3><p style="color:var(--mut);margin-top:6px">Enter amount &amp; generate QR to pay</p>${c.bonus?`<div class="tag" style="color:#16a34a;border-color:#86efac">🎁 +${c.bonus}% deposit bonus</div>`:''}
 <div style="text-align:left"><label class="fld">Enter Amount</label><div class="pre"><b>₹</b><input class="inp" id="amt" type="number" inputmode="decimal" placeholder="Min: Rs.${c.min_dep}"></div><div class="chips">${[50,100,200,500,1000].filter(v=>v>=c.min_dep).map(v=>`<button class="chip" onclick="document.getElementById('amt').value=${v}">₹${v}</button>`).join('')}</div></div>
 <button class="btn" style="margin-top:14px" id="gbtn" onclick="genQR()">${ic('qr',22)}Generate QR &amp; Pay</button><p style="font-size:12px;color:var(--mut);margin-top:12px">${w.mode==='auto'?'⚡ Auto: balance is added instantly after UTR verification':'✋ Manual: admin verifies your payment and adds balance'}</p></div>`}
 h+=`<div class="card"><h3 style="font-size:15px;margin-bottom:10px">${ic('gift',18)} Have a coupon?</h3><div class="row"><input class="inp" id="cpn" placeholder="CODE" style="font-size:15px;padding:13px" autocapitalize="characters"><button class="btn sm" style="width:auto;padding:13px 20px" onclick="redeem()">Apply</button></div></div>`;
 h+=`<div class="sec">${ic('chart',22)}Recent Deposits</div>`+(S.deps===null?skel(1):S.deps.length?S.deps.map(d=>`<div class="li"><div class="g"><div class="n">₹${Number(d.amount).toFixed(2)}${d.bonus>0?` <small style="color:#16a34a">+₹${Number(d.bonus).toFixed(2)} bonus</small>`:''}</div><div class="s">#${d.id} · ${d.mode} · ${esc((d.created_at||'').slice(5,16))}</div></div><span class="st s-${d.status}">${d.status}</span></div>`).join(''):'<div class="empty" style="padding:14px">No deposits yet</div>')}
 $('#main').innerHTML=h}
async function genQR(){if(S.busy)return;const a=parseFloat($('#amt').value);if(!a||a<S.cfg.min_dep)return toast('Minimum deposit is ₹'+S.cfg.min_dep,'err');S.busy=true;const b=$('#gbtn');b.disabled=true;const r=await api('dep_new',{amount:a,mode:S.w.mode});S.busy=false;if(r.ok){S.w.tx=r;rWallet();scrollTo(0,0)}else{b.disabled=false;toast(r.msg,'err')}}
async function sendUtr(){if(S.busy)return;const u=$('#utr').value.trim();if(u.length<8)return toast('Enter a valid UTR','err');S.busy=true;const b=$('#vbtn');b.disabled=true;b.textContent='Checking... (up to 1 min)';const r=await api('dep_utr',{tx:S.w.tx.tx,utr:u});S.busy=false;
 if(!r.ok){b.disabled=false;rWallet();return toast(r.msg,'err')}
 if(r.status==='approved'){S.user.balance=r.balance;S.w.tx=null;S.w.done={title:'Payment Successful',msg:r.msg};S.deps=null;rWallet();loadDeps();toast(r.msg,'ok')}
 else{S.w.tx.review=true;rWallet();toast(r.msg,'ok');let n=0;clearInterval(S.poll);S.poll=setInterval(async()=>{n++;const s=await api('dep_status',{tx:S.w.tx&&S.w.tx.tx});if(!s.ok||n>60){clearInterval(S.poll);return}if(s.status==='approved'){clearInterval(S.poll);S.user.balance=s.balance;S.w.tx=null;S.w.done={title:'Payment Approved',msg:'Your balance has been added.'};S.deps=null;if(S.tab==='wallet')rWallet();loadDeps();toast('Payment approved','ok')}else if(s.status==='rejected'||s.status==='expired'){clearInterval(S.poll);S.w.tx=null;if(S.tab==='wallet')rWallet();toast('Payment was '+s.status,'err')}},6000)}}
async function redeem(){const c=$('#cpn').value.trim();if(!c)return;const r=await api('coupon',{code:c});toast(r.msg,r.ok?'ok':'err');if(r.ok){S.user.balance=r.balance;rWallet()}}
function rProfile(){$('#top').innerHTML='';const u=S.user,c=S.cfg,i=(u.name||'U')[0].toUpperCase();
 const L=(k,t,col,bg,u2)=>`<button class="link" onclick="openL('${esc(u2)}')"><div class="bx" style="background:${bg};color:${col}">${ic(k,26)}</div><span>${t}</span>${ic('ext',20)}</button>`;
 $('#main').innerHTML=`<div class="hero" style="text-align:center;padding:30px 20px"><div class="av" style="width:104px;height:104px;margin:0 auto 14px;font-size:40px;${u.photo?`background-image:url('${esc(u.photo)}')`:''}">${u.photo?'':i}<i style="width:20px;height:20px;right:4px;bottom:6px"></i></div><div class="nm" style="justify-content:center;font-size:22px;position:relative;z-index:1">${esc(u.name)}<span class="vf" style="width:22px;height:22px">${ic('check',13).replace('currentColor','#fff')}</span></div><div style="color:#94a3b8;margin-top:6px;position:relative;z-index:1">${u.username?'@'+esc(u.username):'No username'}</div>${u.username?`<button class="tag" style="background:none;font-family:inherit;margin-top:18px;position:relative;z-index:1;text-transform:uppercase" onclick="openL('https://t.me/${esc(u.username)}')">✈ Telegram Profile</button>`:''}</div>
 <div class="stats"><div class="stat">${ic('finger',30)}<small>Telegram ID</small><b>${u.id}</b></div><div class="stat">${ic('wallet',30).replace('currentColor','#60a5fa')}<small>Balance</small><b style="color:#60a5fa">Rs. ${fm(u.balance)}</b></div><div class="stat">${ic('chart',30)}<small>Total Spent</small><b>Rs. ${fm(u.spent)}</b></div></div>
 ${u.ref?`<div class="card"><div class="row"><div style="color:#ec4899">${ic('gift',30)}</div><div style="flex:1"><b>Refer &amp; Earn</b><div style="font-size:12px;color:var(--mut)">Earned: ₹${Number(u.ref_earn).toFixed(2)}</div></div><button class="chip" onclick="copy('${esc(u.ref)}')">Copy link</button></div></div>`:''}
 ${L('head','Support Team','#16a34a','#dcfce7',c.support)}${L('code','Developer Contact','#9333ea','#f3e8ff',c.dev||c.support)}${L('mega','Updated Channel','#2563eb','#dbeafe',c.channel)}`}
async function boot(){$('#main').innerHTML=skel(2);const r=await api('init');
 if(!r.ok){$('#main').innerHTML=`<div class="empty" style="padding-top:90px"><div style="font-size:50px">${r.err==='banned'?'🚫':'🔒'}</div><br>${esc(r.msg||'Open this app from Telegram.')}</div>`;return}
 S.user=r.user;S.cfg=r.cfg;S.plats=r.plats;if(r.cfg.maint){$('#main').innerHTML='<div class="empty" style="padding-top:90px"><div style="font-size:50px">🛠</div><br><b>Under maintenance</b><br>We will be back shortly.</div>';$('#navin').innerHTML='';return}
 if(r.cfg.logo){}render()}
if(tg)try{tg.BackButton.onClick(back)}catch(e){}
boot();
</script></body></html>
'''


# ───────────────────────── orders ─────────────────────────
def norm_status(s):
    s = (s or "").lower().strip()
    return {"in progress": "processing", "processing": "processing", "pending": "pending", "completed": "completed",
            "complete": "completed", "partial": "partial", "canceled": "canceled", "cancelled": "canceled",
            "refunded": "canceled", "fail": "canceled", "failed": "canceled"}.get(s, s or "pending")


def refund(oid, amount, why=""):
    amount = round(float(amount), 4)
    if amount <= 0:
        return 0
    with _lock:
        o = q1("SELECT * FROM orders WHERE id=?", (oid,))
        if not o or o["refunded"] > 0:
            return 0
        amount = min(amount, o["price"])
        ex("UPDATE orders SET refunded=? WHERE id=?", (amount, oid))
        ex("UPDATE users SET balance=balance+?, total_spent=MAX(total_spent-?,0) WHERE telegram_id=?", (amount, amount, o["user_id"]))
    return amount


def apply_status(o, info):
    st = norm_status(info.get("status"))
    sc, rem = str(info.get("start_count") or ""), str(info.get("remains") or "")
    changed = st != o["status"]
    ex("UPDATE orders SET status=?, start_count=?, remains=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (st, sc, rem, o["id"]))
    if not changed:
        return
    msg = None
    if st == "completed":
        msg = f"✅ <b>Order #{o['id']} completed!</b>"
    elif st == "canceled":
        r = refund(o["id"], o["price"])
        msg = f"❌ <b>Order #{o['id']} canceled.</b>\n💰 {money(r)} refunded to your wallet."
    elif st == "partial":
        try:
            r = refund(o["id"], o["price"] * float(rem or 0) / max(int(o["quantity"]), 1))
        except ValueError:
            r = 0
        msg = f"⚠️ <b>Order #{o['id']} partially completed.</b>\n💰 {money(r)} refunded for the remaining quantity."
    if msg:
        tg(o["user_id"], msg)


def sync_orders():
    rows = q("SELECT * FROM orders WHERE provider_order IS NOT NULL AND provider_order!='' AND status IN ('pending','processing') ORDER BY id LIMIT 600")
    by = {}
    for o in rows:
        by.setdefault(o["provider_id"], []).append(o)
    n = 0
    for pid, lst in by.items():
        p = q1("SELECT * FROM providers WHERE id=?", (pid,))
        if not p:
            continue
        for i in range(0, len(lst), 100):
            chunk = lst[i:i + 100]
            try:
                res = papi(p, action="status", orders=",".join(o["provider_order"] for o in chunk))
            except ApiErr as e:
                log.warning("sync %s: %s", p["name"], e)
                break
            if not isinstance(res, dict):
                continue
            for o in chunk:
                info = res.get(o["provider_order"])
                if isinstance(info, dict) and not info.get("error"):
                    apply_status(o, info)
                    n += 1
    return n


def place_order(user, sid, link, qty, comments):
    if S("maintenance") == "1" and user["telegram_id"] not in ADMINS:
        return {"ok": False, "msg": "Panel is under maintenance. Try again later."}
    s = q1(SVC_SQL + " WHERE s.id=?", (sid,))
    if not s or not (s["active"] and s["avail"] and s["cact"] and s["pact"]) or s["type"].lower() not in ("default", "custom comments"):
        return {"ok": False, "msg": "This service is not available."}
    link = (link or "").strip()
    if len(link) < 3 or len(link) > 500 or "\n" in link:
        return {"ok": False, "msg": "Enter a valid link or @username."}
    clist = ""
    if s["type"].lower() == "custom comments":
        lines = [x.strip() for x in (comments or "").splitlines() if x.strip()]
        clist = "\n".join(lines)
        qty = len(lines)
    if qty < s["min"] or qty > s["max"]:
        return {"ok": False, "msg": f"Quantity must be between {s['min']} and {s['max']}."}
    if S("block_dup") == "1" and q1("SELECT 1 x FROM orders WHERE user_id=? AND service_id=? AND link=? AND status IN ('pending','processing')",
                                    (user["telegram_id"], sid, link)):
        return {"ok": False, "msg": "You already have an active order for this link and service."}
    disc = float(user.get("discount") or 0)
    price = max(round(sell_rate(s) * qty / 1000 * (1 - disc / 100), 4), 0.0001)
    if price < SF("min_order"):
        return {"ok": False, "msg": f"Minimum order amount is {money(SF('min_order'))}."}
    cost = round(cost_rate(s) * qty / 1000, 4)
    if not ex("UPDATE users SET balance=balance-?, total_spent=total_spent+?, total_orders=total_orders+1 WHERE telegram_id=? AND balance>=?",
              (price, price, user["telegram_id"], price)):
        return {"ok": False, "code": "funds", "msg": "Not enough balance. Add funds in the Wallet."}
    oid = exid("INSERT INTO orders(user_id,service_id,provider_id,link,quantity,price,cost,comments,status) VALUES(?,?,?,?,?,?,?,?,'pending')",
               (user["telegram_id"], sid, s["provider_id"], link, qty, price, cost, clist))
    p = q1("SELECT * FROM providers WHERE id=?", (s["provider_id"],))
    try:
        data = {"action": "add", "service": s["pid"], "link": link}
        if clist:
            data["comments"] = clist
        else:
            data["quantity"] = qty
        r = papi(p, **data)
        po = str(r.get("order") or "") if isinstance(r, dict) else ""
        if not po:
            raise ApiErr("no order id returned")
        ex("UPDATE orders SET provider_order=?, status='processing' WHERE id=?", (po, oid))
    except ApiErr as e:
        ex("UPDATE orders SET status='failed', note=? WHERE id=?", (str(e)[:200], oid))
        ex("UPDATE users SET balance=balance+?, total_spent=MAX(total_spent-?,0), total_orders=MAX(total_orders-1,0) WHERE telegram_id=?",
           (price, price, user["telegram_id"]))
        tg_admins(f"⚠️ <b>Provider order failed</b>\n#{oid} · {esc(s['name'][:80])}\n<code>{esc(str(e))}</code>")
        return {"ok": False, "msg": "Service is busy right now. Your balance was not charged. Try again shortly."}
    if S("notify_orders") == "1":
        tg_admins(f"🛒 <b>New order #{oid}</b>\n👤 <code>{user['telegram_id']}</code> {esc(user['first_name'] or '')}\n"
                  f"📦 {esc(s['name'][:80])}\n🔗 {esc(link[:100])}\n🔢 {qty} · 💰 {money(price)} · profit ≈ {money(price - cost)}")
    nb = q1("SELECT balance FROM users WHERE telegram_id=?", (user["telegram_id"],))["balance"]
    return {"ok": True, "oid": oid, "price": price, "balance": nb, "msg": f"Order #{oid} placed successfully!"}


# ───────────────────────── payments ─────────────────────────
class FmPayError(Exception):
    pass


def fampay_verify(utr, amount):
    key, url = S("fampay_key").strip(), S("fampay_url").strip().rstrip("/")
    if not key or not url:
        raise FmPayError("FamPay API key / base URL not set")
    try:
        resp = requests.post(f"{url}/verify", json={"utr": utr, "amount": round(float(amount), 2), "api_key": key},
                             headers={"X-API-Key": key, "Content-Type": "application/json"}, timeout=60)
    except requests.RequestException as e:
        raise FmPayError(f"network error: {e}")
    try:
        j = resp.json()
    except ValueError:
        raise FmPayError(f"non-JSON reply (HTTP {resp.status_code})")
    if not isinstance(j, dict):
        raise FmPayError("unexpected reply")
    log.info("FamPay verify %s: HTTP %s %s", utr, resp.status_code, str(j)[:300])
    msg = str(j.get("message") or j.get("error") or j.get("status") or "")
    if resp.status_code in (401, 403) or resp.status_code >= 500:
        raise FmPayError(msg or f"HTTP {resp.status_code}")
    ok = j.get("success") is True
    for k in ("verified", "found", "paid", "valid"):
        if k in j and not j[k]:
            ok = False
    if str(j.get("status") or "").lower() in ("failed", "not_found", "notfound", "pending", "invalid", "error"):
        ok = False
    try:
        paid = float(j.get("amount"))
    except (TypeError, ValueError):
        paid = None
    if ok and paid is not None and paid + 0.011 < float(amount):
        ok, msg = False, "Amount mismatch"
    return {"ok": ok, "message": msg}


def credit_tx(tx_id, utr=None, by="auto"):
    with _lock:
        t = q1("SELECT * FROM transactions WHERE id=?", (tx_id,))
        if not t or t["status"] not in ("pending", "review"):
            return None
        bonus = round(t["amount"] * SF("deposit_bonus") / 100, 4)
        try:
            ex("UPDATE transactions SET status='approved', utr=COALESCE(?,utr), bonus=?, approved_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
               (utr, bonus, by, tx_id))
        except sqlite3.IntegrityError:
            return "duplicate"
        ex("UPDATE users SET balance=balance+? WHERE telegram_id=?", (t["amount"] + bonus, t["user_id"]))
        u = q1("SELECT * FROM users WHERE telegram_id=?", (t["user_id"],))
        rp = SF("ref_percent")
        if u and u["ref_by"] and rp > 0:
            rb = round(t["amount"] * rp / 100, 4)
            ex("UPDATE users SET balance=balance+?, ref_earn=ref_earn+? WHERE telegram_id=?", (rb, rb, u["ref_by"]))
            tg(u["ref_by"], f"🎁 <b>Referral bonus!</b> You earned {money(rb)} from your friend's deposit.")
    nb = q1("SELECT balance FROM users WHERE telegram_id=?", (t["user_id"],))["balance"]
    tg(t["user_id"], f"✅ <b>Payment received!</b>\n💰 {money(t['amount'])}" + (f" + 🎁 bonus {money(bonus)}" if bonus else "") +
       f"\n👛 New balance: <b>{money(nb)}</b>")
    tg_admins(f"💳 <b>Deposit #{tx_id}</b> {money(t['amount'])} · user <code>{t['user_id']}</code> · {esc(by)}")
    return "ok"


def norm_utr(s):
    s = re.sub(r"[^A-Za-z0-9]", "", str(s or "")).upper()
    return s if 8 <= len(s) <= 40 else ""


def submit_utr(user, tx_id, utr):
    t = q1("SELECT * FROM transactions WHERE id=? AND user_id=?", (tx_id, user["telegram_id"]))
    if not t:
        return {"ok": False, "msg": "Payment not found."}
    if t["status"] == "approved":
        return {"ok": True, "status": "approved", "msg": "Already credited."}
    if t["status"] != "pending":
        return {"ok": False, "msg": "This payment is closed. Start a new deposit."}
    utr = norm_utr(utr)
    if not utr:
        return {"ok": False, "msg": "Enter the 12-digit UTR / transaction ID."}
    if q1("SELECT 1 x FROM transactions WHERE utr=? AND status IN ('approved','review')", (utr,)):
        return {"ok": False, "msg": "This UTR was already used."}
    use_auto = t["mode"] == "auto"
    if use_auto:
        try:
            r = fampay_verify(utr, t["amount"])
        except FmPayError as e:
            tg_admins(f"⚠️ <b>FamPay API error</b>\n<code>{esc(str(e))[:300]}</code>")
            return {"ok": False, "msg": "Verification service is busy. Try again in a minute."}
        if not r["ok"]:
            return {"ok": False, "msg": "Payment not found. Check the ID and the exact amount." + (f" ({r['message'][:80]})" if r["message"] else "")}
        res = credit_tx(tx_id, utr, "fampay")
        if res == "duplicate":
            return {"ok": False, "msg": "This UTR was already used."}
        nb = q1("SELECT balance FROM users WHERE telegram_id=?", (user["telegram_id"],))["balance"]
        return {"ok": True, "status": "approved", "balance": nb, "msg": "Payment verified! Balance added."}
    try:
        ex("UPDATE transactions SET utr=?, status='review', updated_at=CURRENT_TIMESTAMP WHERE id=?", (utr, tx_id))
    except sqlite3.IntegrityError:
        return {"ok": False, "msg": "This UTR was already used."}
    tg_admins(f"🕒 <b>MANUAL PAYMENT CHECK #{tx_id}</b>\n👤 <code>{user['telegram_id']}</code> {esc(user['first_name'] or '')}\n"
              f"💰 <b>{money(t['amount'])}</b>\n🔢 UTR: <code>{esc(utr)}</code>\n\nCheck your bank / UPI app, then choose:",
              InlineKeyboardMarkup([[mk_btn("✅ Approve", "success", callback_data=f"a:txok:{tx_id}"),
                                     mk_btn("❌ Reject", "danger", callback_data=f"a:txno:{tx_id}")]]))
    return {"ok": True, "status": "review", "msg": "Submitted! Admin will verify and add your balance soon."}


def make_qr(data):
    try:
        import qrcode
        img = qrcode.make(data, box_size=8, border=2)
        buf = io.BytesIO()
        img.save(buf, "PNG")
        return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()
    except Exception as e:
        log.warning("qr failed: %s", e)
        return ""


# ───────────────────────── Mini App API (single POST endpoint) ─────────────────────────
def tg_auth(init):
    try:
        pairs = dict(parse_qsl(init or "", keep_blank_values=True))
        h = pairs.pop("hash", "")
        dcs = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret = hmac.new(b"WebAppData", TOKEN.encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest(), h):
            return None
        if time.time() - int(pairs.get("auth_date", "0")) > 3 * 86400:
            return None
        return json.loads(pairs["user"])
    except Exception:
        return None


_HITS = {}


def rate_ok(uid, limit=90, per=60):
    now = time.time()
    lst = [t for t in _HITS.get(uid, []) if now - t < per]
    lst.append(now)
    _HITS[uid] = lst
    return len(lst) <= limit


def svc_row(s, disc):
    return {"id": s["id"], "name": s["name"], "rate": round(sell_rate(s) * (1 - disc / 100), 4), "min": s["min"], "max": s["max"],
            "type": s["type"].lower(), "refill": s["refill"], "desc": s["descr"] or "", "cat": s["cname"]}


def a_init(u, b, tgu):
    plats = q("SELECT c.platform p, COUNT(s.id) n FROM services s JOIN categories c ON c.id=s.cat_id JOIN providers pr ON pr.id=s.provider_id "
              f"WHERE {LIVE} GROUP BY c.platform")
    order = [p[0] for p in PLATFORMS] + ["other"]
    plats.sort(key=lambda x: order.index(x["p"]) if x["p"] in order else 99)
    auto_on = S("pay_auto_on") == "1" and bool(S("fampay_key")) and bool(S("upi_id"))
    man_on = S("pay_manual_on") == "1" and bool(S("upi_id"))
    return {"ok": True, "user": {"id": u["telegram_id"], "name": u["first_name"] or "User", "username": u["username"] or "",
                                 "photo": (tgu or {}).get("photo_url", ""), "balance": u["balance"], "spent": u["total_spent"],
                                 "orders": u["total_orders"], "discount": u["discount"], "ref_earn": u["ref_earn"],
                                 "ref": f"https://t.me/{BOT_USER}?start=ref_{u['telegram_id']}" if BOT_USER else ""},
            "cfg": {"store": S("store_name"), "support": tglink(S("support")), "channel": tglink(S("channel")), "dev": tglink(S("developer")),
                    "banner": S("announcement"), "credit": S("credit"), "min_dep": SF("min_deposit", 10), "max_dep": SF("max_deposit", 50000),
                    "bonus": SF("deposit_bonus"), "auto_on": auto_on, "manual_on": man_on, "maint": S("maintenance") == "1" and u["telegram_id"] not in ADMINS,
                    "is_admin": u["telegram_id"] in ADMINS, "logo": os.path.exists(LOGO)},
            "plats": [{"id": x["p"], "name": PLAT_NAME.get(x["p"], x["p"].title()), "n": x["n"]} for x in plats]}


def a_cats(u, b, tgu):
    rows = q("SELECT c.id, c.name, COUNT(s.id) n, MIN(s.rate*pr.mult) lo FROM categories c JOIN services s ON s.cat_id=c.id "
             f"JOIN providers pr ON pr.id=s.provider_id WHERE c.platform=? AND {LIVE} GROUP BY c.id ORDER BY c.sort, c.name", (str(b.get("plat")),))
    return {"ok": True, "cats": [{"id": r["id"], "name": r["name"], "n": r["n"]} for r in rows]}


def a_svcs(u, b, tgu):
    rows = q(SVC_SQL + f" WHERE s.cat_id=? AND {LIVE} ORDER BY s.rate*pr.mult, s.id", (int(b.get("cat") or 0),))
    return {"ok": True, "svcs": [svc_row(s, u["discount"]) for s in rows]}


def a_search(u, b, tgu):
    t = "%" + re.sub(r"[%_]", "", str(b.get("q") or "").strip())[:40] + "%"
    if len(t) < 5:
        return {"ok": True, "svcs": []}
    rows = q(SVC_SQL + f" WHERE {LIVE} AND (s.name LIKE ? OR c.name LIKE ? OR s.id LIKE ?) ORDER BY s.id LIMIT 40", (t, t, t))
    return {"ok": True, "svcs": [svc_row(s, u["discount"]) for s in rows]}


def a_order(u, b, tgu):
    try:
        sid, qty = int(b.get("sid")), int(float(b.get("qty") or 0))
    except (TypeError, ValueError):
        return {"ok": False, "msg": "Invalid input."}
    return place_order(u, sid, str(b.get("link") or ""), qty, str(b.get("comments") or ""))


def a_orders(u, b, tgu):
    rows = q("SELECT o.id, o.link, o.quantity, o.price, o.status, o.start_count, o.remains, o.created_at, o.refunded, o.refill_at, s.name sname, s.refill "
             "FROM orders o LEFT JOIN services s ON s.id=o.service_id WHERE o.user_id=? ORDER BY o.id DESC LIMIT 60", (u["telegram_id"],))
    for r in rows:
        r["can_refill"] = bool(r["refill"]) and r["status"] == "completed" and not r["refill_at"]
        r.pop("refill_at", None)
    return {"ok": True, "orders": rows, "balance": u["balance"]}


def a_refill(u, b, tgu):
    o = q1("SELECT o.*, s.refill FROM orders o JOIN services s ON s.id=o.service_id WHERE o.id=? AND o.user_id=?", (int(b.get("oid") or 0), u["telegram_id"]))
    if not o or not o["refill"] or o["status"] != "completed" or o["refill_at"]:
        return {"ok": False, "msg": "Refill is not available for this order."}
    p = q1("SELECT * FROM providers WHERE id=?", (o["provider_id"],))
    try:
        papi(p, action="refill", order=o["provider_order"])
    except ApiErr:
        return {"ok": False, "msg": "Refill request failed. Try later or contact support."}
    ex("UPDATE orders SET refill_at=CURRENT_TIMESTAMP WHERE id=?", (o["id"],))
    return {"ok": True, "msg": "Refill requested."}


def a_dep_new(u, b, tgu):
    mode = "auto" if b.get("mode") == "auto" else "manual"
    auto_on = S("pay_auto_on") == "1" and bool(S("fampay_key"))
    if not S("upi_id"):
        return {"ok": False, "msg": "Deposits are not set up yet. Contact support."}
    if mode == "auto" and not auto_on:
        return {"ok": False, "msg": "Auto deposit is off right now. Use Manual."}
    if mode == "manual" and S("pay_manual_on") != "1":
        return {"ok": False, "msg": "Manual deposit is off right now. Use Auto."}
    try:
        amt = round(float(b.get("amount")), 2)
    except (TypeError, ValueError):
        return {"ok": False, "msg": "Enter a valid amount."}
    if amt < SF("min_deposit", 10) or amt > SF("max_deposit", 50000):
        return {"ok": False, "msg": f"Amount must be between ₹{SF('min_deposit', 10):g} and ₹{SF('max_deposit', 50000):g}."}
    ex("UPDATE transactions SET status='expired' WHERE user_id=? AND status='pending'", (u["telegram_id"],))
    tx = exid("INSERT INTO transactions(user_id, amount, mode) VALUES(?,?,?)", (u["telegram_id"], amt, mode))
    link = f"upi://pay?pa={quote(S('upi_id'))}&pn={quote(S('upi_name') or S('store_name'))}&am={amt:.2f}&cu=INR&tn={quote('VC' + str(tx))}"
    return {"ok": True, "tx": tx, "amount": amt, "upi": S("upi_id"), "name": S("upi_name"), "link": link, "qr": make_qr(link), "mode": mode}


def a_dep_utr(u, b, tgu):
    try:
        return submit_utr(u, int(b.get("tx")), str(b.get("utr") or ""))
    except (TypeError, ValueError):
        return {"ok": False, "msg": "Invalid request."}


def a_dep_status(u, b, tgu):
    t = q1("SELECT status FROM transactions WHERE id=? AND user_id=?", (int(b.get("tx") or 0), u["telegram_id"]))
    return {"ok": True, "status": t["status"] if t else "none", "balance": u["balance"]}


def a_dep_list(u, b, tgu):
    return {"ok": True, "list": q("SELECT id, amount, bonus, mode, status, created_at FROM transactions WHERE user_id=? AND status!='expired' ORDER BY id DESC LIMIT 20",
                                  (u["telegram_id"],)), "balance": u["balance"]}


def a_coupon(u, b, tgu):
    code = re.sub(r"[^A-Za-z0-9_-]", "", str(b.get("code") or "")).upper()[:30]
    c = q1("SELECT * FROM coupons WHERE code=?", (code,))
    if not c or c["used"] >= c["max_uses"]:
        return {"ok": False, "msg": "Invalid or expired coupon."}
    try:
        ex("INSERT INTO coupon_log(code,user_id) VALUES(?,?)", (code, u["telegram_id"]))
    except sqlite3.IntegrityError:
        return {"ok": False, "msg": "You already used this coupon."}
    if not ex("UPDATE coupons SET used=used+1 WHERE code=? AND used<max_uses", (code,)):
        ex("DELETE FROM coupon_log WHERE code=? AND user_id=?", (code, u["telegram_id"]))
        return {"ok": False, "msg": "Invalid or expired coupon."}
    ex("UPDATE users SET balance=balance+? WHERE telegram_id=?", (c["amount"], u["telegram_id"]))
    nb = q1("SELECT balance FROM users WHERE telegram_id=?", (u["telegram_id"],))["balance"]
    return {"ok": True, "msg": f"Coupon applied! {money(c['amount'])} added.", "balance": nb}


ACTIONS = {"init": a_init, "cats": a_cats, "svcs": a_svcs, "search": a_search, "order": a_order, "orders": a_orders, "refill": a_refill,
           "dep_new": a_dep_new, "dep_utr": a_dep_utr, "dep_status": a_dep_status, "dep_list": a_dep_list, "coupon": a_coupon}


def rpc(b):
    tgu = tg_auth(b.get("init"))
    if not tgu:
        return {"ok": False, "err": "auth", "msg": "Please open this app from the Telegram bot."}
    if not rate_ok(tgu["id"]):
        return {"ok": False, "msg": "Too many requests. Wait a moment."}
    u = ensure_user(tgu)
    if u["banned"]:
        return {"ok": False, "err": "banned", "msg": "Your account is banned. Contact support."}
    fn = ACTIONS.get(str(b.get("a")))
    if not fn:
        return {"ok": False, "msg": "Unknown action."}
    if S("maintenance") == "1" and u["telegram_id"] not in ADMINS and b.get("a") not in ("init",):
        return {"ok": False, "msg": "Panel is under maintenance. Please try later."}
    try:
        return fn(u, b, tgu)
    except Exception as e:
        log.exception("rpc %s failed: %s", b.get("a"), e)
        return {"ok": False, "msg": "Something went wrong. Try again."}


class Handler(BaseHTTPRequestHandler):
    server_version = "VC"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="text/html; charset=utf-8", cache="no-store"):
        if isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        p = urlparse(self.path).path
        try:
            if p == "/pay":
                th = {k: THEME[k] for k in ("c1", "c2", "n1", "n2", "bg") if isinstance(THEME.get(k), str)}
                self._send(200, HTML.replace("__THEME__", json.dumps(th)).replace("__STORE__", esc(S("store_name"))))
            elif p == "/logo" and os.path.exists(LOGO):
                self._send(200, open(LOGO, "rb").read(), "image/jpeg", "public, max-age=300")
            elif p == "/health":
                self._send(200, "ok", "text/plain")
            elif p == "/api/status":
                self._send(200, '{"ok":true}', "application/json")
            else:
                self._send(404, "Not found", "text/plain")
        except Exception as e:
            log.error("web GET: %s", e)

    def do_POST(self):
        try:
            if urlparse(self.path).path != "/api/verify":
                return self._send(404, "Not found", "text/plain")
            n = int(self.headers.get("Content-Length") or 0)
            if n <= 0 or n > 30000:
                return self._send(400, '{"ok":false,"msg":"Bad request"}', "application/json")
            body = json.loads(self.rfile.read(n).decode("utf-8", "replace"))
            self._send(200, json.dumps(rpc(body), default=str), "application/json")
        except Exception as e:
            log.error("web POST: %s", e)
            try:
                self._send(500, '{"ok":false,"msg":"Server error"}', "application/json")
            except Exception:
                pass


def start_web():
    try:
        srv = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError as e:
        log.warning("Mini App server could not start on %s:%s: %s", HOST, PORT, e)
        return
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    log.info("Mini App server on %s:%s | public: %s", HOST, PORT, WEBAPP_URL or "NOT SET")


# ───────────────────────── Telegram bot ─────────────────────────
def btn_style(text, cb=None):
    """Telegram coloured button: success = green, danger = red, primary = blue."""
    t = text or ""
    c = cb or ""
    if any(x in t for x in ("🗑", "❌", "✖", "🚫", "Reject", "Delete", "Cancel", "Deduct", "➖", "↩️")) or c.startswith(("a:pdel", "a:cdel", "a:txno")):
        return "danger"
    if any(x in t for x in ("✅", "🟢", "➕", "🚀", "⚡", "Approve", "Send now", "Add ", "Open", "Import", "Refresh", "🔄", "💼", "💰", "🎁")):
        return "success"
    if any(x in t for x in ("⬅️", "◀️", "▶️", "Back", "Prev", "Next", "⚪")):
        return "primary" if "⚪" not in t else "danger"
    return "primary"


def mk_btn(text, style=None, **kw):
    if style:
        try:
            return InlineKeyboardButton(text, api_kwargs={"style": style}, **kw)
        except TypeError:
            pass
    return InlineKeyboardButton(text, **kw)


def B(text, cb=None, url=None, web=None, style=None):
    kw = {}
    if cb:
        kw["callback_data"] = cb
    if url:
        kw["url"] = url
    if web:
        kw["web_app"] = WebAppInfo(url=web)
    return mk_btn(text, style or btn_style(text, cb), **kw)


def kbtn(text, style="primary", web=None):
    kw = {"web_app": WebAppInfo(url=web)} if web else {}
    try:
        return KeyboardButton(text, api_kwargs={"style": style}, **kw)
    except TypeError:
        return KeyboardButton(text, **kw)


def app_url():
    return f"{WEBAPP_URL}/pay" if WEBAPP_URL else ""


BTN_OPEN = TH("btn_open", "🚀 Open SMM")
BTN_PROFILE = TH("btn_profile", "👤 My Profile")
BTN_CHANNEL = TH("btn_channel", "📢 Updated Channel")
BTN_CONTACT = TH("btn_contact", "📩 Contact Admin")


def main_kb():
    url = app_url()
    first = kbtn(BTN_OPEN, TH("style_open", "success"), url or None)
    return ReplyKeyboardMarkup([[first], [kbtn(BTN_PROFILE, TH("style_profile", "primary"))],
                                [kbtn(BTN_CHANNEL, TH("style_channel", "primary"))],
                                [kbtn(BTN_CONTACT, TH("style_contact", "success"))]],
                               resize_keyboard=True)


def is_admin(update):
    return bool(update.effective_user and update.effective_user.id in ADMINS)


async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    ref = None
    if ctx.args and ctx.args[0].startswith("ref_") and ctx.args[0][4:].isdigit():
        ref = int(ctx.args[0][4:])
    row = ensure_user({"id": u.id, "first_name": u.first_name, "last_name": u.last_name, "username": u.username}, ref)
    if row["banned"]:
        return await update.message.reply_text("🚫 Your account is banned. Contact support.")
    text = S("welcome").replace("{store}", esc(S("store_name"))).replace("{name}", esc(u.first_name or "there"))
    rows = [[B("🚀 Open SMM Panel", web=app_url())]] if app_url() else []
    try:
        await update.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(rows) if rows else None)
    except Exception:
        await update.message.reply_text(re.sub(r"<[^>]+>", "", text), reply_markup=InlineKeyboardMarkup(rows) if rows else None)
    await update.message.reply_text("✅ Menu ready - use the buttons below 👇", reply_markup=main_kb())
    if not app_url():
        await update.message.reply_text("ℹ️ Mini App URL is not set yet (host panel Cloudflare address missing).")


async def send_profile(update):
    u = update.effective_user
    r = q1("SELECT * FROM users WHERE telegram_id=?", (u.id,)) or {}
    await update.message.reply_text(
        f"👤 <b>MY PROFILE</b>\n\n🆔 User ID: <code>{u.id}</code>\n📝 Name: {esc(u.full_name)}\n🔗 Username: @{esc(u.username or '-')}\n"
        f"💰 Balance: <b>{money(r.get('balance', 0))}</b>\n🛒 Orders: {r.get('total_orders', 0)}\n💸 Total spent: {money(r.get('total_spent', 0))}\n"
        f"🌐 Language: {esc(u.language_code or '-')}", parse_mode="HTML")


async def send_channel(update):
    link = tglink(S("channel"))
    if not link:
        return await update.message.reply_text("📢 Channel is not set yet.")
    await update.message.reply_text("📢 <b>Join Our Updated Channel</b>\n\nJoin our channel to get the latest updates, announcements and new services.",
                                    parse_mode="HTML", reply_markup=InlineKeyboardMarkup([[B("📢 Updated Channel", url=link)]]))


async def send_contact(update):
    link = tglink(S("support"))
    await update.message.reply_text("📩 <b>Contact Admin</b>\n\nNeed help or have any questions? Contact our admin for support.\n\n👇 Click the button below to message the admin.",
                                    parse_mode="HTML", reply_markup=InlineKeyboardMarkup([[B("📩 Contact Admin", url=link)]]) if link else None)


# ───────────────────────── admin panel (everything from the bot) ─────────────────────────
BK = lambda to="a:home": [B("⬅️ Back", to)]
META = {
    "store_name": ("🏷 Store name", "text"), "welcome": ("👋 Welcome message (HTML ok, {store} {name})", "text"),
    "support": ("💬 Support @username or link", "text"), "channel": ("📢 Updated channel link", "text"),
    "developer": ("👨‍💻 Developer contact link", "text"), "announcement": ("📣 Mini App banner text (- to clear)", "text"),
    "credit": ("❤ Footer credit name", "text"), "global_margin": ("📈 Global margin %", "num"), "min_order": ("🧮 Min order amount ₹", "num"),
    "ref_percent": ("🎁 Referral % on friend's deposits", "num"), "low_balance": ("⚠️ Alert when provider balance below (0=off)", "num"),
    "upi_id": ("🏦 UPI ID (e.g. name@fam)", "text"), "upi_name": ("🪪 UPI payee name", "text"),
    "fampay_key": ("🔑 FamPay / FMPay API key", "secret"), "fampay_url": ("🌐 FamPay API base URL (https://...)", "url"),
    "min_deposit": ("⬇️ Min deposit ₹", "num"), "max_deposit": ("⬆️ Max deposit ₹", "num"), "deposit_bonus": ("🎁 Deposit bonus %", "num"),
}
TOGGLES = {"maintenance": "🛠 Maintenance", "notify_orders": "🔔 Order alerts", "notify_users": "🆕 New-user alerts", "block_dup": "🚫 Block duplicate orders",
           "auto_sync": "🔄 Auto order sync", "pay_auto_on": "⚡ Auto deposit", "pay_manual_on": "✋ Manual deposit"}
COLS = {("providers", "margin"): "numn", ("providers", "mult"): "num", ("providers", "name"): "text", ("providers", "url"): "url",
        ("providers", "key"): "secret", ("categories", "margin"): "numn", ("categories", "name"): "text", ("services", "margin"): "numn",
        ("services", "name"): "text", ("services", "descr"): "textn", ("users", "discount"): "num", ("categories", "platform"): "text"}
COL_LABEL = {"margin": "margin % (send - for default)", "mult": "currency multiplier (e.g. 83 if provider rates are in USD, else 1)",
             "name": "new name", "url": "API URL", "key": "API key", "descr": "description (- to clear)", "discount": "discount % (0-90)", "platform": "platform"}


def mask(v):
    v = v or ""
    return (v[:4] + "•••" + v[-3:]) if len(v) > 9 else ("•••" if v else "not set")


async def show(update, text, rows=None):
    markup = InlineKeyboardMarkup(rows) if rows else None
    cq = update.callback_query
    try:
        if cq:
            await cq.edit_message_text(text[:4000], parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True)
        else:
            await update.effective_message.reply_text(text[:4000], parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True)
    except Exception as e:
        if "not modified" not in str(e).lower():
            log.warning("show failed: %s", e)


async def prompt(update, ctx, text, back, **kw):
    ctx.user_data["ask"] = dict(back=back, **kw)
    await show(update, text + "\n\n<i>Send the value now.</i>", [[B("✖️ Cancel", back)]])


def pager(prefix, page, total, per):
    row = []
    if page > 0:
        row.append(B("◀️ Prev", f"{prefix}:{page - 1}"))
    if (page + 1) * per < total:
        row.append(B("Next ▶️", f"{prefix}:{page + 1}"))
    return row


def stats():
    ist = "+330 minutes"
    one = lambda s, a=(): q1(s, a)
    base = "COUNT(*) n, COALESCE(SUM(price-refunded),0) rev, COALESCE(SUM(CASE WHEN price>0 THEN (price-refunded)*(1.0-cost/price) ELSE 0 END),0) pf"
    return {
        "users": one("SELECT COUNT(*) n FROM users")["n"], "ut": one("SELECT COUNT(*) n FROM users WHERE DATE(created_at,?)=DATE('now',?)", (ist, ist))["n"],
        "all": one(f"SELECT {base} FROM orders WHERE status!='failed'"),
        "today": one(f"SELECT {base} FROM orders WHERE status!='failed' AND DATE(created_at,?)=DATE('now',?)", (ist, ist)),
        "dep": one("SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE status='approved'")["s"],
        "dept": one("SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE status='approved' AND DATE(created_at,?)=DATE('now',?)", (ist, ist))["s"],
        "act": one("SELECT COUNT(*) n FROM orders WHERE status IN ('pending','processing')")["n"],
        "rev": one("SELECT COUNT(*) n FROM transactions WHERE status='review'")["n"],
        "bal": one("SELECT COALESCE(SUM(balance),0) s FROM users")["s"],
        "svc": one("SELECT COUNT(*) n FROM services WHERE active=1 AND avail=1")["n"],
    }


async def ui_home(update, ctx):
    await show(update, f"🛡 <b>{esc(S('store_name'))} · Admin Panel</b>\n\nControl everything from here. Choose a section:", [
        [B("📊 Dashboard", "a:dash"), B("📦 Orders", "a:ord")], [B("🔌 Providers", "a:prov"), B("🛒 Services", "a:svc")],
        [B("💳 Payments", "a:pay"), B("👥 Users", "a:usr")], [B("🎟 Coupons", "a:cp"), B("📢 Broadcast", "a:bc")],
        [B("⚙️ Settings", "a:set"), B("🧰 Tools", "a:tools")]])


async def ui_dash(update, ctx):
    s = stats()
    pend = f"\n⏳ <b>{s['rev']} payment(s) waiting for approval</b>" if s["rev"] else ""
    await show(update,
               f"📊 <b>DASHBOARD</b>  <i>{now_ist()} IST</i>\n\n👥 Users: <b>{s['users']}</b> (+{s['ut']} today)\n🛒 Live services: <b>{s['svc']}</b>\n"
               f"🔄 Active orders: <b>{s['act']}</b>\n\n<b>Today</b>\n  Orders: {s['today']['n']} · Sales {money(s['today']['rev'])}\n"
               f"  Profit ≈ <b>{money(s['today']['pf'])}</b> · Deposits {money(s['dept'])}\n\n<b>All time</b>\n  Orders: {s['all']['n']} · Sales {money(s['all']['rev'])}\n"
               f"  Profit ≈ <b>{money(s['all']['pf'])}</b> · Deposits {money(s['dep'])}\n  Users' wallet total: {money(s['bal'])}{pend}",
               [[B("🔄 Refresh", "a:dash"), B("🕒 Payments", "a:pend")], BK()])


# ── providers ──
async def ui_prov(update, ctx):
    rows = q("SELECT p.*, (SELECT COUNT(*) FROM services WHERE provider_id=p.id AND avail=1) n FROM providers p ORDER BY id")
    txt = "🔌 <b>SMM PROVIDERS</b>\n\n" + ("\n".join(f"{'🟢' if p['active'] else '⚪'} <b>{esc(p['name'])}</b> · {p['n']} services" for p in rows) or "No provider yet. Add your SMM panel API.")
    await show(update, txt, [[B(f"{'🟢' if p['active'] else '⚪'} {p['name'][:24]}", f"a:pv:{p['id']}")] for p in rows] + [[B("➕ Add provider", "a:padd")], BK()])


async def ui_pv(update, ctx, pid):
    p = q1("SELECT * FROM providers WHERE id=?", (pid,))
    if not p:
        return await ui_prov(update, ctx)
    n = q1("SELECT COUNT(*) n FROM services WHERE provider_id=? AND avail=1", (pid,))["n"]
    m = f"{p['margin']:g}%" if p["margin"] is not None else f"default ({SF('global_margin', 30):g}%)"
    await show(update, f"🔌 <b>{esc(p['name'])}</b>\n\n🌐 <code>{esc(p['url'])}</code>\n🔑 <code>{esc(mask(p['key']))}</code>\n📈 Margin: <b>{m}</b>\n"
                       f"💱 Rate multiplier: <b>×{p['mult']:g}</b>\n💼 Balance: <b>{esc(p['balance'] or '-')}</b>\n📦 Services: <b>{n}</b>\nStatus: {'🟢 active' if p['active'] else '⚪ hidden'}",
               [[B("💼 Check balance", f"a:pbal:{pid}"), B("⬇️ Import services", f"a:pimp:{pid}")],
                [B("📈 Margin", f"a:col:providers:{pid}:margin:a:pv:{pid}"), B("💱 Multiplier", f"a:col:providers:{pid}:mult:a:pv:{pid}")],
                [B("✏️ Name", f"a:col:providers:{pid}:name:a:pv:{pid}"), B("🌐 URL", f"a:col:providers:{pid}:url:a:pv:{pid}"), B("🔑 Key", f"a:col:providers:{pid}:key:a:pv:{pid}")],
                [B("⚪ Hide" if p["active"] else "🟢 Show", f"a:ptog:{pid}"), B("🗑 Delete", f"a:pdel:{pid}")], BK("a:prov")])


async def do_pbal(update, ctx, pid):
    p = q1("SELECT * FROM providers WHERE id=?", (pid,))
    try:
        r = await asyncio.to_thread(papi, p, action="balance")
        bal = f"{r.get('balance')} {r.get('currency', '')}".strip()
        ex("UPDATE providers SET balance=? WHERE id=?", (bal, pid))
    except ApiErr as e:
        await update.callback_query.answer(f"Error: {e}"[:190], show_alert=True)
    await ui_pv(update, ctx, pid)


async def do_pimp(update, ctx, pid):
    await update.callback_query.answer("Importing services... wait", show_alert=False)
    try:
        new, upd, gone = await asyncio.to_thread(import_services, pid)
        await update.callback_query.message.reply_text(f"✅ Import done\n➕ New: {new}\n🔄 Updated: {upd}\n🚫 Removed by provider: {gone}\n\nNew services use your margin. Check 🛒 Services to hide or edit.")
    except ApiErr as e:
        await update.callback_query.message.reply_text(f"❌ Import failed: {e}")
    await ui_pv(update, ctx, pid)


# ── services / categories ──
async def ui_svc(update, ctx):
    rows = q("SELECT c.platform p, COUNT(DISTINCT c.id) cn, COUNT(s.id) n FROM categories c LEFT JOIN services s ON s.cat_id=c.id AND s.avail=1 GROUP BY c.platform ORDER BY n DESC")
    await show(update, "🛒 <b>SERVICES</b>\n\nPick a platform to manage its categories and services.\n<i>Margin order: service → category → provider → global.</i>",
               [[B(f"{PLAT_NAME.get(r['p'], r['p'].title())} · {r['cn']} cats · {r['n']} svc", f"a:sp:{r['p']}:0")] for r in rows] +
               [[B("🔎 Find service by ID/name", "a:sfind")], BK()])


async def ui_sp(update, ctx, plat, page):
    per = 8
    rows = q("SELECT c.*, (SELECT COUNT(*) FROM services WHERE cat_id=c.id AND avail=1) n FROM categories c WHERE platform=? ORDER BY c.name", (plat,))
    chunk = rows[page * per:(page + 1) * per]
    kb = [[B(f"{'🟢' if c['active'] else '⚪'} {c['name'][:34]} ({c['n']})", f"a:sc:{c['id']}")] for c in chunk]
    pg = pager(f"a:sp:{plat}", page, len(rows), per)
    await show(update, f"🛒 <b>{esc(PLAT_NAME.get(plat, plat.title()))}</b> · {len(rows)} categories", kb + ([pg] if pg else []) + [BK("a:svc")])


async def ui_sc(update, ctx, cid):
    c = q1("SELECT * FROM categories WHERE id=?", (cid,))
    if not c:
        return await ui_svc(update, ctx)
    n = q1("SELECT COUNT(*) n FROM services WHERE cat_id=? AND avail=1", (cid,))["n"]
    m = f"{c['margin']:g}%" if c["margin"] is not None else "inherit"
    await show(update, f"📁 <b>{esc(c['name'])}</b>\n\nPlatform: <b>{esc(PLAT_NAME.get(c['platform'], c['platform']))}</b>\nServices: <b>{n}</b>\nMargin: <b>{m}</b>\nStatus: {'🟢 visible' if c['active'] else '⚪ hidden'}",
               [[B("📋 Services", f"a:ssl:{cid}:0"), B("⚪ Hide" if c["active"] else "🟢 Show", f"a:ctog:{cid}")],
                [B("📈 Margin", f"a:col:categories:{cid}:margin:a:sc:{cid}"), B("✏️ Rename", f"a:col:categories:{cid}:name:a:sc:{cid}")],
                [B("🔀 Move platform", f"a:cpl:{cid}"), B("🗑 Delete", f"a:cdel:{cid}")], BK(f"a:sp:{c['platform']}:0")])


async def ui_ssl(update, ctx, cid, page):
    per = 8
    rows = q("SELECT * FROM services WHERE cat_id=? AND avail=1 ORDER BY id", (cid,))
    kb = [[B(f"{'🟢' if s['active'] else '⚪'} {s['id']} · {s['name'][:38]}", f"a:sv:{s['id']}")] for s in rows[page * per:(page + 1) * per]]
    pg = pager(f"a:ssl:{cid}", page, len(rows), per)
    await show(update, f"📋 <b>Services</b> · {len(rows)}", kb + ([pg] if pg else []) + [BK(f"a:sc:{cid}")])


async def ui_sv(update, ctx, sid):
    s = q1(SVC_SQL + " WHERE s.id=?", (sid,))
    if not s:
        return await ui_svc(update, ctx)
    sr, cr = sell_rate(s), cost_rate(s)
    await show(update, f"📦 <b>#{s['id']}</b> {esc(s['name'])}\n\n📁 {esc(s['cname'])}\n🔌 {esc(s['prname'])} (id {esc(s['pid'])}) · {esc(s['type'])}\n"
                       f"💵 Cost/1000: <b>{money(cr)}</b>\n📈 Margin: <b>{eff_margin(s):g}%</b>{' (custom)' if s['margin'] is not None else ''}\n"
                       f"🏷 Sell/1000: <b>{money(sr)}</b> · profit/1000 {money(sr - cr)}\n🔢 Min {s['min']} · Max {s['max']}\n♻️ Refill: {'yes' if s['refill'] else 'no'}\n"
                       f"📝 {esc(s['descr'] or '-')}\nStatus: {'🟢 visible' if s['active'] else '⚪ hidden'}",
               [[B("⚪ Hide" if s["active"] else "🟢 Show", f"a:stog:{sid}"), B("📈 Margin", f"a:col:services:{sid}:margin:a:sv:{sid}")],
                [B("✏️ Name", f"a:col:services:{sid}:name:a:sv:{sid}"), B("📝 Description", f"a:col:services:{sid}:descr:a:sv:{sid}")], BK(f"a:ssl:{s['cat_id']}:0")])


# ── payments ──
def tbtn(k, back):
    return B(f"{'✅' if S(k) == '1' else '❌'} {TOGGLES[k]}", f"a:tg:{k}:{back}")


async def ui_pay(update, ctx):
    pend = q1("SELECT COUNT(*) n FROM transactions WHERE status='review'")["n"]
    await show(update,
               f"💳 <b>PAYMENTS</b>\n\n🏦 UPI ID: <code>{esc(S('upi_id') or 'not set')}</code>\n🪪 Name: {esc(S('upi_name'))}\n"
               f"🔑 FamPay key: <code>{esc(mask(S('fampay_key')))}</code>\n🌐 Base URL: <code>{esc(S('fampay_url'))}</code>\n"
               f"⬇️ Min ₹{SF('min_deposit'):g} · ⬆️ Max ₹{SF('max_deposit'):g} · 🎁 Bonus {SF('deposit_bonus'):g}%\n\n"
               "⚡ <b>Auto</b> = user pays then sends UTR, FamPay verifies, balance added instantly.\n✋ <b>Manual</b> = you approve from here.",
               [[B("🏦 UPI ID", "a:as:upi_id:a:pay"), B("🪪 Payee name", "a:as:upi_name:a:pay")],
                [B("🔑 FamPay API key", "a:as:fampay_key:a:pay"), B("🌐 FamPay base URL", "a:as:fampay_url:a:pay")],
                [B("⬇️ Min", "a:as:min_deposit:a:pay"), B("⬆️ Max", "a:as:max_deposit:a:pay"), B("🎁 Bonus %", "a:as:deposit_bonus:a:pay")],
                [tbtn("pay_auto_on", "a:pay"), tbtn("pay_manual_on", "a:pay")],
                [B(f"🕒 Pending approvals ({pend})", "a:pend"), B("🧪 Test FamPay", "a:fptest")], BK()])


async def ui_pend(update, ctx):
    rows = q("SELECT * FROM transactions WHERE status='review' ORDER BY id LIMIT 10")
    if not rows:
        return await show(update, "🕒 <b>No payments waiting.</b>", [BK("a:pay")])
    kb = [[B(f"✅ #{t['id']} {money(t['amount'])}", f"a:txok:{t['id']}"), B("❌ Reject", f"a:txno:{t['id']}")] for t in rows]
    txt = "🕒 <b>PENDING PAYMENTS</b>\n\n" + "\n".join(f"#{t['id']} · user <code>{t['user_id']}</code> · <b>{money(t['amount'])}</b> · UTR <code>{esc(t['utr'] or '-')}</code>" for t in rows)
    await show(update, txt, kb + [BK("a:pay")])


async def do_fptest(update, ctx):
    try:
        r = await asyncio.to_thread(fampay_verify, "TEST000000000", 1)
        msg = f"✅ API reachable. Reply: {r['message'] or 'ok'}"
    except FmPayError as e:
        msg = f"⚠️ {e}"
    await update.callback_query.answer(msg[:190], show_alert=True)


# ── users ──
async def ui_usr(update, ctx):
    n = q1("SELECT COUNT(*) n FROM users")["n"]
    await show(update, f"👥 <b>USERS</b> · {n}", [[B("🔍 Find user (ID or @username)", "a:usearch")], [B("💰 Top balances", "a:utop"), B("🚫 Banned", "a:ubanned")], BK()])


async def ui_ulist(update, ctx, title, sql):
    rows = q(sql)
    await show(update, f"{title}\n\n" + ("\n".join(f"<code>{r['telegram_id']}</code> {esc(r['first_name'] or '')} · {money(r['balance'])}" for r in rows) or "Nothing here."),
               [[B(f"{r['telegram_id']} {(r['first_name'] or '')[:14]}", f"a:u:{r['telegram_id']}")] for r in rows[:10]] + [BK("a:usr")])


async def ui_u(update, ctx, uid):
    u = q1("SELECT * FROM users WHERE telegram_id=?", (uid,))
    if not u:
        return await show(update, "User not found.", [BK("a:usr")])
    await show(update, f"👤 <b>{esc(u['first_name'] or '-')}</b> @{esc(u['username'] or '-')}\n🆔 <code>{uid}</code>\n💰 Balance: <b>{money(u['balance'])}</b>\n"
                       f"🛒 Orders {u['total_orders']} · Spent {money(u['total_spent'])}\n🏷 Discount: {u['discount']:g}%\n🎁 Referral earned: {money(u['ref_earn'])}\n"
                       f"📅 Joined: {esc(u['created_at'] or '')}\nStatus: {'🚫 BANNED' if u['banned'] else '✅ active'}",
               [[B("➕ Add balance", f"a:ubal:{uid}:1"), B("➖ Deduct", f"a:ubal:{uid}:-1")],
                [B("🏷 Discount %", f"a:col:users:{uid}:discount:a:u:{uid}"), B("✉️ Message", f"a:umsg:{uid}")],
                [B("✅ Unban" if u["banned"] else "🚫 Ban", f"a:uban:{uid}"), B("📦 Orders", f"a:uord:{uid}")], BK("a:usr")])


# ── orders ──
async def ui_ord(update, ctx):
    c = {r["status"]: r["n"] for r in q("SELECT status, COUNT(*) n FROM orders GROUP BY status")}
    kb = [[B(f"{st.title()} ({c.get(st, 0)})", f"a:ol:{st}:0")] for st in ("pending", "processing", "completed", "partial", "canceled", "failed")]
    await show(update, "📦 <b>ORDERS</b>\n\nPick a status to open the list.", [[B("📋 All latest", "a:ol:all:0")]] + kb + [[B("🔄 Sync with providers now", "a:sync")], BK()])


async def ui_ol(update, ctx, st, page, uid=0):
    per = 8
    where, args = ("1=1", ()) if st == "all" else ("status=?", (st,))
    if uid:
        where, args = "user_id=?", (uid,)
    rows = q(f"SELECT * FROM orders WHERE {where} ORDER BY id DESC LIMIT 200", args)
    kb = [[B(f"#{o['id']} · {o['status']} · {money(o['price'])}", f"a:ov:{o['id']}")] for o in rows[page * per:(page + 1) * per]]
    pg = pager(f"a:ol:{st}", page, len(rows), per) if not uid else []
    await show(update, f"📦 <b>Orders · {esc(st if not uid else 'user ' + str(uid))}</b> ({len(rows)})", kb + ([pg] if pg else []) + [BK("a:ord" if not uid else f"a:u:{uid}")])


async def ui_ov(update, ctx, oid):
    o = q1("SELECT o.*, s.name sname FROM orders o LEFT JOIN services s ON s.id=o.service_id WHERE o.id=?", (oid,))
    if not o:
        return await ui_ord(update, ctx)
    await show(update, f"📦 <b>Order #{oid}</b>\n\n👤 <code>{o['user_id']}</code>\n🛍 {esc(o['sname'] or '-')}\n🔗 {esc(o['link'][:120])}\n🔢 Qty {o['quantity']} · 💰 {money(o['price'])} (cost {money(o['cost'])})\n"
                       f"🆔 Provider order: <code>{esc(o['provider_order'] or '-')}</code>\n📊 Status: <b>{esc(o['status'])}</b> · start {esc(o['start_count'] or '-')} · remains {esc(o['remains'] or '-')}\n"
                       f"↩️ Refunded: {money(o['refunded'])}\n📝 {esc(o['note'] or '')}\n🕒 {esc(o['created_at'])}",
               [[B("🔍 Check status", f"a:oc:{oid}"), B("✅ Mark done", f"a:od:{oid}")], [B("↩️ Cancel + refund", f"a:orf:{oid}")], BK("a:ord")])


# ── coupons / settings / tools ──
async def ui_cp(update, ctx):
    rows = q("SELECT * FROM coupons ORDER BY created_at DESC LIMIT 15")
    await show(update, "🎟 <b>COUPONS</b>\n\n" + ("\n".join(f"<code>{c['code']}</code> · {money(c['amount'])} · {c['used']}/{c['max_uses']}" for c in rows) or "No coupons yet."),
               [[B(f"🗑 {c['code']}", f"a:cpd:{c['code']}")] for c in rows[:8]] + [[B("➕ New coupon", "a:cpn")], BK()])


async def ui_set(update, ctx):
    keys = ["store_name", "welcome", "support", "channel", "developer", "announcement", "global_margin", "min_order", "ref_percent", "low_balance"]
    tg_ = ["maintenance", "notify_orders", "notify_users", "block_dup", "auto_sync"]
    kb = [[B(META[k][0].split(" (")[0], f"a:as:{k}:a:set")] for k in keys]
    kb2 = [[tbtn(k, "a:set")] for k in tg_]
    await show(update, f"⚙️ <b>SETTINGS</b>\n\n📈 Global margin: <b>{SF('global_margin', 30):g}%</b>\n🏷 Store: {esc(S('store_name'))}\n💬 Support: {esc(S('support') or '-')}\n"
                       f"📢 Channel: {esc(S('channel') or '-')}\n🛠 Maintenance: {'ON' if S('maintenance') == '1' else 'off'}\n\nTap an item to change it.", kb + kb2 + [BK()])


async def ui_tools(update, ctx):
    await show(update, "🧰 <b>TOOLS</b>", [
        [B("🖼 Set logo (send photo)", "a:logo"), B("🔄 Sync orders now", "a:sync")],
        [B("💾 Backup database", "a:bkp"), B("📤 Export users CSV", "a:csv")],
        [B("💼 All provider balances", "a:allbal"), B("🧹 Clear all margin overrides", "a:clr")],
        [B("♻️ Re-import ALL providers", "a:impall")], BK()])


# ── router ──
async def route(update, ctx, data):
    p = data.split(":")
    c = p[1] if len(p) > 1 else "home"
    cq = update.callback_query
    I = lambda i: int(p[i])
    if c == "home":
        return await ui_home(update, ctx)
    if c == "dash":
        return await ui_dash(update, ctx)
    if c == "prov":
        return await ui_prov(update, ctx)
    if c == "pv":
        return await ui_pv(update, ctx, I(2))
    if c == "padd":
        return await prompt(update, ctx, "➕ <b>Add provider</b>\n\nSend 3-5 lines:\n<code>Name\nhttps://panel.com/api/v2\nAPI_KEY\nmargin% (optional)\nmultiplier (optional, 83 if rates are USD)</code>", "a:prov", t="padd")
    if c == "pbal":
        return await do_pbal(update, ctx, I(2))
    if c == "pimp":
        return await do_pimp(update, ctx, I(2))
    if c == "ptog":
        ex("UPDATE providers SET active=1-active WHERE id=?", (I(2),))
        return await ui_pv(update, ctx, I(2))
    if c == "pdel":
        return await show(update, "🗑 Delete this provider and ALL its services/categories? Old orders stay.", [[B("✅ Yes delete", f"a:pdelc:{I(2)}"), B("✖️ No", f"a:pv:{I(2)}")]])
    if c == "pdelc":
        ex("DELETE FROM services WHERE provider_id=?", (I(2),))
        ex("DELETE FROM categories WHERE provider_id=?", (I(2),))
        ex("DELETE FROM providers WHERE id=?", (I(2),))
        return await ui_prov(update, ctx)
    if c == "svc":
        return await ui_svc(update, ctx)
    if c == "sp":
        return await ui_sp(update, ctx, p[2], I(3))
    if c == "sc":
        return await ui_sc(update, ctx, I(2))
    if c == "ssl":
        return await ui_ssl(update, ctx, I(2), I(3))
    if c == "sv":
        return await ui_sv(update, ctx, I(2))
    if c == "sfind":
        return await prompt(update, ctx, "🔎 Send service ID or part of its name", "a:svc", t="sfind")
    if c == "ctog":
        ex("UPDATE categories SET active=1-active WHERE id=?", (I(2),))
        return await ui_sc(update, ctx, I(2))
    if c == "stog":
        ex("UPDATE services SET active=1-active WHERE id=?", (I(2),))
        return await ui_sv(update, ctx, I(2))
    if c == "cpl":
        return await show(update, "🔀 Move category to platform:", [[B(n, f"a:cpl2:{I(2)}:{k}")] for k, n in PLAT_NAME.items()] + [BK(f"a:sc:{I(2)}")])
    if c == "cpl2":
        ex("UPDATE categories SET platform=? WHERE id=?", (p[3], I(2)))
        return await ui_sc(update, ctx, I(2))
    if c == "cdel":
        return await show(update, "🗑 Delete this category and its services?", [[B("✅ Yes", f"a:cdelc:{I(2)}"), B("✖️ No", f"a:sc:{I(2)}")]])
    if c == "cdelc":
        pl = (q1("SELECT platform FROM categories WHERE id=?", (I(2),)) or {"platform": "other"})["platform"]
        ex("DELETE FROM services WHERE cat_id=?", (I(2),))
        ex("DELETE FROM categories WHERE id=?", (I(2),))
        return await ui_sp(update, ctx, pl, 0)
    if c == "col":      # a:col:<table>:<id>:<col>:<back...>
        tb, rid, col, back = p[2], I(3), p[4], ":".join(p[5:])
        if (tb, col) not in COLS:
            return
        return await prompt(update, ctx, f"✏️ Send new <b>{COL_LABEL.get(col, col)}</b>", back, t="col", tb=tb, rid=rid, col=col)
    if c == "pay":
        return await ui_pay(update, ctx)
    if c == "pend":
        return await ui_pend(update, ctx)
    if c == "fptest":
        return await do_fptest(update, ctx)
    if c in ("txok", "txno"):
        tid = I(2)
        if c == "txok":
            r = credit_tx(tid, None, f"admin {update.effective_user.id}")
            await cq.answer("✅ Approved" if r == "ok" else "Already handled / duplicate", show_alert=True)
        else:
            t = q1("SELECT * FROM transactions WHERE id=?", (tid,))
            if t and t["status"] in ("pending", "review"):
                ex("UPDATE transactions SET status='rejected', updated_at=CURRENT_TIMESTAMP WHERE id=?", (tid,))
                tg(t["user_id"], f"❌ <b>Payment #{tid} rejected.</b> Contact {esc(S('support'))} if you paid.")
            await cq.answer("❌ Rejected", show_alert=True)
        try:
            await cq.edit_message_text(f"Payment #{tid}: {q1('SELECT status FROM transactions WHERE id=?', (tid,))['status'].upper()}")
        except Exception:
            pass
        return
    if c == "as":
        k, back = p[2], ":".join(p[3:])
        if k in META:
            return await prompt(update, ctx, f"✏️ <b>{esc(META[k][0])}</b>\nCurrent: <code>{esc(mask(S(k)) if META[k][1] == 'secret' else (S(k) or '-')[:300])}</code>", back, t="set", key=k)
    if c == "tg":
        k, back = p[2], ":".join(p[3:])
        if k in TOGGLES:
            SET(k, "0" if S(k) == "1" else "1")
        return await route(update, ctx, back)
    if c == "usr":
        return await ui_usr(update, ctx)
    if c == "usearch":
        return await prompt(update, ctx, "🔍 Send user ID or @username", "a:usr", t="usearch")
    if c == "utop":
        return await ui_ulist(update, ctx, "💰 <b>Top balances</b>", "SELECT * FROM users ORDER BY balance DESC LIMIT 15")
    if c == "ubanned":
        return await ui_ulist(update, ctx, "🚫 <b>Banned users</b>", "SELECT * FROM users WHERE banned=1 LIMIT 30")
    if c == "u":
        return await ui_u(update, ctx, I(2))
    if c == "uban":
        ex("UPDATE users SET banned=1-banned WHERE telegram_id=?", (I(2),))
        return await ui_u(update, ctx, I(2))
    if c == "ubal":
        return await prompt(update, ctx, "💰 Send the amount to " + ("ADD" if I(3) > 0 else "DEDUCT"), f"a:u:{I(2)}", t="ubal", uid=I(2), sign=I(3))
    if c == "umsg":
        return await prompt(update, ctx, "✉️ Send the message for this user", f"a:u:{I(2)}", t="umsg", uid=I(2))
    if c == "uord":
        return await ui_ol(update, ctx, "all", 0, I(2))
    if c == "ord":
        return await ui_ord(update, ctx)
    if c == "ol":
        return await ui_ol(update, ctx, p[2], I(3))
    if c == "ov":
        return await ui_ov(update, ctx, I(2))
    if c in ("oc", "od", "orf"):
        o = q1("SELECT * FROM orders WHERE id=?", (I(2),))
        if o and c == "oc" and o["provider_order"]:
            try:
                r = await asyncio.to_thread(papi, q1("SELECT * FROM providers WHERE id=?", (o["provider_id"],)), action="status", order=o["provider_order"])
                apply_status(o, r)
            except ApiErr as e:
                await cq.answer(str(e)[:190], show_alert=True)
        elif o and c == "od":
            ex("UPDATE orders SET status='completed' WHERE id=?", (o["id"],))
        elif o and c == "orf":
            ex("UPDATE orders SET status='canceled' WHERE id=?", (o["id"],))
            r = refund(o["id"], o["price"])
            tg(o["user_id"], f"↩️ <b>Order #{o['id']} canceled.</b> {money(r)} refunded.")
        return await ui_ov(update, ctx, I(2))
    if c == "sync":
        n = await asyncio.to_thread(sync_orders)
        await cq.answer(f"Synced {n} order(s)", show_alert=True)
        return
    if c == "cp":
        return await ui_cp(update, ctx)
    if c == "cpn":
        return await prompt(update, ctx, "🎟 Send: <code>CODE AMOUNT MAX_USES</code>\nExample: <code>WELCOME10 10 100</code>", "a:cp", t="cpn")
    if c == "cpd":
        ex("DELETE FROM coupons WHERE code=?", (p[2],))
        return await ui_cp(update, ctx)
    if c == "bc":
        return await prompt(update, ctx, "📢 <b>Broadcast</b>\nSend the message text (HTML allowed). I will ask to confirm.", "a:home", t="bc")
    if c == "bcgo":
        text = ctx.user_data.pop("bc", "")
        if text:
            ctx.application.create_task(broadcast(ctx, update.effective_user.id, text))
            await show(update, "📢 Broadcast started. I will report when done.", [BK()])
        return
    if c == "set":
        return await ui_set(update, ctx)
    if c == "tools":
        return await ui_tools(update, ctx)
    if c == "logo":
        return await prompt(update, ctx, "🖼 Send a square photo for the logo (shown in Mini App).", "a:tools", t="logo")
    if c == "bkp":
        tmp = os.path.join(BASE, "backup.tmp.db")
        s_, d_ = sqlite3.connect(DB), sqlite3.connect(tmp)
        s_.backup(d_)
        d_.close()
        s_.close()
        with open(tmp, "rb") as f:
            await cq.message.reply_document(f, filename=f"vcsmm_{time.strftime('%Y%m%d_%H%M')}.db", caption="💾 Database backup")
        os.remove(tmp)
        return
    if c == "csv":
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["telegram_id", "username", "name", "balance", "spent", "orders", "banned", "joined"])
        for u in q("SELECT * FROM users"):
            w.writerow([u["telegram_id"], u["username"], u["first_name"], u["balance"], u["total_spent"], u["total_orders"], u["banned"], u["created_at"]])
        await cq.message.reply_document(io.BytesIO(buf.getvalue().encode()), filename="users.csv")
        return
    if c == "allbal":
        out = []
        for pr in q("SELECT * FROM providers"):
            try:
                r = await asyncio.to_thread(papi, pr, action="balance")
                b = f"{r.get('balance')} {r.get('currency', '')}".strip()
                ex("UPDATE providers SET balance=? WHERE id=?", (b, pr["id"]))
            except ApiErr as e:
                b = f"error: {e}"
            out.append(f"• <b>{esc(pr['name'])}</b>: {esc(b)}")
        return await show(update, "💼 <b>Provider balances</b>\n\n" + ("\n".join(out) or "No providers."), [BK("a:tools")])
    if c == "clr":
        return await show(update, "🧹 Remove ALL custom margins (services, categories, providers)? Everything will use the global margin.", [[B("✅ Yes", "a:clrc"), B("✖️ No", "a:tools")]])
    if c == "clrc":
        ex("UPDATE services SET margin=NULL")
        ex("UPDATE categories SET margin=NULL")
        ex("UPDATE providers SET margin=NULL")
        await cq.answer("Done. Global margin is used now.", show_alert=True)
        return await ui_tools(update, ctx)
    if c == "impall":
        await cq.answer("Importing all providers...")
        for pr in q("SELECT id, name FROM providers WHERE active=1"):
            try:
                n, u_, g = await asyncio.to_thread(import_services, pr["id"])
                await cq.message.reply_text(f"✅ {pr['name']}: +{n} new, {u_} updated, {g} removed")
            except ApiErr as e:
                await cq.message.reply_text(f"❌ {pr['name']}: {e}")
        return
    return await ui_home(update, ctx)


async def broadcast(ctx, admin, text):
    ok = bad = 0
    for u in q("SELECT telegram_id FROM users WHERE banned=0"):
        try:
            await ctx.bot.send_message(u["telegram_id"], text, parse_mode="HTML")
            ok += 1
        except Exception:
            bad += 1
        await asyncio.sleep(0.05)
    await ctx.bot.send_message(admin, f"📢 Broadcast finished\n✅ Sent: {ok}\n❌ Failed: {bad}")


async def on_cb(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cq = update.callback_query
    if not cq.data or not cq.data.startswith("a:"):
        return await cq.answer()
    if not is_admin(update):
        return await cq.answer("Admins only", show_alert=True)
    if not cq.data.startswith(("a:txok", "a:txno", "a:oc", "a:sync", "a:fptest", "a:pbal", "a:pimp", "a:allbal", "a:impall", "a:bkp", "a:csv", "a:clrc")):
        await cq.answer()
    ctx.user_data.pop("ask", None)
    try:
        await route(update, ctx, cq.data)
        try:
            await cq.answer()
        except Exception:
            pass
    except Exception as e:
        log.exception("admin route %s: %s", cq.data, e)
        try:
            await cq.answer("Error: " + str(e)[:150], show_alert=True)
        except Exception:
            pass


async def on_ask(update, ctx, a):
    m = update.message
    t = (m.text or "").strip()
    typ, back = a["t"], a["back"]
    back_update = update

    async def done(msg=None):
        ctx.user_data.pop("ask", None)
        if msg:
            await m.reply_text(msg, parse_mode="HTML")
        await route(back_update, ctx, back)
    try:
        if typ == "set":
            k = a["key"]
            kind = META[k][1]
            if kind == "num":
                v = str(float(t))
            elif kind == "url":
                if not t.startswith("http"):
                    return await m.reply_text("❌ URL must start with http:// or https://")
                v = t.rstrip("/")
            else:
                v = "" if t == "-" else (t if k == "welcome" else t[:300])
            SET(k, v)
            if kind == "secret":
                try:
                    await m.delete()
                except Exception:
                    pass
            return await done("✅ Saved")
        if typ == "col":
            tb, rid, col = a["tb"], a["rid"], a["col"]
            kind = COLS[(tb, col)]
            if kind == "numn":
                v = None if t == "-" else float(t)
            elif kind == "num":
                v = float(t)
                if col == "discount":
                    v = min(max(v, 0), 90)
                if col == "mult" and v <= 0:
                    return await m.reply_text("❌ Must be above 0")
            elif kind == "textn":
                v = "" if t == "-" else t[:1500]
            elif kind == "url":
                if not t.startswith("http"):
                    return await m.reply_text("❌ URL must start with http")
                v = t
            else:
                v = t[:200]
            ex(f"UPDATE {tb} SET {col}=? WHERE {'telegram_id' if tb == 'users' else 'id'}=?", (v, rid))
            if kind == "secret":
                try:
                    await m.delete()
                except Exception:
                    pass
            return await done("✅ Saved")
        if typ == "padd":
            ln = [x.strip() for x in re.split(r"\n|\|", t) if x.strip()]
            if len(ln) < 3 or not ln[1].startswith("http"):
                return await m.reply_text("❌ Send at least: name, https URL, API key (each on a new line)")
            mg = float(ln[3]) if len(ln) > 3 and ln[3] != "-" else None
            mu = float(ln[4]) if len(ln) > 4 else 1.0
            pid = exid("INSERT INTO providers(name,url,key,margin,mult) VALUES(?,?,?,?,?)", (ln[0][:40], ln[1], ln[2], mg, mu))
            try:
                await m.delete()
            except Exception:
                pass
            back_update = update
            ctx.user_data.pop("ask", None)
            await m.reply_text(f"✅ Provider <b>{esc(ln[0])}</b> added. Open it and tap <b>Import services</b>.", parse_mode="HTML")
            return await route(update, ctx, f"a:pv:{pid}")
        if typ == "usearch":
            r = q1("SELECT telegram_id FROM users WHERE telegram_id=?", (int(t),)) if t.lstrip("-").isdigit() else q1("SELECT telegram_id FROM users WHERE LOWER(username)=?", (t.lstrip("@").lower(),))
            if not r:
                return await m.reply_text("❌ User not found. Send again or tap Cancel.")
            ctx.user_data.pop("ask", None)
            return await route(update, ctx, f"a:u:{r['telegram_id']}")
        if typ == "ubal":
            amt = abs(float(t)) * a["sign"]
            if a["sign"] < 0:
                if not ex("UPDATE users SET balance=balance+? WHERE telegram_id=? AND balance+?>=0", (amt, a["uid"], amt)):
                    return await m.reply_text("❌ User does not have that much balance.")
            else:
                ex("UPDATE users SET balance=balance+? WHERE telegram_id=?", (amt, a["uid"]))
            tg(a["uid"], f"{'➕' if amt > 0 else '➖'} <b>Admin {'added' if amt > 0 else 'deducted'} {money(abs(amt))}</b> {'to' if amt > 0 else 'from'} your wallet.")
            return await done("✅ Balance updated")
        if typ == "umsg":
            tg(a["uid"], t)
            return await done("✅ Sent")
        if typ == "cpn":
            code, amount, uses = t.split()[:3]
            ex("INSERT OR REPLACE INTO coupons(code,amount,max_uses,used) VALUES(?,?,?,0)", (re.sub(r"[^A-Za-z0-9_-]", "", code).upper(), float(amount), int(uses)))
            return await done("✅ Coupon saved")
        if typ == "bc":
            ctx.user_data.pop("ask", None)
            ctx.user_data["bc"] = m.text_html if hasattr(m, "text_html") else t
            n = q1("SELECT COUNT(*) n FROM users WHERE banned=0")["n"]
            return await m.reply_text(f"📢 Send this to <b>{n}</b> users?\n\n{ctx.user_data['bc']}", parse_mode="HTML",
                                      reply_markup=InlineKeyboardMarkup([[B("✅ Send now", "a:bcgo"), B("✖️ Cancel", "a:home")]]))
        if typ == "sfind":
            ctx.user_data.pop("ask", None)
            rows = q(SVC_SQL + " WHERE s.id=? OR s.name LIKE ? LIMIT 10", (int(t) if t.isdigit() else -1, f"%{t}%"))
            return await m.reply_text("🔎 Results:" if rows else "Nothing found.", reply_markup=InlineKeyboardMarkup(
                [[B(f"{s['id']} · {s['name'][:40]}", f"a:sv:{s['id']}")] for s in rows] + [BK("a:svc")]))
    except (ValueError, IndexError):
        return await m.reply_text("❌ Invalid value. Send again, or tap Cancel above.")


async def on_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    t = (update.message.text or "").strip()
    a = ctx.user_data.get("ask")
    if a and is_admin(update):
        return await on_ask(update, ctx, a)
    u = update.effective_user
    row = ensure_user({"id": u.id, "first_name": u.first_name, "last_name": u.last_name, "username": u.username})
    if row["banned"]:
        return
    if t == BTN_PROFILE:
        return await send_profile(update)
    if t == BTN_CHANNEL:
        return await send_channel(update)
    if t == BTN_CONTACT:
        return await send_contact(update)
    if t == BTN_OPEN:
        return await update.message.reply_text("🚀 Tap below to open the panel", reply_markup=InlineKeyboardMarkup([[B("🚀 Open SMM Panel", web=app_url())]]) if app_url() else None)


async def on_photo(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    a = ctx.user_data.get("ask")
    if not (a and a.get("t") == "logo" and is_admin(update)):
        return
    f = await update.message.photo[-1].get_file()
    await f.download_to_drive(LOGO)
    ctx.user_data.pop("ask", None)
    await update.message.reply_text("✅ Logo updated. It shows in the Mini App header.")
    await route(update, ctx, "a:tools")


async def cmd_admin(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data.pop("ask", None)
    if not is_admin(update):
        return await update.message.reply_text(f"🆔 Your ID: <code>{update.effective_user.id}</code>", parse_mode="HTML")
    await ui_home(update, ctx)


async def cmd_cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data.pop("ask", None)
    await update.message.reply_text("Cancelled.")


async def cmd_id(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"🆔 <code>{update.effective_user.id}</code>", parse_mode="HTML")


async def job_sync(ctx: ContextTypes.DEFAULT_TYPE):
    ex("UPDATE transactions SET status='expired' WHERE status='pending' AND created_at < datetime('now','-45 minutes')")
    if S("auto_sync") == "1":
        try:
            await asyncio.to_thread(sync_orders)
        except Exception as e:
            log.warning("sync failed: %s", e)


_LOWSENT = {}


async def job_alert(ctx: ContextTypes.DEFAULT_TYPE):
    lim = SF("low_balance")
    if lim <= 0:
        return
    for pr in q("SELECT * FROM providers WHERE active=1"):
        try:
            r = await asyncio.to_thread(papi, pr, action="balance")
            b = float(r.get("balance"))
        except Exception:
            continue
        ex("UPDATE providers SET balance=? WHERE id=?", (f"{r.get('balance')} {r.get('currency', '')}".strip(), pr["id"]))
        if b < lim and time.time() - _LOWSENT.get(pr["id"], 0) > 6 * 3600:
            _LOWSENT[pr["id"]] = time.time()
            tg_admins(f"⚠️ <b>Low provider balance</b>\n{esc(pr['name'])}: {b:g} (limit {lim:g}). Orders may fail - recharge now.")


async def post_init(app):
    global LOOP, BOT, BOT_USER
    LOOP, BOT = asyncio.get_running_loop(), app.bot
    try:
        BOT_USER = (await app.bot.get_me()).username or ""
    except Exception:
        pass
    start_web()
    if app_url():
        try:
            from telegram import MenuButtonWebApp
            await app.bot.set_chat_menu_button(menu_button=MenuButtonWebApp(text="🚀 Open SMM", web_app=WebAppInfo(url=app_url())))
        except Exception as e:
            log.info("menu button not set: %s", e)


async def on_error(update, ctx):
    log.error("bot error: %s", ctx.error)


def main():
    if not TOKEN:
        raise SystemExit("BOT_TOKEN missing")
    init_db()
    app = Application.builder().token(TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("admin", cmd_admin))
    app.add_handler(CommandHandler("cancel", cmd_cancel))
    app.add_handler(CommandHandler("id", cmd_id))
    app.add_handler(CallbackQueryHandler(on_cb))
    app.add_handler(MessageHandler(filters.PHOTO, on_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    app.add_error_handler(on_error)
    if app.job_queue:
        app.job_queue.run_repeating(job_sync, interval=60, first=20)
        app.job_queue.run_repeating(job_alert, interval=1800, first=120)
    log.info("VC Mini SMM started | admins=%s | app=%s", sorted(ADMINS), app_url() or "NOT SET")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
