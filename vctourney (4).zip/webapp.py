"""Mini App backend for VC Tournament: tiny HTTP server (stdlib only) + JSON API.

Runs inside the bot process (bot.py starts it) and shares its database and wallet functions.
Every API call carries Telegram's signed initData, which is verified with the bot token, so users
cannot fake an identity. Admin endpoints additionally require the user to be in ADMIN_IDS.
"""
import os
import re
import json
import time
import hmac
import base64
import hashlib
import threading
import urllib.parse
from datetime import datetime, timedelta, timezone
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

import requests

import pay

b = None                                   # the bot module (set in start())
BASE = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(BASE, "static")
LOGOS = os.path.join(BASE, "logos")
IST = timezone(timedelta(hours=5, minutes=30))
MAX_BODY = 2 * 1024 * 1024
FILE_RE = re.compile(r"^[A-Za-z0-9_.\-]{1,80}$")

APP_DEFAULTS = {
    "app_title": "Welcome, {name} 👋",
    "app_sub": "Join tournaments, win real prizes & get paid to UPI",
}

# auto icon + colour suggestions when the admin adds a game
HINTS = [("free fire", "🔥", "fire"), ("freefire", "🔥", "fire"), ("bgmi", "🪖", "gold"), ("pubg", "🪖", "gold"),
         ("call of duty", "🎯", "olive"), ("cod", "🎯", "olive"), ("minecraft", "⛏️", "green"), ("ludo", "🎲", "rainbow"),
         ("valorant", "🔫", "red"), ("cs", "💣", "sunset"), ("counter", "💣", "sunset"), ("chess", "♟️", "dark"),
         ("cricket", "🏏", "blue"), ("fifa", "⚽", "green"), ("football", "⚽", "green"), ("efootball", "⚽", "blue"),
         ("carrom", "🎯", "gold"), ("pool", "🎱", "cyan"), ("clash", "⚔️", "purple"), ("rummy", "🃏", "red"),
         ("poker", "♠️", "dark"), ("fortnite", "🛡️", "purple"), ("apex", "🦅", "red"), ("roblox", "🧱", "pink"),
         ("mobile legends", "🗡️", "cyan"), ("mlbb", "🗡️", "cyan"), ("among", "🚀", "red"), ("subway", "🏃", "sunset")]
GRADS = {"fire", "gold", "olive", "green", "rainbow", "red", "blue", "purple", "pink", "cyan", "dark", "sunset"}

SETTING_KEYS = {
    "text": ["brand", "support", "app_title", "app_sub", "notice", "txt_welcome", "txt_terms", "upi", "webapp_url",
             "fam_base", "fam_path", "fam_key_param", "fam_utr_param", "fam_paid_field", "fam_paid_value", "fam_amount_field", "welcome_btn"],
    "num": ["min_dep", "min_wd"],
    "bool": ["maint"],
    "choice": {"gw": ["none", "razorpay", "upigateway", "fampay"], "fam_method": ["GET", "POST"]},
    "secret": ["rzp_key", "rzp_secret", "rzp_hook", "upig_key", "fam_key"],
}


class ApiError(Exception):
    pass


# ------------------------------------------------------------------ helpers
def verify(init):
    try:
        pairs = dict(urllib.parse.parse_qsl(init, keep_blank_values=True))
        h = pairs.pop("hash", "")
        if not h or "user" not in pairs:
            return None
        dcs = "\n".join("%s=%s" % (k, pairs[k]) for k in sorted(pairs))
        secret = hmac.new(b"WebAppData", b.BOT_TOKEN.encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest(), h):
            return None
        if time.time() - int(pairs.get("auth_date", "0")) > 86400 * 2:
            return None
        u = json.loads(pairs["user"])
        return u if isinstance(u, dict) and "id" in u else None
    except (ValueError, TypeError):
        return None


def rows(r):
    return [dict(x) for x in r]


def fnum(v, lo=0.0, hi=1e7, what="amount"):
    try:
        f = round(float(str(v).replace(",", "").replace("₹", "").strip()), 2)
    except ValueError:
        raise ApiError("Enter a valid %s" % what)
    if f != f or f < lo or f > hi:
        raise ApiError("%s must be between %s and %s" % (what.capitalize(), lo, hi))
    return f


def inum(v, lo, hi, what):
    try:
        i = int(float(v))
    except (ValueError, TypeError):
        raise ApiError("Enter a valid %s" % what)
    if i < lo or i > hi:
        raise ApiError("%s must be %d-%d" % (what.capitalize(), lo, hi))
    return i


def logo_url(g):
    v = g.get("logo") or ""
    return ("/logos/" + v[5:]) if v.startswith("file:") else v


def img_url(v):
    v = v or ""
    return ("/logos/" + v[5:]) if v.startswith("file:") else v


def upload_photo(uid, path, caption=""):
    """Upload a local image to a Telegram chat; returns the reusable file_id (or None)."""
    try:
        with open(path, "rb") as f:
            r = b.SESSION.post(b.API + "/sendPhoto", data={"chat_id": uid, "caption": caption[:1000], "parse_mode": "HTML"},
                               files={"photo": f}, timeout=40).json()
        return r["result"]["photo"][-1]["file_id"]
    except Exception:
        return None


def game_out(g):
    g = dict(g)
    return {"id": g["id"], "name": g["name"], "emoji": g["emoji"], "color": g.get("color") or "", "logo": logo_url(g), "active": g["active"], "sort": g.get("sort", 0)}


def tour_out(t, uid=None):
    t = dict(t)
    g = b.q1("SELECT * FROM games WHERE id=?", (t["gid"],))
    t["game"] = game_out(g) if g else None
    t["filled"] = b.filled(t["id"])
    t["joined"] = bool(uid and b.q1("SELECT 1 FROM parts WHERE tid=? AND uid=?", (t["id"], uid)))
    t["banner"] = img_url(t.get("banner"))
    t.pop("room_id", None)
    t.pop("room_pass", None)
    return t


def save_image(data_url, prefix):
    m = re.match(r"^data:image/(png|jpeg|jpg|webp|gif);base64,([A-Za-z0-9+/=\s]+)$", data_url or "")
    if not m:
        raise ApiError("Upload a PNG / JPG / WEBP image")
    raw = base64.b64decode(m.group(2))
    if len(raw) > 700 * 1024:
        raise ApiError("Image is too big (max 700 KB)")
    os.makedirs(LOGOS, exist_ok=True)
    name = "%s_%d.%s" % (prefix, int(time.time()), "jpg" if m.group(1) == "jpeg" else m.group(1))
    with open(os.path.join(LOGOS, name), "wb") as f:
        f.write(raw)
    return name


def start_text(ts):
    return datetime.fromtimestamp(ts, IST).strftime("%d %b, %I:%M %p").lstrip("0")


def parse_when(v):
    """datetime-local string from the admin form, treated as IST -> epoch seconds."""
    try:
        return int(datetime.strptime(v[:16], "%Y-%m-%dT%H:%M").replace(tzinfo=IST).timestamp())
    except (ValueError, TypeError):
        raise ApiError("Pick a valid start date & time")


def notify(uid, text, kb=None):
    try:
        b.send(uid, text, kb)
    except Exception as e:
        b.log("notify failed: %r" % (e,))


def admins(text, kb=None):
    try:
        b.notify_admins(text, kb)
    except Exception as e:
        b.log("admin notify failed: %r" % (e,))


def open_btn(path="/"):
    u = b.app_url(path)
    return [[b.B("🏆 Open App", web=u, style="success")]] if u else None


# ------------------------------------------------------------------ user API
def api_me(u, p):
    d, w = b.balances(u["id"])
    sup = b.S("support").lstrip("@")
    return {"user": {"id": u["id"], "name": u["name"], "username": u["username"], "photo": u["photo"], "joined": u["joined"]},
            "is_admin": b.is_admin(u["id"]), "brand": b.S("brand"), "support": sup, "notice": b.S("notice"),
            "title": b.S("app_title").replace("{name}", u["name"].split(" ")[0]).replace("{brand}", b.S("brand")), "sub": b.S("app_sub"),
            "dep": d, "win": w, "maint": b.S("maint") == "1", "terms": b.plain(b.S("txt_terms")),
            "min_dep": b.fnum("min_dep", 10), "min_wd": b.fnum("min_wd", 50),
            "welcome_img": img_url("file:" + b.S("welcome_img_file")) if b.S("welcome_img_file") else "", "welcome_btn": b.S("welcome_btn")}


def api_home(u, p):
    gs = [game_out(g) for g in b.q("SELECT * FROM games WHERE active=1 ORDER BY sort, id")]
    ts = b.q("SELECT * FROM tournaments WHERE status IN ('live','upcoming') ORDER BY CASE status WHEN 'live' THEN 0 ELSE 1 END, "
             "CASE WHEN start_ts>0 THEN start_ts ELSE 9999999999 END, id DESC LIMIT 30")
    st = b.q1("SELECT (SELECT COUNT(*) FROM users) players, (SELECT COALESCE(SUM(amount),0) FROM txns WHERE kind='prize') paid, "
              "(SELECT COUNT(*) FROM tournaments WHERE status='completed') done")
    mine = b.q1("SELECT COUNT(*) c FROM parts p JOIN tournaments t ON t.id=p.tid WHERE p.uid=? AND t.status IN ('upcoming','live')", (u["id"],))["c"]
    return {"games": gs, "tours": [tour_out(t, u["id"]) for t in ts], "banners": [dict(x, img=img_url(x.get("img"))) for x in rows(b.q("SELECT * FROM banners WHERE active=1 ORDER BY id DESC LIMIT 6"))],
            "stats": dict(st), "mine_active": mine}


def api_game(u, p):
    gid = inum(p.get("id"), 1, 10**9, "game")
    g = b.q1("SELECT * FROM games WHERE id=?", (gid,))
    if not g:
        raise ApiError("Game not found")
    ts = b.q("SELECT * FROM tournaments WHERE gid=? ORDER BY CASE status WHEN 'live' THEN 0 WHEN 'upcoming' THEN 1 ELSE 2 END, id DESC LIMIT 40", (gid,))
    return {"game": game_out(g), "tours": [tour_out(t, u["id"]) for t in ts]}


def api_tour(u, p):
    tid = inum(p.get("id"), 1, 10**9, "tournament")
    t = b.q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t:
        raise ApiError("Tournament not found")
    out = tour_out(t, u["id"])
    mine = b.q1("SELECT * FROM parts WHERE tid=? AND uid=?", (tid, u["id"]))
    out["mine"] = dict(mine) if mine else None
    if mine and t["status"] in ("upcoming", "live") and t["room_id"]:
        out["room"] = {"id": t["room_id"], "pass": t["room_pass"]}
    out["players"] = rows(b.q("SELECT slot, ign, rank, kills, prize FROM parts WHERE tid=? ORDER BY slot LIMIT 200", (tid,)))
    out["results"] = rows(b.q("SELECT slot, ign, rank, kills, prize FROM parts WHERE tid=? AND (rank>0 OR prize>0) ORDER BY rank", (tid,))) if t["status"] == "completed" else []
    s = b.q1("SELECT name FROM ign WHERE uid=? AND gid=?", (u["id"], t["gid"]))
    out["saved_ign"] = s["name"] if s else ""
    return out


def api_join(u, p):
    tid = inum(p.get("id"), 1, 10**9, "tournament")
    ign = str(p.get("ign", "")).strip()
    if not 2 <= len(ign) <= 40:
        raise ApiError("Enter your in-game name (2-40 characters)")
    res, slot = b.do_join(u["id"], tid, ign)
    msg = {"closed": "This tournament is not open for joining", "dup": "You already joined this tournament", "full": "Slots are full",
           "funds": "Not enough balance - add money first"}
    if res != "ok":
        raise ApiError(msg[res])
    t = b.q1("SELECT title FROM tournaments WHERE id=?", (tid,))
    notify(u["id"], "🎉 <b>Joined %s</b>\nSlot <b>#%d</b> · IGN <code>%s</code>" % (b.esc(t["title"]), slot, b.esc(ign)), open_btn("/#t/%d" % tid))
    d, w = b.balances(u["id"])
    return {"slot": slot, "dep": d, "win": w}


def api_my(u, p):
    r = b.q("SELECT t.*, p.slot, p.ign, p.rank, p.kills, p.prize FROM parts p JOIN tournaments t ON t.id=p.tid WHERE p.uid=? ORDER BY p.id DESC LIMIT 60", (u["id"],))
    out = []
    for t in r:
        o = tour_out(t, u["id"])
        o.update({"slot": t["slot"], "ign": t["ign"], "rank": t["rank"], "kills": t["kills"], "prize": t["prize"]})
        out.append(o)
    return {"items": out}


def api_wallet(u, p):
    d, w = b.balances(u["id"])
    return {"dep": d, "win": w, "gw": pay.mode(b), "min_dep": b.fnum("min_dep", 10), "min_wd": b.fnum("min_wd", 50),
            "txns": rows(b.q("SELECT kind, amount, note, created FROM txns WHERE uid=? ORDER BY id DESC LIMIT 40", (u["id"],))),
            "deps": rows(b.q("SELECT id, amount, status, gw, created FROM deposits WHERE uid=? ORDER BY id DESC LIMIT 8", (u["id"],))),
            "wds": rows(b.q("SELECT id, amount, upi, status, created FROM withdrawals WHERE uid=? ORDER BY id DESC LIMIT 8", (u["id"],)))}


def settle(did):
    """Credit a confirmed gateway deposit (atomic and idempotent) and tell the user."""
    d = b.dep_decide(did, True)
    if d:
        notify(d["uid"], "✅ <b>%s added to your wallet</b> (auto payment). Good luck! 🏆" % b.fm(d["amount"]), open_btn("/"))
        admins("💳 <b>Auto deposit %s</b> · user <code>%d</code> · #%d" % (b.fm(d["amount"]), d["uid"], did))
    return d


def api_dep_create(u, p):
    amt = fnum(p.get("amount"), b.fnum("min_dep", 10), 100000, "amount")
    m = pay.mode(b)
    if m in ("none", "fampay"):
        if not b.S("upi") and not b.S("qr"):
            raise ApiError("Add Money is not set up yet. Contact support.")
        link = "upi://pay?pa=%s&pn=%s&am=%s&cu=INR&tn=Wallet" % (urllib.parse.quote(b.S("upi")), urllib.parse.quote(b.S("brand")), amt)
        return {"manual": True, "auto": m == "fampay", "upi": b.S("upi"), "link": link, "qr": bool(b.S("qr_file")), "amount": amt}
    if b.q1("SELECT COUNT(*) c FROM deposits WHERE uid=? AND status='awaiting'", (u["id"],))["c"] >= 5:
        raise ApiError("Too many unpaid payment links. Finish or wait a few minutes.")
    did = b.x("INSERT INTO deposits(uid,amount,utr,gw,ref,status,created) VALUES(?,?,?,?,?,?,?)",
              (u["id"], amt, "GW%d-%d" % (0, time.time()), m, "", "awaiting", b.now_s()))
    ret = b.app_url("/pay/return")
    url, ref = pay.create(b, u["id"], u["name"], did, amt, ret)
    if not url:
        b.x("DELETE FROM deposits WHERE id=?", (did,))
        raise ApiError(ref)
    b.x("UPDATE deposits SET ref=?, utr=? WHERE id=?", (ref, ref, did))
    return {"url": url, "did": did, "amount": amt}


def api_dep_check(u, p):
    did = inum(p.get("id"), 1, 10**9, "deposit")
    d = b.q1("SELECT * FROM deposits WHERE id=? AND uid=?", (did, u["id"]))
    if not d:
        raise ApiError("Deposit not found")
    if d["status"] == "awaiting" and d["gw"]:
        r = pay.check(b, d)
        if r is True:
            settle(did)
        elif r is False:
            b.x("UPDATE deposits SET status='failed' WHERE id=? AND status='awaiting'", (did,))
        d = b.q1("SELECT status FROM deposits WHERE id=?", (did,))
    dd, ww = b.balances(u["id"])
    return {"status": d["status"], "dep": dd, "win": ww}


def api_dep_manual(u, p):
    amt = fnum(p.get("amount"), b.fnum("min_dep", 10), 100000, "amount")
    utr = str(p.get("utr", "")).strip().upper()
    if not b.UTR_RE.match(utr):
        raise ApiError("UTR / transaction ID is 6-30 letters or numbers")
    with b.L:
        if b.DB.execute("SELECT 1 FROM deposits WHERE utr=? AND status NOT IN ('rejected','failed','expired')", (utr,)).fetchone():
            raise ApiError("This UTR was already submitted")
        if b.DB.execute("SELECT COUNT(*) c FROM deposits WHERE uid=? AND status='pending'", (u["id"],)).fetchone()["c"] >= 3:
            raise ApiError("You already have 3 pending deposits. Please wait for approval.")
        fam = pay.mode(b) == "fampay"
        did = b.DB.execute("INSERT INTO deposits(uid,amount,utr,gw,created) VALUES(?,?,?,?,?)", (u["id"], amt, utr, "fampay" if fam else "", b.now_s())).lastrowid
        b.DB.commit()
    if fam:
        # ask the FamPay-style checker right away; if it confirms, the wallet is credited instantly
        if pay.check_utr(b, b.q1("SELECT * FROM deposits WHERE id=?", (did,))) is True and settle(did):
            return {"id": did, "credited": True}
    admins("<blockquote><b>📥 NEW DEPOSIT #%d</b></blockquote>\nUser: %s (<code>%d</code>)\nAmount: <b>%s</b>\nUTR: <code>%s</code>" % (did, b.esc(u["name"]), u["id"], b.fm(amt), utr),
           [[b.B("✅ Approve", "dp:a:%d" % did, style="success"), b.B("❌ Reject", "dp:r:%d" % did, style="danger")]])
    return {"id": did, "credited": False}


def api_wd(u, p):
    amt = fnum(p.get("amount"), b.fnum("min_wd", 50), 100000, "amount")
    upi = str(p.get("upi", "")).strip()
    if not b.UPI_RE.match(upi):
        raise ApiError("Enter a valid UPI ID, e.g. name@okaxis")
    wid = b.wd_create(u["id"], amt, upi)
    if wid is None:
        raise ApiError("Not enough winning balance")
    if wid == -1:
        raise ApiError("You already have 2 pending withdrawals")
    admins("<blockquote><b>📤 NEW WITHDRAWAL #%d</b></blockquote>\nUser: %s (<code>%d</code>)\nAmount: <b>%s</b>\nUPI: <code>%s</code>" % (wid, b.esc(u["name"]), u["id"], b.fm(amt), b.esc(upi)),
           [[b.B("✅ Paid", "wr:p:%d" % wid, style="success"), b.B("❌ Reject & refund", "wr:r:%d" % wid, style="danger")]])
    d, w = b.balances(u["id"])
    return {"id": wid, "dep": d, "win": w}


def api_lb(u, p):
    r = b.q("SELECT u.id, u.name, u.username, u.photo, COALESCE(SUM(p.prize),0) earned, COUNT(p.id) played, COALESCE(SUM(p.kills),0) kills, u.wins "
            "FROM users u JOIN parts p ON p.uid=u.id GROUP BY u.id HAVING earned>0 ORDER BY earned DESC, kills DESC LIMIT 25")
    return {"items": rows(r)}


def api_profile(u, p):
    s = b.q1("SELECT COUNT(*) played, COALESCE(SUM(prize),0) earned, COALESCE(SUM(kills),0) kills FROM parts WHERE uid=?", (u["id"],))
    uu = b.q1("SELECT wins FROM users WHERE id=?", (u["id"],))
    return {"played": s["played"], "earned": s["earned"], "kills": s["kills"], "wins": uu["wins"]}


# ------------------------------------------------------------------ admin API
def a_dash(u, p):
    g = lambda sql: b.q1(sql)[0] or 0
    return {"users": g("SELECT COUNT(*) FROM users"), "wallet": g("SELECT SUM(dep+win) FROM users"),
            "dep_pending": g("SELECT COUNT(*) FROM deposits WHERE status='pending'"), "wd_pending": g("SELECT COUNT(*) FROM withdrawals WHERE status='pending'"),
            "dep_total": g("SELECT SUM(amount) FROM deposits WHERE status='approved'"), "wd_total": g("SELECT SUM(amount) FROM withdrawals WHERE status='paid'"),
            "fees": g("SELECT SUM(amount) FROM txns WHERE kind='join'"), "prizes": g("SELECT SUM(amount) FROM txns WHERE kind='prize'"),
            "live": g("SELECT COUNT(*) FROM tournaments WHERE status='live'"), "upcoming": g("SELECT COUNT(*) FROM tournaments WHERE status='upcoming'"),
            "gw": pay.mode(b), "url": b.app_url(), "new_today": g("SELECT COUNT(*) FROM users WHERE joined LIKE '%s%%'" % datetime.now(IST).strftime("%d-%m-%Y"))}


def mask(v):
    return ("•" * 6 + v[-4:]) if v else ""


def a_settings_get(u, p):
    out = {}
    for k in SETTING_KEYS["text"] + SETTING_KEYS["num"] + SETTING_KEYS["bool"] + list(SETTING_KEYS["choice"]):
        out[k] = b.S(k)
    for k in SETTING_KEYS["secret"]:
        out[k] = mask(b.S(k))
    out["qr"] = bool(b.S("qr"))
    out["tunnel_url"] = b.RT["url"]
    out["gw_active"] = pay.mode(b)
    out["welcome_img_url"] = img_url("file:" + b.S("welcome_img_file")) if b.S("welcome_img") and b.S("welcome_img_file") else ""
    out["webhook"] = (b.app_url("/pay/webhook/razorpay"))
    return out


def a_settings_set(u, p):
    vals = p.get("values") or {}
    if not isinstance(vals, dict):
        raise ApiError("Bad data")
    for k, v in vals.items():
        v = str(v).strip()
        if k in SETTING_KEYS["secret"]:
            if v.startswith("•"):
                continue
        elif k in SETTING_KEYS["num"]:
            v = str(fnum(v, 1, 100000, k.replace("_", " ")))
        elif k in SETTING_KEYS["bool"]:
            v = "1" if v in ("1", "true", "True") else "0"
        elif k in SETTING_KEYS["choice"]:
            if v not in SETTING_KEYS["choice"][k]:
                raise ApiError("Bad option")
        elif k in SETTING_KEYS["text"]:
            if k == "support":
                v = v.lstrip("@")
                if v and not re.match(r"^[A-Za-z0-9_]{4,32}$", v):
                    raise ApiError("Support must be a Telegram username")
            elif k == "upi" and v and not b.UPI_RE.match(v):
                raise ApiError("Invalid UPI ID")
            elif k == "fam_base" and v and not v.startswith("https://"):
                raise ApiError("FamPay base URL must start with https://")
            elif k == "webapp_url" and v and not v.startswith("https://"):
                raise ApiError("App URL must start with https://")
            elif k == "brand" and not v:
                raise ApiError("Brand name cannot be empty")
            elif len(v) > 3500:
                raise ApiError("Text too long")
        else:
            continue
        b.set_S(k, v)
    if "webapp_url" in vals:
        b.set_menu_button((b.S("webapp_url") or b.RT["url"]).rstrip("/"))
    return {"ok": True}


def a_qr_set(u, p):
    name = save_image(p.get("data"), "qr")
    path = os.path.join(LOGOS, name)
    try:
        with open(path, "rb") as f:
            r = b.SESSION.post(b.API + "/sendPhoto", data={"chat_id": u["id"], "caption": "✅ UPI QR saved"}, files={"photo": f}, timeout=40).json()
        fid = r["result"]["photo"][-1]["file_id"]
    except Exception:
        raise ApiError("Could not store QR. Try again.")
    b.set_S("qr", fid)
    b.set_S("qr_file", name)
    return {"ok": True}


def a_welcome_img_set(u, p):
    name = save_image(p.get("data"), "welcome")
    fid = upload_photo(u["id"], os.path.join(LOGOS, name), "✅ Welcome photo saved")
    if not fid:
        raise ApiError("Could not store the photo. Try again.")
    b.set_S("welcome_img", fid)
    b.set_S("welcome_img_file", name)
    return {"url": img_url("file:" + name)}


def a_welcome_img_clear(u, p):
    b.set_S("welcome_img", "")
    b.set_S("welcome_img_file", "")
    return {"ok": True}


def a_welcome_preview(u, p):
    b.home(u["id"], None, u["id"], u["name"])
    return {"ok": True}


def a_fam_test(u, p):
    return pay.test(b)


def a_game_list(u, p):
    return {"items": [game_out(g) for g in b.q("SELECT * FROM games ORDER BY sort, id")], "hints": [{"k": h[0], "e": h[1], "c": h[2]} for h in HINTS]}


def a_game_save(u, p):
    name = str(p.get("name", "")).strip()
    hint = next((h for h in HINTS if h[0] in name.lower()), None)
    emoji = str(p.get("emoji", "")).strip()[:8] or (hint[1] if hint else "🎮")
    if not 2 <= len(name) <= 30:
        raise ApiError("Game name must be 2-30 characters")
    color = str(p.get("color", ""))
    if color not in GRADS:
        color = hint[2] if hint else "purple"
    gid = p.get("id")
    logo = str(p.get("logo_url", "")).strip()
    if logo and not logo.startswith("https://"):
        raise ApiError("Logo link must start with https://")
    if gid:
        gid = inum(gid, 1, 10**9, "game")
        if not b.q1("SELECT 1 FROM games WHERE id=?", (gid,)):
            raise ApiError("Game not found")
        b.x("UPDATE games SET name=?, emoji=?, color=?, active=?, sort=? WHERE id=?", (name, emoji, color, 1 if p.get("active", True) else 0, inum(p.get("sort", 0), 0, 9999, "order"), gid))
    else:
        gid = b.x("INSERT INTO games(name,emoji,color,sort) VALUES(?,?,?,?)", (name, emoji, color, inum(p.get("sort", 0), 0, 9999, "order")))
    if p.get("logo_data"):
        b.x("UPDATE games SET logo=? WHERE id=?", ("file:" + save_image(p["logo_data"], "game%d" % gid), gid))
    elif p.get("clear_logo"):
        b.x("UPDATE games SET logo='' WHERE id=?", (gid,))
    elif logo:
        b.x("UPDATE games SET logo=? WHERE id=?", (logo, gid))
    return {"id": gid}


def a_game_del(u, p):
    gid = inum(p.get("id"), 1, 10**9, "game")
    if b.q1("SELECT 1 FROM tournaments WHERE gid=?", (gid,)):
        b.x("UPDATE games SET active=0 WHERE id=?", (gid,))
        return {"hidden": True}
    b.x("DELETE FROM games WHERE id=?", (gid,))
    return {"hidden": False}


def a_banner_list(u, p):
    return {"items": [dict(x, img=img_url(x.get("img"))) for x in rows(b.q("SELECT * FROM banners ORDER BY id DESC"))]}


def a_banner_save(u, p):
    title = str(p.get("title", "")).strip()[:40]
    if not title:
        raise ApiError("Banner needs a title")
    grad = str(p.get("grad", "fire"))
    grad = grad if grad in GRADS else "fire"
    args = (title, str(p.get("sub", "")).strip()[:80], str(p.get("emoji", "🔥")).strip()[:8] or "🔥", grad, 1 if p.get("active", True) else 0)
    if p.get("id"):
        bid = inum(p["id"], 1, 10**9, "banner")
        b.x("UPDATE banners SET title=?, sub=?, emoji=?, grad=?, active=? WHERE id=?", args + (bid,))
    else:
        bid = b.x("INSERT INTO banners(title,sub,emoji,grad,active) VALUES(?,?,?,?,?)", args)
    if p.get("img_data"):
        b.x("UPDATE banners SET img=? WHERE id=?", ("file:" + save_image(p["img_data"], "ban%d" % bid), bid))
    elif p.get("clear_img"):
        b.x("UPDATE banners SET img='' WHERE id=?", (bid,))
    return {"ok": True}


def a_banner_del(u, p):
    b.x("DELETE FROM banners WHERE id=?", (inum(p.get("id"), 1, 10**9, "banner"),))
    return {"ok": True}


def a_tours(u, p):
    return {"items": [tour_out(t) for t in b.q("SELECT * FROM tournaments ORDER BY id DESC LIMIT 60")]}


def a_tour_get(u, p):
    t = b.q1("SELECT * FROM tournaments WHERE id=?", (inum(p.get("id"), 1, 10**9, "tournament"),))
    if not t:
        raise ApiError("Not found")
    o = tour_out(t)
    o["room"] = {"id": t["room_id"], "pass": t["room_pass"]}
    o["players"] = rows(b.q("SELECT uid, slot, ign, rank, kills, prize FROM parts WHERE tid=? ORDER BY slot", (t["id"],)))
    return o


def a_tour_save(u, p):
    gid = inum(p.get("gid"), 1, 10**9, "game")
    if not b.q1("SELECT 1 FROM games WHERE id=?", (gid,)):
        raise ApiError("Pick a game")
    title = str(p.get("title", "")).strip()[:40]
    if len(title) < 3:
        raise ApiError("Enter a tournament title")
    mode = str(p.get("mode", "Solo")).strip()[:20] or "Solo"
    fee, pool, pk = fnum(p.get("fee", 0), 0, 100000, "entry fee"), fnum(p.get("pool", 0), 0, 10**7, "prize pool"), fnum(p.get("per_kill", 0), 0, 100000, "per kill")
    slots = inum(p.get("slots"), 2, 1000, "slots")
    ts = parse_when(p.get("when"))
    mp = str(p.get("map", "")).strip()[:30]
    if p.get("id"):
        tid = inum(p["id"], 1, 10**9, "tournament")
        t = b.q1("SELECT * FROM tournaments WHERE id=?", (tid,))
        if not t or t["status"] != "upcoming":
            raise ApiError("Only upcoming tournaments can be edited")
        if slots < b.filled(tid):
            raise ApiError("Slots cannot be less than players already joined")
        if fee != t["fee"] and b.filled(tid):
            raise ApiError("Entry fee cannot change after players joined")
        b.x("UPDATE tournaments SET gid=?, title=?, mode=?, fee=?, pool=?, per_kill=?, slots=?, start=?, start_ts=?, map=? WHERE id=?",
            (gid, title, mode, fee, pool, pk, slots, start_text(ts), ts, mp, tid))
    else:
        tid = b.x("INSERT INTO tournaments(gid,title,mode,fee,pool,per_kill,slots,start,start_ts,map,created) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                  (gid, title, mode, fee, pool, pk, slots, start_text(ts), ts, mp, b.now_s()))
    if p.get("banner_data"):
        b.x("UPDATE tournaments SET banner=? WHERE id=?", ("file:" + save_image(p["banner_data"], "tour%d" % tid), tid))
    elif p.get("clear_banner"):
        b.x("UPDATE tournaments SET banner='' WHERE id=?", (tid,))
    if not p.get("id") and p.get("announce"):
        threading.Thread(target=announce_new, args=(tid,), daemon=True).start()
    return {"id": tid}


def a_tour_banner(u, p):
    """Poster Studio: set / clear a tournament banner and optionally send the image to the admin's Telegram chat."""
    tid = inum(p.get("id"), 1, 10**9, "tournament")
    t = b.q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t:
        raise ApiError("Tournament not found")
    if p.get("data"):
        b.x("UPDATE tournaments SET banner=? WHERE id=?", ("file:" + save_image(p["data"], "tour%d" % tid), tid))
    elif p.get("clear"):
        b.x("UPDATE tournaments SET banner='' WHERE id=?", (tid,))
    else:
        raise ApiError("No image")
    t = b.q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    sent = False
    if p.get("send") and (t["banner"] or "").startswith("file:"):
        cap = "<b>🏆 %s</b>\n🎟 Entry %s · 💰 Prize %s\n🕒 %s" % (b.esc(t["title"]), b.fm(t["fee"]) if t["fee"] else "FREE", b.fm(t["pool"]), b.esc(t["start"]))
        sent = bool(upload_photo(u["id"], os.path.join(LOGOS, t["banner"][5:]), cap))
    return {"banner": img_url(t["banner"]), "sent": sent}


def announce_new(tid):
    t = b.q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    g = b.q1("SELECT emoji, name FROM games WHERE id=?", (t["gid"],))
    txt = ("<blockquote><b>🔥 NEW TOURNAMENT</b></blockquote>\n<b>%s %s</b>\n🎮 %s · 💰 Prize %s · 🎟 Entry %s\n🕒 %s" %
           (g["emoji"], b.esc(t["title"]), b.esc(t["mode"]), b.fm(t["pool"]), b.fm(t["fee"]) if t["fee"] else "FREE", b.esc(t["start"])))
    kb = open_btn("/#t/%d" % tid)
    fid = None
    if (t["banner"] or "").startswith("file:") and b.ADMINS:
        fid = upload_photo(list(b.ADMINS)[0], os.path.join(LOGOS, t["banner"][5:]), "📣 Announcement poster (sending to all users)")
    for r in b.q("SELECT id FROM users WHERE banned=0"):
        if fid:
            b.call("sendPhoto", {"chat_id": r["id"], "photo": fid, "caption": txt, "parse_mode": "HTML", "reply_markup": {"inline_keyboard": kb or []}})
        else:
            b.call("sendMessage", {"chat_id": r["id"], "text": txt, "parse_mode": "HTML", "reply_markup": {"inline_keyboard": kb or []}})
        time.sleep(0.05)


def a_tour_room(u, p):
    tid = inum(p.get("id"), 1, 10**9, "tournament")
    rid, rpw = str(p.get("room_id", "")).strip()[:40], str(p.get("room_pass", "")).strip()[:40]
    if not rid:
        raise ApiError("Enter the Room ID")
    t = b.q1("SELECT title, status FROM tournaments WHERE id=?", (tid,))
    if not t or t["status"] not in ("upcoming", "live"):
        raise ApiError("Tournament is not active")
    b.x("UPDATE tournaments SET room_id=?, room_pass=? WHERE id=?", (rid, rpw, tid))
    n = 0
    for r in b.q("SELECT uid FROM parts WHERE tid=?", (tid,)):
        notify(r["uid"], "<blockquote><b>🔑 ROOM DETAILS · %s</b></blockquote>\nRoom ID: <code>%s</code>\nPassword: <code>%s</code>" % (b.esc(t["title"]), b.esc(rid), b.esc(rpw)), open_btn("/#t/%d" % tid))
        n += 1
    return {"sent": n}


def a_tour_live(u, p):
    tid = inum(p.get("id"), 1, 10**9, "tournament")
    b.x("UPDATE tournaments SET status='live' WHERE id=? AND status='upcoming'", (tid,))
    for r in b.q("SELECT uid FROM parts WHERE tid=?", (tid,)):
        notify(r["uid"], "🔴 <b>Your match is LIVE now!</b> Open the tournament for details.", open_btn("/#t/%d" % tid))
    return {"ok": True}


def a_tour_results(u, p):
    tid = inum(p.get("id"), 1, 10**9, "tournament")
    t = b.q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t or t["status"] not in ("upcoming", "live"):
        raise ApiError("Results already done or tournament cancelled")
    raw = p.get("rows") or []
    if not isinstance(raw, list) or not raw:
        raise ApiError("Enter at least one winner")
    seen, items = set(), []
    for r in raw:
        slot, prize, kills = inum(r.get("slot"), 1, 10**6, "slot"), fnum(r.get("prize", 0) or 0, 0, 10**7, "prize"), inum(r.get("kills", 0) or 0, 0, 1000, "kills")
        rank = inum(r.get("rank"), 1, 10**4, "rank")
        if slot in seen:
            raise ApiError("Slot #%d is listed twice" % slot)
        if not b.q1("SELECT 1 FROM parts WHERE tid=? AND slot=?", (tid, slot)):
            raise ApiError("Slot #%d does not exist" % slot)
        seen.add(slot)
        items.append((rank, slot, prize, kills))
    items.sort()
    out = b.apply_results(tid, [(s, pr, k) for _, s, pr, k in items])
    if out is None:
        raise ApiError("Results already done or tournament cancelled")
    for puid, ign, rank, kills, total in out:
        notify(puid, "🏆 <b>Result · %s</b>\nRank <b>#%d</b> · Kills <b>%d</b>\n%s" % (b.esc(t["title"]), rank, kills, ("💰 <b>%s</b> added to your Winning balance!" % b.fm(total)) if total else "Thanks for playing!"), open_btn("/#t/%d" % tid))
    for r in b.q("SELECT uid FROM parts WHERE tid=? AND rank=0", (tid,)):
        notify(r["uid"], "🏁 <b>Result is out for %s.</b>" % b.esc(t["title"]), open_btn("/#t/%d" % tid))
    return {"paid": len(out)}


def a_tour_cancel(u, p):
    r = b.cancel_tour(inum(p.get("id"), 1, 10**9, "tournament"))
    if r is None:
        raise ApiError("Already completed or cancelled")
    uids, t = r
    for x in uids:
        notify(x, "❌ <b>%s was cancelled.</b>%s" % (b.esc(t["title"]), ("\n💰 %s refunded to your Deposit balance." % b.fm(t["fee"])) if t["fee"] else ""))
    return {"refunded": len(uids)}


def a_deps(u, p):
    return {"items": rows(b.q("SELECT d.*, u.name, u.username FROM deposits d LEFT JOIN users u ON u.id=d.uid WHERE d.status='pending' ORDER BY d.id LIMIT 50")),
            "recent": rows(b.q("SELECT d.id, d.amount, d.status, d.gw, d.created, u.name FROM deposits d LEFT JOIN users u ON u.id=d.uid WHERE d.status!='pending' ORDER BY d.id DESC LIMIT 15"))}


def a_dep_do(u, p):
    ok = bool(p.get("approve"))
    d = b.dep_decide(inum(p.get("id"), 1, 10**9, "deposit"), ok)
    if not d:
        raise ApiError("Already handled")
    if ok:
        notify(d["uid"], "✅ <b>%s added to your wallet.</b> Good luck!" % b.fm(d["amount"]), open_btn("/"))
    else:
        notify(d["uid"], "❌ <b>Your deposit of %s (UTR %s) was rejected.</b> Contact support if this is a mistake." % (b.fm(d["amount"]), b.esc(d["utr"])))
    return {"ok": True}


def a_wds(u, p):
    return {"items": rows(b.q("SELECT w.*, u.name, u.username FROM withdrawals w LEFT JOIN users u ON u.id=w.uid WHERE w.status='pending' ORDER BY w.id LIMIT 50")),
            "recent": rows(b.q("SELECT w.id, w.amount, w.status, w.upi, w.created, u.name FROM withdrawals w LEFT JOIN users u ON u.id=w.uid WHERE w.status!='pending' ORDER BY w.id DESC LIMIT 15"))}


def a_wd_do(u, p):
    paid = bool(p.get("paid"))
    w = b.wd_decide(inum(p.get("id"), 1, 10**9, "withdrawal"), paid)
    if not w:
        raise ApiError("Already handled")
    if paid:
        notify(w["uid"], "✅ <b>%s sent to your UPI</b> <code>%s</code>." % (b.fm(w["amount"]), b.esc(w["upi"])))
    else:
        notify(w["uid"], "❌ <b>Withdrawal of %s rejected.</b> The amount is back in your Winning balance." % b.fm(w["amount"]))
    return {"ok": True}


def a_users(u, p):
    s = str(p.get("q", "")).strip()
    if s.isdigit():
        r = b.q("SELECT * FROM users WHERE id=? LIMIT 1", (int(s),))
    elif s:
        like = "%" + s.lstrip("@").replace("%", "") + "%"
        r = b.q("SELECT * FROM users WHERE name LIKE ? OR username LIKE ? ORDER BY last_seen DESC LIMIT 30", (like, like))
    else:
        r = b.q("SELECT * FROM users ORDER BY rowid DESC LIMIT 30")
    return {"items": rows(r)}


def a_user_adj(u, p):
    uid2 = inum(p.get("uid"), 1, 10**14, "user")
    amt = fnum(p.get("amount"), 0.01, 1000000, "amount")
    sign = 1 if str(p.get("sign", 1)).lstrip("+") not in ("-1", "-") else -1
    with b.L:
        r = b.DB.execute("SELECT dep FROM users WHERE id=?", (uid2,)).fetchone()
        if not r:
            raise ApiError("User not found")
        new = round(max(0.0, r["dep"] + sign * amt), 2)
        b.DB.execute("UPDATE users SET dep=? WHERE id=?", (new, uid2))
        b.txn(uid2, "adjust", abs(new - r["dep"]), "admin %s" % ("credit" if sign > 0 else "debit"))
        b.DB.commit()
    notify(uid2, "ℹ️ Your wallet was %s by admin: <b>%s</b>." % ("credited" if sign > 0 else "debited", b.fm(amt)))
    return {"ok": True}


def a_user_ban(u, p):
    uid2 = inum(p.get("uid"), 1, 10**14, "user")
    b.x("UPDATE users SET banned = 1 - banned WHERE id=?", (uid2,))
    return {"banned": b.q1("SELECT banned FROM users WHERE id=?", (uid2,))["banned"]}


def a_broadcast(u, p):
    text = str(p.get("text", "")).strip()
    if not text:
        raise ApiError("Write a message")
    kb = open_btn("/")
    ids = [r["id"] for r in b.q("SELECT id FROM users WHERE banned=0")]

    def run():
        ok = bad = 0
        for i in ids:
            r = b.call("sendMessage", {"chat_id": i, "text": b.cut(text), "parse_mode": "HTML", "reply_markup": {"inline_keyboard": kb or []}})
            ok, bad = (ok, bad + 1) if b.bad(r) else (ok + 1, bad)
            time.sleep(0.05)
        notify(u["id"], "📢 <b>Broadcast done.</b> Sent %d · Failed %d" % (ok, bad))
    threading.Thread(target=run, daemon=True).start()
    return {"users": len(ids)}


USER_API = {"me": api_me, "home": api_home, "game": api_game, "tour": api_tour, "join": api_join, "my": api_my, "wallet": api_wallet,
            "dep_create": api_dep_create, "dep_check": api_dep_check, "dep_manual": api_dep_manual, "wd": api_wd, "lb": api_lb, "profile": api_profile}
ADMIN_API = {
    "a_dash": a_dash, "a_settings_get": a_settings_get, "a_settings_set": a_settings_set, "a_qr_set": a_qr_set, "a_game_list": a_game_list,
    "a_game_save": a_game_save, "a_game_del": a_game_del, "a_banner_list": a_banner_list, "a_banner_save": a_banner_save, "a_banner_del": a_banner_del,
    "a_tours": a_tours, "a_tour_get": a_tour_get, "a_tour_save": a_tour_save, "a_tour_room": a_tour_room, "a_tour_live": a_tour_live,
    "a_tour_results": a_tour_results, "a_tour_cancel": a_tour_cancel, "a_deps": a_deps, "a_dep_do": a_dep_do, "a_wds": a_wds, "a_wd_do": a_wd_do,
    "a_users": a_users, "a_user_adj": a_user_adj, "a_user_ban": a_user_ban, "a_broadcast": a_broadcast,
    "a_welcome_img_set": a_welcome_img_set, "a_welcome_img_clear": a_welcome_img_clear, "a_welcome_preview": a_welcome_preview,
    "a_fam_test": a_fam_test, "a_tour_banner": a_tour_banner}


# ------------------------------------------------------------------ HTTP
PAID_PAGE = """<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<body style="margin:0;background:#0b0b1a;color:#fff;font-family:system-ui;display:grid;place-items:center;min-height:100vh;text-align:center">
<div><div style="font-size:64px">✅</div><h2>Payment received</h2><p style="opacity:.7">Your wallet updates in a few seconds.<br>Go back to Telegram.</p></div>"""


class Handler(BaseHTTPRequestHandler):
    server_version = "VCT"
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False, default=str).encode()
        elif isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path, cache):
        try:
            with open(path, "rb") as f:
                data = f.read()
        except OSError:
            return self._send(404, b"not found", "text/plain")
        ext = path.rsplit(".", 1)[-1].lower()
        ct = {"html": "text/html; charset=utf-8", "png": "image/png", "jpg": "image/jpeg", "webp": "image/webp", "gif": "image/gif", "js": "text/javascript", "css": "text/css"}.get(ext, "application/octet-stream")
        self._send(200, data, ct, {"Cache-Control": cache})

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path in ("/", "/index.html"):
            return self._file(os.path.join(STATIC, "index.html"), "no-cache")
        if path.startswith("/logos/") and FILE_RE.match(path[7:]):
            return self._file(os.path.join(LOGOS, path[7:]), "public, max-age=86400")
        if path == "/qr":
            name = b.S("qr_file")
            return self._file(os.path.join(LOGOS, name), "no-cache") if name and FILE_RE.match(name) else self._send(404, b"", "text/plain")
        if path == "/pay/return":
            return self._send(200, PAID_PAGE, "text/html; charset=utf-8")
        if path == "/health":
            return self._send(200, {"ok": True})
        self._send(404, b"not found", "text/plain")

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length", "0") or 0)
        except ValueError:
            n = 0
        if n > MAX_BODY:
            return self._send(413, {"ok": False, "err": "Too large"})
        raw = self.rfile.read(n) if n else b""
        path = urllib.parse.urlparse(self.path).path
        if path == "/pay/webhook/razorpay":
            return self._razorpay_hook(raw)
        if not path.startswith("/api/"):
            return self._send(404, {"ok": False, "err": "Not found"})
        name = path[5:]
        fn = USER_API.get(name) or ADMIN_API.get(name)
        if not fn:
            return self._send(404, {"ok": False, "err": "Unknown call"})
        tgu = verify(self.headers.get("X-Init-Data", ""))
        if not tgu:
            return self._send(401, {"ok": False, "err": "Open this app from Telegram"})
        try:
            params = json.loads(raw.decode() or "{}")
            if not isinstance(params, dict):
                raise ValueError
        except ValueError:
            return self._send(400, {"ok": False, "err": "Bad request"})
        try:
            u = b.ensure_user({"id": tgu["id"], "first_name": tgu.get("first_name", ""), "last_name": tgu.get("last_name", ""), "username": tgu.get("username", "")})
            if tgu.get("photo_url") and tgu["photo_url"] != u["photo"]:
                b.x("UPDATE users SET photo=? WHERE id=?", (str(tgu["photo_url"])[:300], tgu["id"]))
                u = b.q1("SELECT * FROM users WHERE id=?", (tgu["id"],))
            admin = b.is_admin(u["id"])
            if name in ADMIN_API and not admin:
                return self._send(403, {"ok": False, "err": "Admin only"})
            if u["banned"] and not admin:
                return self._send(403, {"ok": False, "err": "You are banned"})
            if b.S("maint") == "1" and not admin and name not in ("me",):
                return self._send(503, {"ok": False, "err": "Under maintenance. Please try again later."})
            res = fn(u, params)
            res["ok"] = True
            return self._send(200, res)
        except ApiError as e:
            return self._send(200, {"ok": False, "err": str(e)})
        except Exception as e:
            b.log("api %s error: %r" % (name, e))
            return self._send(500, {"ok": False, "err": "Server error, try again"})

    def _razorpay_hook(self, raw):
        if not pay.verify_rzp_webhook(b, raw, self.headers.get("X-Razorpay-Signature", "")):
            return self._send(400, {"ok": False})
        try:
            ev = json.loads(raw.decode())
            if ev.get("event") == "payment_link.paid":
                pl = ev["payload"]["payment_link"]["entity"]
                d = b.q1("SELECT * FROM deposits WHERE ref=? AND gw='razorpay'", (pl["id"],))
                if d and d["status"] == "awaiting" and int(pl.get("amount_paid", 0)) >= int(round(d["amount"] * 100)):
                    settle(d["id"])
        except Exception as e:
            b.log("razorpay hook error: %r" % (e,))
        self._send(200, {"ok": True})


def poller():
    """Auto-payment checker: confirms awaiting gateway deposits without any admin action."""
    while True:
        time.sleep(10)
        try:
            for d in b.q("SELECT * FROM deposits WHERE status='pending' AND gw='fampay' ORDER BY id LIMIT 40"):
                try:
                    age = (datetime.now(IST) - datetime.strptime(d["created"], "%d-%m-%Y %H:%M").replace(tzinfo=IST)).total_seconds()
                except ValueError:
                    age = 0
                if age <= 45 * 60 and pay.check_utr(b, d) is True:
                    settle(d["id"])
            for d in b.q("SELECT * FROM deposits WHERE status='awaiting' AND gw!='' AND gw!='fampay' ORDER BY id LIMIT 40"):
                try:
                    age = (datetime.now(IST) - datetime.strptime(d["created"], "%d-%m-%Y %H:%M").replace(tzinfo=IST)).total_seconds()
                except ValueError:
                    age = 0
                r = pay.check(b, d)
                if r is True:
                    settle(d["id"])
                elif r is False:
                    b.x("UPDATE deposits SET status='failed' WHERE id=? AND status='awaiting'", (d["id"],))
                elif age > 3 * 3600:
                    b.x("UPDATE deposits SET status='expired' WHERE id=? AND status='awaiting'", (d["id"],))
        except Exception as e:
            b.log("poller error: %r" % (e,))


def start(bot_module, port=0):
    global b
    b = bot_module
    for k, v in APP_DEFAULTS.items():
        b.DEFAULTS.setdefault(k, v)
    os.makedirs(LOGOS, exist_ok=True)
    srv = None
    for pt in ([port] if port else list(range(8787, 8800)) + [0]):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", pt), Handler)
            break
        except OSError:
            continue
    if not srv:
        raise RuntimeError("no free port for web app")
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    threading.Thread(target=poller, daemon=True).start()
    return srv.server_address[1]
