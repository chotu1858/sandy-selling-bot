#!/usr/bin/env bash
# Run after copying new files:  bash update.sh
# Restarts the panel, then reloads every hosted bot with the new storebot_template.py.
# Your data, keys, bots and panel.env are kept.
cd "$(dirname "$0")" || exit 1
[ -d venv ] || { echo "venv missing - run: bash install.sh"; exit 1; }
[ -f storebot_template.py ] || { echo "storebot_template.py missing"; exit 1; }
./venv/bin/pip install -q flask "python-telegram-bot[job-queue]" requests qrcode pillow
mkdir -p data && touch data/restart_all.flag
if [ "$(id -u)" = "0" ] && command -v systemctl >/dev/null 2>&1 && [ -f /etc/systemd/system/bothost.service ]; then
  systemctl restart bothost
else
  pkill -f "venv/bin/python app.py" 2>/dev/null || true
  sleep 1
  nohup ./venv/bin/python app.py > panel.log 2>&1 &
fi
sleep 4
tail -n 5 panel.log 2>/dev/null
echo
echo "Panel updated. Hosted bots reload within ~10 seconds."
echo "Website : /        Buyer login : /login        Owner : /admin"
