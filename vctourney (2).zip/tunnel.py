"""Cloudflare tunnel runner for the Mini App.

Modes
  1. Quick tunnel (default, zero setup): runs `cloudflared tunnel --url http://127.0.0.1:PORT` and reads the
     https://xxxx.trycloudflare.com address. The URL changes when cloudflared restarts - the bot re-sets the
     Telegram menu button automatically every time.
  2. Permanent tunnel: put CF_TUNNEL_TOKEN (from Cloudflare Zero Trust -> Tunnels) and WEBAPP_URL
     (your https://app.yourdomain.com) in the script's .env. The URL then never changes.
cloudflared is downloaded once next to the script (from the official GitHub releases).
"""
import os
import re
import stat
import subprocess
import threading
import time
import platform
import urllib.request

URL_RE = re.compile(r"https://[a-z0-9\-]+\.trycloudflare\.com")


def _asset():
    m = platform.machine().lower()
    arch = "arm64" if m in ("aarch64", "arm64") else ("arm" if m.startswith("arm") else ("386" if m in ("i386", "i686") else "amd64"))
    return "cloudflared-linux-" + arch


def ensure_bin(base, log):
    for cand in ("cloudflared", os.path.join(base, "cloudflared")):
        path = cand if os.path.isabs(cand) else None
        if path and os.path.exists(path):
            return path
    from shutil import which
    w = which("cloudflared")
    if w:
        return w
    path = os.path.join(base, "cloudflared")
    url = "https://github.com/cloudflare/cloudflared/releases/latest/download/" + _asset()
    log("downloading cloudflared (one time)...")
    try:
        urllib.request.urlretrieve(url, path + ".part")
        os.replace(path + ".part", path)
        os.chmod(path, os.stat(path).st_mode | stat.S_IEXEC)
        return path
    except Exception as e:
        log("cloudflared download failed: %r  (set WEBAPP_URL + DISABLE_TUNNEL=1 if you host the app yourself)" % (e,))
        return None


def _loop(base, port, on_url, log):
    token = os.getenv("CF_TUNNEL_TOKEN", "").strip()
    fixed = os.getenv("WEBAPP_URL", "").strip().rstrip("/")
    binp = ensure_bin(base, log)
    if not binp:
        return
    delay = 3
    while True:
        if token:
            args = [binp, "tunnel", "--no-autoupdate", "run", "--token", token]
        else:
            args = [binp, "tunnel", "--no-autoupdate", "--url", "http://127.0.0.1:%d" % port]
        started = time.time()
        try:
            p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            if token and fixed:
                on_url(fixed)
            for line in p.stdout:
                m = URL_RE.search(line)
                if m and not token:
                    on_url(m.group(0))
                elif "ERR" in line and "Unauthorized" in line:
                    log("cloudflared: " + line.strip()[:160])
            p.wait()
        except Exception as e:
            log("cloudflared error: %r" % (e,))
        # ran fine for a while -> restart quickly, otherwise back off
        delay = 3 if time.time() - started > 120 else min(delay * 2, 60)
        log("cloudflared stopped, restarting in %ds" % delay)
        time.sleep(delay)


def start(base, port, on_url, log):
    threading.Thread(target=_loop, args=(base, port, on_url, log), daemon=True).start()
