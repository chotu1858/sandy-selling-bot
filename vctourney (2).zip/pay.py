"""Auto-payment gateways for Add Money.

Admin picks the gateway in the app (Admin -> Payments):
  none        manual UPI + UTR (admin approves)
  razorpay    Razorpay Payment Link (key id + secret). Paid status is polled, webhook optional.
  upigateway  UPIGateway.com / ekqr.in (user token key)
A deposit is created with status 'awaiting'; once the gateway confirms payment the wallet is credited
automatically and exactly once (bot.dep_decide is atomic).
"""
import hmac
import hashlib
import time
import requests

TIMEOUT = 20


def mode(b):
    m = b.S("gw")
    if m == "razorpay" and b.S("rzp_key") and b.S("rzp_secret"):
        return m
    if m == "upigateway" and b.S("upig_key"):
        return m
    if m == "fampay" and b.S("fam_base").startswith("https://"):
        return m
    return "none"


def _dig(obj, path):
    """Read a.b.c style path from parsed JSON ('' -> whole object)."""
    for part in [p for p in str(path).split(".") if p]:
        if isinstance(obj, list):
            try:
                obj = obj[int(part)]
            except (ValueError, IndexError):
                return None
        elif isinstance(obj, dict):
            obj = obj.get(part)
        else:
            return None
    return obj


def check_utr(b, dep):
    """FamPay / custom checker API: ask the provider if this UTR was paid.
    True = verified paid, False = provider says failed, None = not found yet / unreachable (keep waiting or manual)."""
    base = b.S("fam_base").rstrip("/")
    path = b.S("fam_path") or "/"
    if not path.startswith("/"):
        path = "/" + path
    params = {b.S("fam_utr_param") or "utr": dep["utr"], "amount": ("%g" % dep["amount"])}
    headers = {}
    kp, key = b.S("fam_key_param") or "key", b.S("fam_key")
    if key:
        if kp.lower().startswith("header:"):
            headers[kp[7:].strip()] = key
        else:
            params[kp] = key
    try:
        if (b.S("fam_method") or "GET").upper() == "POST":
            r = requests.post(base + path, json=params, headers=headers, timeout=TIMEOUT)
        else:
            r = requests.get(base + path, params=params, headers=headers, timeout=TIMEOUT)
        j = r.json()
    except (requests.RequestException, ValueError):
        return None
    got = _dig(j, b.S("fam_paid_field") or "status")
    want = (b.S("fam_paid_value") or "success").strip().lower()
    if got is None:
        return None
    if str(got).strip().lower() != want:
        return False if str(got).strip().lower() in ("failed", "failure", "rejected", "cancelled", "false") else None
    af = b.S("fam_amount_field")
    if af:
        try:
            if float(_dig(j, af)) + 0.001 < dep["amount"]:
                return None      # paid less than requested -> leave for admin
        except (TypeError, ValueError):
            return None
    return True


def create(b, uid, name, did, amount, return_url):
    """Returns (pay_url, ref) or (None, error)."""
    m = mode(b)
    try:
        if m == "razorpay":
            body = {"amount": int(round(amount * 100)), "currency": "INR", "accept_partial": False,
                    "reference_id": "vct%d" % did, "description": "%s wallet top-up" % b.S("brand"),
                    "notes": {"deposit_id": str(did), "uid": str(uid)}, "reminder_enable": False}
            if return_url:
                body["callback_url"] = return_url
                body["callback_method"] = "get"
            r = requests.post("https://api.razorpay.com/v1/payment_links", json=body, auth=(b.S("rzp_key"), b.S("rzp_secret")), timeout=TIMEOUT)
            j = r.json()
            if r.status_code < 300 and j.get("short_url"):
                return j["short_url"], j["id"]
            return None, (j.get("error") or {}).get("description", "Razorpay error")
        if m == "upigateway":
            ref = "VCT%d%d" % (did, int(time.time()) % 100000)
            body = {"key": b.S("upig_key"), "client_txn_id": ref, "amount": str(int(amount) if amount == int(amount) else amount),
                    "p_info": "Wallet top-up", "customer_name": (name or "Player")[:40], "customer_email": "player%d@example.com" % uid,
                    "customer_mobile": "9999999999", "redirect_url": return_url or "https://t.me", "udf1": str(did)}
            r = requests.post("https://api.ekqr.in/api/create_order", json=body, timeout=TIMEOUT)
            j = r.json()
            if j.get("status") and (j.get("data") or {}).get("payment_url"):
                return j["data"]["payment_url"], ref
            return None, str(j.get("msg") or "UPIGateway error")
    except (requests.RequestException, ValueError) as e:
        return None, "Gateway not reachable: %s" % e.__class__.__name__
    return None, "Auto payment is off"


def check(b, dep):
    """True = paid, False = failed/expired, None = still waiting / unknown."""
    m = dep["gw"]
    try:
        if m == "razorpay":
            r = requests.get("https://api.razorpay.com/v1/payment_links/" + dep["ref"], auth=(b.S("rzp_key"), b.S("rzp_secret")), timeout=TIMEOUT)
            j = r.json()
            if j.get("status") == "paid" and int(j.get("amount_paid", 0)) >= int(round(dep["amount"] * 100)):
                return True
            if j.get("status") in ("cancelled", "expired"):
                return False
            return None
        if m == "upigateway":
            r = requests.post("https://api.ekqr.in/api/check_order_status",
                              json={"key": b.S("upig_key"), "client_txn_id": dep["ref"], "txn_date": dep["created"][:10]}, timeout=TIMEOUT)
            j = r.json()
            st = str((j.get("data") or {}).get("status", "")).lower()
            if j.get("status") and st == "success":
                paid = float((j.get("data") or {}).get("amount", dep["amount"]) or 0)
                return True if paid + 0.001 >= dep["amount"] else None
            if st in ("failure", "failed", "cancelled"):
                return False
            return None
    except (requests.RequestException, ValueError):
        return None
    return None


def verify_rzp_webhook(b, raw, sig):
    sec = b.S("rzp_hook")
    if not sec or not sig:
        return False
    return hmac.compare_digest(hmac.new(sec.encode(), raw, hashlib.sha256).hexdigest(), sig)
