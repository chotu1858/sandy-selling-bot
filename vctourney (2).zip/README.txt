VC TOURNAMENT BOT v2.0 (vctourney) - HostPanel script + Telegram Mini App

UPDATE (HostPanel):
  cd ~/hostpanel
  mkdir -p scripts/vctourney
  rm -f ~/vctourney.zip
  wget -O ~/vctourney.zip https://github.com/chotu1858/sandy-selling-bot/raw/main/vctourney.zip
  unzip -o ~/vctourney.zip -d scripts/vctourney
  ls scripts/vctourney
  bash update.sh
Your database (tourney.db), settings and uploaded logos are kept on update.

WHAT'S NEW
  * Telegram Mini App ("OPEN TOURNAMENT APP" button + chat menu button). Served by the bot itself and exposed with a
    free Cloudflare tunnel - no domain, no extra setup. cloudflared is downloaded automatically on first start.
  * Games with bold coloured badges: one-tap add for BGMI, Free Fire, COD Mobile, Valorant etc. Upload each game's official logo from
    Admin -> Games -> tap game -> Custom logo (no logos are bundled in the script).
  * Players see their Telegram photo, @username and a "Telegram connected" badge. Login is automatic and signed (cannot be faked).
  * Auto payment: Razorpay or UPIGateway. Wallet is credited automatically after payment. Manual UPI+UTR still works as fallback.
  * Full admin panel in the app (/admin in bot also still works): create/edit tournaments (date picker, map, announce to all),
    room ID/pass, go live, enter results with live payout total, cancel+refund, games, banners, users (balance/ban),
    payments approve/reject, broadcast, settings (welcome text, notice, support, min deposit/withdraw, UPI, QR, terms, maintenance).
  * Countdown timers, leaderboard, my matches, profile stats, copy buttons for room ID.

FIRST SETUP
  1. Owner /admin -> Scripts -> vctourney "ready" -> make access key, launch bot. Set ADMIN_IDS to your Telegram numeric ID.
  2. Wait ~20 seconds after start: the bot messages every admin "MINI APP ONLINE" with an Open App button.
  3. In the app: Profile -> ADMIN PANEL -> Games (add games) -> Settings (welcome text, UPI, auto payment) -> Tournaments -> Create.

AUTO PAYMENT SETUP (Admin -> Settings -> Auto Payment)
  Razorpay   : paste Key ID + Key Secret. Payment status is checked every 10 seconds (no webhook needed).
               Optional: add the webhook URL shown in settings (event payment_link.paid) and put its secret in "Webhook secret".
  UPIGateway : paste the API key from your UPIGateway dashboard.
  FamPay     : choose "FamPay / Custom API", enter your Base URL + API key. Player pays your UPI/QR and submits the UTR; the app asks
               your API to verify it and credits the wallet instantly (else it waits for manual approval). Under "Advanced" set the
               endpoint path, GET/POST, key param name (or header:X-API-Key), UTR param, and which response field/value means PAID.
  Choose "Off" to go back to manual UPI + UTR approval.

PERMANENT LINK (optional)
  The free quick tunnel link changes whenever the bot restarts (the bot re-sets the menu button automatically, but old chat
  buttons keep the old link). For a fixed link create a Cloudflare Tunnel in Zero Trust, then add to the script .env:
      CF_TUNNEL_TOKEN=<token>
      WEBAPP_URL=https://app.yourdomain.com
  and point the tunnel's public hostname to http://localhost:8787 (set WEB_PORT=8787 as well).

OPTIONAL ENV: WEB_PORT, WEBAPP_URL, CF_TUNNEL_TOKEN, DISABLE_TUNNEL=1 (if you host the app yourself).

MONEY FLOW
  Entry fee is taken from Deposit balance first, then Winning balance. Prize + kills x per-kill goes to Winning balance.
  Withdraw: only from Winning balance, held at request; pay the user's UPI yourself, then tap Paid (or Reject = refunded).
