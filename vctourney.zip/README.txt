VC TOURNAMENT BOT (vctourney)  -  HostPanel script
Install / update:
  cd ~/hostpanel && mkdir -p scripts/vctourney && unzip -o ~/vctourney.zip -d scripts/vctourney && bash update.sh
Owner /admin -> Scripts -> vctourney should show "ready". Make an access key for it, pick a theme (default / neon / minimal) and launch a bot.

First setup (in the bot, send /admin):
  Settings  : UPI ID, UPI QR photo, min deposit, min withdraw, support username, welcome / terms text, maintenance.
  Games     : add a game like "🔥 Free Fire".
  Tournaments -> Create: choose game, then send 7 lines: title, mode, entry fee, prize pool, per kill, slots, start time.

Match day:
  Tournaments -> open it -> Set Room ID/Pass  (players who joined get it instantly)
  -> Go Live -> Enter Results  (lines: "slot prize kills", 1st place first) -> Confirm & pay.
  Prize + kills x per-kill is added to each player's Winning balance. Cancel & Refund returns every entry fee.

Money flow:
  Add Money  : user pays your UPI, sends UTR (+ screenshot) -> you get Approve / Reject buttons -> wallet credited.
  Withdraw   : only from Winning balance, held at request; you pay the UPI manually, then tap Paid (or Reject = refunded).
  Entry fee is taken from Deposit balance first, then Winning balance.
Admin also has: Users (find by ID, add/deduct balance, ban), Broadcast, Stats.
