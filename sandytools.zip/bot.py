#!/usr/bin/env python3
# ============================================================
#  SANDY TOOLS BOT  -  all-in-one Telegram utility bot (HostPanel script)
#  * 40+ tools: QR, file->link, stylish text, encoders, calculators, online tools ...
#  * Post Creator: text/media + coloured buttons + premium emoji -> channel / group / users
#  * force-join channels, broadcast, users, per-button colour / premium emoji / on-off,
#    everything is controlled from the in-bot admin panel (/admin)
# ============================================================
import os
import re
import io
import ast
import json
import math
import calendar
import time
import html
import uuid
import base64
import random
import string
import hashlib
import secrets
import sqlite3
import operator
import threading
from datetime import datetime, timedelta, timezone, date
from urllib.parse import quote
from concurrent.futures import ThreadPoolExecutor

import requests

BASE = os.path.dirname(os.path.abspath(__file__))
IST = timezone(timedelta(hours=5, minutes=30))


def load_env(path):
    try:
        for line in open(path, encoding="utf-8").read().splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
    except OSError:
        pass


load_env(os.path.join(BASE, ".env"))
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
_ENV_ADMINS = [int(x) for x in os.getenv("ADMIN_IDS", "").replace(" ", "").split(",") if x.isdigit()]
OWNER = _ENV_ADMINS[0] if _ENV_ADMINS else 0
BRAND_ENV = os.getenv("STORE_NAME", "") or os.getenv("BOT_NAME", "") or "Sandy Tools"
DB_FILE = os.path.join(BASE, os.getenv("DB_NAME", "tools.db"))
API = "https://api.telegram.org/bot" + BOT_TOKEN
BOT_USER = ""
BOT_ID = 0

try:
    THEME = json.load(open(os.getenv("THEME_FILE", ""), encoding="utf-8"))
    if not isinstance(THEME, dict):
        THEME = {}
except Exception:
    THEME = {}


def log(msg):
    print("[%s] %s" % (datetime.now(IST).strftime("%H:%M:%S"), msg), flush=True)


def now_s():
    return datetime.now(IST).strftime("%d-%m-%Y %H:%M")


# ============================================================
# DATABASE
# ============================================================
DB = sqlite3.connect(DB_FILE, check_same_thread=False, timeout=30)
DB.row_factory = sqlite3.Row
DB.execute("PRAGMA journal_mode=WAL")
L = threading.RLock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, username TEXT, joined TEXT, banned INTEGER DEFAULT 0,
  last_seen TEXT, uses INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS channels(id INTEGER PRIMARY KEY AUTOINCREMENT, chat TEXT, link TEXT, title TEXT);
CREATE TABLE IF NOT EXISTS files(token TEXT PRIMARY KEY, uid INTEGER, items TEXT, created TEXT, views INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, run_at REAL, data TEXT);
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, title TEXT, data TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS uchannels(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, chat TEXT, title TEXT);
CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, text TEXT, created TEXT);
"""
with L:
    DB.executescript(SCHEMA)
    DB.commit()

DEFAULTS = {
    "brand": BRAND_ENV,
    "bold_btn": "1",
    "maint": "0",
    "file_ttl": "600",
    "imglink_url": "",
    "txt_welcome": ("<blockquote><b>👋 WELCOME TO {brand} BOT</b></blockquote>\n"
                    "<blockquote><b>├── 🛠 40+ Tools in one bot\n├── ✍️ Create posts with coloured buttons\n"
                    "├── 💎 Premium emoji support\n└── ⚡ Fast · Free · Secure</b></blockquote>\n"
                    "<b>Hey {name}, choose a tool below 👇</b>"),
    "txt_terms": ("<blockquote><b>📜 TERMS &amp; CONDITIONS</b></blockquote>\n"
                  "<blockquote><b>01.</b> Use the bot only for legal and permitted purposes.\n"
                  "<b>02.</b> Do not use it for harmful, fraudulent or illegal activities.\n"
                  "<b>03.</b> You are responsible for the content and files you process.\n"
                  "<b>04.</b> Do not upload content that violates copyright or other laws.\n"
                  "<b>05.</b> Results may not always be 100% accurate.\n"
                  "<b>06.</b> Features may change or stop without prior notice.\n"
                  "<b>07.</b> By using this bot you agree to these terms.</blockquote>"),
}

_SC = {}
_SC_L = threading.Lock()


def _load_settings():
    with _SC_L:
        _SC.clear()
        for r in q("SELECT k,v FROM settings"):
            _SC[r["k"]] = r["v"]


def S(k):
    with _SC_L:
        if k in _SC:
            return _SC[k]
    t = (THEME.get("texts") or {}).get(k)
    if isinstance(t, str) and t:
        return t
    return DEFAULTS.get(k, "")


def setS(k, v):
    x("INSERT OR REPLACE INTO settings VALUES(?,?)", (k, str(v)))
    with _SC_L:
        _SC[k] = str(v)


def delS(k):
    x("DELETE FROM settings WHERE k=?", (k,))
    with _SC_L:
        _SC.pop(k, None)


SESSION = requests.Session()
STATE = {}
STATE_L = threading.Lock()
MEDIA_METHODS = {"photo": "sendPhoto", "video": "sendVideo", "animation": "sendAnimation", "document": "sendDocument",
                 "audio": "sendAudio"}
MEDIA_ICON = {"photo": "🖼 photo", "video": "🎬 video", "animation": "🎞 GIF", "document": "📎 file", "audio": "🎵 audio"}
_ORPHAN = {}
_TGE = re.compile(r'<tg-emoji emoji-id="\d+">(.*?)</tg-emoji>', re.S)
USER_LOCKS = {}
USER_LOCKS_L = threading.Lock()


def esc(s):
    return html.escape(str(s if s is not None else ""), quote=False)


def q(sql, p=()):
    with L:
        return [dict(r) for r in DB.execute(sql, p).fetchall()]


def q1(sql, p=()):
    r = q(sql, p)
    return r[0] if r else None


def x(sql, p=()):
    with L:
        cur = DB.execute(sql, p)
        DB.commit()
        return cur.lastrowid


def bad(res):
    return isinstance(res, dict) and "_err" in res


def tg(method, params=None, files=None, timeout=35):
    for _ in range(3):
        try:
            if files:
                r = SESSION.post(API + "/" + method, data=params, files=files, timeout=timeout)
            else:
                r = SESSION.post(API + "/" + method, json=params or {}, timeout=timeout)
            j = r.json()
        except (requests.RequestException, ValueError):
            time.sleep(1)
            continue
        if j.get("ok"):
            return j.get("result")
        ra = (j.get("parameters") or {}).get("retry_after")
        if ra and j.get("error_code") == 429:
            time.sleep(min(int(ra), 10))
            continue
        return {"_err": str(j.get("description", "error"))}
    return {"_err": "network error"}


def _strip_kb(kb, level):
    out = {"inline_keyboard": []}
    for row in kb.get("inline_keyboard", []):
        nr = []
        for b in row:
            b = dict(b)
            b.pop("icon_custom_emoji_id", None)
            if level >= 2:
                b.pop("style", None)
            nr.append(b)
        out["inline_keyboard"].append(nr)
    return out


def call(method, p):
    """tg() with graceful fallback: premium-emoji / colour not accepted -> retry plain."""
    res = tg(method, p)
    if bad(res) and "not modified" not in res["_err"]:
        kb = p.get("reply_markup")
        if kb and re.search(r"(?i)button|emoji|style|reply markup", res["_err"]):
            for lvl in (1, 2):
                p2 = dict(p)
                p2["reply_markup"] = _strip_kb(kb, lvl)
                res = tg(method, p2)
                if not bad(res):
                    return res
        for f in ("text", "caption"):
            if "tg-emoji" in str(p.get(f, "")) and res and bad(res):
                p2 = dict(p)
                p2[f] = _TGE.sub(r"\1", p[f])
                if kb:
                    p2["reply_markup"] = _strip_kb(kb, 2)
                res = tg(method, p2)
    return res


def cut(t, n=4000):
    t = str(t)
    return t if len(t) <= n else t[:n - 3] + "..."


def send(c, text, kb=None):
    p = {"chat_id": c, "text": cut(text), "parse_mode": "HTML", "disable_web_page_preview": True}
    if kb:
        p["reply_markup"] = {"inline_keyboard": kb}
    return call("sendMessage", p)


def show(c, mid, text, kb=None):
    """Edit the menu message in place (falls back to a fresh message)."""
    drop_orphan(c)
    if not mid:
        return send(c, text, kb)
    p = {"chat_id": c, "message_id": mid, "text": cut(text), "parse_mode": "HTML", "disable_web_page_preview": True,
         "reply_markup": {"inline_keyboard": kb or []}}
    res = call("editMessageText", p)
    if bad(res):
        if "not modified" in res["_err"]:
            return None
        tg("deleteMessage", {"chat_id": c, "message_id": mid})
        return send(c, text, kb)
    return res


def send_photo(c, photo, cap, kb=None):
    p = {"chat_id": c, "photo": photo, "caption": cut(cap, 1000), "parse_mode": "HTML"}
    if kb:
        p["reply_markup"] = {"inline_keyboard": kb}
    return call("sendPhoto", p)


def delete(c, mid):
    if mid:
        tg("deleteMessage", {"chat_id": c, "message_id": mid})


def drop_orphan(c):
    o = _ORPHAN.pop(c, None)
    if o:
        delete(c, o)


def plain_len(t):
    return len(re.sub(r"<[^>]+>", "", str(t)))


def extract_media(msg):
    if msg.get("photo"):
        return "photo", msg["photo"][-1]["file_id"]
    for k in ("video", "animation", "document"):
        if msg.get(k):
            return k, msg[k]["file_id"]
    return "", ""


def show_media(c, mid, text, kb, mtype, fid):
    """Media + text. Text goes as caption when it fits (<=1024), else media first and text/buttons below it."""
    drop_orphan(c)
    if mtype not in MEDIA_METHODS or not fid:
        return show(c, mid, text, kb)
    delete(c, mid)
    method = MEDIA_METHODS[mtype]
    p = {"chat_id": c, mtype: fid}
    if plain_len(text) <= 1000:
        p["parse_mode"] = "HTML"
        p["caption"] = text
        if kb:
            p["reply_markup"] = {"inline_keyboard": kb}
        res = call(method, p)
        if bad(res):                                   # bad/expired file id -> still show the text menu
            return send(c, text, kb)
        return res
    res = call(method, p)
    if not bad(res) and isinstance(res, dict) and res.get("message_id"):
        _ORPHAN[c] = res["message_id"]
    return send(c, text, kb)


def ack(cid, text="", alert=False):
    tg("answerCallbackQuery", {"callback_query_id": cid, "text": text[:190], "show_alert": alert}, timeout=10)


def auto_style(t, cb):
    t = t or ""
    c = cb or ""
    if any(w in t for w in ("❌", "🗑", "🚫", "Cancel", "Reject", "Delete", "Ban", "Deduct")):
        return "danger"
    if any(w in t for w in ("✅", "➕", "Confirm", "Verify", "Add", "Approve", "SPIN", "🎰", "🛒", "Unban")):
        return "success"
    return "primary"


def bold_u(t):
    """Normal letters/digits -> bold sans-serif unicode (works inside button labels)."""
    out = []
    for ch in str(t):
        o = ord(ch)
        if 65 <= o <= 90:
            out.append(chr(0x1D5D4 + o - 65))
        elif 97 <= o <= 122:
            out.append(chr(0x1D5EE + o - 97))
        elif 48 <= o <= 57:
            out.append(chr(0x1D7EC + o - 48))
        else:
            out.append(ch)
    return "".join(out)


def grid(btns, per=2):
    return [btns[i:i + per] for i in range(0, len(btns), per)]


def ent_html(text, ents):
    if not ents:
        return esc(text)
    u = text.encode("utf-16-le")
    marks = []
    for i, e in enumerate(ents):
        t, o, ln = e.get("type"), e["offset"], e["length"]
        op = cl = ""
        if t == "bold":
            op, cl = "<b>", "</b>"
        elif t == "italic":
            op, cl = "<i>", "</i>"
        elif t == "underline":
            op, cl = "<u>", "</u>"
        elif t == "strikethrough":
            op, cl = "<s>", "</s>"
        elif t == "code":
            op, cl = "<code>", "</code>"
        elif t == "pre":
            op, cl = "<pre>", "</pre>"
        elif t == "spoiler":
            op, cl = "<tg-spoiler>", "</tg-spoiler>"
        elif t == "blockquote":
            op, cl = "<blockquote>", "</blockquote>"
        elif t == "text_link":
            op, cl = '<a href="%s">' % html.escape(e.get("url", ""), quote=True), "</a>"
        elif t == "custom_emoji":
            op, cl = '<tg-emoji emoji-id="%s">' % e.get("custom_emoji_id", ""), "</tg-emoji>"
        if op:
            marks.append((o, 1, -ln, i, op))
            marks.append((o + ln, 0, ln, -i, cl))
    marks.sort(key=lambda z: (z[0], z[1], z[2], z[3]))
    out, pos = [], 0
    for at, _k, _l, _i, tag in marks:
        if at > pos:
            out.append(esc(u[pos * 2:at * 2].decode("utf-16-le", "ignore")))
            pos = at
        out.append(tag)
    out.append(esc(u[pos * 2:].decode("utf-16-le", "ignore")))
    return "".join(out)


def fmt(t, **kw):
    for k, v in kw.items():
        t = t.replace("{" + k + "}", str(v))
    return t


def st_set(uid, s, **xx):
    with STATE_L:
        STATE[uid] = (s, xx)


def st_get(uid):
    with STATE_L:
        return STATE.get(uid, ("", {}))


def st_clear(uid):
    with STATE_L:
        STATE.pop(uid, None)


def user_lock(uid):
    with USER_LOCKS_L:
        return USER_LOCKS.setdefault(uid, threading.Lock())



_load_settings()


def is_admin(uid):
    return uid in _ENV_ADMINS


def admin_list():
    return list(_ENV_ADMINS)


def B(text, cb=None, url=None, style="auto", eid=None, web=None):
    st0 = auto_style(text, cb) if style in ("auto", "", None) else style
    if S("bold_btn") == "1":
        text = bold_u(text)
    b = {"text": str(text)[:60]}
    if url:
        b["url"] = url
    elif web:
        b["web_app"] = {"url": web}
    else:
        b["callback_data"] = str(cb)[:64]
    if st0 in ("primary", "success", "danger"):
        b["style"] = st0
    if eid and str(eid).isdigit():
        b["icon_custom_emoji_id"] = str(eid)
    return b


def msg_html(msg):
    """Message text/caption -> HTML that keeps bold/italic/links/premium emoji."""
    if msg.get("text") is not None:
        return ent_html(msg["text"], msg.get("entities"))
    return ent_html(msg.get("caption") or "", msg.get("caption_entities"))


def strip_custom_emoji(text, ents):
    """Returns (clean_text, first_custom_emoji_id). The emoji char is removed from the text."""
    ce = [e for e in (ents or []) if e.get("type") == "custom_emoji"]
    if not ce:
        return text.strip(), ""
    e = ce[0]
    u = text.encode("utf-16-le")
    a, b = e["offset"] * 2, (e["offset"] + e["length"]) * 2
    clean = (u[:a] + u[b:]).decode("utf-16-le", "ignore").strip()
    return clean, e.get("custom_emoji_id", "")


# ============================================================
# USERS / GATE
# ============================================================
def get_user(uid):
    return q1("SELECT * FROM users WHERE id=?", (uid,))


def ensure_user(fr):
    uid = fr["id"]
    name = ((fr.get("first_name") or "") + " " + (fr.get("last_name") or "")).strip() or "User"
    un = fr.get("username") or ""
    u = get_user(uid)
    if not u:
        x("INSERT INTO users(id,name,username,joined,last_seen) VALUES(?,?,?,?,?)", (uid, name, un, now_s(), now_s()))
        if S("notify_new") != "0":
            for a in admin_list():
                send(a, "<blockquote><b>👤 NEW USER JOINED</b></blockquote>\n<blockquote><b>├── 👤 Name: %s\n├── 🔗 Username: %s\n└── 🆔 ID: </b><code>%s</code></blockquote>"
                     % (esc(name), ("@" + un) if un else "—", uid))
        u = get_user(uid)
    else:
        x("UPDATE users SET name=?, username=?, last_seen=? WHERE id=?", (name, un, now_s(), uid))
    return u


_MEM = {}


def is_member(chat, uid):
    key = (chat, uid)
    v = _MEM.get(key)
    if v and time.time() - v[0] < 45:
        return v[1]
    r = tg("getChatMember", {"chat_id": chat, "user_id": uid})
    if bad(r):
        return None                       # cannot verify (bot not admin etc.) -> do not block users
    st = r.get("status")
    ok = st in ("member", "administrator", "creator") or (st == "restricted" and r.get("is_member"))
    _MEM[key] = (time.time(), bool(ok))
    return bool(ok)


def missing_channels(uid):
    out = []
    for ch in q("SELECT * FROM channels ORDER BY id"):
        if is_member(ch["chat"], uid) is False:
            out.append(ch)
    return out


def gate(c, uid, u, param=""):
    if u and u["banned"] and not is_admin(uid):
        send(c, "🚫 <b>You are banned from this bot.</b>")
        return False
    if S("maint") == "1" and not is_admin(uid):
        send(c, "🛠 <b>Bot is under maintenance.</b>\n\nPlease try again later.")
        return False
    if is_admin(uid):
        return True
    miss = missing_channels(uid)
    if miss:
        kb = [[B("📢 Join " + (ch["title"] or ch["chat"]), url=ch["link"], style="primary")] for ch in miss if ch["link"]]
        kb.append([B("✅ Joined", "joined" + (":" + param if param else ""), style="success")])
        send(c, "<blockquote><b>📢 JOIN REQUIRED</b></blockquote>\n<blockquote><b>Please join our channel(s) first, then tap ✅ Joined.</b></blockquote>", kb)
        return False
    return True


# ============================================================
# BACKGROUND JOBS (file auto-delete, reminders)
# ============================================================
def add_job(kind, delay, data):
    x("INSERT INTO jobs(kind,run_at,data) VALUES(?,?,?)", (kind, time.time() + delay, json.dumps(data)))


def run_job(kind, d):
    if kind == "del":
        for mid in d.get("mids", []):
            delete(d["chat"], mid)
        send(d["chat"], "<blockquote><b>📁 FILE ACCESS EXPIRED</b></blockquote>\n<blockquote><b>The files sent to this chat were removed because the temporary access time ended.</b></blockquote>",
             [[B("♻️ Get Files Again", url="https://t.me/%s?start=f_%s" % (BOT_USER, d["token"]), style="success")]])
    elif kind == "remind":
        send(d["chat"], "<blockquote><b>⏰ REMINDER</b></blockquote>\n<blockquote><b>%s</b></blockquote>" % esc(d["text"]))


def job_loop():
    while True:
        try:
            for j in q("SELECT * FROM jobs WHERE run_at<=? ORDER BY run_at LIMIT 20", (time.time(),)):
                x("DELETE FROM jobs WHERE id=?", (j["id"],))
                try:
                    run_job(j["kind"], json.loads(j["data"]))
                except Exception as e:
                    log("job error: %s" % e)
        except Exception as e:
            log("job loop: %s" % e)
        time.sleep(4)


# ============================================================
# MENU: groups / tools / button config
# ============================================================
GROUPS = [
    ("qr", "📱", "QR Codes"), ("files", "📁", "File Tools"), ("text", "🎨", "Text Tools"),
    ("sec", "🔐", "Encode & Security"), ("calc", "🧮", "Calculators"), ("online", "🌐", "Online Tools"),
    ("fun", "🎲", "Fun & Games"), ("tg", "👤", "Telegram Tools"), ("prod", "🗒", "Productivity"),
]
TOOLS = [
    ("upiqr", "qr", "💳", "UPI Payment QR"), ("urlqr", "qr", "🔗", "URL → QR"), ("textqr", "qr", "📝", "Text → QR"), ("wifiqr", "qr", "📶", "WiFi QR"),
    ("f2l", "files", "📁", "File → Link"), ("img2l", "files", "🖼", "Image → Link"),
    ("stylish", "text", "✨", "Stylish Text"), ("case", "text", "🔡", "Case Converter"), ("reverse", "text", "🔁", "Reverse Text"),
    ("counter", "text", "🔢", "Word Counter"), ("sortl", "text", "📑", "Sort / Unique Lines"), ("repeat", "text", "♻️", "Text Repeater"),
    ("lorem", "text", "📃", "Lorem Ipsum"),
    ("passgen", "sec", "🔐", "Password Generator"), ("hash", "sec", "#️⃣", "Hash Generator"), ("b64", "sec", "🧬", "Base64"),
    ("urlenc", "sec", "🌍", "URL Encode/Decode"), ("binary", "sec", "💾", "Text ↔ Binary"), ("hexc", "sec", "🔣", "Text ↔ Hex"),
    ("morse", "sec", "📡", "Morse Code"), ("rot13", "sec", "🔄", "ROT13"), ("uuid", "sec", "🆔", "UUID Generator"), ("jsonf", "sec", "🧾", "JSON Formatter"),
    ("calc", "calc", "🧮", "Calculator"), ("age", "calc", "🎂", "Age Calculator"), ("datec", "calc", "📆", "Date Calculator"),
    ("units", "calc", "📏", "Unit Converter"), ("percent", "calc", "➗", "Percentage"), ("tstamp", "calc", "⏱", "Timestamp"),
    ("color", "calc", "🎨", "Color Converter"),
    ("short", "online", "✂️", "URL Shortener"), ("expand", "online", "🔍", "Link Expander"), ("ip", "online", "📍", "IP Lookup"),
    ("site", "online", "🌐", "Website Status"), ("weather", "online", "⛅", "Weather"), ("currency", "online", "💱", "Currency"),
    ("crypto", "online", "🪙", "Crypto Price"),
    ("dice", "fun", "🎲", "Dice & Games"), ("coin", "fun", "🪙", "Coin Flip"), ("randnum", "fun", "🔀", "Random Number"),
    ("picker", "fun", "🎯", "Random Picker"), ("poll", "fun", "📊", "Poll Maker"),
    ("mydet", "tg", "👤", "My Details"), ("getid", "tg", "🆔", "Get ID / File ID"), ("emojiid", "tg", "💎", "Premium Emoji ID"),
    ("mention", "tg", "🔖", "Mention Maker"), ("tglink", "tg", "🔗", "Telegram Link Maker"),
    ("notes", "prod", "🗒", "My Notes"), ("remind", "prod", "⏰", "Reminder"),
]
TOOL_BY = {t[0]: t for t in TOOLS}
GROUP_BY = {g[0]: g for g in GROUPS}
STYLES = ["success", "primary", "danger", "primary"]
BTN_KEYS = ["post"] + ["g_" + g[0] for g in GROUPS] + ["t_" + t[0] for t in TOOLS]


def _btn_default(key):
    if key == "post":
        return "✍️", "Create Post", "success"
    if key.startswith("g_"):
        i = [g[0] for g in GROUPS].index(key[2:])
        g = GROUP_BY[key[2:]]
        return g[1], g[2], STYLES[i % 4]
    i = [t[0] for t in TOOLS].index(key[2:])
    t = TOOLS[i]
    return t[2], t[3], STYLES[i % 4]


def bcfg(key):
    emo, name, st = _btn_default(key)
    cfg = {"text": "%s %s" % (emo, name), "style": st, "eid": "", "hide": False}
    th = (THEME.get("buttons") or {}).get(key)
    if isinstance(th, dict):
        cfg["text"] = th.get("text") or cfg["text"]
        cfg["style"] = th.get("style") or cfg["style"]
        cfg["eid"] = str(th.get("eid") or "")
    raw = S("bt:" + key)
    if raw:
        try:
            o = json.loads(raw)
            for k in ("text", "style", "eid"):
                if o.get(k) not in (None, ""):
                    cfg[k] = o[k]
            cfg["hide"] = bool(o.get("hide"))
        except ValueError:
            pass
    if cfg["eid"] == "none":
        cfg["eid"] = ""
    return cfg


def bsave(key, **kw):
    raw = S("bt:" + key)
    try:
        o = json.loads(raw) if raw else {}
    except ValueError:
        o = {}
    o.update(kw)
    setS("bt:" + key, json.dumps(o, ensure_ascii=False))


def kbtn(key, cb):
    c = bcfg(key)
    if c["hide"]:
        return None
    text = c["text"]
    eid = c["eid"]
    if eid:                                   # premium icon replaces the leading emoji
        text = re.sub(r"^\S+\s+", "", text, count=1) if re.match(r"^[^\w\s]", text) else text
    return B(text, cb, style=c["style"], eid=eid)


def home_kb(uid):
    kb = []
    b = kbtn("post", "pb:new")
    if b:
        kb.append([b])
    gb = [kbtn("g_" + g[0], "g:" + g[0]) for g in GROUPS]
    kb += grid([b for b in gb if b], 2)
    kb.append([B("📜 Terms", "terms", style="primary"), B("ℹ️ Help", "help", style="primary")])
    if is_admin(uid):
        kb.append([B("👑 Admin Panel", "adm", style="danger")])
    return kb


def home(c, mid, uid):
    u = get_user(uid) or {}
    t = fmt(S("txt_welcome"), name=esc(u.get("name", "User")), id=uid, brand=esc(S("brand")), bot=BOT_USER)
    mt, fid = S("welcome_media_type"), S("welcome_media_id")
    if fid:
        return show_media(c, mid, t, home_kb(uid), mt, fid)
    show(c, mid, t, home_kb(uid))


def show_group(c, mid, gk):
    g = GROUP_BY.get(gk)
    if not g:
        return home(c, mid, c)
    bs = [kbtn("t_" + t[0], "t:" + t[0]) for t in TOOLS if t[1] == gk]
    bs = [b for b in bs if b]
    kb = grid(bs, 2) + [[B("⬅️ Back", "home", style="primary")]]
    show(c, mid, "<blockquote><b>%s %s</b></blockquote>\n<blockquote><b>Choose a tool 👇</b></blockquote>" % (g[1], g[2].upper()), kb)


HELP_TXT = ("<blockquote><b>ℹ️ HELP</b></blockquote>\n"
            "<blockquote><b>1.</b> Tap a category, then a tool.\n<b>2.</b> Send your input when the bot asks.\n"
            "<b>3.</b> Many tools keep running — just send the next input.\n<b>4.</b> /cancel stops the current tool, /start opens the menu.\n"
            "<b>✍️ Create Post</b> builds posts with coloured buttons &amp; premium emoji and sends them to your channel.</blockquote>")


# ============================================================
# TOOL IMPLEMENTATIONS
# ============================================================
def code(s):
    return "<code>%s</code>" % esc(s)


def hdr(title):
    return "<blockquote><b>%s</b></blockquote>\n" % title


def chunks(s, n=3800):
    out, cur = [], ""
    for part in s.split("\n\n"):
        if len(cur) + len(part) + 2 > n and cur:
            out.append(cur)
            cur = ""
        cur += (("\n\n" if cur else "") + part)
    if cur:
        out.append(cur)
    return out or [s[:n]]


class UserErr(Exception):
    pass


# ---------- stylish text ----------
def _map(up, lo, dg=None, exc=None):
    m = {}
    for i in range(26):
        m[65 + i] = chr(up + i)
        m[97 + i] = chr(lo + i)
    if dg:
        for i in range(10):
            m[48 + i] = chr(dg + i)
    for k, v in (exc or {}).items():
        m[ord(k)] = v
    return m


_CIRC = _map(0x24B6, 0x24D0)
_CIRC.update({48 + i: chr(0x2460 + i - 1) for i in range(1, 10)})
_CIRC[48] = "⓪"
_SMALLCAPS = dict(zip(map(ord, "abcdefghijklmnopqrstuvwxyz"), "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ"))
FONT_STYLES = [
    ("Bold", _map(0x1D400, 0x1D41A, 0x1D7CE)), ("Italic", _map(0x1D608, 0x1D622)), ("Bold Italic", _map(0x1D468, 0x1D482)),
    ("Monospace", _map(0x1D670, 0x1D68A, 0x1D7F6)), ("Script", _map(0x1D4D0, 0x1D4EA)), ("Bold Sans", _map(0x1D5D4, 0x1D5EE, 0x1D7EC)),
    ("Full Width", _map(0xFF21, 0xFF41, 0xFF10)), ("Fraktur", _map(0x1D56C, 0x1D586)),
    ("Double Struck", _map(0x1D538, 0x1D552, 0x1D7D8, {"C": "ℂ", "H": "ℍ", "N": "ℕ", "P": "ℙ", "Q": "ℚ", "R": "ℝ", "Z": "ℤ"})),
    ("Circled", _CIRC), ("Squared", _map(0x1F170, 0x1F170)), ("Small Caps", _SMALLCAPS),
]
DECOS = ["『{}』", "【{}】", "〖{}〗", "《{}》", "〈{}〉", "꧁{}꧂", "༺{}༻", "乂{}乂", "メ{}メ", "✦ {} ✦", "✧ {} ✧", "★ {} ★",
         "☆ {} ☆", "༒ {} ༒", "•·.·´¯`·.·• {} •·.·´¯`·.·•", "╰┈➤ {}", "▄︻デ {} ══━一", "꧁༒☬ {} ☬༒꧂"]


def f_stylish(t, msg, uid):
    t = t[:200]
    lines = []
    n = 0
    for name, tb in FONT_STYLES:
        n += 1
        lines.append("%d. %s ➜ %s" % (n, name, code(t.translate(tb))))
    n += 1
    lines.append("%d. Strike ➜ %s" % (n, code("".join(ch + "\u0336" for ch in t))))
    n += 1
    lines.append("%d. Underline ➜ %s" % (n, code("".join(ch + "\u0332" for ch in t))))
    for d in DECOS:
        n += 1
        lines.append("%d. ➜ %s" % (n, code(d.format(t))))
    return chunks("\n\n".join(lines))


def f_case(t, msg, uid):
    alt = "".join(ch.upper() if i % 2 else ch.lower() for i, ch in enumerate(t))
    sent = re.sub(r"(^|[.!?]\s+)([a-z])", lambda m_: m_.group(1) + m_.group(2).upper(), t.lower())
    return (hdr("🔡 CASE CONVERTER") + "<b>UPPER:</b>\n%s\n\n<b>lower:</b>\n%s\n\n<b>Title Case:</b>\n%s\n\n<b>Sentence case:</b>\n%s\n\n"
            "<b>aLtErNaTiNg:</b>\n%s\n\n<b>sWAP:</b>\n%s") % (code(t.upper()), code(t.lower()), code(t.title()), code(sent), code(alt), code(t.swapcase()))


def f_reverse(t, msg, uid):
    return hdr("🔁 REVERSED") + "<b>Characters:</b>\n%s\n\n<b>Words:</b>\n%s" % (code(t[::-1]), code(" ".join(t.split()[::-1])))


def f_counter(t, msg, uid):
    words = len(t.split())
    return hdr("🔢 TEXT STATS") + ("<b>├── Characters:</b> %d\n<b>├── Without spaces:</b> %d\n<b>├── Words:</b> %d\n<b>├── Lines:</b> %d\n"
                                   "<b>├── Sentences:</b> %d\n<b>└── Reading time:</b> ~%d sec") % (
        len(t), len(re.sub(r"\s", "", t)), words, len(t.splitlines()) or 1, len(re.findall(r"[.!?]+", t)) or (1 if t.strip() else 0), max(1, round(words / 3.8)))


def f_sortl(t, msg, uid):
    ls = [l for l in t.splitlines() if l.strip()]
    uniq = list(dict.fromkeys(ls))
    return hdr("📑 LINES") + "<b>A → Z:</b>\n%s\n\n<b>Z → A:</b>\n%s\n\n<b>Unique (%d of %d):</b>\n%s" % (
        code("\n".join(sorted(ls, key=str.lower))), code("\n".join(sorted(ls, key=str.lower, reverse=True))), len(uniq), len(ls), code("\n".join(uniq)))


def f_repeat(t, msg, uid):
    m_ = re.match(r"^(\d+)\s+(.+)$", t, re.S)
    if not m_:
        raise UserErr("Format: <code>5 hello</code> (count then text)")
    n = min(int(m_.group(1)), 200)
    out = "\n".join([m_.group(2)] * n)
    return code(out[:3800])


LOREM = ("lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua enim ad minim "
         "veniam quis nostrud exercitation ullamco laboris nisi aliquip ex ea commodo consequat duis aute irure in reprehenderit voluptate velit esse "
         "cillum eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt culpa qui officia deserunt mollit anim id est laborum").split()


def f_lorem(t, msg, uid):
    n = 2
    if t.strip().isdigit():
        n = max(1, min(int(t.strip()), 6))
    paras = []
    for _ in range(n):
        words = [random.choice(LOREM) for _ in range(random.randint(40, 70))]
        s = " ".join(words).capitalize() + "."
        paras.append(s)
    return code("\n\n".join(paras))


# ---------- encode / security ----------
def f_hash(t, msg, uid):
    b = t.encode()
    return hdr("#️⃣ HASHES") + "\n\n".join("<b>%s</b>\n%s" % (n.upper(), code(hashlib.new(n, b).hexdigest())) for n in ("md5", "sha1", "sha256", "sha512"))


def f_b64(t, msg, uid):
    enc = base64.b64encode(t.encode()).decode()
    out = hdr("🧬 BASE64") + "<b>Encoded:</b>\n%s" % code(enc)
    try:
        dec = base64.b64decode(t.strip() + "=" * (-len(t.strip()) % 4), validate=True).decode()
        out += "\n\n<b>Decoded:</b>\n%s" % code(dec)
    except Exception:
        pass
    return out


def f_urlenc(t, msg, uid):
    from urllib.parse import unquote
    return hdr("🌍 URL ENCODE / DECODE") + "<b>Encoded:</b>\n%s\n\n<b>Decoded:</b>\n%s" % (code(quote(t, safe="")), code(unquote(t)))


def f_binary(t, msg, uid):
    if re.fullmatch(r"[01\s]+", t.strip()) and len(t.replace(" ", "")) % 8 == 0:
        bits = t.replace(" ", "").replace("\n", "")
        try:
            return hdr("💾 BINARY → TEXT") + code(bytes(int(bits[i:i + 8], 2) for i in range(0, len(bits), 8)).decode())
        except Exception:
            raise UserErr("Invalid binary.")
    return hdr("💾 TEXT → BINARY") + code(" ".join(format(b_, "08b") for b_ in t.encode())[:3800])


def f_hexc(t, msg, uid):
    s = re.sub(r"\s", "", t)
    if re.fullmatch(r"[0-9a-fA-F]+", s) and len(s) % 2 == 0:
        try:
            return hdr("🔣 HEX → TEXT") + code(bytes.fromhex(s).decode())
        except Exception:
            pass
    return hdr("🔣 TEXT → HEX") + code(t.encode().hex(" ")[:3800])


MORSE = {"a": ".-", "b": "-...", "c": "-.-.", "d": "-..", "e": ".", "f": "..-.", "g": "--.", "h": "....", "i": "..", "j": ".---", "k": "-.-",
         "l": ".-..", "m": "--", "n": "-.", "o": "---", "p": ".--.", "q": "--.-", "r": ".-.", "s": "...", "t": "-", "u": "..-", "v": "...-",
         "w": ".--", "x": "-..-", "y": "-.--", "z": "--..", "0": "-----", "1": ".----", "2": "..---", "3": "...--", "4": "....-", "5": ".....",
         "6": "-....", "7": "--...", "8": "---..", "9": "----.", ".": ".-.-.-", ",": "--..--", "?": "..--..", "!": "-.-.--", "/": "-..-."}
MORSE_R = {v: k for k, v in MORSE.items()}


def f_morse(t, msg, uid):
    if re.fullmatch(r"[.\-/\s]+", t.strip()):
        words = t.strip().split(" / ") if " / " in t else t.strip().split("/")
        return hdr("📡 MORSE → TEXT") + code(" ".join("".join(MORSE_R.get(c_, "?") for c_ in w.split()) for w in words))
    return hdr("📡 TEXT → MORSE") + code(" / ".join(" ".join(MORSE.get(ch, "") for ch in w.lower() if ch in MORSE) for w in t.split()))


def f_rot13(t, msg, uid):
    import codecs
    return hdr("🔄 ROT13") + code(codecs.encode(t, "rot_13"))


def f_jsonf(t, msg, uid):
    try:
        o = json.loads(t)
    except ValueError as e:
        raise UserErr("Invalid JSON: %s" % esc(str(e)))
    return hdr("🧾 JSON") + "<b>Pretty:</b>\n<pre>%s</pre>\n\n<b>Minified:</b>\n%s" % (esc(json.dumps(o, indent=2, ensure_ascii=False)[:2500]), code(json.dumps(o, separators=(",", ":"), ensure_ascii=False)[:800]))


def make_password(n=16, sym=True):
    chars = string.ascii_letters + string.digits + ("@#$%&*_-+=!?" if sym else "")
    while True:
        p = "".join(secrets.choice(chars) for _ in range(n))
        if any(c_.islower() for c_ in p) and any(c_.isupper() for c_ in p) and any(c_.isdigit() for c_ in p):
            return p


# ---------- calculators ----------
_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv,
        ast.Mod: operator.mod, ast.Pow: operator.pow, ast.USub: operator.neg, ast.UAdd: operator.pos}
_FUNCS = {"sqrt": math.sqrt, "abs": abs, "round": round, "sin": lambda a: math.sin(math.radians(a)), "cos": lambda a: math.cos(math.radians(a)),
          "tan": lambda a: math.tan(math.radians(a)), "log": math.log10, "ln": math.log, "fact": math.factorial, "floor": math.floor, "ceil": math.ceil}
_CONST = {"pi": math.pi, "e": math.e}


def _ev(n):
    if isinstance(n, ast.Expression):
        return _ev(n.body)
    if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
        return n.value
    if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
        a, b_ = _ev(n.left), _ev(n.right)
        if isinstance(n.op, ast.Pow) and abs(b_) > 1000:
            raise UserErr("Exponent too large.")
        return _OPS[type(n.op)](a, b_)
    if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
        return _OPS[type(n.op)](_ev(n.operand))
    if isinstance(n, ast.Name) and n.id in _CONST:
        return _CONST[n.id]
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in _FUNCS and len(n.args) == 1:
        return _FUNCS[n.func.id](_ev(n.args[0]))
    raise UserErr("Unsupported expression.")


def numfmt(v):
    if isinstance(v, float):
        if v == int(v) and abs(v) < 1e15:
            v = int(v)
        else:
            return ("%.10f" % v).rstrip("0").rstrip(".")
    return str(v)


def f_calc(t, msg, uid):
    ex = t.replace("^", "**").replace("×", "*").replace("÷", "/").replace(",", "")
    ex = re.sub(r"(?<=\d)\s*[xX]\s*(?=[\d(])", "*", ex)
    try:
        r = _ev(ast.parse(ex.strip(), mode="eval"))
    except UserErr:
        raise
    except ZeroDivisionError:
        raise UserErr("Division by zero.")
    except Exception:
        raise UserErr("I could not understand that expression. Example: <code>(25*4)+sqrt(81)</code>")
    return hdr("🧮 CALCULATOR") + "<b>%s</b>\n= %s" % (esc(t), code(numfmt(r)))


def parse_date(s):
    s = s.strip().replace("/", "-").replace(".", "-")
    for f in ("%d-%m-%Y", "%Y-%m-%d", "%d-%m-%y"):
        try:
            return datetime.strptime(s, f).date()
        except ValueError:
            continue
    raise UserErr("Date format: <code>DD-MM-YYYY</code> (example 15-08-2000)")


def f_age(t, msg, uid):
    d = parse_date(t)
    today = datetime.now(IST).date()
    if d > today:
        raise UserErr("Birth date is in the future.")
    y = today.year - d.year - ((today.month, today.day) < (d.month, d.day))
    mo = today.month - d.month - (today.day < d.day)
    if mo < 0:
        mo += 12
    ay, am = divmod(d.year * 12 + d.month - 1 + y * 12 + mo, 12)
    am += 1
    anchor = date(ay, am, min(d.day, calendar.monthrange(ay, am)[1]))
    dd = (today - anchor).days

    def bday(yr):
        return date(yr, d.month, min(d.day, calendar.monthrange(yr, d.month)[1]))

    nb = bday(today.year)
    if nb < today:
        nb = bday(today.year + 1)
    return hdr("🎂 AGE CALCULATOR") + ("<b>├── Age:</b> %d years, %d months, %d days\n<b>├── Total days:</b> %s\n<b>├── Born on:</b> %s\n"
                                       "<b>└── Next birthday:</b> %s") % (
        y, mo, dd, format((today - d).days, ","), d.strftime("%A"), "today 🎉" if nb == today else "in %d days" % (nb - today).days)


def f_datec(t, msg, uid):
    parts = [p for p in re.split(r"\s+(?:to|and|-)\s+|\s+", t.strip()) if p]
    today = datetime.now(IST).date()
    if len(parts) == 1:
        d = parse_date(parts[0])
        diff = (d - today).days
        txt = "in %d days" % diff if diff > 0 else ("today" if diff == 0 else "%d days ago" % -diff)
        return hdr("📆 DATE") + "<b>%s</b> (%s) is <b>%s</b>\n≈ %d weeks" % (d.strftime("%d %b %Y"), d.strftime("%A"), txt, abs(diff) // 7)
    d1, d2 = parse_date(parts[0]), parse_date(parts[1])
    diff = abs((d2 - d1).days)
    return hdr("📆 DATE DIFFERENCE") + "<b>%s → %s</b>\n<b>├── Days:</b> %s\n<b>├── Weeks:</b> %d (+%d days)\n<b>└── ≈ Months:</b> %.1f" % (
        d1.strftime("%d %b %Y"), d2.strftime("%d %b %Y"), format(diff, ","), diff // 7, diff % 7, diff / 30.4375)


UNITS = {"length": {"m": 1, "km": 1000, "cm": 0.01, "mm": 0.001, "mi": 1609.344, "yd": 0.9144, "ft": 0.3048, "in": 0.0254},
         "mass": {"kg": 1, "g": 0.001, "mg": 1e-6, "lb": 0.45359237, "oz": 0.028349523, "t": 1000},
         "data": {"b": 1, "kb": 1024, "mb": 1024 ** 2, "gb": 1024 ** 3, "tb": 1024 ** 4},
         "time": {"s": 1, "min": 60, "h": 3600, "d": 86400, "wk": 604800},
         "speed": {"ms": 1, "kmh": 0.277778, "mph": 0.44704, "kn": 0.514444}}
UALIAS = {"km/h": "kmh", "kph": "kmh", "m/s": "ms", "meter": "m", "metre": "m", "meters": "m", "mile": "mi", "miles": "mi", "feet": "ft", "foot": "ft",
          "inch": "in", "inches": "in", "kg": "kg", "lbs": "lb", "pound": "lb", "pounds": "lb", "hour": "h", "hr": "h", "hours": "h", "minute": "min",
          "sec": "s", "day": "d", "days": "d", "week": "wk", "celsius": "c", "fahrenheit": "f", "kelvin": "k", "°c": "c", "°f": "f", "ton": "t"}


def f_units(t, msg, uid):
    m_ = re.match(r"^\s*(-?[\d.,]+)\s*([^\s\d]+)\s*(?:to|in|=|->|→)\s*([^\s\d]+)\s*$", t, re.I)
    if not m_:
        raise UserErr("Format: <code>10 km to mi</code>, <code>100 c to f</code>, <code>5 gb to mb</code>")
    v = float(m_.group(1).replace(",", ""))
    a, b_ = m_.group(2).lower(), m_.group(3).lower()
    a, b_ = UALIAS.get(a, a), UALIAS.get(b_, b_)
    if a in ("c", "f", "k") and b_ in ("c", "f", "k"):
        c_ = v if a == "c" else (v - 32) * 5 / 9 if a == "f" else v - 273.15
        r = c_ if b_ == "c" else c_ * 9 / 5 + 32 if b_ == "f" else c_ + 273.15
        return hdr("📏 CONVERTED") + "<b>%s °%s = %s °%s</b>" % (numfmt(v), a.upper(), numfmt(round(r, 6)), b_.upper())
    for tb in UNITS.values():
        if a in tb and b_ in tb:
            r = v * tb[a] / tb[b_]
            return hdr("📏 CONVERTED") + "<b>%s %s = %s %s</b>" % (numfmt(v), a, numfmt(round(r, 8)), b_)
    raise UserErr("Unknown / incompatible units. Supported: m km cm mm mi yd ft in · kg g mg lb oz t · c f k · b kb mb gb tb · s min h d wk · kmh mph ms kn")


def f_percent(t, msg, uid):
    s = t.lower().replace(",", "")
    m_ = re.match(r"^\s*([\d.]+)\s*%\s*of\s*([\d.]+)\s*$", s)
    if m_:
        return hdr("➗ PERCENTAGE") + "<b>%s%% of %s = %s</b>" % (m_.group(1), m_.group(2), numfmt(round(float(m_.group(1)) * float(m_.group(2)) / 100, 6)))
    m_ = re.match(r"^\s*([\d.]+)\s*(?:is what %|is what percent of|/)\s*(?:of\s*)?([\d.]+)\s*$", s)
    if m_:
        return hdr("➗ PERCENTAGE") + "<b>%s is %s%% of %s</b>" % (m_.group(1), numfmt(round(float(m_.group(1)) / float(m_.group(2)) * 100, 4)), m_.group(2))
    m_ = re.match(r"^\s*([\d.]+)\s*([+-])\s*([\d.]+)\s*%\s*$", s)
    if m_:
        base, p = float(m_.group(1)), float(m_.group(3))
        r = base * (1 + p / 100) if m_.group(2) == "+" else base * (1 - p / 100)
        return hdr("➗ PERCENTAGE") + "<b>%s %s %s%% = %s</b>" % (m_.group(1), m_.group(2), m_.group(3), numfmt(round(r, 6)))
    raise UserErr("Examples:\n<code>20% of 500</code>\n<code>50 / 200</code> (what % is 50 of 200)\n<code>1000 + 18%</code> or <code>1000 - 10%</code>")


def f_tstamp(t, msg, uid):
    s = t.strip().lower()
    if s in ("now", ""):
        ts = time.time()
    elif re.fullmatch(r"\d{9,13}", s):
        ts = int(s) / (1000 if len(s) > 11 else 1)
    else:
        dt = None
        for f in ("%d-%m-%Y %H:%M", "%d-%m-%Y", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
            try:
                dt = datetime.strptime(t.strip().replace("/", "-"), f).replace(tzinfo=IST)
                break
            except ValueError:
                continue
        if not dt:
            raise UserErr("Send a unix timestamp, <code>now</code>, or a date like <code>25-12-2026 18:30</code> (IST)")
        ts = dt.timestamp()
    d = datetime.fromtimestamp(ts, timezone.utc)
    return hdr("⏱ TIMESTAMP") + "<b>├── Unix:</b> %s\n<b>├── Millis:</b> %s\n<b>├── UTC:</b> %s\n<b>└── IST:</b> %s" % (
        code(int(ts)), code(int(ts * 1000)), d.strftime("%d-%m-%Y %H:%M:%S"), d.astimezone(IST).strftime("%d-%m-%Y %H:%M:%S"))


def f_color(t, msg, uid):
    import colorsys
    s = t.strip().lstrip("#")
    if re.fullmatch(r"[0-9a-fA-F]{6}", s):
        r, g, b_ = int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16)
    elif re.fullmatch(r"[0-9a-fA-F]{3}", s):
        r, g, b_ = [int(ch * 2, 16) for ch in s]
    else:
        nums = re.findall(r"\d+", t)
        if len(nums) != 3 or any(int(n) > 255 for n in nums):
            raise UserErr("Send a HEX like <code>#1a73e8</code> or RGB like <code>26,115,232</code>")
        r, g, b_ = map(int, nums)
    h, l_, s_ = colorsys.rgb_to_hls(r / 255, g / 255, b_ / 255)
    return hdr("🎨 COLOR") + "<b>├── HEX:</b> %s\n<b>├── RGB:</b> %s\n<b>└── HSL:</b> %s" % (
        code("#%02x%02x%02x" % (r, g, b_)), code("%d, %d, %d" % (r, g, b_)), code("%d°, %d%%, %d%%" % (h * 360, s_ * 100, l_ * 100)))


# ---------- online tools ----------
HEADERS = {"User-Agent": "Mozilla/5.0 (SandyToolsBot)"}


def need_url(t):
    t = t.strip()
    if not re.match(r"^https?://", t, re.I):
        t = "https://" + t
    if not re.match(r"^https?://[^\s/]+\.[^\s/]+", t):
        raise UserErr("Send a valid link.")
    return t


def f_short(t, msg, uid):
    u = need_url(t)
    for api in ("https://tinyurl.com/api-create.php?url=" + quote(u, safe=""), "https://is.gd/create.php?format=simple&url=" + quote(u, safe="")):
        try:
            r = requests.get(api, timeout=12, headers=HEADERS)
            if r.status_code == 200 and r.text.startswith("http"):
                return hdr("✂️ SHORT LINK") + "<b>%s</b>\n\n<s>%s</s>" % (esc(r.text.strip()), esc(u[:200]))
        except requests.RequestException:
            continue
    raise UserErr("Shortener service is not reachable right now.")


def f_expand(t, msg, uid):
    u = need_url(t)
    try:
        r = requests.get(u, timeout=12, allow_redirects=True, headers=HEADERS, stream=True)
    except requests.RequestException:
        raise UserErr("Could not open that link.")
    chain = [h.url for h in r.history] + [r.url]
    r.close()
    return hdr("🔍 LINK EXPANDER") + "<b>Final URL:</b>\n%s\n\n<b>Redirects:</b> %d\n<b>Status:</b> %s" % (esc(chain[-1]), len(chain) - 1, r.status_code)


def f_ip(t, msg, uid):
    ip = t.strip()
    if not re.fullmatch(r"[0-9a-fA-F:.]{3,45}|[A-Za-z0-9.-]+\.[A-Za-z]{2,}", ip):
        raise UserErr("Send an IP address or domain.")
    try:
        j = requests.get("http://ip-api.com/json/%s?fields=status,message,country,regionName,city,zip,lat,lon,timezone,isp,org,as,query" % quote(ip), timeout=10, headers=HEADERS).json()
    except (requests.RequestException, ValueError):
        raise UserErr("IP service is not reachable right now.")
    if j.get("status") != "success":
        raise UserErr("Not found: %s" % esc(j.get("message", "")))
    return hdr("📍 IP LOOKUP") + ("<b>├── IP:</b> %s\n<b>├── Country:</b> %s\n<b>├── Region:</b> %s\n<b>├── City:</b> %s (%s)\n<b>├── Timezone:</b> %s\n"
                                  "<b>├── ISP:</b> %s\n<b>├── Org:</b> %s\n<b>└── Location:</b> %s, %s") % (
        code(j.get("query")), esc(j.get("country")), esc(j.get("regionName")), esc(j.get("city")), esc(j.get("zip")), esc(j.get("timezone")),
        esc(j.get("isp")), esc(j.get("org")), j.get("lat"), j.get("lon"))


def f_site(t, msg, uid):
    u = need_url(t)
    t0 = time.time()
    try:
        r = requests.get(u, timeout=12, headers=HEADERS, stream=True)
        ms = int((time.time() - t0) * 1000)
        info = "<b>├── Status:</b> %s %s\n<b>├── Response:</b> %d ms\n<b>├── Server:</b> %s\n<b>└── Final URL:</b> %s" % (
            r.status_code, "✅ ONLINE" if r.status_code < 400 else "⚠️", ms, esc(r.headers.get("Server", "—")), esc(r.url[:200]))
        r.close()
    except requests.RequestException as e:
        info = "<b>└── Status:</b> ❌ OFFLINE / unreachable"
    return hdr("🌐 WEBSITE STATUS") + "<b>%s</b>\n%s" % (esc(u), info)


def f_weather(t, msg, uid):
    city = t.strip()[:60]
    try:
        j = requests.get("https://wttr.in/%s?format=j1" % quote(city), timeout=14, headers=HEADERS).json()
        cur = j["current_condition"][0]
        area = j["nearest_area"][0]["areaName"][0]["value"]
        country = j["nearest_area"][0]["country"][0]["value"]
    except Exception:
        raise UserErr("Weather service is not reachable or city not found.")
    days = "\n".join("📅 %s: %s°C / %s°C" % (d_["date"], d_["mintempC"], d_["maxtempC"]) for d_ in j.get("weather", [])[:3])
    return hdr("⛅ WEATHER · %s, %s" % (esc(area).upper(), esc(country))) + (
        "<b>├── Now:</b> %s°C (feels %s°C) · %s\n<b>├── Humidity:</b> %s%%\n<b>├── Wind:</b> %s km/h\n<b>└── Visibility:</b> %s km\n\n<b>Next days (min / max)</b>\n%s") % (
        cur["temp_C"], cur["FeelsLikeC"], esc(cur["weatherDesc"][0]["value"]), cur["humidity"], cur["windspeedKmph"], cur["visibility"], days)


def f_currency(t, msg, uid):
    m_ = re.match(r"^\s*([\d.,]+)\s*([a-zA-Z]{3})\s*(?:to|in|=|->|→)\s*([a-zA-Z]{3})\s*$", t)
    if not m_:
        raise UserErr("Format: <code>100 usd to inr</code>")
    amt, a, b_ = float(m_.group(1).replace(",", "")), m_.group(2).upper(), m_.group(3).upper()
    try:
        j = requests.get("https://open.er-api.com/v6/latest/" + a, timeout=12, headers=HEADERS).json()
        rate = j["rates"][b_]
    except Exception:
        raise UserErr("Rate not available (check currency codes) or service unreachable.")
    return hdr("💱 CURRENCY") + "<b>%s %s = %s %s</b>\n\n1 %s = %s %s" % (numfmt(amt), a, format(round(amt * rate, 4), ",.4f").rstrip("0").rstrip("."), b_, a, numfmt(round(rate, 6)), b_)


COINS = {"btc": "bitcoin", "eth": "ethereum", "usdt": "tether", "bnb": "binancecoin", "sol": "solana", "xrp": "ripple", "doge": "dogecoin",
         "ton": "the-open-network", "trx": "tron", "ltc": "litecoin", "ada": "cardano", "matic": "matic-network", "shib": "shiba-inu"}


def f_crypto(t, msg, uid):
    k = t.strip().lower()
    cid = COINS.get(k, k)
    try:
        j = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=%s&vs_currencies=usd,inr&include_24hr_change=true" % quote(cid), timeout=12, headers=HEADERS).json()
        d = j[cid]
    except Exception:
        raise UserErr("Coin not found or service busy. Try <code>btc</code>, <code>eth</code>, <code>ton</code> ...")
    ch = d.get("usd_24h_change") or 0
    return hdr("🪙 %s" % esc(cid.upper())) + "<b>├── USD:</b> $%s\n<b>├── INR:</b> ₹%s\n<b>└── 24h:</b> %s %.2f%%" % (format(d["usd"], ",.6g"), format(d["inr"], ",.6g"), "📈" if ch >= 0 else "📉", ch)


# ---------- fun ----------
def f_randnum(t, msg, uid):
    nums = re.findall(r"-?\d+", t)
    if len(nums) < 2:
        raise UserErr("Send two numbers: <code>1 100</code>")
    a, b_ = sorted((int(nums[0]), int(nums[1])))
    return hdr("🔀 RANDOM NUMBER") + "<b>%d</b>  <i>(between %d and %d)</i>" % (random.randint(a, b_), a, b_)


def f_picker(t, msg, uid):
    items = [l.strip() for l in re.split(r"[\n,]+", t) if l.strip()]
    if len(items) < 2:
        raise UserErr("Send at least 2 options (one per line or comma separated).")
    return hdr("🎯 PICKED") + "<b>%s</b>\n\n<i>from %d options</i>" % (esc(random.choice(items)), len(items))


def f_poll(t, msg, uid):
    lines = [l.strip() for l in t.splitlines() if l.strip()]
    if len(lines) < 3 or len(lines) > 11:
        raise UserErr("Send the question on line 1 and 2–10 options on the next lines.")
    r = tg("sendPoll", {"chat_id": msg["chat"]["id"], "question": lines[0][:300], "options": [{"text": o[:100]} for o in lines[1:]], "is_anonymous": False})
    if bad(r):
        raise UserErr("Poll failed: %s" % esc(r["_err"]))
    return None


# ---------- telegram tools ----------
def f_mention(t, msg, uid):
    m_ = re.match(r"^\s*(\d{5,15})\s+(.+)$", t, re.S)
    if not m_:
        raise UserErr("Format: <code>123456789 Name</code> (user ID, then the name)")
    h = '<a href="tg://user?id=%s">%s</a>' % (m_.group(1), esc(m_.group(2).strip()))
    return hdr("🔖 MENTION") + "<b>Preview:</b> %s\n\n<b>HTML:</b>\n%s" % (h, code(h))


def f_tglink(t, msg, uid):
    s = t.strip().lstrip("@").replace("https://t.me/", "").replace("http://t.me/", "").strip("/")
    if re.fullmatch(r"\+?\d{8,15}", s):
        return hdr("🔗 LINKS") + "<b>Phone link:</b>\n%s\n%s" % (code("https://t.me/+" + s.lstrip("+")), code("tg://resolve?phone=" + s.lstrip("+")))
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{3,31}", s):
        raise UserErr("Send a username like <code>@durov</code> or a phone number.")
    return hdr("🔗 LINKS") + ("<b>├── Profile:</b> %s\n<b>├── App link:</b> %s\n<b>├── Message link:</b> %s\n<b>└── Share link:</b> %s") % (
        code("https://t.me/" + s), code("tg://resolve?domain=" + s), code("https://t.me/%s?text=Hello" % s), code("https://t.me/share/url?url=https://t.me/" + s))


def f_remind(t, msg, uid):
    m_ = re.match(r"^\s*(\d+)\s*([smhd])\s+(.+)$", t, re.S | re.I)
    if not m_:
        raise UserErr("Format: <code>10m drink water</code>\nUnits: s = seconds, m = minutes, h = hours, d = days")
    n, unit = int(m_.group(1)), m_.group(2).lower()
    secs = n * {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]
    if secs < 5 or secs > 30 * 86400:
        raise UserErr("Time must be between 5 seconds and 30 days.")
    add_job("remind", secs, {"chat": msg["chat"]["id"], "text": m_.group(3).strip()[:500]})
    when = datetime.now(IST) + timedelta(seconds=secs)
    return hdr("⏰ REMINDER SET") + "<b>%s</b>\n\n🕒 %s IST" % (esc(m_.group(3).strip()[:200]), when.strftime("%d-%m-%Y %H:%M:%S"))


# tool -> (prompt, function)
INPUT_TOOLS = {
    "stylish": ("Send the <b>text</b> you want to style.\n<i>You get 30+ fancy styles.</i>", f_stylish),
    "case": ("Send the <b>text</b> to convert.", f_case),
    "reverse": ("Send the <b>text</b> to reverse.", f_reverse),
    "counter": ("Send the <b>text</b> to count.", f_counter),
    "sortl": ("Send the <b>lines</b> (one per line).", f_sortl),
    "repeat": ("Send <code>count text</code>\nExample: <code>5 hello</code>", f_repeat),
    "lorem": ("Send the number of <b>paragraphs</b> (1–6).", f_lorem),
    "hash": ("Send the <b>text</b> to hash.", f_hash),
    "b64": ("Send <b>text</b> to encode (or a Base64 string to decode).", f_b64),
    "urlenc": ("Send <b>text or URL</b>.", f_urlenc),
    "binary": ("Send <b>text</b> (or binary like <code>01001000 01101001</code>).", f_binary),
    "hexc": ("Send <b>text</b> (or hex like <code>48 69</code>).", f_hexc),
    "morse": ("Send <b>text</b> (or morse like <code>.... ..</code>).", f_morse),
    "rot13": ("Send the <b>text</b>.", f_rot13),
    "jsonf": ("Send your <b>JSON</b>.", f_jsonf),
    "calc": ("Send a <b>math expression</b>.\nExample: <code>(25*4)+sqrt(81)</code> · <code>2^10</code> · <code>sin(30)</code>", f_calc),
    "age": ("Send your <b>date of birth</b>\nExample: <code>15-08-2000</code>", f_age),
    "datec": ("Send <b>one date</b> (days from today) or <b>two dates</b>.\nExample: <code>25-12-2026</code> or <code>01-01-2026 15-08-2026</code>", f_datec),
    "units": ("Send like <code>10 km to mi</code> · <code>100 c to f</code> · <code>5 gb to mb</code>", f_units),
    "percent": ("Send like <code>20% of 500</code> · <code>50 / 200</code> · <code>1000 + 18%</code>", f_percent),
    "tstamp": ("Send a <b>unix timestamp</b>, <code>now</code>, or a date like <code>25-12-2026 18:30</code> (IST).", f_tstamp),
    "color": ("Send a <b>HEX</b> (<code>#1a73e8</code>) or <b>RGB</b> (<code>26,115,232</code>).", f_color),
    "short": ("Send the <b>link</b> to shorten.", f_short),
    "expand": ("Send a <b>short link</b> to expand.", f_expand),
    "ip": ("Send an <b>IP address or domain</b>.", f_ip),
    "site": ("Send a <b>website URL</b> to check.", f_site),
    "weather": ("Send a <b>city name</b>.\nExample: <code>Mumbai</code>", f_weather),
    "currency": ("Send like <code>100 usd to inr</code>", f_currency),
    "crypto": ("Send a <b>coin</b>: <code>btc</code>, <code>eth</code>, <code>ton</code>, <code>sol</code> ...", f_crypto),
    "randnum": ("Send <b>two numbers</b>.\nExample: <code>1 100</code>", f_randnum),
    "picker": ("Send the <b>options</b> (one per line or comma separated).", f_picker),
    "poll": ("Send the <b>question</b> on line 1 and the <b>options</b> on the next lines.", f_poll),
    "mention": ("Send <code>user_id Name</code>\nExample: <code>123456789 Sandy</code>", f_mention),
    "tglink": ("Send a <b>@username</b> or phone number.", f_tglink),
    "remind": ("Send like <code>10m drink water</code> · <code>2h call mom</code> · <code>1d pay bill</code>", f_remind),
}


# ============================================================
# TOOL RUNNER, QR, FILES, SPECIAL TOOLS
# ============================================================
LASTQR = {}
F2L = {}
WIFI = {}
QR_COLORS = [("⚫ Black", "000000", "primary"), ("🔵 Blue", "1a73e8", "primary"), ("🟣 Purple", "7b1fa2", "primary"),
             ("🟢 Green", "188038", "success"), ("🔴 Red", "d93025", "danger"), ("🟠 Orange", "f57c00", "success")]


def tool_kb(key):
    t = TOOL_BY.get(key)
    return [[B("🔁 Use Again", "t:" + key, style="success"), B("⬅️ " + (GROUP_BY[t[1]][2] if t else "Menu"), "g:" + t[1] if t else "home", style="primary")]]


def reply_result(c, res, kb):
    if isinstance(res, str):
        res = [res]
    for i, part in enumerate(res):
        send(c, part, kb if i == len(res) - 1 else None)


def qr_png(text, dark="000000"):
    r = requests.get("https://quickchart.io/qr", params={"text": text, "size": 900, "margin": 3, "ecLevel": "H", "dark": dark, "light": "ffffff"},
                     timeout=25, headers=HEADERS)
    if r.status_code != 200 or "image" not in r.headers.get("content-type", ""):
        raise UserErr("QR service is not reachable right now. Please try again.")
    return r.content


def send_png(c, png, caption, kb=None):
    data = {"chat_id": c, "caption": cut(caption, 1000), "parse_mode": "HTML"}
    if kb:
        data["reply_markup"] = json.dumps({"inline_keyboard": kb})
    res = tg("sendPhoto", data, files={"photo": ("qr.png", png, "image/png")}, timeout=60)
    if bad(res) and kb and re.search(r"(?i)button|emoji|style|reply markup", res["_err"]):
        data["reply_markup"] = json.dumps(_strip_kb({"inline_keyboard": kb}, 2))
        res = tg("sendPhoto", data, files={"photo": ("qr.png", png, "image/png")}, timeout=60)
    return res


def qr_kb(back_key):
    rows = [[B(n, "qrc:" + h, style=s) for n, h, s in QR_COLORS[:3]], [B(n, "qrc:" + h, style=s) for n, h, s in QR_COLORS[3:]]]
    return rows + [[B("🔁 Make Another", "t:" + back_key, style="success"), B("🏠 Menu", "home", style="primary")]]


def send_qr(c, uid, text, caption, key, dark="000000"):
    wait = send(c, "⏳ <b>Generating QR...</b>")
    try:
        png = qr_png(text, dark)
    except UserErr as e:
        delete(c, (wait or {}).get("message_id"))
        return send(c, "❌ %s" % esc(str(e)), tool_kb(key))
    except requests.RequestException:
        delete(c, (wait or {}).get("message_id"))
        return send(c, "❌ <b>QR service is not reachable right now.</b>", tool_kb(key))
    LASTQR[uid] = (text, caption, key)
    delete(c, (wait or {}).get("message_id"))
    return send_png(c, png, caption, qr_kb(key))


def qr_caption(title, lines):
    return "<blockquote><b>✅ %s</b></blockquote>\n<blockquote><b>%s</b></blockquote>\n<b>📱 Scan the QR code.</b>" % (title, "\n".join(lines))


def upi_uri(upi, amount):
    s = "upi://pay?pa=%s&cu=INR" % upi
    if amount:
        s = "upi://pay?pa=%s&am=%s&cu=INR" % (upi, amount)
    return s


def wifi_esc(s):
    return re.sub(r"([\\;,:\"])", r"\\\1", s)


def send_files(c, items, token, uid):
    mids = []
    protect = S("protect_files") == "1"
    for f in items:
        t = f["type"]
        meth = {"photo": "sendPhoto", "video": "sendVideo", "audio": "sendAudio", "voice": "sendVoice", "document": "sendDocument",
                "animation": "sendAnimation", "sticker": "sendSticker"}.get(t)
        if not meth:
            continue
        p = {"chat_id": c, t: f["file_id"]}
        if protect:
            p["protect_content"] = True
        if f.get("caption") and t in ("photo", "video", "document", "audio", "animation"):
            p["caption"] = f["caption"]
            p["parse_mode"] = "HTML"
        r = call(meth, p)
        if not bad(r) and isinstance(r, dict) and r.get("message_id"):
            mids.append(r["message_id"])
    ttl = int(SN_("file_ttl", 600))
    if ttl > 0:
        note = send(c, "<blockquote><b>⏳ TEMPORARY FILE ACCESS</b></blockquote>\n<blockquote><b>These files will be removed after %s.</b></blockquote>" % (
            ("%d minutes" % (ttl // 60)) if ttl >= 120 else "%d seconds" % ttl))
        if note and isinstance(note, dict) and note.get("message_id"):
            mids.append(note["message_id"])
        add_job("del", ttl, {"chat": c, "mids": mids, "token": token})
    x("UPDATE files SET views=views+1 WHERE token=?", (token,))


def SN_(k, d=0):
    try:
        return float(str(S(k)).strip())
    except ValueError:
        return d


def deliver_token(c, uid, token):
    r = q1("SELECT * FROM files WHERE token=?", (token,))
    if not r:
        return send(c, "❌ <b>This file link is no longer available.</b>")
    send_files(c, json.loads(r["items"]), token, uid)


def file_item(msg):
    for k in ("photo", "video", "audio", "voice", "document", "animation", "sticker"):
        v = msg.get(k)
        if v:
            fid = v[-1]["file_id"] if k == "photo" else v["file_id"]
            it = {"type": k, "file_id": fid}
            if msg.get("caption") and k in ("photo", "video", "document", "audio", "animation"):
                it["caption"] = msg_html(msg)
            return it
    return None


def make_file_link(c, uid):
    items = F2L.pop(uid, [])
    if not items:
        return send(c, "📭 <b>Nothing uploaded yet.</b>\nSend at least one file first.")
    token = secrets.token_urlsafe(7).replace("-", "a").replace("_", "b")
    x("INSERT INTO files(token,uid,items,created) VALUES(?,?,?,?)", (token, uid, json.dumps(items), now_s()))
    link = "https://t.me/%s?start=f_%s" % (BOT_USER, token)
    send(c, "<blockquote><b>✅ FILE LINK CREATED</b></blockquote>\n<blockquote><b>🔗 Your link:</b>\n%s\n\n📦 Files: %d</blockquote>\n<b>Share this link — anyone who opens it receives the file(s).</b>" % (code(link), len(items)),
         [[B("📤 Share Link", url="https://t.me/share/url?url=" + quote(link, safe=""), style="success")],
          [B("🔁 New Link", "t:f2l", style="primary"), B("⬅️ Back", "g:files", style="primary")]])


# ---------- notes ----------
def show_notes(c, mid, uid):
    ns = q("SELECT * FROM notes WHERE uid=? ORDER BY id DESC LIMIT 15", (uid,))
    if not ns:
        t = hdr("🗒 MY NOTES") + "<b>No notes yet.</b>"
    else:
        t = hdr("🗒 MY NOTES") + "\n\n".join("<b>%d.</b> %s\n<i>%s</i>" % (i + 1, esc(n["text"][:300]), n["created"]) for i, n in enumerate(ns))
    kb = [[B("➕ Add Note", "nt:add", style="success")]]
    kb += grid([B("🗑 %d" % (i + 1), "nt:del:%d" % n["id"], style="danger") for i, n in enumerate(ns)], 5)
    kb.append([B("⬅️ Back", "g:prod", style="primary")])
    show(c, mid, t, kb)


# ---------- single tools ----------
def pass_kb():
    return [[B("%d" % n, "pg:%d" % n, style="primary") for n in (8, 12, 16)], [B("%d" % n, "pg:%d" % n, style="primary") for n in (20, 24, 32)],
            [B("🔡 No Symbols", "pg:s16", style="success"), B("⬅️ Back", "g:sec", style="primary")]]


def show_pass(c, mid, n, sym=True):
    p = make_password(n, sym)
    show(c, mid, hdr("🔐 PASSWORD GENERATOR") + "%s\n\n<b>%d characters · %s</b>\n<i>Tap a length to generate a new one</i>" % (
        code(p), n, "Letters · Numbers · Symbols" if sym else "Letters · Numbers"), pass_kb())


def my_details(c, uid, msg_from):
    fr = msg_from
    now = datetime.now(IST)
    d = ("<blockquote><b>👤 YOUR TELEGRAM DETAILS</b></blockquote>\n<blockquote><b>├── 👤 First Name:</b> %s\n<b>├── 📝 Last Name:</b> %s\n<b>├── 🔗 Username:</b> %s\n"
         "<b>├── 🆔 User ID:</b> <code>%s</code>\n<b>├── 🌐 Language:</b> %s\n<b>├── 💎 Premium:</b> %s\n<b>├── 🕐 Time:</b> %s\n<b>└── 📅 Date:</b> %s</blockquote>") % (
        esc(fr.get("first_name") or "—"), esc(fr.get("last_name") or "—"), ("@" + fr["username"]) if fr.get("username") else "—", fr["id"],
        esc(fr.get("language_code") or "—"), "Yes ✅" if fr.get("is_premium") else "No", now.strftime("%I:%M %p"), now.strftime("%d %b %Y"))
    kb = [[B("⬅️ Back", "g:tg", style="primary")]]
    ph = tg("getUserProfilePhotos", {"user_id": uid, "limit": 1})
    if not bad(ph) and ph.get("total_count"):
        r = send_photo(c, ph["photos"][0][-1]["file_id"], d, kb)
        if not bad(r):
            return
    send(c, d, kb)


def id_info(c, msg):
    L_ = ["<b>├── 👤 Your ID:</b> %s" % code(msg["from"]["id"]), "<b>├── 💬 Chat ID:</b> %s" % code(msg["chat"]["id"])]
    fo = msg.get("forward_origin") or {}
    if fo.get("type") == "user":
        L_.append("<b>├── ↪️ Forwarded user ID:</b> %s" % code(fo["sender_user"]["id"]))
    elif fo.get("type") in ("channel", "chat"):
        ch = fo.get("chat") or fo.get("sender_chat") or {}
        L_.append("<b>├── ↪️ Forwarded chat ID:</b> %s (%s)" % (code(ch.get("id")), esc(ch.get("title", ""))))
    elif fo.get("type") == "hidden_user":
        L_.append("<b>├── ↪️ Forwarded from hidden user:</b> %s" % esc(fo.get("sender_user_name", "")))
    if msg.get("forward_from"):
        L_.append("<b>├── ↪️ Forwarded user ID:</b> %s" % code(msg["forward_from"]["id"]))
    if msg.get("forward_from_chat"):
        L_.append("<b>├── ↪️ Forwarded chat ID:</b> %s" % code(msg["forward_from_chat"]["id"]))
    if msg.get("contact") and msg["contact"].get("user_id"):
        L_.append("<b>├── 📇 Contact user ID:</b> %s" % code(msg["contact"]["user_id"]))
    it = file_item(msg)
    if it:
        L_.append("<b>├── 📎 File type:</b> %s\n<b>├── 🆔 File ID:</b> %s" % (it["type"], code(it["file_id"])))
    L_[-1] = L_[-1].replace("├──", "└──", 1)
    return hdr("🆔 ID INFO") + "\n".join(L_) + "\n\n<i>Forward any message / send a file to get more IDs.</i>"


def emoji_ids(msg):
    ids = []
    for e in (msg.get("entities") or []) + (msg.get("caption_entities") or []):
        if e.get("type") == "custom_emoji":
            ids.append(e["custom_emoji_id"])
    st = msg.get("sticker") or {}
    if st.get("custom_emoji_id"):
        ids.append(st["custom_emoji_id"])
    for n in re.findall(r"\b\d{15,20}\b", msg.get("text") or ""):
        ids.append(n)
    ids = list(dict.fromkeys(ids))
    if not ids:
        return None
    out = hdr("💎 PREMIUM EMOJI IDs")
    for i, e in enumerate(ids, 1):
        out += "<b>%d.</b> %s\n<b>HTML:</b> %s\n\n" % (i, code(e), code('<tg-emoji emoji-id="%s">⭐</tg-emoji>' % e))
    return out + "<i>Use this ID for button icons in Admin → Buttons, and in the Post Creator buttons.</i>"


def fn_input(key, c, uid, msg):
    """Runs an input tool. Returns True when handled."""
    t = msg.get("text") or ""
    kb = tool_kb(key)
    if key == "getid":
        send(c, id_info(c, msg), kb)
        return True
    if key == "emojiid":
        r = emoji_ids(msg)
        send(c, r or "❌ <b>Send a premium emoji (or a premium sticker).</b>", kb)
        return True
    if not t:
        send(c, "❌ <b>Please send text.</b>", kb)
        return True
    if key == "urlqr":
        if not re.match(r"^https?://\S+$", t.strip(), re.I):
            send(c, "❌ <b>INVALID URL</b>\n\nSend a link starting with <code>http://</code> or <code>https://</code>", kb)
            return True
        send_qr(c, uid, t.strip(), qr_caption("QR CODE GENERATED", ["🔗 " + esc(t.strip()[:300])]), key)
        return True
    if key == "textqr":
        send_qr(c, uid, t[:900], qr_caption("QR CODE GENERATED", ["📝 " + esc(t[:300])]), key)
        return True
    fn = INPUT_TOOLS[key][1]
    try:
        res = fn(t, msg, uid)
    except UserErr as e:
        send(c, "❌ " + str(e), kb)
        return True
    except Exception as e:
        log("tool %s error: %s" % (key, e))
        send(c, "⚠️ <b>Something went wrong.</b> Please check your input and try again.", kb)
        return True
    if res:
        reply_result(c, res, kb)
    return True


def tool_start(c, mid, uid, key, fr=None):
    t = TOOL_BY.get(key)
    if not t:
        return home(c, mid, uid)
    gk = t[1]
    back = [[B("⬅️ Back", "g:" + gk, style="danger")]]
    title = "%s %s" % (t[2], t[3].upper())
    if key == "passgen":
        return show_pass(c, mid, 16)
    if key == "uuid":
        return show(c, mid, hdr("🆔 UUID GENERATOR") + "\n".join(code(str(uuid.uuid4())) for _ in range(5)),
                    [[B("🔁 Generate More", "t:uuid", style="success"), B("⬅️ Back", "g:sec", style="primary")]])
    if key == "coin":
        return show(c, mid, hdr("🪙 COIN FLIP") + "<b>%s</b>" % random.choice(["🪙 HEADS", "🪙 TAILS"]),
                    [[B("🔁 Flip Again", "t:coin", style="success"), B("⬅️ Back", "g:fun", style="primary")]])
    if key == "dice":
        return show(c, mid, hdr("🎲 DICE & GAMES") + "<b>Pick one 👇</b>", grid([B(e, "dc:" + e, style="primary") for e in ("🎲", "🎯", "🏀", "⚽", "🎳", "🎰")], 3) + back)
    if key == "mydet":
        delete(c, mid)
        return my_details(c, uid, fr or {"id": uid})
    if key == "notes":
        return show_notes(c, mid, uid)
    if key == "f2l":
        F2L[uid] = []
        st_set(uid, "f2l")
        return show(c, mid, hdr("📁 FILE → LINK") + "<b>📤 Send your file(s)</b>\nDocument · Photo · Video · Audio · Voice · GIF · Sticker\n\nSend as many as you want, then tap <b>✔️ Done</b> to get one share link.",
                    [[B("✔️ Done", "f2l:done", style="success")], [B("⬅️ Back", "g:files", style="danger")]])
    if key == "img2l":
        url = S("imglink_url").strip()
        if url:
            return show(c, mid, hdr("🖼 IMAGE → LINK") + "<b>Upload your image and get a direct link instantly.\n\n👇 Tap the button below.</b>",
                        [[B("🖼 Upload Image", web=url, style="primary")], [B("⬅️ Back", "g:files", style="danger")]])
        F2L[uid] = []
        st_set(uid, "f2l")
        return show(c, mid, hdr("🖼 IMAGE → LINK") + "<b>📤 Send your image(s)</b>\nYou will get a shareable Telegram link.\n\nSend images, then tap <b>✔️ Done</b>.",
                    [[B("✔️ Done", "f2l:done", style="success")], [B("⬅️ Back", "g:files", style="danger")]])
    if key == "upiqr":
        st_set(uid, "upi_id")
        return show(c, mid, hdr("💳 UPI PAYMENT QR") + "<b>Enter the UPI ID</b> where you want to receive the payment.\n\nExample: <code>yourname@upi</code>", back)
    if key == "wifiqr":
        st_set(uid, "wifi_ssid")
        return show(c, mid, hdr("📶 WIFI QR") + "<b>Send your WiFi name (SSID).</b>", back)
    if key == "getid":
        st_set(uid, "tool", key=key)
        return show(c, mid, hdr(title) + "<b>Forward any message or send any file/contact here</b> to get IDs.", back)
    if key == "emojiid":
        st_set(uid, "tool", key=key)
        return show(c, mid, hdr(title) + "<b>Send premium emoji(s)</b> — I will reply with their IDs.", back)
    if key in ("urlqr", "textqr"):
        st_set(uid, "tool", key=key)
        return show(c, mid, hdr(title) + ("<b>🌐 Send the URL</b> you want to convert into a QR code." if key == "urlqr" else "<b>📝 Send any text</b> to convert into a QR code."), back)
    if key in INPUT_TOOLS:
        st_set(uid, "tool", key=key)
        return show(c, mid, hdr(title) + "<b>%s</b>" % INPUT_TOOLS[key][0], back)
    home(c, mid, uid)


# ============================================================
# POST CREATOR  (text / media + coloured buttons + premium emoji)
# ============================================================
DRAFT = {}
PEND = {}
COLOR_WORDS = {"green": "success", "success": "success", "g": "success", "blue": "primary", "primary": "primary", "b": "primary",
               "red": "danger", "danger": "danger", "r": "danger", "default": "", "none": "", "grey": "", "gray": ""}
COLOR_ICON = {"success": "🟢", "primary": "🔵", "danger": "🔴", "": "⚪"}


def new_draft():
    return {"type": "", "fid": "", "html": "", "rows": [], "silent": 0, "protect": 0, "preview": 1, "id": None}


def draft(uid):
    return DRAFT.setdefault(uid, new_draft())


def media_of(msg):
    if msg.get("photo"):
        return "photo", msg["photo"][-1]["file_id"]
    for k in ("video", "animation", "document", "audio"):
        if msg.get(k):
            return k, msg[k]["file_id"]
    return "", ""


def norm_url(u):
    u = (u or "").strip()
    if re.match(r"^@[A-Za-z][A-Za-z0-9_]{3,31}$", u):
        return "https://t.me/" + u[1:]
    if re.match(r"^(t\.me|telegram\.me)/", u, re.I):
        return "https://" + u
    if re.match(r"^(https?://|tg://)\S+$", u, re.I):
        return u
    if re.match(r"^[^\s/]+\.[A-Za-z]{2,}(/\S*)?$", u):
        return "https://" + u
    return ""


def kb_of(d):
    rows = []
    for row in d["rows"]:
        r = []
        for b_ in row:
            x_ = {"text": b_["text"][:60] or "•", "url": b_["url"]}
            if b_.get("style"):
                x_["style"] = b_["style"]
            if b_.get("eid"):
                x_["icon_custom_emoji_id"] = str(b_["eid"])
            r.append(x_)
        rows.append(r)
    return {"inline_keyboard": rows} if rows else None


def post_params(chat, d):
    base = {"chat_id": chat, "parse_mode": "HTML"}
    if d["silent"]:
        base["disable_notification"] = True
    if d["protect"]:
        base["protect_content"] = True
    kb = kb_of(d)
    if kb:
        base["reply_markup"] = kb
    if d["type"] == "text":
        base["text"] = d["html"]
        if not d["preview"]:
            base["disable_web_page_preview"] = True
        return "sendMessage", base
    base[d["type"]] = d["fid"]
    if d["html"]:
        base["caption"] = d["html"]
    return MEDIA_METHODS[d["type"]], base


def post_ready(d):
    if not d["type"]:
        return "Add the post text or media first."
    if d["type"] == "text" and not d["html"].strip():
        return "Post text is empty."
    if d["type"] != "text" and plain_len(d["html"]) > 1024:
        return "Caption is too long (%d/1024). Shorten the text or send it as a text post." % plain_len(d["html"])
    if d["type"] == "text" and plain_len(d["html"]) > 4000:
        return "Text is too long (max 4000)."
    return ""


def send_post(chat, d):
    meth, p = post_params(chat, d)
    return call(meth, p)


def pb_status(d):
    kind = "—" if not d["type"] else ("📝 text" if d["type"] == "text" else MEDIA_ICON[d["type"]])
    nb = sum(len(r) for r in d["rows"])
    txt = re.sub(r"<[^>]+>", "", d["html"]).strip()
    return ("<blockquote><b>✍️ POST CREATOR</b></blockquote>\n<blockquote><b>├── Content: %s\n├── Text: %s\n├── Buttons: %d in %d row(s)\n"
            "└── Options: %s · %s · %s</b></blockquote>\n<i>Add text/media → add coloured buttons → preview → send.</i>") % (
        kind, esc(txt[:70] + ("…" if len(txt) > 70 else "")) if txt else "—", nb, len(d["rows"]),
        "🔕 silent" if d["silent"] else "🔔 normal", "🔒 protected" if d["protect"] else "🔓 forwardable", "🔗 preview on" if d["preview"] else "🚫 preview off")


def pb_panel(c, mid, uid):
    d = draft(uid)
    kb = [[B("📝 Set Text / Media", "pb:txt", style="primary"), B("➕ Add Button", "pb:add", style="success")],
          [B("📋 Bulk Buttons", "pb:bulk", style="primary"), B("➖ Remove Last", "pb:undo", style="danger")],
          [B("🗑 Clear Buttons", "pb:clear", style="danger"), B("👁 Preview", "pb:prev", style="success")],
          [B("🔕 Silent: %s" % ("ON" if d["silent"] else "OFF"), "pb:sil", style="primary"), B("🔒 Protect: %s" % ("ON" if d["protect"] else "OFF"), "pb:prot", style="primary")],
          [B("🔗 Link Preview: %s" % ("ON" if d["preview"] else "OFF"), "pb:lp", style="primary"), B("💾 Save Post", "pb:save", style="success")],
          [B("📤 Send to Channel / Group", "pb:send", style="success"), B("📨 Send to Me", "pb:me", style="primary")]]
    if is_admin(uid):
        kb.append([B("📢 Broadcast to All Users", "pb:bc", style="danger")])
    kb.append([B("📂 My Posts", "pb:list", style="primary"), B("🆕 New Post", "pb:new", style="success")])
    row = [B("⬅️ Menu", "home", style="primary")]
    if d.get("id"):
        row.insert(0, B("🗑 Delete Saved", "pb:del", style="danger"))
    kb.append(row)
    show(c, mid, pb_status(d), kb)


def pb_cancel_kb():
    return [[B("❌ Cancel", "pb:panel", style="danger")]]


def parse_buttons_bulk(txt):
    """Each line = one row.  ' && ' puts several buttons in the same row.  Label | URL | colour   ({emojiId}Label for premium icon)."""
    rows, errs = [], []
    for ln, line in enumerate([l for l in txt.splitlines() if l.strip()], 1):
        row = []
        for part in re.split(r"\s+&&\s+", line):
            seg = [s.strip() for s in part.split("|")]
            if len(seg) < 2:
                errs.append("Line %d: need  Label | URL" % ln)
                continue
            label, eid = seg[0], ""
            m_ = re.match(r"^\{(\d{10,25})\}\s*(.*)$", label)
            if m_:
                eid, label = m_.group(1), m_.group(2)
            url = norm_url(seg[1])
            if not url or not label:
                errs.append("Line %d: bad label or URL" % ln)
                continue
            style = COLOR_WORDS.get(seg[2].lower(), "") if len(seg) > 2 else ""
            row.append({"text": label[:60], "url": url, "style": style, "eid": eid})
        if row:
            rows.append(row)
    return rows, errs


def pb_color_prompt(c, mid):
    b = PEND.get(c, {})
    show(c, mid, "<blockquote><b>🎨 CHOOSE BUTTON COLOUR</b></blockquote>\n<b>Button:</b> %s%s" % ("💎 " if b.get("eid") else "", esc(b.get("text", ""))),
         [[B("🟢 Green", "pbc:success", style="success"), B("🔵 Blue", "pbc:primary", style="primary"), B("🔴 Red", "pbc:danger", style="danger")],
          [B("⚪ Default (no colour)", "pbc:none", style="primary")]])


def pb_target_prompt(c, mid, uid):
    chs = q("SELECT * FROM uchannels WHERE uid=? ORDER BY id DESC LIMIT 10", (uid,))
    kb = [[B("📢 " + (ch["title"] or ch["chat"])[:40], "pbt:%d" % ch["id"], style="success")] for ch in chs]
    kb.append([B("❌ Cancel", "pb:panel", style="danger")])
    st_set(uid, "pb_target")
    show(c, mid, "<blockquote><b>📤 SEND POST</b></blockquote>\n<b>Send the channel / group:</b>\n• <code>@channelusername</code>\n• a <code>-100…</code> chat ID\n• or <b>forward any message</b> from it\n\n"
         "<i>The bot must be an <b>admin</b> there (with permission to post).</i>" + ("\n\n<b>Or pick a saved one 👇</b>" if chs else ""), kb)


def pb_deliver(c, uid, chat, title=""):
    d = draft(uid)
    err = post_ready(d)
    if err:
        return send(c, "❌ " + esc(err), [[B("⬅️ Back", "pb:panel", style="primary")]])
    r = send_post(chat, d)
    if bad(r):
        e = r["_err"]
        hint = ""
        if re.search(r"(?i)chat not found|not a member|kicked", e):
            hint = "\n\n<i>Make sure the bot is added to that channel/group as admin.</i>"
        elif re.search(r"(?i)rights|permission|forbidden", e):
            hint = "\n\n<i>Give the bot permission to post messages.</i>"
        return send(c, "❌ <b>Could not send:</b> %s%s" % (esc(e), hint), [[B("🔁 Try Again", "pb:send", style="success"), B("⬅️ Back", "pb:panel", style="primary")]])
    if str(chat) != str(c) and (str(chat).startswith("@") or str(chat).startswith("-")):
        if not q1("SELECT 1 FROM uchannels WHERE uid=? AND chat=?", (uid, str(chat))):
            x("INSERT INTO uchannels(uid,chat,title) VALUES(?,?,?)", (uid, str(chat), title or str(chat)))
    send(c, "<blockquote><b>✅ POST SENT</b></blockquote>\n<b>Delivered to:</b> %s" % esc(title or str(chat)),
         [[B("✍️ Back to Post", "pb:panel", style="primary"), B("🆕 New Post", "pb:new", style="success")]])


def resolve_target(msg):
    fo = msg.get("forward_origin") or {}
    ch = fo.get("chat") or fo.get("sender_chat") or msg.get("forward_from_chat")
    if ch:
        return ch["id"], ch.get("title") or ch.get("username") or str(ch["id"])
    t = (msg.get("text") or "").strip()
    m_ = re.match(r"^(?:https?://)?(?:t\.me/)?@?([A-Za-z][A-Za-z0-9_]{3,31})/?$", t)
    if m_:
        return "@" + m_.group(1), "@" + m_.group(1)
    if re.fullmatch(r"-?\d{6,16}", t):
        return int(t), t
    return None, None


def broadcast_post(c, uid):
    d = draft(uid)
    users = [r["id"] for r in q("SELECT id FROM users WHERE banned=0")]
    send(c, "📢 <b>Broadcasting to %d users...</b>" % len(users))

    def run():
        ok = fail = 0
        for u_ in users:
            r = send_post(u_, d)
            if bad(r):
                fail += 1
            else:
                ok += 1
            time.sleep(0.05)
        send(c, "<blockquote><b>✅ BROADCAST DONE</b></blockquote>\n<b>├── Users:</b> %d\n<b>├── Sent:</b> %d\n<b>└── Failed:</b> %d" % (len(users), ok, fail))
    threading.Thread(target=run, daemon=True).start()


def pb_route(c, mid, uid, a):
    d = draft(uid)
    sub = a[1] if len(a) > 1 else "panel"
    if sub == "new":
        DRAFT[uid] = new_draft()
        return pb_panel(c, mid, uid)
    if sub == "panel":
        return pb_panel(c, mid, uid)
    if sub == "txt":
        st_set(uid, "pb_content")
        return show(c, mid, "<blockquote><b>📝 POST CONTENT</b></blockquote>\n<b>Send the post now:</b>\n• plain <b>text</b>, or\n• a <b>photo / video / GIF / file / audio</b> with a caption\n\n"
                    "<i>Bold, italic, links, quotes and 💎 premium emoji are kept exactly as you type them.</i>", pb_cancel_kb())
    if sub == "add":
        st_set(uid, "pb_label")
        return show(c, mid, "<blockquote><b>➕ NEW BUTTON</b></blockquote>\n<b>Step 1/3 — Send the button text.</b>\n\nTip: put a <b>💎 premium emoji</b> at the start and it becomes the button icon.", pb_cancel_kb())
    if sub == "bulk":
        st_set(uid, "pb_bulk")
        return show(c, mid, "<blockquote><b>📋 BULK BUTTONS</b></blockquote>\n<b>One row per line:</b>\n<code>Label | URL | colour</code>\n\n<b>Same row:</b> separate with <code> &amp;&amp; </code>\n<b>Colours:</b> green · blue · red · default\n<b>Premium icon:</b> <code>{emoji_id}Label</code>\n\n"
                    "<b>Example</b>\n<code>Join Channel | @mychannel | green\nWebsite | example.com | blue &amp;&amp; Support | @support | red</code>", pb_cancel_kb())
    if sub == "undo":
        if d["rows"]:
            d["rows"][-1].pop()
            if not d["rows"][-1]:
                d["rows"].pop()
        return pb_panel(c, mid, uid)
    if sub == "clear":
        d["rows"] = []
        return pb_panel(c, mid, uid)
    if sub in ("sil", "prot", "lp"):
        k = {"sil": "silent", "prot": "protect", "lp": "preview"}[sub]
        d[k] = 0 if d[k] else 1
        return pb_panel(c, mid, uid)
    if sub == "prev":
        err = post_ready(d)
        if err:
            return send(c, "❌ " + esc(err), [[B("⬅️ Back", "pb:panel", style="primary")]])
        r = send_post(c, d)
        if bad(r):
            return send(c, "❌ <b>Preview failed:</b> %s" % esc(r["_err"]), [[B("⬅️ Back", "pb:panel", style="primary")]])
        return send(c, "👆 <b>This is how your post looks.</b>", [[B("✍️ Back to Post", "pb:panel", style="primary")]])
    if sub == "me":
        return pb_deliver(c, uid, c, "yourself")
    if sub == "send":
        err = post_ready(d)
        if err:
            return send(c, "❌ " + esc(err), [[B("⬅️ Back", "pb:panel", style="primary")]])
        return pb_target_prompt(c, mid, uid)
    if sub == "save":
        err = post_ready(d)
        if err:
            return send(c, "❌ " + esc(err), [[B("⬅️ Back", "pb:panel", style="primary")]])
        title = re.sub(r"<[^>]+>", "", d["html"]).strip()[:40] or ("[%s post]" % d["type"])
        data = json.dumps(d, ensure_ascii=False)
        if d.get("id"):
            x("UPDATE posts SET data=?, title=? WHERE id=? AND uid=?", (data, title, d["id"], uid))
        else:
            d["id"] = x("INSERT INTO posts(uid,title,data,created) VALUES(?,?,?,?)", (uid, title, data, now_s()))
            x("UPDATE posts SET data=? WHERE id=?", (json.dumps(d, ensure_ascii=False), d["id"]))
        return pb_panel(c, mid, uid)
    if sub == "list":
        ps = q("SELECT id,title,created FROM posts WHERE uid=? ORDER BY id DESC LIMIT 20", (uid,))
        kb = [[B("📄 " + (p["title"] or "post"), "pb:open:%d" % p["id"], style=STYLES[i % 3])] for i, p in enumerate(ps)]
        kb.append([B("⬅️ Back", "pb:panel", style="primary")])
        return show(c, mid, "<blockquote><b>📂 MY POSTS</b></blockquote>\n<b>%s</b>" % ("Tap a post to open it." if ps else "No saved posts yet."), kb)
    if sub == "open" and len(a) > 2:
        r = q1("SELECT * FROM posts WHERE id=? AND uid=?", (int(a[2]), uid))
        if r:
            DRAFT[uid] = json.loads(r["data"])
            DRAFT[uid]["id"] = r["id"]
        return pb_panel(c, mid, uid)
    if sub == "del":
        if d.get("id"):
            x("DELETE FROM posts WHERE id=? AND uid=?", (d["id"], uid))
        DRAFT[uid] = new_draft()
        return pb_panel(c, mid, uid)
    if sub == "bc" and is_admin(uid):
        err = post_ready(d)
        if err:
            return send(c, "❌ " + esc(err), [[B("⬅️ Back", "pb:panel", style="primary")]])
        return show(c, mid, "<blockquote><b>📢 BROADCAST</b></blockquote>\n<b>Send this post to <u>all bot users</u>?</b>",
                    [[B("✅ Yes, send", "pb:bcgo", style="success"), B("❌ Cancel", "pb:panel", style="danger")]])
    if sub == "bcgo" and is_admin(uid):
        return broadcast_post(c, uid)
    return pb_panel(c, mid, uid)


def pb_state(c, uid, s, xx, msg):
    """Message input for the post creator. Returns True when handled."""
    d = draft(uid)
    if s == "pb_content":
        mt, fid = media_of(msg)
        if mt:
            d["type"], d["fid"], d["html"] = mt, fid, msg_html(msg)
        elif msg.get("text"):
            d["type"], d["fid"], d["html"] = "text", "", msg_html(msg)
        else:
            send(c, "❌ <b>Send text, or a photo/video/GIF/file.</b>", pb_cancel_kb())
            st_set(uid, "pb_content")
            return True
        err = post_ready(d)
        if err:
            send(c, "⚠️ " + esc(err))
        pb_panel(c, None, uid)
        return True
    if s == "pb_label":
        if not msg.get("text"):
            send(c, "❌ <b>Send the button text.</b>", pb_cancel_kb())
            st_set(uid, "pb_label")
            return True
        label, eid = strip_custom_emoji(msg["text"], msg.get("entities"))
        if not label:
            label = "💎"
        st_set(uid, "pb_url", label=label[:60], eid=eid)
        send(c, "<blockquote><b>➕ NEW BUTTON</b></blockquote>\n<b>Step 2/3 — Send the link.</b>\n\n<code>https://example.com</code> · <code>@channel</code> · <code>t.me/…</code>" + ("\n💎 <i>Premium icon detected.</i>" if eid else ""), pb_cancel_kb())
        return True
    if s == "pb_url":
        url = norm_url(msg.get("text") or "")
        if not url:
            send(c, "❌ <b>Invalid link.</b> Send a URL like <code>https://example.com</code> or <code>@channel</code>.", pb_cancel_kb())
            st_set(uid, "pb_url", **xx)
            return True
        PEND[c] = {"text": xx["label"], "url": url, "eid": xx.get("eid", "")}
        pb_color_prompt(c, None)
        return True
    if s == "pb_bulk":
        rows, errs = parse_buttons_bulk(msg.get("text") or "")
        d["rows"] += rows
        note = ("⚠️ " + "\n".join(esc(e) for e in errs[:6])) if errs else ""
        if note:
            send(c, note)
        pb_panel(c, None, uid)
        return True
    if s == "pb_target":
        chat, title = resolve_target(msg)
        if chat is None:
            send(c, "❌ <b>Could not read that.</b> Send <code>@channelusername</code>, a <code>-100…</code> ID or forward a message from the channel.", pb_cancel_kb())
            st_set(uid, "pb_target")
            return True
        info = tg("getChat", {"chat_id": chat})
        if not bad(info):
            title = info.get("title") or info.get("username") or title
            chat = info.get("id", chat) if not str(chat).startswith("@") else chat
        pb_deliver(c, uid, chat, title)
        return True
    return False


def pb_color_pick(c, mid, uid, style):
    b = PEND.get(c)
    d = draft(uid)
    if not b:
        return pb_panel(c, mid, uid)
    b["style"] = "" if style == "none" else style
    if d["rows"]:
        show(c, mid, "<blockquote><b>➕ PLACEMENT</b></blockquote>\n<b>Where should the button go?</b>",
             [[B("➡️ Same row as last", "pbp:same", style="primary"), B("⬇️ New row", "pbp:row", style="success")]])
    else:
        d["rows"].append([PEND.pop(c)])
        pb_panel(c, mid, uid)


def pb_place(c, mid, uid, how):
    b = PEND.pop(c, None)
    d = draft(uid)
    if b:
        if how == "same" and d["rows"] and len(d["rows"][-1]) < 3:
            d["rows"][-1].append(b)
        else:
            d["rows"].append([b])
    pb_panel(c, mid, uid)


# ============================================================
# ADMIN PANEL
# ============================================================
def adm_home(c, mid, uid):
    n = q1("SELECT COUNT(*) n FROM users")["n"]
    t = ("<blockquote><b>👑 ADMIN PANEL</b></blockquote>\n<blockquote><b>├── 👥 Users: %d\n├── 📡 Force channels: %d\n└── 🛠 Maintenance: %s</b></blockquote>\n<i>Manage everything from here.</i>") % (
        n, q1("SELECT COUNT(*) n FROM channels")["n"], "ON" if S("maint") == "1" else "OFF")
    kb = [[B("📊 Stats", "adm:stats", style="primary"), B("👥 Users", "adm:users", style="success")],
          [B("📢 Broadcast", "adm:bc", style="success"), B("📡 Force Channels", "adm:ch", style="primary")],
          [B("👋 Welcome", "adm:wel", style="success"), B("📜 Texts", "adm:txt", style="primary")],
          [B("🎛 Buttons & Tools", "adm:bl", style="primary"), B("⚙️ Settings", "adm:set", style="success")],
          [B("💎 Premium Emoji ID Finder", "adm:idf", style="primary")],
          [B("⬅️ Menu", "home", style="danger")]]
    show(c, mid, t, kb)


def adm_stats(c, mid):
    today = datetime.now(IST).strftime("%d-%m-%Y")
    t = ("<blockquote><b>📊 BOT STATS</b></blockquote>\n<blockquote><b>├── 👥 Total users:</b> %d\n<b>├── 🆕 Joined today:</b> %d\n<b>├── 🚫 Banned:</b> %d\n"
         "<b>├── 📁 File links:</b> %d\n<b>├── ✍️ Saved posts:</b> %d\n<b>├── 🗒 Notes:</b> %d\n<b>└── ⏳ Pending jobs:</b> %d</blockquote>") % (
        q1("SELECT COUNT(*) n FROM users")["n"], q1("SELECT COUNT(*) n FROM users WHERE joined LIKE ?", (today + "%",))["n"],
        q1("SELECT COUNT(*) n FROM users WHERE banned=1")["n"], q1("SELECT COUNT(*) n FROM files")["n"], q1("SELECT COUNT(*) n FROM posts")["n"],
        q1("SELECT COUNT(*) n FROM notes")["n"], q1("SELECT COUNT(*) n FROM jobs")["n"])
    show(c, mid, t, [[B("🔄 Refresh", "adm:stats", style="success"), B("⬅️ Back", "adm", style="primary")]])


def adm_users(c, mid):
    us = q("SELECT * FROM users ORDER BY rowid DESC LIMIT 12")
    t = "<blockquote><b>👥 USERS (%d)</b></blockquote>\n" % q1("SELECT COUNT(*) n FROM users")["n"]
    t += "\n".join("%s <b>%s</b> %s · <code>%s</code>" % ("🚫" if u["banned"] else "👤", esc(u["name"][:20]), ("@" + u["username"]) if u["username"] else "", u["id"]) for u in us)
    show(c, mid, t, [[B("🚫 Ban by ID", "adm:ban", style="danger"), B("✅ Unban by ID", "adm:unban", style="success")], [B("⬅️ Back", "adm", style="primary")]])


def adm_channels(c, mid):
    chs = q("SELECT * FROM channels ORDER BY id")
    t = "<blockquote><b>📡 FORCE-JOIN CHANNELS</b></blockquote>\n"
    if not chs:
        t += "<b>None set.</b> Users can use the bot without joining."
    for ch in chs:
        r = tg("getChatMember", {"chat_id": ch["chat"], "user_id": BOT_ID})
        ok = (not bad(r)) and r.get("status") in ("administrator", "creator")
        t += "%s <b>%s</b>  <code>%s</code>\n" % ("✅" if ok else "⚠️", esc(ch["title"] or ""), esc(ch["chat"]))
    t += "\n<i>✅ = bot is admin there (membership can be verified). ⚠️ = add the bot as admin.</i>"
    kb = [[B("🗑 " + (ch["title"] or ch["chat"])[:30], "adm:chdel:%d" % ch["id"], style="danger")] for ch in chs]
    kb += [[B("➕ Add Channel", "adm:chadd", style="success")], [B("⬅️ Back", "adm", style="primary")]]
    show(c, mid, t, kb)


def adm_welcome(c, mid):
    has = bool(S("welcome_media_id"))
    t = ("<blockquote><b>👋 WELCOME SETUP</b></blockquote>\n<b>🎬 Media:</b> %s\n\n<b>📝 Text:</b>\n<code>%s</code>\n\n"
         "<i>Variables: {name} {id} {brand} {bot}. Premium emoji you type are kept.</i>") % (MEDIA_ICON.get(S("welcome_media_type"), "✅") if has else "— (none)", esc(S("txt_welcome")[:600]))
    kb = [[B("📝 Edit Welcome Text", "adm:wtxt", style="primary")], [B("🎬 %s Photo / Video" % ("Change" if has else "Add"), "adm:wmed", style="success")]]
    if has:
        kb.append([B("🗑 Remove Media", "adm:wmx", style="danger")])
    kb += [[B("♻️ Reset Text", "adm:wrst", style="danger"), B("👁 Preview", "adm:wprev", style="success")], [B("⬅️ Back", "adm", style="primary")]]
    show(c, mid, t, kb)


def adm_texts(c, mid):
    t = "<blockquote><b>📜 TEXTS</b></blockquote>\n<b>🏷 Brand name:</b> %s\n\n<b>📜 Terms:</b>\n<code>%s</code>" % (esc(S("brand")), esc(S("txt_terms")[:500]))
    show(c, mid, t, [[B("🏷 Edit Brand Name", "adm:sv:brand:text", style="primary")], [B("📜 Edit Terms", "adm:sv:txt_terms:html", style="success")],
                     [B("⬅️ Back", "adm", style="primary")]])


TOGGLES = [("bold_btn", "🔠 Bold buttons", "1"), ("notify_new", "🔔 Notify admin of new users", "1"), ("protect_files", "🔒 Protect delivered files", "0"), ("maint", "🛠 Maintenance mode", "0")]


def tog_state(k, d):
    v = S(k)
    return (v if v != "" else d) == "1"


def adm_settings(c, mid):
    t = ("<blockquote><b>⚙️ SETTINGS</b></blockquote>\n<b>├── ⏳ File auto-delete:</b> %s sec (0 = off)\n<b>└── 🖼 Image→Link web app:</b> %s") % (
        esc(S("file_ttl")), esc(S("imglink_url")) or "— (uses Telegram link)")
    kb = [[B("%s %s" % ("🟢" if tog_state(k, d) else "⚪", lab), "adm:tg:" + k, style="success" if tog_state(k, d) else "primary")] for k, lab, d in TOGGLES]
    kb += [[B("⏳ File Auto-delete Time", "adm:sv:file_ttl:num", style="primary")], [B("🖼 Image→Link Web App URL", "adm:sv:imglink_url:text", style="primary")],
           [B("⬅️ Back", "adm", style="primary")]]
    show(c, mid, t, kb)


def adm_btn_list(c, mid):
    bs = []
    for i, k in enumerate(BTN_KEYS):
        cf = bcfg(k)
        bs.append(B(("🚫 " if cf["hide"] else "") + re.sub(r"\s+", " ", cf["text"])[:26], "adm:be:" + k, style=cf["style"] if not cf["hide"] else "danger", eid=None))
    show(c, mid, "<blockquote><b>🎛 BUTTONS &amp; TOOLS</b></blockquote>\n<b>Tap a button to edit its label, colour, premium emoji icon, or hide the tool.</b>\n<i>🚫 = hidden</i>",
         grid(bs, 2) + [[B("⬅️ Back", "adm", style="primary")]])


def adm_btn(c, mid, key):
    if key not in BTN_KEYS:
        return adm_btn_list(c, mid)
    cf = bcfg(key)
    names = {"": "Auto", "success": "🟢 Green", "primary": "🔵 Blue", "danger": "🔴 Red"}
    t = ("<blockquote><b>🎛 EDIT BUTTON</b></blockquote>\n<b>├── Label:</b> %s\n<b>├── Colour:</b> %s\n<b>├── 💎 Premium emoji ID:</b> %s\n<b>└── Visible:</b> %s") % (
        esc(cf["text"]), names.get(cf["style"], cf["style"]), code(cf["eid"]) if cf["eid"] else "—", "No 🚫" if cf["hide"] else "Yes ✅")
    kb = [[B("✏️ Label", "adm:bl2:" + key, style="primary"), B("🎨 Colour", "adm:bc2:" + key, style=cf["style"] or "primary")],
          [B("💎 Premium Emoji", "adm:bm:" + key, style="success"), B("%s" % ("👁 Show" if cf["hide"] else "🙈 Hide"), "adm:bh:" + key, style="primary")],
          [B("♻️ Reset", "adm:br:" + key, style="danger"), B("⬅️ Back", "adm:bl", style="primary")]]
    show(c, mid, t, kb)


def adm_prompt(c, mid, uid, state, text, back="adm", **kw):
    st_set(uid, state, **kw)
    show(c, mid, text, [[B("❌ Cancel", back, style="danger")]])


def bcast_all(c, msg):
    users = [r["id"] for r in q("SELECT id FROM users WHERE banned=0")]
    send(c, "📢 <b>Broadcasting to %d users...</b>" % len(users))

    def run():
        ok = fail = 0
        for u_ in users:
            r = tg("copyMessage", {"chat_id": u_, "from_chat_id": msg["chat"]["id"], "message_id": msg["message_id"]})
            if bad(r):
                fail += 1
            else:
                ok += 1
            time.sleep(0.05)
        send(c, "<blockquote><b>✅ BROADCAST COMPLETED</b></blockquote>\n<b>├── Total:</b> %d\n<b>├── Sent:</b> %d\n<b>└── Failed:</b> %d" % (len(users), ok, fail))
    threading.Thread(target=run, daemon=True).start()


def adm_route(c, mid, uid, a):
    sub = a[1] if len(a) > 1 else ""
    arg = a[2] if len(a) > 2 else ""
    if sub == "":
        return adm_home(c, mid, uid)
    if sub == "stats":
        return adm_stats(c, mid)
    if sub == "users":
        return adm_users(c, mid)
    if sub in ("ban", "unban"):
        return adm_prompt(c, mid, uid, "adm_" + sub, "<blockquote><b>%s</b></blockquote>\n<b>Send the user ID.</b>" % ("🚫 BAN USER" if sub == "ban" else "✅ UNBAN USER"), "adm:users")
    if sub == "bc":
        return adm_prompt(c, mid, uid, "adm_bc", "<blockquote><b>📢 BROADCAST</b></blockquote>\n<b>Send the message to broadcast</b> (text, photo, video, file, anything).\n<i>For coloured buttons use ✍️ Create Post → Broadcast.</i>")
    if sub == "ch":
        return adm_channels(c, mid)
    if sub == "chadd":
        return adm_prompt(c, mid, uid, "adm_ch", "<blockquote><b>📡 ADD CHANNEL</b></blockquote>\n<b>Send the channel:</b> <code>@username</code> / link, or a <code>-100…</code> ID, or forward a message from it.\n<i>Add the bot as admin there first.</i>", "adm:ch")
    if sub == "chdel":
        x("DELETE FROM channels WHERE id=?", (int(arg),))
        return adm_channels(c, mid)
    if sub == "wel":
        return adm_welcome(c, mid)
    if sub == "wtxt":
        return adm_prompt(c, mid, uid, "adm_set", "<blockquote><b>📝 WELCOME TEXT</b></blockquote>\n<b>Send the new text.</b> Formatting and 💎 premium emoji are kept.\nVariables: {name} {id} {brand} {bot}", "adm:wel", key="txt_welcome", kind="html")
    if sub == "wmed":
        return adm_prompt(c, mid, uid, "adm_wmedia", "<blockquote><b>🎬 WELCOME MEDIA</b></blockquote>\n<b>Send a photo / video / GIF.</b>", "adm:wel")
    if sub == "wmx":
        delS("welcome_media_id")
        delS("welcome_media_type")
        return adm_welcome(c, mid)
    if sub == "wrst":
        delS("txt_welcome")
        return adm_welcome(c, mid)
    if sub == "wprev":
        return home(c, None, uid)
    if sub == "txt":
        return adm_texts(c, mid)
    if sub == "set":
        return adm_settings(c, mid)
    if sub == "tg":
        d = [t_ for t_ in TOGGLES if t_[0] == arg]
        if d:
            setS(arg, "0" if tog_state(arg, d[0][2]) else "1")
        return adm_settings(c, mid)
    if sub == "sv" and len(a) > 3:
        labels = {"brand": "Brand name", "txt_terms": "Terms text", "file_ttl": "File auto-delete seconds (0 = never)", "imglink_url": "Image→Link web app URL (send - to clear)"}
        back = "adm:txt" if arg in ("brand", "txt_terms") else "adm:set"
        return adm_prompt(c, mid, uid, "adm_set", "<blockquote><b>✏️ %s</b></blockquote>\n<b>Send the new value.</b>" % esc(labels.get(arg, arg)), back, key=arg, kind=a[3])
    if sub == "bl":
        return adm_btn_list(c, mid)
    if sub == "be":
        return adm_btn(c, mid, arg)
    if sub == "bl2":
        return adm_prompt(c, mid, uid, "adm_blabel", "<blockquote><b>✏️ BUTTON LABEL</b></blockquote>\n<b>Send the new label.</b> (Start with an emoji if you like.)", "adm:be:" + arg, key=arg)
    if sub == "bm":
        return adm_prompt(c, mid, uid, "adm_beid", "<blockquote><b>💎 PREMIUM EMOJI ICON</b></blockquote>\n<b>Send a premium emoji</b> (or its numeric ID).\nSend <code>0</code> to remove the icon.", "adm:be:" + arg, key=arg)
    if sub == "bc2":
        order = ["success", "primary", "danger"]
        cur = bcfg(arg)["style"]
        bsave(arg, style=order[(order.index(cur) + 1) % 3] if cur in order else "success")
        return adm_btn(c, mid, arg)
    if sub == "bh":
        bsave(arg, hide=not bcfg(arg)["hide"])
        return adm_btn(c, mid, arg)
    if sub == "br":
        delS("bt:" + arg)
        return adm_btn(c, mid, arg)
    if sub == "idf":
        return adm_prompt(c, mid, uid, "idf", "<blockquote><b>💎 PREMIUM EMOJI ID FINDER</b></blockquote>\n<b>Send premium emoji(s)</b> — I reply with their IDs.")
    return adm_home(c, mid, uid)


def adm_state(c, uid, s, xx, msg):
    t = (msg.get("text") or "").strip()
    if s in ("adm_ban", "adm_unban"):
        if not t.isdigit():
            send(c, "❌ Send a numeric user ID.")
            st_set(uid, s)
            return True
        x("UPDATE users SET banned=? WHERE id=?", (1 if s == "adm_ban" else 0, int(t)))
        send(c, "✅ <b>User %s %s.</b>" % (t, "banned 🚫" if s == "adm_ban" else "unbanned ✅"), [[B("⬅️ Users", "adm:users", style="primary")]])
        return True
    if s == "adm_bc":
        bcast_all(c, msg)
        return True
    if s == "adm_ch":
        chat, title = resolve_target(msg)
        if chat is None:
            send(c, "❌ Could not read that. Send <code>@username</code>, a <code>-100…</code> ID or forward a message from the channel.")
            st_set(uid, s)
            return True
        info = tg("getChat", {"chat_id": chat})
        if bad(info):
            send(c, "❌ <b>Chat not found:</b> %s\nAdd the bot as admin there and try again." % esc(info["_err"]), [[B("⬅️ Back", "adm:ch", style="primary")]])
            return True
        link = ("https://t.me/" + info["username"]) if info.get("username") else (info.get("invite_link") or "")
        if not link:
            st_set(uid, "adm_chlink", chat=info["id"], title=info.get("title", ""))
            send(c, "🔗 This chat is private. <b>Send its invite link</b> (for the Join button).")
            return True
        x("INSERT INTO channels(chat,link,title) VALUES(?,?,?)", (str(info["id"]) if not info.get("username") else "@" + info["username"], link, info.get("title", "")))
        send(c, "✅ <b>Channel added:</b> %s" % esc(info.get("title", "")), [[B("📡 Channels", "adm:ch", style="primary")]])
        return True
    if s == "adm_chlink":
        if not re.match(r"^https?://t\.me/\S+", t):
            send(c, "❌ Send a valid <code>https://t.me/…</code> invite link.")
            st_set(uid, s, **xx)
            return True
        x("INSERT INTO channels(chat,link,title) VALUES(?,?,?)", (str(xx["chat"]), t, xx["title"]))
        send(c, "✅ <b>Channel added.</b>", [[B("📡 Channels", "adm:ch", style="primary")]])
        return True
    if s == "adm_set":
        key, kind = xx["key"], xx["kind"]
        if kind == "html":
            if not (msg.get("text") or msg.get("caption")):
                send(c, "❌ Send text.")
                st_set(uid, s, **xx)
                return True
            setS(key, msg_html(msg))
        elif kind == "num":
            if not t.isdigit():
                send(c, "❌ Send a number.")
                st_set(uid, s, **xx)
                return True
            setS(key, t)
        else:
            setS(key, "" if t == "-" else t)
        send(c, "✅ <b>Saved.</b>", [[B("⬅️ Back", "adm:wel" if key == "txt_welcome" else ("adm:txt" if key in ("brand", "txt_terms") else "adm:set"), style="primary")]])
        return True
    if s == "adm_wmedia":
        mt, fid = extract_media(msg)
        if not fid:
            send(c, "❌ Send a photo, video or GIF.")
            st_set(uid, s)
            return True
        setS("welcome_media_type", mt)
        setS("welcome_media_id", fid)
        send(c, "✅ <b>Welcome media saved.</b>", [[B("⬅️ Welcome", "adm:wel", style="primary")]])
        return True
    if s == "adm_blabel":
        if not t:
            send(c, "❌ Send text.")
            st_set(uid, s, **xx)
            return True
        bsave(xx["key"], text=t[:40])
        send(c, "✅ <b>Label saved.</b>", [[B("⬅️ Back", "adm:be:" + xx["key"], style="primary")]])
        return True
    if s == "adm_beid":
        eid = ""
        for e in msg.get("entities") or []:
            if e.get("type") == "custom_emoji":
                eid = e["custom_emoji_id"]
                break
        if not eid and re.fullmatch(r"\d{10,25}", t):
            eid = t
        if t == "0":
            bsave(xx["key"], eid="none")
        elif eid:
            bsave(xx["key"], eid=eid)
        else:
            send(c, "❌ Send a premium emoji or its numeric ID (or 0 to remove).")
            st_set(uid, s, **xx)
            return True
        send(c, "✅ <b>Icon saved.</b>", [[B("⬅️ Back", "adm:be:" + xx["key"], style="primary")]])
        return True
    if s == "idf":
        r = emoji_ids(msg)
        send(c, r or "❌ <b>Send a premium emoji.</b>", [[B("⬅️ Back", "adm", style="primary")]])
        st_set(uid, "idf")
        return True
    return False


# ============================================================
# ROUTER / STATE / UPDATES / MAIN
# ============================================================
def route(c, mid, uid, d, fr=None):
    a = d.split(":")
    k = a[0]
    if d == "home":
        return home(c, mid, uid)
    if k == "g" and len(a) > 1:
        return show_group(c, mid, a[1])
    if k == "t" and len(a) > 1:
        return tool_start(c, mid, uid, a[1], fr)
    if d == "terms":
        return show(c, mid, S("txt_terms"), [[B("⬅️ Back", "home", style="primary")]])
    if d == "help":
        return show(c, mid, HELP_TXT, [[B("⬅️ Back", "home", style="primary")]])
    if k == "pg" and len(a) > 1:
        return show_pass(c, mid, 16, False) if a[1] == "s16" else show_pass(c, mid, max(4, min(int(a[1]), 64)))
    if k == "dc" and len(a) > 1:
        e = d.split(":", 1)[1]
        if e in ("🎲", "🎯", "🏀", "⚽", "🎳", "🎰"):
            call("sendDice", {"chat_id": c, "emoji": e, "reply_markup": {"inline_keyboard": [[B(e + " Again", "dc:" + e, style="success"), B("⬅️ Back", "t:dice", style="primary")]]}})
        return
    if k == "qrc" and len(a) > 1:
        last = LASTQR.get(uid)
        if not last:
            return send(c, "❌ QR session expired. Please generate again.", [[B("🏠 Menu", "home", style="primary")]])
        return send_qr(c, uid, last[0], last[1], last[2], a[1])
    if d == "f2l:done":
        return make_file_link(c, uid)
    if k == "wf" and len(a) > 1:
        w = WIFI.pop(uid, None)
        if not w:
            return send(c, "❌ Session expired.", [[B("🔁 Start again", "t:wifiqr", style="success")]])
        sec = a[1]
        text = "WIFI:T:%s;S:%s;P:%s;;" % (sec if sec != "nopass" else "nopass", wifi_esc(w["ssid"]), wifi_esc(w["pw"]) if sec != "nopass" else "")
        return send_qr(c, uid, text, qr_caption("WIFI QR GENERATED", ["📶 " + esc(w["ssid"]), "🔐 " + ("Open" if sec == "nopass" else sec)]), "wifiqr")
    if k == "nt" and len(a) > 1:
        if a[1] == "add":
            st_set(uid, "note_add")
            return show(c, mid, hdr("🗒 NEW NOTE") + "<b>Send the note text.</b>", [[B("❌ Cancel", "t:notes", style="danger")]])
        if a[1] == "del" and len(a) > 2:
            x("DELETE FROM notes WHERE id=? AND uid=?", (int(a[2]), uid))
        return show_notes(c, mid, uid)
    if k == "pb":
        return pb_route(c, mid, uid, a)
    if k == "pbc" and len(a) > 1:
        return pb_color_pick(c, mid, uid, a[1])
    if k == "pbp" and len(a) > 1:
        return pb_place(c, mid, uid, a[1])
    if k == "pbt" and len(a) > 1:
        ch = q1("SELECT * FROM uchannels WHERE id=? AND uid=?", (int(a[1]), uid))
        if ch:
            chat = ch["chat"]
            return pb_deliver(c, uid, int(chat) if re.fullmatch(r"-?\d+", chat) else chat, ch["title"])
        return pb_panel(c, mid, uid)
    if k == "adm":
        if not is_admin(uid):
            return home(c, mid, uid)
        return adm_route(c, mid, uid, a)
    home(c, mid, uid)


def handle_state(c, uid, msg):
    s, xx = st_get(uid)
    if not s:
        return False
    t = (msg.get("text") or "").strip()
    if s.startswith("pb_"):
        return pb_state(c, uid, s, xx, msg)
    if (s.startswith("adm_") or s == "idf") and is_admin(uid):
        return adm_state(c, uid, s, xx, msg)
    if s == "tool":
        key = xx["key"]
        fn_input(key, c, uid, msg)
        st_set(uid, "tool", key=key)
        return True
    if s == "f2l":
        it = file_item(msg)
        if not it:
            send(c, "❌ <b>Please send a file / photo / video / audio / voice / GIF / sticker.</b>", [[B("✔️ Done", "f2l:done", style="success")]])
        else:
            F2L.setdefault(uid, []).append(it)
            send(c, "✅ <b>Added (%d)</b>\nSend another file or tap <b>✔️ Done</b>." % len(F2L[uid]), [[B("✔️ Done", "f2l:done", style="success")]])
        st_set(uid, "f2l")
        return True
    if s == "upi_id":
        if not re.fullmatch(r"[\w.\-]{2,}@[\w.\-]{2,}", t):
            send(c, "❌ <b>Invalid UPI ID.</b> Example: <code>yourname@upi</code>", [[B("⬅️ Back", "g:qr", style="danger")]])
            st_set(uid, "upi_id")
            return True
        st_set(uid, "upi_amt", upi=t)
        send(c, hdr("💰 AMOUNT") + "<b>Enter the amount</b> (example <code>100</code>)\n\nWant the payer to type their own amount? Send <code>skip</code>.", [[B("⬅️ Back", "g:qr", style="danger")]])
        return True
    if s == "upi_amt":
        upi = xx["upi"]
        if t.lower() == "skip":
            amt = ""
        else:
            try:
                v = float(t.replace(",", ""))
                if v <= 0 or v > 1000000:
                    raise ValueError
                amt = ("%.2f" % v).rstrip("0").rstrip(".")
            except ValueError:
                send(c, "❌ <b>Invalid amount.</b> Send a number, or <code>skip</code>.")
                st_set(uid, s, **xx)
                return True
        send_qr(c, uid, upi_uri(upi, amt), qr_caption("UPI QR GENERATED", ["💳 UPI: " + esc(upi), "💰 Amount: " + ("₹" + amt if amt else "Custom (payer enters)")]), "upiqr")
        return True
    if s == "wifi_ssid":
        if not t:
            send(c, "❌ Send the WiFi name.")
            st_set(uid, s)
            return True
        st_set(uid, "wifi_pw", ssid=t[:64])
        send(c, hdr("📶 WIFI QR") + "<b>Send the WiFi password</b> (send <code>-</code> for an open network).")
        return True
    if s == "wifi_pw":
        WIFI[uid] = {"ssid": xx["ssid"], "pw": "" if t == "-" else t[:64]}
        send(c, hdr("📶 WIFI QR") + "<b>Choose the security type 👇</b>",
             [[B("🔐 WPA/WPA2", "wf:WPA", style="success"), B("🔑 WEP", "wf:WEP", style="primary"), B("🔓 Open", "wf:nopass", style="danger")]])
        return True
    if s == "note_add":
        if not t:
            send(c, "❌ Send text.")
            st_set(uid, s)
            return True
        x("INSERT INTO notes(uid,text,created) VALUES(?,?,?)", (uid, t[:1000], now_s()))
        show_notes(c, None, uid)
        return True
    return False


def handle_update(upd):
    try:
        if "callback_query" in upd:
            cq = upd["callback_query"]
            fr = cq["from"]
            uid = fr["id"]
            msg = cq.get("message") or {}
            c = (msg.get("chat") or {}).get("id", uid)
            mid = msg.get("message_id")
            d = cq.get("data", "")
            u = ensure_user(fr)
            param = d.split(":", 1)[1] if d.startswith("joined:") else ""
            if not gate(c, uid, u, param):
                return ack(cq["id"])
            ack(cq["id"])
            if d == "joined" or d.startswith("joined:"):
                delete(c, mid)
                if param.startswith("f_"):
                    return deliver_token(c, uid, param[2:])
                return home(c, None, uid)
            st_clear(uid)
            route(c, mid, uid, d, fr)
        elif "message" in upd:
            msg = upd["message"]
            if (msg.get("chat") or {}).get("type") != "private" or "from" not in msg:
                return
            fr = msg["from"]
            uid = fr["id"]
            c = msg["chat"]["id"]
            text = (msg.get("text") or "").strip()
            u = ensure_user(fr)
            param = ""
            if text.startswith("/start") and " " in text:
                param = text.split(None, 1)[1].strip()[:40]
            if not gate(c, uid, u, param):
                return
            if text.startswith("/start"):
                st_clear(uid)
                if param.startswith("f_"):
                    return deliver_token(c, uid, param[2:])
                return home(c, None, uid)
            if text.startswith("/admin") and is_admin(uid):
                st_clear(uid)
                return adm_home(c, None, uid)
            if text.startswith("/cancel"):
                st_clear(uid)
                return home(c, None, uid)
            if text.startswith("/post"):
                st_clear(uid)
                return pb_panel(c, None, uid)
            if text.startswith(("/term", "/terms")):
                return send(c, S("txt_terms"), [[B("⬅️ Menu", "home", style="primary")]])
            if text.startswith("/help"):
                return send(c, HELP_TXT, [[B("⬅️ Menu", "home", style="primary")]])
            if not handle_state(c, uid, msg):
                home(c, None, uid)
    except Exception as e:      # never let one bad update stop the bot
        import traceback
        log("update error: %s\n%s" % (e, traceback.format_exc()[-900:]))


def safe_handle(group):
    for upd in group:
        uid = None
        try:
            uid = (upd.get("callback_query") or upd.get("message") or {}).get("from", {}).get("id")
        except AttributeError:
            pass
        with user_lock(uid or 0):
            handle_update(upd)


def main():
    global BOT_USER, BOT_ID
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN missing")
    me = tg("getMe")
    if bad(me):
        raise SystemExit("Invalid BOT_TOKEN: %s" % me["_err"])
    BOT_USER = me.get("username", "")
    BOT_ID = me.get("id", 0)
    tg("deleteWebhook", {"drop_pending_updates": True})
    tg("setMyCommands", {"commands": [{"command": "start", "description": "Open the tools menu"}, {"command": "post", "description": "Create a post with coloured buttons"},
                                      {"command": "help", "description": "How to use"}, {"command": "terms", "description": "Terms & conditions"},
                                      {"command": "cancel", "description": "Cancel current tool"}]})
    threading.Thread(target=job_loop, daemon=True).start()
    log("%s started: @%s owner=%s theme=%s" % (S("brand") or "Sandy Tools", BOT_USER, OWNER, os.getenv("THEME", "")))
    pool = ThreadPoolExecutor(max_workers=16)
    offset = 0
    while True:
        try:
            r = SESSION.post(API + "/getUpdates", json={"offset": offset, "timeout": 50, "allowed_updates": ["message", "callback_query"]}, timeout=65)
            j = r.json()
        except (requests.RequestException, ValueError):
            time.sleep(3)
            continue
        if not j.get("ok"):
            log("getUpdates: %s" % str(j)[:200])
            time.sleep(5)
            continue
        groups = {}
        for upd in j.get("result", []):
            offset = max(offset, upd["update_id"] + 1)
            uid = (upd.get("callback_query") or upd.get("message") or {}).get("from", {}).get("id", 0)
            groups.setdefault(uid, []).append(upd)
        for g in groups.values():
            pool.submit(safe_handle, g)


if __name__ == "__main__":
    main()
