SANDY TOOLS BOT (sandytools)  -  HostPanel script
Install / update:
  cd ~/hostpanel && mkdir -p scripts/sandytools && unzip -o ~/sandytools.zip -d scripts/sandytools && bash update.sh
Owner /admin -> Scripts -> sandytools should show "ready". Make an access key for it, pick a theme (default / neon / minimal) and launch a bot.
Then open the bot and send /admin  (everything is set from there):
  Force Channels : add public (@username) or private channels, users must join first.
  Welcome        : text (premium emoji kept) + photo/video/GIF.
  Buttons & Tools: every menu button -> label / colour / premium emoji icon / hide (turns a tool off).
  Settings       : bold buttons, new-user alerts, protected files, maintenance, file auto-delete time, Image->Link web app URL.
  Broadcast      : text/media to all users.   Post Creator also has a broadcast with coloured buttons.
Tools: QR (UPI / URL / text / WiFi, 6 colours), File->Link, Image->Link, Stylish text (30+), case, reverse, counter, sort lines, repeater, lorem,
  password, hash, base64, URL, binary, hex, morse, rot13, uuid, JSON, calculator, age, dates, units, percent, timestamp, colour,
  URL shortener, link expander, IP lookup, website status, weather, currency, crypto, dice, coin, random number/picker, poll,
  my details, get ID / file ID, premium emoji ID, mention maker, link maker, notes, reminders.
Post Creator (/post): text or media + unlimited URL buttons with colours (green / blue / red) and premium emoji icons, preview,
  save posts, send to your channel/group, silent/protected options.
Premium emoji + coloured buttons need Telegram support for the bot; if Telegram refuses, the bot falls back to normal emoji automatically.
Online tools (QR image, shortener, weather, currency ...) need internet access from the server.
