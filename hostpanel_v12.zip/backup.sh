#!/usr/bin/env bash
# Full backup of everything (bots, databases, ALL scripts + themes, keys, orders, settings, tunnel token).
#   bash backup.sh                 -> data/backups/hostpanel-backup-<date>.tar.gz
#   bash backup.sh /path/my.tar.gz -> custom file
# The panel also does this by itself every 24h and sends it to your Telegram (Owner /admin -> Settings -> Backup).
cd "$(dirname "$0")" || exit 1
PY=./venv/bin/python; [ -x "$PY" ] || PY=python3
"$PY" hpbackup.py backup "$@" || exit 1
echo
echo "Copy it somewhere safe, e.g. from your PC:   scp root@THIS_VPS_IP:$(pwd)/data/backups/<file> ."
