#!/usr/bin/env python3
"""
HostPanel full backup / restore (pure standard library, works before the panel is installed).

  python3 hpbackup.py backup  [out.tar.gz]          make a backup of everything
  python3 hpbackup.py restore backup.tar.gz         put a backup into this folder (panel must be stopped)
  python3 hpbackup.py info    backup.tar.gz         show what is inside

A backup contains: panel.env (password, port, brand, tunnel token), data/ (panel database, keys, orders,
settings, branding, secret key), bots/<id>/ (every hosted bot: its database, .env, demo template) and
scripts/ (ALL your scripts + themes + requirements). Libraries (venvs/) are NOT stored: they are
rebuilt automatically from each script's requirements.txt on the new server.
"""
import io
import json
import os
import re
import secrets
import shutil
import sqlite3
import sys
import tarfile
import time
from datetime import datetime
from pathlib import Path

FORMAT = "hostpanel-backup"
VERSION = 12
KEEP_LOCAL = 7
MAX_UNPACKED = 3 * 1024 ** 3          # refuse archives that unpack to more than 3 GB

SKIP_NAMES = {"__pycache__", ".git", "venv", "venvs", "node_modules"}
DATA_SKIP = {"tmp", "backups", "script_logs", "scripts_state.json", "restart_all.flag"}
BOT_SKIP = {"bot.log", "bot.py", "storebot.py", "db_backups", "demo_template.db-journal"}
SERVICE_FILE = Path("/etc/systemd/system/cftunnel.service")


def _now_tag() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def _copy_sqlite(src: Path, dst: Path):
    """Consistent copy of a live SQLite file (safe while the bot/panel is writing)."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    a = sqlite3.connect(f"file:{src}?mode=ro", uri=True, timeout=20)
    b = sqlite3.connect(dst)
    try:
        a.backup(b)
    finally:
        b.close()
        a.close()


def _is_sqlite(p: Path) -> bool:
    try:
        with open(p, "rb") as f:
            return f.read(16) == b"SQLite format 3\x00"
    except OSError:
        return False


def _copy_tree(src: Path, dst: Path, skip_top=(), skip_names=SKIP_NAMES):
    for item in sorted(src.iterdir()):
        if item.name in skip_names or item.name in skip_top or item.is_symlink():
            continue
        if item.name.endswith((".pyc", "-wal", "-shm", "-journal")):
            continue
        target = dst / item.name
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            _copy_tree(item, target)
        elif item.is_file():
            if item.suffix in (".db", ".sqlite", ".sqlite3") and _is_sqlite(item):
                try:
                    _copy_sqlite(item, target)
                    continue
                except sqlite3.Error:
                    pass
            shutil.copy2(item, target)


def _tunnel_token(base: Path) -> str:
    """CF_TUNNEL_TOKEN from panel.env, or (older installs) from the cftunnel systemd unit."""
    try:
        m = re.search(r"^CF_TUNNEL_TOKEN=(\S+)", (base / "panel.env").read_text(), re.M)
        if m:
            return m.group(1).strip("\"'")
    except OSError:
        pass
    try:
        m = re.search(r"--token\s+(\S+)", SERVICE_FILE.read_text())
        if m:
            return m.group(1)
    except OSError:
        pass
    return ""


def create(base: Path, out: Path = None) -> Path:
    base = Path(base).resolve()
    stage_root = base / "data" / "tmp"
    stage_root.mkdir(parents=True, exist_ok=True)
    stage = stage_root / f"bk-{secrets.token_hex(5)}"
    stage.mkdir()
    try:
        # panel.env (+ tunnel token so the same address comes back on the new server)
        env_text = ""
        if (base / "panel.env").exists():
            env_text = (base / "panel.env").read_text()
        tok = _tunnel_token(base)
        if tok and "CF_TUNNEL_TOKEN=" not in env_text:
            env_text = env_text.rstrip("\n") + f"\nCF_TUNNEL_TOKEN={tok}\n"
        if env_text:
            (stage / "panel.env").write_text(env_text)
        if (base / "data").is_dir():
            (stage / "data").mkdir()
            _copy_tree(base / "data", stage / "data", skip_top=DATA_SKIP)
        bots_n = 0
        if (base / "bots").is_dir():
            (stage / "bots").mkdir()
            for d in sorted((base / "bots").iterdir()):
                if d.is_dir() and not d.is_symlink():
                    (stage / "bots" / d.name).mkdir()
                    _copy_tree(d, stage / "bots" / d.name, skip_top=BOT_SKIP)
                    bots_n += 1
        scripts = []
        if (base / "scripts").is_dir():
            (stage / "scripts").mkdir()
            _copy_tree(base / "scripts", stage / "scripts")
            scripts = sorted(p.name for p in (base / "scripts").iterdir() if (p / "bot.py").exists())
        (stage / "MANIFEST.json").write_text(json.dumps({
            "format": FORMAT, "version": VERSION, "created": datetime.now().isoformat(timespec="seconds"),
            "bots": bots_n, "scripts": scripts, "has_tunnel_token": bool(tok)}, indent=1))
        if out is None:
            out = base / "data" / "backups" / f"hostpanel-backup-{_now_tag()}.tar.gz"
        out = Path(out)
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp = out.with_suffix(out.suffix + ".part")
        with tarfile.open(tmp, "w:gz", compresslevel=6) as tf:
            for p in sorted(stage.iterdir()):
                tf.add(p, arcname=p.name)
        os.chmod(tmp, 0o600)
        os.replace(tmp, out)
        _prune(out.parent)
        return out
    finally:
        shutil.rmtree(stage, ignore_errors=True)


def _prune(folder: Path):
    files = sorted(folder.glob("hostpanel-backup-*.tar.gz"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in files[KEEP_LOCAL:]:
        try:
            old.unlink()
        except OSError:
            pass


def _safe_members(tf: tarfile.TarFile):
    total = 0
    out = []
    for m in tf.getmembers():
        name = m.name[2:] if m.name.startswith("./") else m.name
        parts = Path(name).parts
        if not name or name == "." or name.startswith("/") or ".." in parts:
            raise ValueError(f"unsafe path in backup: {m.name}")
        if not (m.isfile() or m.isdir()):
            raise ValueError(f"unsupported entry in backup: {m.name}")
        if parts[0] not in ("panel.env", "data", "bots", "scripts", "MANIFEST.json"):
            continue
        total += max(0, m.size)
        if total > MAX_UNPACKED:
            raise ValueError("backup is unreasonably large")
        m.name = name
        m.mode = 0o600 if m.isfile() else 0o700
        out.append(m)
    return out


def info(archive: Path) -> dict:
    with tarfile.open(archive, "r:gz") as tf:
        f = tf.extractfile("MANIFEST.json")
        man = json.loads(f.read().decode())
    if man.get("format") != FORMAT:
        raise ValueError("this is not a HostPanel backup")
    return man


def restore(base: Path, archive: Path, with_env: bool = True) -> dict:
    """Replace data/, bots/, scripts/ (and panel.env if with_env) with the backup. Stop the panel and bots first."""
    base = Path(base).resolve()
    archive = Path(archive)
    man = info(archive)
    if (base / "data" / "panel.db").exists():          # safety copy of what is here now
        try:
            create(base, base / "data" / "backups" / f"pre-restore-{_now_tag()}.tar.gz")
        except Exception:
            pass
    stage = base / f".restore-{secrets.token_hex(5)}"
    stage.mkdir()
    try:
        with tarfile.open(archive, "r:gz") as tf:
            kw = {"filter": "data"} if hasattr(tarfile, "data_filter") else {}
            tf.extractall(stage, members=_safe_members(tf), **kw)
        # data/: keep local backups, temp and logs of this machine
        old_data = base / "data"
        old_data.mkdir(exist_ok=True)
        for item in list(old_data.iterdir()):
            if item.name in ("backups", "tmp", "script_logs"):
                continue
            shutil.rmtree(item) if item.is_dir() else item.unlink()
        if (stage / "data").is_dir():
            for item in (stage / "data").iterdir():
                shutil.move(str(item), str(old_data / item.name))
        for top in ("bots", "scripts"):
            dst = base / top
            if dst.exists():
                shutil.rmtree(dst)
            if (stage / top).is_dir():
                shutil.move(str(stage / top), str(dst))
            else:
                dst.mkdir()
        if with_env and (stage / "panel.env").exists():
            shutil.copyfile(stage / "panel.env", base / "panel.env")
            os.chmod(base / "panel.env", 0o600)
        # clean up what must not survive a move to another machine
        pdb = base / "data" / "panel.db"
        if pdb.exists():
            con = sqlite3.connect(pdb, timeout=20)
            try:
                con.execute("UPDATE bots SET pid = NULL")
                con.commit()
            except sqlite3.Error:
                pass
            finally:
                con.close()
        for d in (base / "bots").glob("*"):
            if d.is_dir():
                os.chmod(d, 0o700)
        (base / "data" / "tmp").mkdir(parents=True, exist_ok=True)
        return man
    finally:
        shutil.rmtree(stage, ignore_errors=True)


def _main(argv):
    base = Path(__file__).resolve().parent
    if len(argv) >= 2 and argv[1] == "backup":
        out = create(base, Path(argv[2]) if len(argv) > 2 else None)
        man = info(out)
        print(f"Backup ready: {out}  ({out.stat().st_size / 1024:.0f} KB)")
        print(f"  bots: {man['bots']}   scripts: {', '.join(man['scripts']) or '-'}   tunnel token: {'yes' if man['has_tunnel_token'] else 'no'}")
        return 0
    if len(argv) >= 3 and argv[1] == "restore":
        man = restore(base, Path(argv[2]), with_env="--keep-env" not in argv)
        print(f"Restored: {man['bots']} bot(s), scripts: {', '.join(man['scripts']) or '-'}  (backup made {man['created']})")
        return 0
    if len(argv) >= 3 and argv[1] == "info":
        print(json.dumps(info(Path(argv[2])), indent=1))
        return 0
    print(__doc__)
    return 1


if __name__ == "__main__":
    try:
        sys.exit(_main(sys.argv))
    except (ValueError, tarfile.TarError, KeyError, OSError) as ex:
        print("ERROR:", ex)
        sys.exit(2)
