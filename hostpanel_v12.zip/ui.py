# -*- coding: utf-8 -*-
"""All HTML/CSS/JS for the panel (kept apart from app.py so the backend stays readable)."""
import re
import math
from urllib.parse import quote as _q

DEFAULT_TAG = "Enter your details. Your bot goes live in seconds, no server needed."

# id: (name, bg, s1, s2, line, tx, mu, ac, red, glow-rgb)
_T = {
    "lime":   ("Lime Night",   "#07090f", "#0f1320", "#161c2f", "#232b43", "#eef1f8", "#8b93ab", "#c6ff3d", "#ff9aa4", "91,140,255"),
    "neon":   ("Neon Purple",  "#0a0614", "#130a24", "#1c1033", "#34205a", "#f3ecff", "#9b8bb8", "#b86bff", "#ff9ab8", "255,70,190"),
    "cyber":  ("Cyber Blue",   "#040b14", "#08162a", "#0d2140", "#163a63", "#e6f4ff", "#7f9bb8", "#22d3ee", "#ff9aa4", "40,110,255"),
    "gold":   ("Gold Luxury",  "#0b0905", "#17130a", "#221b0e", "#3d3218", "#fff6e0", "#a89878", "#ffc94d", "#ff9a8a", "255,140,40"),
    "rose":   ("Rose Fire",    "#0f0609", "#1c0b12", "#2a1019", "#4a1a2b", "#ffecf1", "#b88a99", "#ff4d7e", "#ffb3c4", "255,120,60"),
    "matrix": ("Matrix Green", "#020a04", "#07140a", "#0b1f0f", "#12381b", "#e4ffe9", "#74a37e", "#39ff7a", "#ff9aa4", "0,200,120"),
    "light":  ("Clean Light",  "#eef2fb", "#ffffff", "#f1f4fb", "#dbe2f2", "#0f172a", "#64708a", "#5b5bff", "#d0283a", "120,120,255"),
    "crimson": ("Crimson Warlord", "#0b0305", "#160709", "#210b0f", "#4a1219", "#ffeef0", "#b78a90", "#ff2a3d", "#ffb0b8", "255,30,60"),
    "silver":  ("Silver Ninja",    "#070a12", "#0d1422", "#142035", "#26364f", "#eaf1ff", "#8ea0bd", "#8ec5ff", "#ff9aa4", "120,170,255"),
    "swirl":   ("Masked Swirl",    "#0b0612", "#150a20", "#1f1030", "#3b2257", "#f5ecff", "#a592bd", "#ff8a1f", "#ffb0b8", "170,60,255"),
    "shadow":  ("Shadow Void",     "#030304", "#0b0b0e", "#131318", "#26262e", "#f2f2f5", "#8c8c99", "#e9e9f2", "#ff6b81", "255,40,70"),
}
THEMES = {k: {"name": v[0], "bg": v[1], "s1": v[2], "s2": v[3], "line": v[4], "tx": v[5], "mu": v[6],
              "ac": v[7], "red": v[8], "glow": v[9]} for k, v in _T.items()}


def _rgb(hexcol: str) -> tuple:
    h = hexcol.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def theme_vars(theme_id: str, accent: str = "") -> dict:
    t = dict(THEMES.get(theme_id) or THEMES["lime"])
    if accent and re.fullmatch(r"#[0-9a-fA-F]{6}", accent):
        t["ac"] = accent
    r, g, b = _rgb(t["ac"])
    t["act"] = "#0b0f0a" if (0.299 * r + 0.587 * g + 0.114 * b) > 150 else "#ffffff"
    t["acrgb"] = f"{r},{g},{b}"
    return t


# ---- anime themes: original abstract motifs, particles, kanji watermark (no character art) ----
_FX = {
    "crimson": {"char": "戦", "motif": "orbit", "pr": "255,70,60", "dir": -1},
    "silver":  {"char": "忍", "motif": "star", "pr": "160,205,255", "dir": 1},
    "swirl":   {"char": "渦", "motif": "spiral", "pr": "255,150,40", "dir": -1},
    "shadow":  {"char": "影", "motif": "hex", "pr": "230,230,240", "dir": 1},
}


def _motif_svg(kind: str, col: str) -> str:
    c = col
    if kind == "orbit":
        orbs = ""
        for a in (90, 210, 330):
            x, y = 100 + 62 * math.cos(math.radians(a)), 100 + 62 * math.sin(math.radians(a))
            orbs += f'<circle cx="{x:.1f}" cy="{y:.1f}" r="9" fill="{c}"/><circle cx="{x:.1f}" cy="{y:.1f}" r="3" fill="#000"/>'
        body = (f'<circle cx="100" cy="100" r="94" fill="none" stroke="{c}" stroke-width="2.4"/>'
                f'<circle cx="100" cy="100" r="62" fill="none" stroke="{c}" stroke-width="1.4" stroke-dasharray="3 5"/>'
                f'<circle cx="100" cy="100" r="22" fill="none" stroke="{c}" stroke-width="2.4"/>' + orbs)
    elif kind == "star":
        body = (f'<circle cx="100" cy="100" r="94" fill="none" stroke="{c}" stroke-width="2"/>'
                f'<path d="M100 8 L116 84 L192 100 L116 116 L100 192 L84 116 L8 100 L84 84 Z" fill="none" stroke="{c}" stroke-width="3"/>'
                f'<circle cx="100" cy="100" r="16" fill="none" stroke="{c}" stroke-width="2.4"/>')
    elif kind == "spiral":
        pts = []
        for arm in (0, math.pi):
            for i in range(0, 260):
                t = i / 12
                r = 2 + t * 5.4
                if r > 94:
                    break
                pts.append((100 + r * math.cos(t + arm), 100 + r * math.sin(t + arm)))
            pts.append(None)
        d, pen = "", False
        for p in pts:
            if p is None:
                pen = False
                continue
            d += ("L" if pen else "M") + f"{p[0]:.1f} {p[1]:.1f} "
            pen = True
        body = f'<path d="{d}" fill="none" stroke="{c}" stroke-width="3" stroke-linecap="round"/><circle cx="100" cy="100" r="96" fill="none" stroke="{c}" stroke-width="1.6"/>'
    else:  # hex
        body = ""
        for r, w in ((94, 2.4), (70, 1.6), (46, 2.4), (24, 1.6)):
            pts = " ".join(f"{100 + r * math.cos(math.radians(60 * i + 30)):.1f},{100 + r * math.sin(math.radians(60 * i + 30)):.1f}" for i in range(6))
            body += f'<polygon points="{pts}" fill="none" stroke="{c}" stroke-width="{w}"/>'
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">{body}</svg>'


def theme_fx(theme_id: str, accent: str = "") -> str:
    fx = _FX.get(theme_id)
    if not fx:
        return ""
    t = theme_vars(theme_id, accent)
    pr, sg = fx["pr"], ("" if fx["dir"] < 0 else "")
    sgn = "-" if fx["dir"] < 0 else ""
    dots = ",".join(f"radial-gradient({r}px {r}px at {x}px {y}px,rgba({pr},{a}),transparent)" for r, x, y, a in (
        (2, 20, 30, .9), (1.5, 110, 150, .7), (2.4, 170, 240, .8), (1.6, 60, 260, .6), (2, 230, 90, .75), (1.4, 40, 330, .6), (2.2, 290, 380, .7)))
    uri = "data:image/svg+xml," + _q(_motif_svg(fx["motif"], t["ac"]))
    return ("@keyframes hpFx{from{background-position:0 0,0 0,0 0}to{background-position:0 %s300px,0 %s360px,0 %s420px}}" % (sgn, sgn, sgn) +
            "@keyframes hpSpin{to{transform:rotate(360deg)}}@keyframes hpGlow{0%,100%{opacity:.2}50%{opacity:.36}}"
            "body::before{content:\"\";position:fixed;inset:0;z-index:-1;pointer-events:none;opacity:.75;background-image:" + dots +
            ";background-size:200px 300px,260px 360px,320px 420px;animation:hpFx 30s linear infinite}"
            "body::after{content:\"" + fx["char"] + "\";position:fixed;right:-1vw;bottom:-6vh;font-size:46vh;line-height:1;font-weight:900;"
            "color:rgba(" + pr + ",.045);pointer-events:none;z-index:-1;font-family:'Noto Serif JP','Yu Mincho','Hiragino Mincho ProN','MS Mincho',serif}"
            ".herox{position:relative;isolation:isolate}"
            ".herox::before{content:\"\";position:absolute;left:50%;top:-8px;width:min(540px,92vw);height:min(540px,92vw);margin-left:calc(min(540px,92vw)/-2);"
            "z-index:-1;background:url(\"" + uri + "\") center/contain no-repeat;animation:hpSpin 50s linear infinite,hpGlow 6s ease-in-out infinite}"
            ".herox h1{font-style:italic;font-weight:900;text-transform:uppercase;letter-spacing:-.6px;text-shadow:0 0 34px rgba(var(--glow),.55)}"
            ".stitle h2{font-style:italic;text-transform:uppercase;letter-spacing:.6px}"
            ".card,.fcard,.stat,.bot,.price,.adm .card,.adm .kpi{border-color:rgba(var(--acrgb),.3);transition:box-shadow .25s,border-color .25s,transform .25s}"
            ".fcard:hover,.price:hover,.bot:hover,.adm .kpi:hover,.stat:hover{border-color:rgba(var(--acrgb),.75);box-shadow:0 0 0 1px rgba(var(--acrgb),.35),0 0 30px -6px rgba(var(--acrgb),.55);transform:translateY(-2px)}"
            ".big,.adm .big{border-radius:4px;clip-path:polygon(0 0,calc(100% - 12px) 0,100% 12px,100% 100%,12px 100%,0 calc(100% - 12px));text-transform:uppercase;letter-spacing:1.4px;font-weight:900}"
            ".nav{border-bottom-color:rgba(var(--acrgb),.5)}.pill{border-color:rgba(var(--acrgb),.55);box-shadow:0 0 18px rgba(var(--acrgb),.3)}"
            ".adm .kpi b{text-shadow:0 0 22px rgba(var(--acrgb),.55)}"
            "@media(prefers-reduced-motion:reduce){body::before,.herox::before{animation:none}}")


def theme_css(theme_id: str, accent: str = "") -> str:
    t = theme_vars(theme_id, accent)
    return (":root{" + ";".join(f"--{k}:{t[k]}" for k in
                                ("bg", "s1", "s2", "line", "tx", "mu", "ac", "act", "red", "glow", "acrgb")) + "}"
            + theme_fx(theme_id, accent))


CSS = r"""
:root{--bg:#07090f;--s1:#0f1320;--s2:#161c2f;--line:#232b43;--tx:#eef1f8;--mu:#8b93ab;--ac:#c6ff3d;--act:#0b1200;--red:#ff9aa4;--glow:91,140,255;--acrgb:198,255,61;--amber:#ffb020}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html{scroll-behavior:smooth;scroll-padding-top:76px}
html,body{margin:0;color:var(--tx);font-family:Inter,"SF Pro Display",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;-webkit-font-smoothing:antialiased}
body{min-height:100vh;padding:0 16px 40px;background:radial-gradient(70% 40% at 92% -6%,rgba(var(--glow),.24),transparent 65%),radial-gradient(55% 34% at -6% 6%,rgba(var(--acrgb),.14),transparent 62%),var(--bg);background-attachment:fixed}
button,input,select,textarea{font:inherit;color:inherit}
@keyframes up{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(var(--acrgb),.55)}70%{box-shadow:0 0 0 8px rgba(var(--acrgb),0)}100%{box-shadow:0 0 0 0 rgba(var(--acrgb),0)}}
@media(prefers-reduced-motion:no-preference){.card,.stat,.bot,.fcard,.price{animation:up .45s ease both}}
.wrap{max-width:980px;margin:0 auto}
.top{display:flex;align-items:center;gap:10px;padding:16px 0;flex-wrap:wrap}
.logo{width:38px;height:38px;border-radius:12px;background:linear-gradient(135deg,var(--ac),rgba(var(--acrgb),.65));color:var(--act);display:grid;place-items:center;font-weight:900;box-shadow:0 6px 18px -6px rgba(var(--acrgb),.7)}
.logo:has(img){background:var(--s2);box-shadow:0 0 0 1px var(--line);overflow:hidden}.logo img{width:100%;height:100%;object-fit:contain;display:block}
.top b{font-size:17px;flex:1;min-width:90px;letter-spacing:-.2px}
a.mini,.mini{border:1px solid var(--line);background:var(--s1);color:var(--mu);border-radius:11px;padding:8px 12px;font-size:12.5px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-block;transition:.15s}
a.mini:hover,.mini:hover{color:var(--tx);border-color:var(--ac)}
.card{background:linear-gradient(180deg,rgba(255,255,255,.05),rgba(255,255,255,.012)),var(--s1);border:1px solid var(--line);border-radius:22px;padding:18px;margin-bottom:14px;box-shadow:0 14px 34px -18px rgba(0,0,0,.65)}
h2{margin:0 0 12px;font-size:15px;letter-spacing:-.1px}
.inp{width:100%;border:1.5px solid var(--line);background:var(--s2);border-radius:14px;padding:13px 14px;font-size:15px;font-weight:600;outline:0;margin-bottom:10px;transition:.15s}
.inp:focus{border-color:var(--ac);box-shadow:0 0 0 4px rgba(var(--acrgb),.14)}
textarea.inp{min-height:84px;resize:vertical}
.big{display:block;width:100%;text-align:center;text-decoration:none;border:0;border-radius:14px;padding:14px;background:linear-gradient(135deg,var(--ac),rgba(var(--acrgb),.8));color:var(--act);font-weight:800;font-size:15px;cursor:pointer;box-shadow:0 10px 24px -10px rgba(var(--acrgb),.75);transition:transform .15s,box-shadow .15s}
.big:hover{transform:translateY(-1px)}.big:active{transform:scale(.98)}
.big.alt{background:var(--s2);color:var(--tx);border:1px solid var(--line);margin-bottom:10px;box-shadow:none}
.big:disabled{opacity:.5;transform:none}
.msg{margin-top:10px;font-size:13px;font-weight:600;min-height:18px;line-height:1.5}
.msg.err{color:var(--red)}.msg.ok{color:var(--ac)}
.meta{color:var(--mu);font-size:12px;margin-bottom:8px;font-weight:600;line-height:1.5}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:14px}
@media(min-width:700px){.grid{grid-template-columns:repeat(4,1fr)}}
.stat{background:var(--s1);border:1px solid var(--line);border-radius:18px;padding:14px}
.stat small{display:block;color:var(--mu);font-size:11px;font-weight:700;letter-spacing:.8px;text-transform:uppercase}
.stat b{display:block;font-size:24px;margin-top:6px;font-variant-numeric:tabular-nums}
.stat.hot b{color:var(--ac)}.stat i{font-style:normal;color:var(--mu);font-size:12px}
.bots{display:grid;gap:12px}
@media(min-width:760px){.bots{grid-template-columns:1fr 1fr}}
.bot{background:var(--s1);border:1px solid var(--line);border-radius:20px;padding:15px}
.bh{display:flex;align-items:center;gap:10px;margin-bottom:12px}
.bh b{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.badge{font-size:11px;font-weight:800;border-radius:999px;padding:4px 10px}
.running{background:rgba(var(--acrgb),.16);color:var(--ac)}.stopped{background:rgba(139,147,171,.2);color:var(--mu)}
.crashed,.expired,.suspended{background:rgba(255,93,108,.16);color:var(--red)}
.mm{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}
.mm div{background:var(--s2);border-radius:12px;padding:9px}
.mm small{display:block;color:var(--mu);font-size:10.5px;font-weight:700}.mm b{font-size:15px}
.bar{height:6px;background:var(--s2);border-radius:9px;overflow:hidden;margin-bottom:12px}
.bar span{display:block;height:100%;background:linear-gradient(90deg,rgba(var(--acrgb),.6),var(--ac))}
.acts{display:flex;flex-wrap:wrap;gap:7px}
.acts button{border:1px solid var(--line);background:var(--s2);border-radius:10px;padding:8px 11px;font-size:12.5px;font-weight:700;cursor:pointer;transition:.15s}
.acts button:hover{border-color:var(--ac)}
.acts .g{color:var(--ac)}.acts .r{color:var(--red)}
.row{display:flex;align-items:center;gap:8px;padding:9px 0;border-top:1px solid var(--line);font-size:13px;font-weight:600}
.row code{flex:1;font-size:13.5px;letter-spacing:.4px;word-break:break-all}.row span{color:var(--mu);font-size:12px}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.row3{display:grid;grid-template-columns:2fr 1fr 1fr;gap:10px}
.pkw{margin:12px 0 4px}.pkw label{display:block;font-size:12px;font-weight:800;color:var(--mu);margin:10px 0 7px;letter-spacing:.3px}
.pkc{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:9px}
.pkc button{text-align:left;border:1px solid var(--line);background:var(--s2);border-radius:14px;padding:11px 12px;cursor:pointer;color:var(--tx);transition:.15s}
.pkc button b{display:block;font-size:13.5px}.pkc button small{display:block;color:var(--mu);font-size:11.5px;margin-top:3px;line-height:1.35;font-weight:600}
.pkc button.on{border-color:var(--ac);box-shadow:0 0 0 1px var(--ac) inset;background:rgba(var(--acrgb),.1)}
.pkt{display:flex;gap:7px;flex-wrap:wrap}
.pkt button{border:1px solid var(--line);background:var(--s2);color:var(--tx);border-radius:999px;padding:8px 13px;font-size:12.5px;font-weight:800;cursor:pointer;transition:.15s}
.pkt button.on{border-color:var(--ac);color:var(--ac);background:rgba(var(--acrgb),.12)}
pre{background:rgba(0,0,0,.28);border:1px solid var(--line);border-radius:12px;padding:12px;font-size:11.5px;line-height:1.5;max-height:55vh;overflow:auto;white-space:pre-wrap;word-break:break-all}
.modal{position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);display:none;align-items:flex-start;justify-content:center;padding:16px;z-index:30;overflow:auto}
.modal.on{display:flex}.modal .card{width:100%;max-width:640px;margin:20px 0}
.toast{position:fixed;left:50%;bottom:90px;transform:translate(-50%,20px);background:#fff;color:#0b1200;padding:10px 16px;border-radius:12px;font-size:13px;font-weight:700;opacity:0;pointer-events:none;transition:.25s;z-index:40;max-width:90vw;box-shadow:0 10px 30px rgba(0,0,0,.4)}
.toast.on{opacity:1;transform:translate(-50%,0)}
.hero{text-align:center;padding:22px 0 16px}.hero h1{margin:0 0 8px;font-size:28px;letter-spacing:-.5px}.hero p{margin:0;color:var(--mu);font-size:14px;line-height:1.55}
.plans{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:6px}
.plan{position:relative;background:var(--s2);border:1.5px solid var(--line);border-radius:18px;padding:16px 12px;text-align:center;cursor:pointer;transition:.18s}
.plan:hover,.plan.on{border-color:var(--ac);transform:translateY(-2px);box-shadow:0 14px 30px -16px rgba(var(--acrgb),.6)}
.plan b{display:block;font-size:15px}.plan .pr{font-size:26px;font-weight:900;color:var(--ac);margin:6px 0}.plan small{color:var(--mu);font-weight:600;display:block}
.plan .pop{position:absolute;top:-10px;left:50%;transform:translateX(-50%);background:var(--ac);color:var(--act);font-size:10.5px;font-weight:900;border-radius:999px;padding:3px 10px;white-space:nowrap;letter-spacing:.3px}
.plan .go{margin-top:10px;font-size:12.5px;font-weight:800;color:var(--act);background:var(--ac);border-radius:10px;padding:7px}
.steps{color:var(--mu);font-size:12.5px;line-height:1.7;margin:4px 2px 14px}.steps b{color:var(--tx)}
.keyshow{font-size:22px;font-weight:900;letter-spacing:1px;text-align:center;padding:16px;background:var(--s2);border:1.5px dashed var(--ac);border-radius:14px;margin:10px 0;word-break:break-all;color:var(--ac)}
.sw{display:grid;grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:9px;margin-bottom:12px}
.sw button{border:2px solid var(--line);background:var(--s2);border-radius:14px;padding:10px;cursor:pointer;font-size:12px;font-weight:700}
.sw button.on{border-color:var(--ac)}.sw i{display:flex;height:22px;border-radius:7px;overflow:hidden;margin-bottom:7px}.sw i s{flex:1}
label.chk{display:flex;gap:10px;align-items:center;font-size:13.5px;font-weight:600;margin:6px 0 12px}
label.chk input{width:18px;height:18px;accent-color:var(--ac)}
.sec{margin:16px 0 8px;font-size:12px;letter-spacing:.8px;text-transform:uppercase;color:var(--mu);font-weight:800}
.warn{background:rgba(255,176,32,.12);border:1px solid rgba(255,176,32,.4);color:var(--amber);border-radius:14px;padding:11px 13px;font-size:13px;font-weight:600;margin-bottom:14px;line-height:1.5}
.tabs{display:flex;gap:8px;margin-bottom:14px}.tabs a{flex:1;text-align:center}
/* ---- payment box ---- */
.stepper{display:flex;align-items:center;gap:8px;margin-bottom:14px;font-size:12px;font-weight:800;color:var(--mu)}
.stepper i{flex:1;height:2px;background:var(--line);border-radius:2px}
.stepper .st{display:flex;align-items:center;gap:6px}
.stepper .st:before{content:attr(data-n);width:22px;height:22px;border-radius:50%;display:grid;place-items:center;background:var(--s2);border:1px solid var(--line);font-size:11px}
.stepper .st.on{color:var(--tx)}.stepper .st.on:before{background:var(--ac);color:var(--act);border-color:var(--ac)}
.payhero{display:flex;gap:16px;align-items:center;margin-bottom:14px;flex-wrap:wrap;justify-content:center}
.qrwrap{background:#fff;border-radius:20px;padding:10px;box-shadow:0 0 0 1px var(--line),0 18px 40px -16px rgba(var(--acrgb),.5)}
.qr{display:block;width:176px;height:176px;border-radius:10px}
.payinfo{flex:1;min-width:170px}
.amt{font-size:34px;font-weight:900;color:var(--ac);margin-bottom:8px;letter-spacing:-.5px}
.upi{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.upi code{font-size:14px;word-break:break-all}
.apps{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px}
.apps a{display:block;text-align:center;text-decoration:none;background:var(--s2);border:1px solid var(--line);border-radius:12px;padding:11px 4px;font-size:12.5px;font-weight:800;color:var(--tx);transition:.15s}
.apps a:hover{border-color:var(--ac)}
.okc{width:74px;height:74px;margin:6px auto 12px}
.okc svg{width:100%;height:100%}
.okc-c{fill:rgba(var(--acrgb),.12);stroke:var(--ac);stroke-width:2;stroke-dasharray:152;stroke-dashoffset:152;animation:dr .6s ease forwards}
.okc-p{fill:none;stroke:var(--ac);stroke-width:3.5;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:40;stroke-dashoffset:40;animation:dr .4s .5s ease forwards}
@keyframes dr{to{stroke-dashoffset:0}}
/* ---- landing ---- */
.nav{position:sticky;top:0;z-index:20;margin:0 -16px;padding:0 16px;background:var(--bg);background:color-mix(in srgb,var(--bg) 70%,transparent);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border-bottom:1px solid var(--line)}
.navin{max-width:980px;margin:0 auto;display:flex;align-items:center;gap:12px;padding:11px 0}
.navin b{font-size:16px;letter-spacing:-.2px}.navin .sp{flex:1}
.navl{color:var(--mu);text-decoration:none;font-size:13px;font-weight:700}.navl:hover{color:var(--tx)}
@media(max-width:520px){.navl{display:none}}
.herox{text-align:center;padding:44px 0 26px}
.pill{display:inline-block;border:1px solid var(--line);background:rgba(var(--acrgb),.08);color:var(--ac);border-radius:999px;padding:6px 14px;font-size:12px;font-weight:800;margin-bottom:18px}
.herox h1{margin:0 auto 14px;max-width:760px;font-size:clamp(30px,6.4vw,54px);line-height:1.08;letter-spacing:-1.4px}
.grad{background:linear-gradient(120deg,var(--ac),rgb(var(--glow)));-webkit-background-clip:text;background-clip:text;color:transparent}
.herox p{margin:0 auto 22px;max-width:560px;color:var(--mu);font-size:16px;line-height:1.6}
.cta{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;max-width:440px;margin:0 auto}
.cta .big{flex:1;min-width:150px;margin:0;display:flex;align-items:center;justify-content:center}
.trust{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:22px}
.trust span{font-size:12px;font-weight:700;color:var(--mu);border:1px solid var(--line);background:var(--s1);border-radius:999px;padding:6px 12px}
.trust span:before{content:"✓ ";color:var(--ac)}
.stitle{text-align:center;margin:44px 0 18px}.stitle h2{font-size:24px;letter-spacing:-.5px;margin:0 0 6px}.stitle p{margin:0;color:var(--mu);font-size:14px}
.feat{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:12px}
.fcard{background:var(--s1);border:1px solid var(--line);border-radius:20px;padding:18px}
.fcard .ic{width:42px;height:42px;border-radius:13px;display:grid;place-items:center;background:rgba(var(--acrgb),.12);color:var(--ac);margin-bottom:12px}
.fcard .ic svg{width:22px;height:22px;stroke:currentColor;fill:none;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
.fcard b{display:block;font-size:15px;margin-bottom:5px}.fcard span{color:var(--mu);font-size:13px;line-height:1.55}
.how{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
.hstep{display:flex;gap:14px;align-items:flex-start;background:var(--s1);border:1px solid var(--line);border-radius:20px;padding:16px}
.hstep i{font-style:normal;flex:none;width:34px;height:34px;border-radius:50%;background:var(--ac);color:var(--act);display:grid;place-items:center;font-weight:900}
.hstep b{display:block;margin-bottom:3px}.hstep span{color:var(--mu);font-size:13px;line-height:1.5}
.narrow{max-width:540px;margin:0 auto}
.price .plans{margin-top:14px}
.faq details{background:var(--s1);border:1px solid var(--line);border-radius:16px;padding:14px 16px;margin-bottom:10px}
.faq summary{cursor:pointer;font-weight:800;font-size:14px;list-style:none;display:flex;justify-content:space-between;gap:10px}
.faq summary::-webkit-details-marker{display:none}.faq summary:after{content:"+";color:var(--ac);font-size:18px;line-height:1}
.faq details[open] summary:after{content:"–"}
.faq p{margin:10px 0 0;color:var(--mu);font-size:13px;line-height:1.6}
.foot{text-align:center;margin:36px 0 6px;color:var(--mu);font-size:12.5px}
/* ---- customer dashboard ---- */
.ringbox{display:flex;gap:14px;align-items:center;margin-bottom:14px}
.ring{width:86px;height:86px;flex:none}
.ring circle{fill:none;stroke-width:7}.rg-bg{stroke:var(--s2)}.rg-fg{stroke:var(--ac);stroke-linecap:round;transition:stroke-dasharray .6s}
.ring.low .rg-fg{stroke:var(--amber)}.ring.bad .rg-fg{stroke:#ff5d6c}
.ring text{fill:var(--tx);font-size:19px;font-weight:900}.ring tspan{fill:var(--mu);font-size:8px;font-weight:700}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;background:var(--mu);margin-right:7px}
.dot.running{background:var(--ac);animation:pulse 1.8s infinite}.dot.crashed,.dot.expired,.dot.suspended{background:#ff5d6c}
.tabbar{position:fixed;left:0;right:0;bottom:0;z-index:25;display:flex;justify-content:space-around;gap:2px;padding:8px 10px calc(8px + env(safe-area-inset-bottom));background:var(--s1);background:color-mix(in srgb,var(--bg) 80%,transparent);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border-top:1px solid var(--line)}
.tb{flex:1;max-width:120px;display:flex;flex-direction:column;align-items:center;gap:3px;font-size:11px;font-weight:700;color:var(--mu);background:none;border:0;padding:6px 4px;cursor:pointer;border-radius:12px;transition:.15s}
.tb svg{width:22px;height:22px;stroke:currentColor;fill:none;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
.tb.on{color:var(--ac);background:rgba(var(--acrgb),.1)}
"""

HEAD = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><link rel="icon" href="__FAVICON__"><title>__TITLE__</title><style>""" + CSS + r"""__THEME__</style></head>"""

JS_COMMON = r"""
const $=i=>document.getElementById(i);
const esc=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const inr=n=>"₹"+Number(n||0).toLocaleString("en-IN",{maximumFractionDigits:2});
let _tt;function toast(s){const e=$("toast");e.textContent=s;e.classList.add("on");clearTimeout(_tt);_tt=setTimeout(()=>e.classList.remove("on"),2800)}
function copy(t){try{navigator.clipboard.writeText(t);toast("Copied")}catch(e){toast("Copy failed")}}
async function J(url,body,csrf){const h={"Content-Type":"application/json"};if(csrf)h["X-CSRF"]=csrf;
 try{const r=await fetch(url,{method:body===undefined?"GET":"POST",headers:h,body:body===undefined?undefined:JSON.stringify(body)});
 if(r.status===401&&csrf!==undefined){location.href=csrf_login;return {ok:false,message:"Login again."}}
 return await r.json()}catch(e){return {ok:false,message:"No connection. Try again."}}}
var csrf_login="/login";
async function UP(url,fd,csrf){let r;try{r=await fetch(url,{method:"POST",headers:{"X-CSRF":csrf},body:fd})}catch(e){return{ok:false,message:"Your phone could not send the file. Pick the file again from Downloads/Files (not from Drive or Recent) and retry."}}
 if(r.status===401){location.href=csrf_login;return{ok:false,message:"Login again."}}
 try{return await r.json()}catch(e){return{ok:false,message:"Server answered "+r.status+(r.status===413?" (file too big for the tunnel/proxy)":r.status>=500?" (server error, see panel.log)":"")+". Try again."}}}

function pkMount(id,scripts){const box=$(id);box._pk={scripts:scripts||[],s:"",t:""};
 if(!box._pk.scripts.length){box.innerHTML='<div class="help">No script is available right now.</div>';return}
 if(box._pk.scripts.length===1)box._pk.s=box._pk.scripts[0].id;pkDraw(box)}
function pkDraw(box){const st=box._pk,cur=st.scripts.find(x=>x.id===st.s);let h="";
 if(st.scripts.length>1)h+='<label>Choose script</label><div class="pkc">'+st.scripts.map(x=>'<button type="button" data-pks="'+esc(x.id)+'" class="'+(x.id===st.s?"on":"")+'"><b>'+esc(x.name)+'</b><small>'+esc(x.description||"")+'</small></button>').join("")+'</div>';
 else if(cur)h+='<label>Script</label><div class="pkc"><button type="button" class="on"><b>'+esc(cur.name)+'</b><small>'+esc(cur.description||"")+'</small></button></div>';
 if(cur){if(!cur.themes.some(t=>t.id===st.t))st.t=cur.default_theme||(cur.themes[0]||{}).id||"";
  if(cur.themes.length>1)h+='<label>Choose theme</label><div class="pkt">'+cur.themes.map(t=>'<button type="button" data-pkt="'+esc(t.id)+'" class="'+(t.id===st.t?"on":"")+'" title="'+esc(t.description||"")+'">'+esc(t.emoji)+" "+esc(t.name)+'</button>').join("")+'</div>'}
 box.innerHTML=h;
 box.onclick=e=>{const a=e.target.closest("[data-pks]");if(a){st.s=a.dataset.pks;st.t="";pkDraw(box);return}const b=e.target.closest("[data-pkt]");if(b){st.t=b.dataset.pkt;pkDraw(box)}}}
function pkGet(id){const e=$(id),st=(e&&e._pk)||{};return {script:st.s||"",theme:st.t||""}}
"""

# ───────────────────────── shared payment box (landing + user renew) ─────────────────────────
PAYBOX = r"""
<div class="card" id="paybox" style="display:none">
<div class="stepper"><span class="st on" data-n="1" id="stp1">Pay</span><i></i><span class="st" data-n="2" id="stp2">Verify</span><i></i><span class="st" data-n="3" id="stp3">Done</span></div>
<h2 id="pb_title" style="text-align:center">Pay and get your key</h2>
<div class="payhero"><div class="qrwrap" id="pb_qrw" style="display:none"><img id="pb_qr" class="qr" alt="UPI QR"></div><div class="payinfo">
<div class="meta">Amount to pay</div><div class="amt" id="pb_amt"></div>
<div class="meta">UPI ID</div><div class="upi"><code id="pb_upi"></code><button class="mini" id="pb_copy" type="button">Copy UPI ID</button></div></div></div>
<div class="apps" id="pb_apps" style="display:none"><a id="pb_gpay" href="#">GPay</a><a id="pb_phonepe" href="#">PhonePe</a><a id="pb_paytm" href="#">Paytm</a></div>
<a class="big alt" id="pb_app" href="#">Pay with any UPI app</a>
<div class="steps">Pay the <b>exact amount</b>, then paste the <b>UTR / transaction ID</b> from your payment app below.</div>
<input class="inp" id="pb_utr" placeholder="UTR / Transaction ID" autocomplete="off" autocapitalize="characters">
<button class="big" id="pb_go" type="button">Verify payment</button><div class="msg" id="pb_msg"></div></div>
<div class="card" id="keybox" style="display:none;text-align:center"><div class="okc"><svg viewBox="0 0 52 52"><circle class="okc-c" cx="26" cy="26" r="24"/><path class="okc-p" d="M14 27l8 8 16-17"/></svg></div><h2 id="kb_title">Payment received</h2>
<div id="kb_body"></div></div>
"""

PAYJS = r"""
var ORDER=null,PAYMODE_RENEW=false;
function lsGet(k){try{return localStorage.getItem(k)}catch(e){return null}}
function lsSet(k,v){try{v===null?localStorage.removeItem(k):localStorage.setItem(k,v)}catch(e){}}
function setStep(n){for(let i=1;i<=3;i++){const e=$("stp"+i);if(e)e.classList.toggle("on",i<=n)}}
function showOrder(o,renew){
 ORDER=o;$("keybox").style.display="none";
 if(o.status==="paid"){showPaid(o,renew);return}
 setStep(1);
 $("paybox").style.display="block";$("pb_amt").textContent=inr(o.amount);$("pb_upi").textContent=o.upi_id;
 $("pb_title").textContent="Pay for "+o.plan+" ("+(o.days>=36500?"Lifetime":o.days+" days")+")";
 $("pb_app").href=o.upi_link;
 const q=(o.upi_link.split("?")[1]||""),ua=navigator.userAgent,and=/Android/i.test(ua),ios=/iPhone|iPad|iPod/i.test(ua);
 $("pb_apps").style.display=(and||ios)?"grid":"none";
 const AP={gpay:["tez://upi/pay?","com.google.android.apps.nbu.paisa.user"],phonepe:["phonepe://pay?","com.phonepe.app"],paytm:["paytmmp://pay?","net.one97.paytm"]};
 for(const k in AP)$("pb_"+k).href=and?("intent://pay?"+q+"#Intent;scheme=upi;package="+AP[k][1]+";end"):(AP[k][0]+q);
 if(o.qr){$("pb_qr").src=o.qr;$("pb_qrw").style.display="block"}else $("pb_qrw").style.display="none";
 $("pb_msg").textContent="";$("pb_utr").value="";
 if(PAYMODE_RENEW&&window.tab)tab("plan");
 $("paybox").scrollIntoView({behavior:"smooth",block:"start"});
}
function showPaid(o,renew){
 $("paybox").style.display="none";$("keybox").style.display="block";
 if(o.renew){$("kb_title").textContent="Plan extended";$("kb_body").innerHTML='<p class="meta">Your plan was extended by '+o.days+' days. Thank you!</p>';lsSet("bh_order",null);if(o.invoice)$("kb_body").innerHTML+='<a class="big alt" target="_blank" rel="noopener" href="'+esc(o.invoice)+'">Download receipt</a>';if(window.onRenewed)onRenewed();return}
 $("kb_title").textContent="Payment received. Here is your access key";
 $("kb_body").innerHTML='<div class="keyshow">'+esc(o.key)+'</div><button class="big alt" type="button" onclick="copy(\''+esc(o.key)+'\')">Copy key</button>'+
 '<a class="big" href="#launch" onclick="useKey(\''+esc(o.key)+'\')">Launch my bot now</a><div class="meta" style="margin-top:10px">Save this key. You can use it to login later at /login.</div>'+(o.invoice?'<a class="big alt" target="_blank" rel="noopener" href="'+esc(o.invoice)+'">Download receipt</a>':'');
 $("keybox").scrollIntoView({behavior:"smooth",block:"start"});
}
async function startOrder(pid,renew){
 const j=await J("/api/order/create",{plan_id:pid,renew:!!renew});
 if(!j.ok){toast(j.message||"Could not create order");return}
 lsSet("bh_order",j.order.id);showOrder(j.order,renew);
}
$("pb_copy").onclick=()=>copy($("pb_upi").textContent);
$("pb_go").onclick=async()=>{
 if(!ORDER)return;const m=$("pb_msg");const u=$("pb_utr").value.trim();
 if(u.length<10){m.className="msg err";m.textContent="Enter the full UTR / transaction ID.";return}
 $("pb_go").disabled=true;$("pb_go").textContent="Verifying… (up to a minute)";m.className="msg";m.textContent="";setStep(2);
 const j=await J("/api/order/"+ORDER.id+"/verify",{utr:u});
 $("pb_go").disabled=false;$("pb_go").textContent="Verify payment";
 if(j.ok){setStep(3);showPaid(j.order)}else{setStep(1);m.className="msg err";m.textContent=j.message||"Payment not verified."}
};
async function resumeOrder(){
 const id=lsGet("bh_order");if(!id)return;
 const j=await J("/api/order/"+id);if(j.ok&&j.order&&(!j.order.renew||PAYMODE_RENEW))showOrder(j.order);else if(!j.ok)lsSet("bh_order",null);
}
"""

# ───────────────────────── landing ─────────────────────────
_IC = {
 "pay": '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18M7 15h4"/></svg>',
 "up": '<svg viewBox="0 0 24 24"><path d="M12 3v9m0 0l-3-3m3 3l3-3"/><path d="M5 14a7 7 0 0014 0"/><path d="M12 21v-4"/></svg>',
 "wallet": '<svg viewBox="0 0 24 24"><path d="M4 7a2 2 0 012-2h11v4"/><rect x="3" y="7" width="18" height="12" rx="3"/><circle cx="16.5" cy="13" r="1.2"/></svg>',
 "mega": '<svg viewBox="0 0 24 24"><path d="M4 10v4h3l7 4V6L7 10H4z"/><path d="M18 9a4 4 0 010 6"/></svg>',
 "db": '<svg viewBox="0 0 24 24"><ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/></svg>',
 "lock": '<svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="9" rx="2.5"/><path d="M8 11V8a4 4 0 018 0v3"/></svg>',
}
_FEATS = [
 ("pay", "Auto UPI payments", "Buyers pay by UPI and every payment is verified automatically with its UTR."),
 ("up", "Always online", "Your bot is watched around the clock and restarts itself if it ever crashes."),
 ("wallet", "Wallet and coupons", "Built-in wallet balance, coupon codes and discounts for your buyers."),
 ("mega", "Broadcast and control", "Message all your users and manage products, bans and orders inside Telegram."),
 ("db", "Your data stays yours", "Download your database any time, or upload one to restore or copy your store."),
 ("lock", "Private and separate", "Every bot runs in its own folder with its own database and token."),
]
_FEAT_HTML = "".join(f'<div class="fcard"><div class="ic">{_IC[i]}</div><b>{t}</b><span>{d}</span></div>' for i, t, d in _FEATS)

LANDING = HEAD + r"""<body>
<div class="nav"><div class="navin"><div class="logo">__LOGO__</div><b>__BRAND__</b><span class="sp"></span><a class="navl" href="#features">Features</a><a class="navl" href="#buy">Pricing</a><a class="navl" href="#faq">FAQ</a><a class="mini" href="/login">Login</a></div></div>
<div class="wrap">
<section class="herox"><span class="pill">Instant setup · No server needed</span>
<h1>Launch your own <span class="grad">Telegram store bot</span> in minutes</h1>
<p>__TAG__</p>
<div class="cta"><a class="big" href="#buy">View plans</a><a class="big alt" href="#launch">I already have a key</a></div>
<div class="trust" id="trust"><span>Auto UPI verification</span><span>24x7 uptime</span><span>Database backup and restore</span></div></section>

<section id="features"><div class="stitle"><h2>Everything your store needs</h2><p>One dashboard, one bot, zero server work.</p></div>
<div class="feat">""" + _FEAT_HTML + r"""</div></section>

<section><div class="stitle"><h2>How it works</h2><p>Three simple steps.</p></div>
<div class="how"><div class="hstep"><i>1</i><div><b>Choose a plan and pay</b><span>Pay with any UPI app. It is verified in seconds.</span></div></div>
<div class="hstep"><i>2</i><div><b>Get your access key</b><span>Your key is also your dashboard login.</span></div></div>
<div class="hstep"><i>3</i><div><b>Paste your bot token</b><span>Your bot goes live right away.</span></div></div></div></section>

<section class="narrow" id="buy"><div class="stitle"><h2>Pricing</h2><p>Pick a plan to get your access key.</p></div>
<div class="card price" id="plans_card"><h2>1. Buy an access key</h2>
<div class="plans" id="plans"><div class="meta">Loading plans…</div></div>
<div class="meta" id="plans_note"></div></div>
""" + PAYBOX + r"""
<div class="card" id="form"><h2 id="launch">2. Launch your bot</h2>
<div class="steps"><b>•</b> Create a bot in @BotFather and copy its token<br><b>•</b> Get your numeric ID from @userinfobot<br><b>•</b> Paste everything below</div>
<input class="inp" id="key" placeholder="Access key  (XXXX-XXXX-XXXX-XXXX)" autocomplete="off" autocapitalize="characters">
<input class="inp" id="token" placeholder="Bot token" autocomplete="off" spellcheck="false">
<input class="inp" id="admin" placeholder="Admin Telegram ID" inputmode="numeric" autocomplete="off">
<div class="pkw" id="pk" style="display:none"></div>
<button class="big" id="go" type="button">Launch my bot</button><div class="msg" id="msg"></div></div>

<div class="card" id="done" style="display:none;text-align:center"><div class="okc"><svg viewBox="0 0 52 52"><circle class="okc-c" cx="26" cy="26" r="24"/><path class="okc-p" d="M14 27l8 8 16-17"/></svg></div><h2 style="font-size:22px;color:var(--ac)">Your bot is live</h2>
<p id="dt" class="meta" style="font-size:14px"></p>
<a class="big" id="open" href="#">Open my bot</a><a class="big alt" style="margin-top:10px" href="/login">Go to my dashboard</a></div></section>

<section class="narrow faq" id="faq"><div class="stitle"><h2>Questions</h2></div>
<details><summary>What do I need to start?</summary><p>A bot token from @BotFather and your numeric Telegram ID from @userinfobot. That is all.</p></details>
<details><summary>How do I pay?</summary><p>Choose a plan, pay the exact amount by UPI, then paste the UTR from your payment app. Your key appears as soon as it is verified.</p></details>
<details><summary>What happens when my plan ends?</summary><p>Your bot stops and your data stays saved. Renew from your dashboard and the bot starts again.</p></details>
<details><summary>Can I move my existing store data?</summary><p>Yes. Open your dashboard, go to Database and upload your store database file. You can also download it any time.</p></details>
</section>
<div class="foot"><div id="support"></div><div style="margin-top:6px">© __BRAND__</div></div>
</div><div class="toast" id="toast"></div>
<script>""" + JS_COMMON + PAYJS + r"""
let _kc="";
async function keyCheck(){const k=$("key").value.replace(/\s+/g,"").toUpperCase();
 if(!(k.length===19||(k.length===16&&k.indexOf("-")<0))){$("pk").style.display="none";_kc="";return}
 if(k===_kc)return;_kc=k;const j=await J("/api/key/info",{key:k}),m=$("msg");
 if(j.ok){m.textContent="";m.className="msg";pkMount("pk",j.scripts);$("pk").style.display="block"}
 else{$("pk").style.display="none";m.className="msg err";m.textContent=j.message||""}}
$("key").addEventListener("input",()=>{clearTimeout(window._kt);window._kt=setTimeout(keyCheck,450)});
function useKey(k){$("key").value=k;keyCheck();$("token").focus()}
async function init(){
 const d=await J("/api/public");
 if(d.support){$("support").innerHTML='Need help? <a style="color:var(--ac)" href="'+esc(d.support)+'" target="_blank" rel="noopener">Contact support</a>'}
 if(d.bots>=10)$("trust").insertAdjacentHTML("afterbegin","<span>"+d.bots+"+ bots hosted</span>");
 if(!d.pay_ready||!d.plans.length){$("plans").innerHTML="";$("plans_note").textContent=d.plans.length?"Online payment is not set up yet. Ask the owner for an access key.":"Plans are not available right now. Ask the owner for an access key."}
 else{
  let best=-1;const per=d.plans.map(p=>p.days<36500?p.price/p.days:Infinity);
  if(d.plans.length>=2){const m=Math.min(...per);if(m!==Infinity)best=per.indexOf(m)}
  $("plans").innerHTML=d.plans.map((p,i)=>'<div class="plan" data-p="'+p.id+'">'+(i===best?'<span class="pop">BEST VALUE</span>':'')+'<b>'+esc(p.name)+'</b><div class="pr">'+inr(p.price)+'</div><small>'+(p.days>=36500?'Lifetime':p.days+' days')+'</small>'+(p.days<36500?'<small>about '+inr(p.price/p.days)+' / day</small>':'')+'<div class="go">Buy now</div></div>').join("")}
 resumeOrder();
}
document.addEventListener("click",e=>{const p=e.target.closest("[data-p]");if(p)startOrder(parseInt(p.dataset.p,10),false)});
$("go").onclick=async()=>{const m=$("msg");m.className="msg";m.textContent="";$("go").disabled=true;$("go").textContent="Launching…";
 const j=await J("/api/deploy",Object.assign({key:$("key").value,token:$("token").value.trim(),admin:$("admin").value},pkGet("pk")));
 if(j.ok){$("form").style.display="none";$("paybox").style.display="none";$("keybox").style.display="none";$("plans_card").style.display="none";$("done").style.display="block";
  $("open").href="https://t.me/"+j.username;$("open").textContent="Open @"+j.username;lsSet("bh_order",null);
  $("dt").textContent="Send /start to your bot, then open Admin Panel inside it to add products and payment settings. Plan: "+(j.days>=36500?"Lifetime":j.days+" days")+". Your key is your dashboard login."}
 else{m.className="msg err";m.textContent=j.message||"Something went wrong."}
 $("go").disabled=false;$("go").textContent="Launch my bot"};
init();
</script></body></html>"""

# ───────────────────────── owner console (premium admin UI) ─────────────────────────
ADM_CSS = r"""
body.adm{padding:0;--ok:#34d399;--okrgb:52,211,153;--warn:#fbbf24;--bad:#f87171;--badrgb:248,113,113;--glass:color-mix(in srgb,var(--s1) 82%,transparent);--hair:color-mix(in srgb,var(--line) 70%,transparent);--r:18px}
.adm svg.i{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;flex:none}
.adm svg.i.s{width:15px;height:15px}
.adm .mob{display:none}
.adm .shell{display:grid;grid-template-columns:252px minmax(0,1fr);min-height:100vh}
/* sidebar */
.adm .side{position:sticky;top:0;height:100vh;display:flex;flex-direction:column;padding:20px 14px 16px;border-right:1px solid var(--hair);background:linear-gradient(180deg,rgba(var(--acrgb),.05),transparent 40%),var(--glass);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px)}
.adm .brand{display:flex;align-items:center;gap:12px;padding:4px 8px 18px}
.adm .brand .logo{width:40px;height:40px;border-radius:12px;font-size:17px}
.adm .brand b{display:block;font-size:15.5px;letter-spacing:-.2px;line-height:1.2;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:150px;flex:none}
.adm .brand small{color:var(--mu);font-size:11px;font-weight:700;letter-spacing:.9px;text-transform:uppercase}
.adm .navg{font-size:10.5px;letter-spacing:1.1px;text-transform:uppercase;color:var(--mu);font-weight:800;padding:14px 10px 6px;opacity:.8}
.adm .nv{display:flex;align-items:center;gap:11px;width:100%;border:0;background:none;color:var(--mu);padding:10px 12px;border-radius:12px;font-size:13.5px;font-weight:700;cursor:pointer;text-align:left;text-decoration:none;position:relative;transition:.15s}
.adm .nv:hover{color:var(--tx);background:rgba(var(--acrgb),.06)}
.adm .nv.on{color:var(--tx);background:linear-gradient(90deg,rgba(var(--acrgb),.17),rgba(var(--acrgb),.04))}
.adm .nv.on:before{content:"";position:absolute;left:-14px;top:9px;bottom:9px;width:3px;border-radius:0 3px 3px 0;background:var(--ac);box-shadow:0 0 14px rgba(var(--acrgb),.8)}
.adm .nv.on svg{color:var(--ac)}
.adm .nv em{margin-left:auto;font-style:normal;font-size:11px;font-weight:800;background:rgba(var(--acrgb),.15);color:var(--ac);border-radius:999px;padding:2px 8px;font-variant-numeric:tabular-nums}
.adm .sp{flex:1}
.adm .health{margin:10px 2px 12px;padding:13px;border:1px solid var(--hair);border-radius:15px;background:rgba(255,255,255,.025)}
.adm .health:empty{display:none}
.adm .health h4{margin:0 0 10px;font-size:10.5px;letter-spacing:1.1px;text-transform:uppercase;color:var(--mu);font-weight:800;display:flex;align-items:center;gap:7px}
.adm .hl{display:flex;justify-content:space-between;font-size:12px;font-weight:700;color:var(--mu);margin:9px 0 5px}
.adm .hl b{color:var(--tx);font-variant-numeric:tabular-nums}
.adm .meter{height:5px;border-radius:9px;background:var(--s2);overflow:hidden}
.adm .meter span{display:block;height:100%;border-radius:9px;background:linear-gradient(90deg,var(--ok),#86efac);transition:width .6s}
.adm .meter span.w{background:linear-gradient(90deg,var(--warn),#fde68a)}.adm .meter span.b{background:linear-gradient(90deg,var(--bad),#fca5a5)}
/* main */
.adm .main{min-width:0;padding:0 28px 48px}
.adm .bar-top{position:sticky;top:0;z-index:15;display:flex;align-items:center;gap:10px;padding:16px 0;margin-bottom:6px;background:linear-gradient(var(--bg) 55%,transparent);background:linear-gradient(color-mix(in srgb,var(--bg) 88%,transparent) 60%,transparent);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px)}
.adm .bar-top h1{margin:0;font-size:22px;letter-spacing:-.5px;line-height:1.1}
.adm .bar-top p{margin:3px 0 0;color:var(--mu);font-size:12.5px;font-weight:600;display:flex;align-items:center;gap:7px}
.adm .live{display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--ok);box-shadow:0 0 0 0 rgba(var(--okrgb),.6);animation:lv 2s infinite}
@keyframes lv{70%{box-shadow:0 0 0 7px rgba(var(--okrgb),0)}100%{box-shadow:0 0 0 0 rgba(var(--okrgb),0)}}
.adm .tbtn{display:inline-flex;align-items:center;gap:8px;border:1px solid var(--hair);background:var(--glass);color:var(--tx);border-radius:12px;padding:9px 13px;font-size:13px;font-weight:700;cursor:pointer;text-decoration:none;transition:.15s;white-space:nowrap}
.adm .tbtn:hover{border-color:var(--ac);transform:translateY(-1px)}
.adm .tbtn.pri{background:linear-gradient(135deg,var(--ac),rgba(var(--acrgb),.78));color:var(--act);border-color:transparent;box-shadow:0 8px 20px -9px rgba(var(--acrgb),.8)}
.adm .tbtn.ic{padding:9px}
.adm .view{display:none}.adm .view.on{display:block;animation:up .35s ease both}
/* cards */
.adm .card{border-radius:var(--r);border:1px solid var(--hair);padding:20px;margin-bottom:16px;background:linear-gradient(180deg,rgba(255,255,255,.04),rgba(255,255,255,0) 60%),var(--glass);box-shadow:0 1px 0 rgba(255,255,255,.04) inset,0 18px 40px -26px rgba(0,0,0,.7)}
.adm .card>h2{display:flex;align-items:center;gap:10px;margin:0 0 16px;font-size:14.5px;letter-spacing:-.1px}
.adm .card>h2 .hi{width:30px;height:30px;border-radius:9px;display:grid;place-items:center;background:rgba(var(--acrgb),.12);color:var(--ac);flex:none}
.adm .card>h2 .r{margin-left:auto;color:var(--mu);font-size:12px;font-weight:700}
.adm .g2{display:grid;grid-template-columns:minmax(0,1.5fr) minmax(0,1fr);gap:16px}
.adm .g2e{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.adm .g2>.card,.adm .g2e>.card{margin-bottom:0}
.adm .g2,.adm .g2e{margin-bottom:16px}
/* kpis */
.adm .grid{grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-bottom:16px}
.adm .kpi{position:relative;overflow:hidden;border:1px solid var(--hair);border-radius:var(--r);padding:18px;background:linear-gradient(180deg,rgba(255,255,255,.04),transparent 70%),var(--glass);box-shadow:0 18px 40px -28px rgba(0,0,0,.8);animation:up .45s ease both}
.adm .kpi:after{content:"";position:absolute;right:-30px;top:-30px;width:110px;height:110px;border-radius:50%;background:radial-gradient(circle,rgba(var(--acrgb),.2),transparent 70%)}
.adm .kpi .kh{display:flex;align-items:center;gap:9px;color:var(--mu);font-size:11.5px;font-weight:800;letter-spacing:.7px;text-transform:uppercase}
.adm .kpi .ki{width:32px;height:32px;border-radius:10px;display:grid;place-items:center;background:rgba(var(--acrgb),.13);color:var(--ac)}
.adm .kpi b{display:block;font-size:28px;margin:14px 0 4px;letter-spacing:-.8px;font-variant-numeric:tabular-nums;line-height:1.1}
.adm .kpi.hot b{background:linear-gradient(120deg,var(--tx),var(--ac));-webkit-background-clip:text;background-clip:text;color:transparent}
.adm .kpi i{font-style:normal;color:var(--mu);font-size:12px;font-weight:600}
/* forms */
.adm .inp{background:color-mix(in srgb,var(--s2) 80%,transparent);border:1px solid var(--line);border-radius:12px;padding:12px 14px;font-size:14px;font-weight:600;margin-bottom:10px}
.adm .inp:focus{border-color:var(--ac);box-shadow:0 0 0 4px rgba(var(--acrgb),.14)}
.adm .inp::placeholder{color:var(--mu);opacity:.75;font-weight:500}
.adm select.inp{appearance:none;-webkit-appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' fill='none' stroke='%238b93ab' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M1 1.5l5 5 5-5'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center;padding-right:36px}
.adm .fl{display:block;font-size:11.5px;font-weight:800;color:var(--mu);letter-spacing:.4px;margin:0 0 6px 2px}
.adm .big{border-radius:12px;padding:13px;font-size:14px;letter-spacing:.1px}
.adm .big.alt{background:rgba(255,255,255,.04);border:1px solid var(--line);color:var(--tx);margin-bottom:0}
.adm .big.alt:hover{border-color:var(--ac)}
.adm .btnrow{display:flex;gap:10px;flex-wrap:wrap}.adm .btnrow .big{flex:1;min-width:140px}
.adm .row2{gap:12px}.adm .row3{gap:12px}
.adm .msg{min-height:0}.adm .msg:empty{display:none}
.adm .msg.ok{color:var(--ok)}.adm .msg.err{color:var(--bad)}
.adm .help{color:var(--mu);font-size:12.5px;line-height:1.55;font-weight:500}
/* toolbar */
.adm .tools{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-bottom:16px}
.adm .srch{position:relative;flex:1;min-width:220px}
.adm .srch svg{position:absolute;left:13px;top:50%;transform:translateY(-50%);color:var(--mu)}
.adm .srch .inp{padding-left:40px;margin:0}
.adm .chips{display:flex;gap:7px;flex-wrap:wrap}
.adm .chip{border:1px solid var(--hair);background:var(--glass);color:var(--mu);border-radius:999px;padding:8px 13px;font-size:12.5px;font-weight:800;cursor:pointer;transition:.15s;display:inline-flex;gap:7px;align-items:center}
.adm .chip:hover{color:var(--tx)}
.adm .chip.on{background:rgba(var(--acrgb),.15);border-color:rgba(var(--acrgb),.5);color:var(--ac)}
.adm .chip b{font-size:11px;opacity:.85}
/* bots */
.adm .bots{grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:16px}
.adm .bot{position:relative;border:1px solid var(--hair);border-radius:var(--r);padding:18px;background:linear-gradient(180deg,rgba(255,255,255,.04),transparent 55%),var(--glass);box-shadow:0 18px 40px -28px rgba(0,0,0,.8);transition:.2s;overflow:hidden}
.adm .bot:hover{border-color:rgba(var(--acrgb),.45);transform:translateY(-2px)}
.adm .bot:before{content:"";position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--mu);opacity:.5}
.adm .bot.s-running:before{background:var(--ok);opacity:1;box-shadow:0 0 16px var(--ok)}
.adm .bot.s-crashed:before,.adm .bot.s-expired:before,.adm .bot.s-suspended:before{background:var(--bad);opacity:1}
.adm .bh{gap:12px;margin-bottom:14px}
.adm .av{width:42px;height:42px;border-radius:13px;display:grid;place-items:center;font-weight:900;font-size:16px;color:var(--ac);background:rgba(var(--acrgb),.12);border:1px solid rgba(var(--acrgb),.25);text-transform:uppercase;flex:none}
.adm .bn{flex:1;min-width:0}.adm .bn b{display:block;font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;letter-spacing:-.2px}
.adm .bn small{color:var(--mu);font-size:11.5px;font-weight:600;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.adm .badge{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:800;border-radius:999px;padding:5px 11px;text-transform:capitalize;letter-spacing:.2px;flex:none}
.adm .badge:before{content:"";width:6px;height:6px;border-radius:50%;background:currentColor}
.adm .badge.running,.adm .badge.paid{background:rgba(var(--okrgb),.14);color:var(--ok)}
.adm .badge.running:before{animation:lv 2s infinite;box-shadow:0 0 0 0 rgba(var(--okrgb),.6)}
.adm .badge.stopped,.adm .badge.pending{background:rgba(139,147,171,.16);color:var(--mu)}
.adm .badge.crashed,.adm .badge.expired,.adm .badge.suspended,.adm .badge.failed{background:rgba(var(--badrgb),.14);color:var(--bad)}
.adm .mm{grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:14px}
.adm .mm div{background:rgba(255,255,255,.035);border:1px solid var(--hair);border-radius:12px;padding:10px 11px}
.adm .mm small{font-size:10px;letter-spacing:.7px;text-transform:uppercase;font-weight:800}.adm .mm b{display:block;font-size:15px;margin-top:3px;font-variant-numeric:tabular-nums}
.adm .pl{margin-bottom:14px}.adm .pl .hl{margin:0 0 6px}
.adm .pl .meter{height:6px}
.adm .acts{gap:7px}
.adm .acts button{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--hair);background:rgba(255,255,255,.04);border-radius:10px;padding:8px 11px;font-size:12px;font-weight:700;cursor:pointer;transition:.15s;color:var(--tx)}
.adm .acts button:hover{border-color:var(--ac);background:rgba(var(--acrgb),.08)}
.adm .acts button:disabled{opacity:.5}
.adm .acts .g{color:var(--ok);border-color:rgba(var(--okrgb),.35);background:rgba(var(--okrgb),.08)}
.adm .acts .r{color:var(--bad);border-color:rgba(var(--badrgb),.3);margin-left:auto}
.adm .acts .r:hover{background:rgba(var(--badrgb),.1);border-color:var(--bad)}
.adm .empty{padding:34px 16px;text-align:center;color:var(--mu);font-size:13px;font-weight:600;border:1px dashed var(--line);border-radius:14px}
/* rows / tables */
.adm .tr{display:flex;align-items:center;gap:12px;padding:12px 4px;border-top:1px solid var(--hair);font-size:13px;font-weight:600;min-width:0;color:var(--tx)}
.adm .tr:first-child{border-top:0}
.adm .tr code{font-size:12.5px;background:rgba(255,255,255,.05);border:1px solid var(--hair);padding:4px 9px;border-radius:8px;letter-spacing:.4px;word-break:break-all}
.adm .tr .t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis}
.adm .tr .t small{display:block;color:var(--mu);font-size:11.5px;font-weight:600;margin-top:2px}
.adm .tr .v{font-weight:800;font-variant-numeric:tabular-nums}
.adm .tr .mu{color:var(--mu);font-size:12px;white-space:nowrap}
.adm .mini{border-radius:9px;padding:6px 10px;font-size:12px;background:rgba(255,255,255,.04);border:1px solid var(--hair);color:var(--mu);display:inline-flex;align-items:center;cursor:pointer}
.adm .mini:hover{color:var(--tx);border-color:var(--ac)}.adm .mini.x:hover{color:var(--bad);border-color:var(--bad)}
.adm .sw2{position:relative;width:38px;height:22px;border-radius:999px;border:0;background:var(--line);cursor:pointer;transition:.2s;flex:none;padding:0}
.adm .sw2:after{content:"";position:absolute;left:3px;top:3px;width:16px;height:16px;border-radius:50%;background:#fff;transition:.2s}
.adm .sw2.on{background:var(--ok)}.adm .sw2.on:after{left:19px}
.adm .rv{padding:9px 0}.adm .rv .hl{margin:0 0 7px;color:var(--tx);font-size:13px}.adm .rv .meter{height:8px}
.adm .rv .meter span{background:linear-gradient(90deg,rgba(var(--acrgb),.55),var(--ac))}
.adm .rk{display:inline-grid;place-items:center;width:20px;height:20px;border-radius:7px;background:rgba(var(--acrgb),.14);color:var(--ac);font-size:11px;font-weight:900;margin-right:9px;font-style:normal}
.adm .keyc{font-size:12.5px}
.adm .warn{display:flex;gap:11px;align-items:flex-start;border-radius:14px;margin-bottom:16px;padding:13px 15px}
.adm .warn svg{margin-top:1px;flex:none}
/* modals + drawer */
.adm .modal{background:rgba(3,5,10,.66);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px);align-items:center;padding:18px}
.adm .modal .card{max-width:560px;margin:auto;background:var(--s1);box-shadow:0 40px 90px -20px rgba(0,0,0,.8);animation:up .25s ease both}
.adm .modal.drawer{align-items:stretch;justify-content:flex-end;padding:0}
.adm .modal.drawer .card{max-width:480px;width:100%;margin:0;border-radius:0;border-width:0 0 0 1px;min-height:100%;padding:0;display:flex;flex-direction:column;animation:slide .3s cubic-bezier(.2,.8,.2,1) both}
@keyframes slide{from{transform:translateX(40px);opacity:0}to{transform:none;opacity:1}}
.adm .dh{display:flex;align-items:center;gap:12px;padding:20px 22px;border-bottom:1px solid var(--hair);position:sticky;top:0;background:var(--s1);z-index:2}
.adm .dh h2{margin:0;font-size:17px;flex:1}
.adm .db{padding:6px 22px 22px;flex:1}
.adm .df{position:sticky;bottom:0;padding:14px 22px calc(14px + env(safe-area-inset-bottom));background:var(--s1);border-top:1px solid var(--hair);z-index:2}
.adm .sg{margin-top:20px}
.adm .sg>h3{display:flex;align-items:center;gap:9px;margin:0 0 12px;font-size:11.5px;letter-spacing:1px;text-transform:uppercase;color:var(--mu);font-weight:800}
.adm .sg>h3:after{content:"";flex:1;height:1px;background:var(--hair)}
.adm .sw{grid-template-columns:repeat(auto-fill,minmax(100px,1fr))}
.adm .sw button{border-radius:13px;background:rgba(255,255,255,.03);color:var(--tx)}
.adm label.chk{padding:11px 13px;border:1px solid var(--hair);border-radius:12px;background:rgba(255,255,255,.025);margin:8px 0;line-height:1.4}
.adm pre{border-radius:12px;background:rgba(0,0,0,.35)}
.adm .toast{bottom:28px;background:var(--tx);color:var(--bg);border-radius:12px;padding:11px 18px;box-shadow:0 18px 40px -10px rgba(0,0,0,.6)}
/* mobile nav */
.adm .mnav{display:none}
@media(max-width:1100px){.adm .grid{grid-template-columns:repeat(2,minmax(0,1fr))}.adm .g2{grid-template-columns:1fr}}
@media(max-width:900px){
 .adm .shell{display:block}.adm .side{display:none}
 .adm .mob{display:inline-flex}
 .adm .main{padding:0 14px 96px}
 .adm .bar-top{padding:14px 0}.adm .bar-top h1{font-size:19px}
 .adm .tbtn span{display:none}.adm .tbtn{padding:9px}.adm .tbtn.pri span{display:inline}.adm .tbtn.pri{padding:9px 12px}
 .adm .g2e{grid-template-columns:1fr}
 .adm .bots{grid-template-columns:1fr}
 .adm .mnav{display:flex;position:fixed;left:0;right:0;bottom:0;z-index:25;justify-content:space-around;padding:7px 8px calc(7px + env(safe-area-inset-bottom));background:color-mix(in srgb,var(--bg) 84%,transparent);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border-top:1px solid var(--hair)}
 .adm .mnav button{flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;border:0;background:none;color:var(--mu);font-size:10.5px;font-weight:800;padding:7px 2px;border-radius:12px;cursor:pointer}
 .adm .mnav button.on{color:var(--ac);background:rgba(var(--acrgb),.11)}
 .adm .mnav svg{width:21px;height:21px}
 .adm .toast{bottom:88px}
}
@media(max-width:520px){.adm .grid{gap:10px}.adm .kpi{padding:14px}.adm .kpi b{font-size:22px}.adm .row3{grid-template-columns:1fr 1fr}.adm .row3>:first-child{grid-column:1/-1}.adm .card{padding:16px}.adm .tr{flex-wrap:wrap}.adm .bar-top .tbtn:not(.pri):not(.mob){display:none}}
.adm .brandrow{display:flex;gap:14px;align-items:center;padding:12px;border:1px solid var(--hair);border-radius:14px;background:rgba(255,255,255,.025);margin-bottom:10px}
.adm .bimg{width:64px;height:64px;border-radius:16px;display:grid;place-items:center;background:repeating-conic-gradient(rgba(255,255,255,.06) 0 25%,transparent 0 50%) 0 0/14px 14px;border:1px solid var(--hair);flex:none;overflow:hidden}
.adm .bimg .logo{width:48px;height:48px}.adm .bimg img.pv{width:100%;height:100%;object-fit:contain}
.adm .favp{width:32px;height:32px;border-radius:8px;background:var(--s2) center/contain no-repeat}
.adm .bt{min-width:0}.adm .bt b{display:block;font-size:14px}.adm .bt small{display:block;color:var(--mu);font-size:11.5px;margin-top:2px;line-height:1.45}
/* login */
.adm.lg{display:grid;grid-template-columns:1.05fr 1fr;min-height:100vh}
.adm .lgl{position:relative;overflow:hidden;padding:56px;display:flex;flex-direction:column;justify-content:center;gap:28px;background:radial-gradient(80% 60% at 20% 10%,rgba(var(--acrgb),.28),transparent 60%),radial-gradient(60% 50% at 90% 100%,rgba(var(--glow),.3),transparent 60%),var(--s1);border-right:1px solid var(--hair)}
.adm .lgl:before{content:"";position:absolute;inset:0;background-image:linear-gradient(var(--hair) 1px,transparent 1px),linear-gradient(90deg,var(--hair) 1px,transparent 1px);background-size:44px 44px;mask-image:radial-gradient(70% 70% at 30% 30%,#000,transparent);-webkit-mask-image:radial-gradient(70% 70% at 30% 30%,#000,transparent);opacity:.55}
.adm .lgl>*{position:relative}
.adm .lgl h2{margin:0;font-size:clamp(28px,3.2vw,42px);line-height:1.1;letter-spacing:-1.2px}
.adm .lgl p{margin:0;color:var(--mu);font-size:15px;line-height:1.65;max-width:440px}
.adm .lgf{display:grid;gap:12px;margin-top:4px}
.adm .lgf div{display:flex;align-items:center;gap:12px;font-size:14px;font-weight:700}
.adm .lgf i{width:32px;height:32px;border-radius:10px;display:grid;place-items:center;background:rgba(var(--acrgb),.14);color:var(--ac)}
.adm .lgr{display:grid;place-items:center;padding:28px}
.adm .lgc{width:100%;max-width:400px}
.adm .lgc .logo{width:52px;height:52px;border-radius:15px;font-size:22px;margin-bottom:22px}
.adm .lgc h1{margin:0 0 6px;font-size:26px;letter-spacing:-.6px}
.adm .lgc .sub{color:var(--mu);font-size:14px;margin:0 0 24px;line-height:1.5}
.adm .lgc .big{margin-top:4px;padding:14px}
.adm .pwf{position:relative}.adm .pwf .inp{padding-right:48px}
.adm .eye{position:absolute;right:6px;top:6px;width:38px;height:38px;border:0;background:none;color:var(--mu);cursor:pointer;border-radius:10px;display:grid;place-items:center}
.adm .eye:hover{color:var(--tx)}
.adm .lgc .msg.err{background:rgba(var(--badrgb),.1);border:1px solid rgba(var(--badrgb),.3);border-radius:12px;padding:10px 13px;margin-top:14px}
.adm .secure{display:flex;align-items:center;gap:8px;justify-content:center;margin-top:22px;color:var(--mu);font-size:12px;font-weight:600}
@media(max-width:900px){.adm.lg{display:block}.adm .lgl{display:none}.adm .lgr{min-height:100vh;padding:22px}}
"""

ADM_ICONS = r"""<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
<symbol id="i-home" viewBox="0 0 24 24"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/></symbol>
<symbol id="i-bot" viewBox="0 0 24 24"><rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 8V4"/><circle cx="12" cy="3.5" r="1"/><circle cx="9" cy="14" r="1.2"/><circle cx="15" cy="14" r="1.2"/></symbol>
<symbol id="i-cart" viewBox="0 0 24 24"><circle cx="9" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/><path d="M2 3h3l2.6 11.5a1.5 1.5 0 001.5 1.2h8.2a1.5 1.5 0 001.5-1.1L20.5 8H6"/></symbol>
<symbol id="i-tool" viewBox="0 0 24 24"><path d="M14.7 6.3a4 4 0 00-5.4 5.2L3 17.8V21h3.2l6.3-6.3a4 4 0 005.2-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/></symbol>
<symbol id="i-list" viewBox="0 0 24 24"><path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/></symbol>
<symbol id="i-gear" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/></symbol>
<symbol id="i-globe" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"/></symbol>
<symbol id="i-out" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></symbol>
<symbol id="i-refresh" viewBox="0 0 24 24"><path d="M21 12a9 9 0 01-15.5 6.2L3 16"/><path d="M3 12A9 9 0 0118.5 5.8L21 8"/><path d="M21 3v5h-5M3 21v-5h5"/></symbol>
<symbol id="i-search" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></symbol>
<symbol id="i-play" viewBox="0 0 24 24"><path d="M6 4l14 8-14 8z"/></symbol>
<symbol id="i-stop" viewBox="0 0 24 24"><rect x="5" y="5" width="14" height="14" rx="2"/></symbol>
<symbol id="i-file" viewBox="0 0 24 24"><path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/></symbol>
<symbol id="i-plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>
<symbol id="i-inf" viewBox="0 0 24 24"><path d="M18.2 7.8c-3.2 0-4.8 2.9-6.2 4.2-1.4 1.3-3 4.2-6.2 4.2a4.2 4.2 0 010-8.4c3.2 0 4.8 2.9 6.2 4.2 1.4 1.3 3 4.2 6.2 4.2a4.2 4.2 0 000-8.4z"/></symbol>
<symbol id="i-ban" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/></symbol>
<symbol id="i-up" viewBox="0 0 24 24"><path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a2 2 0 002 2h12a2 2 0 002-2v-3"/></symbol>
<symbol id="i-down" viewBox="0 0 24 24"><path d="M12 4v12M7 11l5 5 5-5"/><path d="M4 16v3a2 2 0 002 2h12a2 2 0 002-2v-3"/></symbol>
<symbol id="i-flask" viewBox="0 0 24 24"><path d="M9 3h6M10 3v6L4.5 19a1.6 1.6 0 001.4 2.4h12.2a1.6 1.6 0 001.4-2.4L14 9V3"/><path d="M7.5 14h9"/></symbol>
<symbol id="i-trash" viewBox="0 0 24 24"><path d="M3 6h18M8 6V4a1 1 0 011-1h6a1 1 0 011 1v2M6 6l1 14a1 1 0 001 1h8a1 1 0 001-1l1-14M10 11v6M14 11v6"/></symbol>
<symbol id="i-users" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0113 0M16 4.6a3.5 3.5 0 010 6.8M18 14.2A6.5 6.5 0 0121.5 20"/></symbol>
<symbol id="i-wallet" viewBox="0 0 24 24"><path d="M3 7a2 2 0 012-2h13v4"/><path d="M3 7v11a2 2 0 002 2h15a1 1 0 001-1v-9a1 1 0 00-1-1H5a2 2 0 01-2-2z"/><circle cx="16.5" cy="14" r="1.2"/></symbol>
<symbol id="i-trend" viewBox="0 0 24 24"><path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/></symbol>
<symbol id="i-key" viewBox="0 0 24 24"><circle cx="8" cy="15" r="4"/><path d="M10.8 12.2L20 3M16 7l3 3M14 9l2 2"/></symbol>
<symbol id="i-tag" viewBox="0 0 24 24"><path d="M3 12V4a1 1 0 011-1h8l9 9-9 9z"/><circle cx="8" cy="8" r="1.3"/></symbol>
<symbol id="i-mega" viewBox="0 0 24 24"><path d="M3 11v2a1 1 0 001 1h2l7 4V6L6 10H4a1 1 0 00-1 1z"/><path d="M16.5 8.5a5 5 0 010 7"/></symbol>
<symbol id="i-pulse" viewBox="0 0 24 24"><path d="M3 12h4l3-8 4 16 3-8h4"/></symbol>
<symbol id="i-shield" viewBox="0 0 24 24"><path d="M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/></symbol>
<symbol id="i-lock" viewBox="0 0 24 24"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 018 0v4"/></symbol>
<symbol id="i-eye" viewBox="0 0 24 24"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></symbol>
<symbol id="i-x" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></symbol>
<symbol id="i-alert" viewBox="0 0 24 24"><path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.1"/></symbol>
<symbol id="i-copy" viewBox="0 0 24 24"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 012-2h10"/></symbol>
</defs></svg>"""


def _ic(n, cls="i"):
    return '<svg class="' + cls + '"><use href="#i-' + n + '"/></svg>'



CHART_CSS = r"""
.adm .g3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin-bottom:16px}
.adm .g3>.card{margin-bottom:0;padding:16px}
@media(max-width:1100px){.adm .g3{grid-template-columns:1fr}}
.adm .chh{display:flex;align-items:baseline;justify-content:space-between;gap:8px;margin:2px 0 8px}
.adm .chh b{font-size:24px;letter-spacing:-.6px;font-variant-numeric:tabular-nums}
.adm .chh small{color:var(--mu);font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.7px}
.adm .ch svg{width:100%;height:auto;display:block;overflow:visible}
.adm .ch .cbar{transform-origin:bottom;transform-box:fill-box;animation:barUp .75s cubic-bezier(.2,.8,.2,1) both}
@keyframes barUp{from{transform:scaleY(0)}to{transform:scaleY(1)}}
.adm .ch .cln{stroke-dasharray:1200;stroke-dashoffset:1200;animation:lnDraw 1.5s ease forwards}
@keyframes lnDraw{to{stroke-dashoffset:0}}
.adm .ch .cfade{animation:fadeIn 1s ease .5s both}@keyframes fadeIn{from{opacity:0}to{opacity:1}}
.adm .ch text{fill:var(--mu);font-size:8.5px;font-weight:700}
.adm .ch .cgl{stroke:rgba(255,255,255,.07);stroke-width:1}
.adm .ch .chit{fill:transparent;cursor:pointer}
.adm .ch .chit:hover{fill:rgba(var(--acrgb),.10)}
.adm .ch .cdot{fill:var(--s1);stroke:var(--ac);stroke-width:2}
.adm .ch .cleg{display:flex;gap:14px;margin-top:6px;color:var(--mu);font-size:11px;font-weight:700}
.adm .ch .cleg i{display:inline-block;width:9px;height:9px;border-radius:3px;margin-right:6px;vertical-align:-1px}
.chtip{position:fixed;z-index:80;pointer-events:none;background:var(--s2);border:1px solid rgba(var(--acrgb),.55);border-radius:10px;padding:6px 10px;font-size:12px;font-weight:700;box-shadow:0 12px 30px -8px #000;display:none;white-space:nowrap;color:var(--tx)}
@media(prefers-reduced-motion:reduce){.adm .ch .cbar,.adm .ch .cln,.adm .ch .cfade{animation:none;stroke-dashoffset:0}}
"""

ADM_HEAD = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><link rel="icon" href="__FAVICON__"><meta name="theme-color" content="#07090f"><title>__TITLE__ · Console</title><style>""" + CSS + ADM_CSS + CHART_CSS + r"""__THEME__</style></head>"""

# ───────────────────────── owner login ─────────────────────────
ADMIN_LOGIN = ADM_HEAD + r"""<body class="adm lg">""" + ADM_ICONS + r"""
<div class="lgl">
 <div class="brand" style="padding:0"><div class="logo">__LOGO__</div><div><b>__BRAND__</b><small>Owner console</small></div></div>
 <div><h2>Run your hosting business<br>from one <span class="grad">command centre</span>.</h2></div>
 <p>Monitor every hosted bot, manage plans and access keys, track revenue and keep customers happy, all in real time.</p>
 <div class="lgf">
  <div><i>""" + _ic("pulse") + r"""</i>Live bot status and server health</div>
  <div><i>""" + _ic("wallet") + r"""</i>Revenue, orders and automatic payments</div>
  <div><i>""" + _ic("shield") + r"""</i>Protected with optional Telegram 2-step login</div>
 </div>
</div>
<div class="lgr"><form class="lgc" method="post">
 <div class="logo">__LOGO__</div>
 <h1>Welcome back</h1><p class="sub">Sign in to the __BRAND__ owner console.</p>
 __FORM__
 <div class="msg err">__ERR__</div>
 <div class="secure">""" + _ic("lock", "i s") + r"""Encrypted session · owner access only</div>
</form></div></body></html>"""

FORM_PW = r"""<label class="fl">Panel password</label><div class="pwf"><input class="inp" id="pw" type="password" name="password" placeholder="Enter your password" autocomplete="current-password" autofocus><button class="eye" type="button" aria-label="Show password" onclick="var p=document.getElementById('pw');p.type=p.type==='password'?'text':'password'">""" + _ic("eye") + r"""</button></div><button class="big">Sign in</button>"""
FORM_OTP = r"""<div class="warn" style="margin-bottom:16px"><span>A 6-digit code was sent to your Telegram.</span></div><label class="fl">Verification code</label><input class="inp" name="otp" placeholder="6-digit code" inputmode="numeric" maxlength="6" autocomplete="one-time-code" autofocus style="letter-spacing:6px;text-align:center;font-size:20px"><button class="big">Verify and continue</button>"""

# ───────────────────────── owner dashboard ─────────────────────────
ADMIN_DASH = ADM_HEAD + r"""<body class="adm">""" + ADM_ICONS + r"""
<div class="shell">
<aside class="side">
 <div class="brand"><div class="logo">__LOGO__</div><div><b>__BRAND__</b><small>Owner console</small></div></div>
 <div class="navg">Workspace</div>
 <button class="nv on" data-v="ov">""" + _ic("home") + r"""Overview</button>
 <button class="nv" data-v="bots">""" + _ic("bot") + r"""Hosted bots<em id="nbots">0</em></button>
 <button class="nv" data-v="sales">""" + _ic("cart") + r"""Sales &amp; plans</button>
 <button class="nv" data-v="tools">""" + _ic("tool") + r"""Tools</button>
 <button class="nv" data-v="scripts">""" + _ic("bolt") + r"""Scripts<em id="nscripts">0</em></button>
 <button class="nv" data-v="log">""" + _ic("list") + r"""Activity</button>
 <div class="navg">System</div>
 <button class="nv" id="setb">""" + _ic("gear") + r"""Settings</button>
 <a class="nv" href="/" target="_blank">""" + _ic("globe") + r"""View website</a>
 <div class="sp"></div>
 <div class="health" id="srv"></div>
 <a class="nv" href="/admin/logout">""" + _ic("out") + r"""Logout</a>
</aside>

<main class="main">
 <div class="bar-top">
  <div style="flex:1;min-width:0"><h1 id="ttl">Overview</h1><p><i class="live"></i><span id="liveT">Syncing…</span></p></div>
  <button class="tbtn" id="rall" title="Restart all bots">""" + _ic("refresh") + r"""<span>Restart all</span></button>
  <button class="tbtn pri" id="addb" type="button">""" + _ic("plus") + r"""<span>Host bot</span></button>
  <button class="tbtn ic mob" id="setb2" title="Settings">""" + _ic("gear") + r"""</button>
  <a class="tbtn ic mob" href="/admin/logout" title="Logout">""" + _ic("out") + r"""</a>
 </div>

 <div id="alerts"></div>

 <section class="view on" id="v-ov">
  <div class="grid" id="tot"></div>
  <div class="g3">
   <div class="card"><h2><span class="hi">""" + _ic("trend", "i s") + r"""</span>Daily sales<span class="r">last 14 days</span></h2><div class="ch" id="ch_sales"><div class="help">Loading…</div></div></div>
   <div class="card"><h2><span class="hi">""" + _ic("tag", "i s") + r"""</span>Keys<span class="r">created vs used</span></h2><div class="ch" id="ch_keys"><div class="help">Loading…</div></div></div>
   <div class="card"><h2><span class="hi">""" + _ic("pulse", "i s") + r"""</span>Bot uptime<span class="r">last 24 hours</span></h2><div class="ch" id="ch_up"><div class="help">Collecting data…</div></div></div>
  </div>
  <div class="g2">
   <div class="card"><h2><span class="hi">""" + _ic("trend", "i s") + r"""</span>Revenue by bot</h2><div id="rev" class="help">Loading…</div></div>
   <div class="card"><h2><span class="hi">""" + _ic("cart", "i s") + r"""</span>Latest orders</h2><div id="ordersMini" class="help">No orders yet.</div></div>
  </div>
  <div class="card"><h2><span class="hi">""" + _ic("pulse", "i s") + r"""</span>Recent activity</h2><div id="actMini" class="help"></div></div>
 </section>

 <section class="view" id="v-bots">
  <div class="tools">
   <div class="srch">""" + _ic("search", "i s") + r"""<input class="inp" id="q" placeholder="Search by @username or ID"></div>
   <div class="chips" id="chips"></div>
  </div>
  <input type="hidden" id="fs" value="">
  <div class="bots" id="bots"></div>
 </section>

 <section class="view" id="v-sales">
  <div class="g2e">
   <div class="card"><h2><span class="hi">""" + _ic("tag", "i s") + r"""</span>Plans<span class="r">shown on your website</span></h2>
    <div id="plans"></div>
    <div class="sg" style="margin-top:16px"><h3>Add a plan</h3>
    <div class="row3"><input class="inp" id="p_name" placeholder="Plan name (e.g. 30 Days)"><input class="inp" id="p_days" placeholder="Days" inputmode="numeric"><input class="inp" id="p_price" placeholder="Price ₹" inputmode="decimal"></div>
    <button class="big" id="p_go">Add plan</button><div class="help" style="margin-top:10px">Tip: use 36500 days for a Lifetime plan.</div></div>
   </div>
   <div class="card"><h2><span class="hi">""" + _ic("wallet", "i s") + r"""</span>Web orders<span class="r">auto payment</span></h2><div id="orders" class="help">No orders yet.</div></div>
  </div>
  <div class="card"><h2><span class="hi">""" + _ic("key", "i s") + r"""</span>Access keys<span class="r">manual sales</span></h2>
   <div class="row3" style="grid-template-columns:1fr 1fr 2fr"><input class="inp" id="k_days" placeholder="Plan days" inputmode="numeric" value="__DEFDAYS__"><input class="inp" id="k_count" placeholder="How many" inputmode="numeric" value="1"><input class="inp" id="k_note" placeholder="Note (buyer name, optional)"></div>
   <label class="fl" style="margin-top:10px">Script access</label><select class="inp" id="k_script"><option value="*">All scripts (buyer picks one)</option></select>
   <button class="big" id="k_go">Create key(s)</button><div class="msg" id="k_msg"></div>
   <div id="keys" style="margin-top:12px"></div></div>
 </section>

 <section class="view" id="v-scripts">
  <div class="g2e">
   <div class="card"><h2><span class="hi">""" + _ic("up", "i s") + r"""</span>Upload a script<span class="r">owner only</span></h2>
    <div class="help" style="margin-bottom:12px">A .zip with <b>bot.py</b>, optional <b>requirements.txt</b> (PyPI packages only), <b>script.json</b> and <b>themes/*.json</b>. Max 5 MB. Same id as an existing script = update (its bots reload). Only upload code you trust: it runs on your server.</div>
    <input class="inp" type="file" id="sz_file" accept=".zip">
    <button class="big" id="sz_go" type="button">Upload script</button><div class="msg" id="sz_msg"></div></div>
   <div class="card"><h2><span class="hi">""" + _ic("up", "i s") + r"""</span>Upload script files<span class="r">no zip needed</span></h2>
    <div class="help" style="margin-bottom:12px">Pick files one by one: <b>bot.py</b>, <b>requirements.txt</b> (PyPI packages only) and one or more <b>theme .json</b> files. Use the id of an existing script to update it: files you skip are kept, so you can add only a new theme or only a new requirements.txt. Only upload code you trust.</div>
    <input class="inp" id="sf_id" placeholder="Script id (example: ottbot)" maxlength="24">
    <input class="inp" id="sf_name" placeholder="Script name shown to buyers (optional)" maxlength="40" style="margin-top:8px">
    <input class="inp" id="sf_desc" placeholder="Short description (optional)" maxlength="200" style="margin-top:8px">
    <label class="fl">bot.py</label><input class="inp" type="file" id="sf_bot" accept=".py">
    <label class="fl">requirements.txt</label><input class="inp" type="file" id="sf_req" accept=".txt">
    <label class="fl">Themes (.json, you can select many)</label><input class="inp" type="file" id="sf_themes" accept=".json" multiple>
    <label class="fl">script.json (optional)</label><input class="inp" type="file" id="sf_meta" accept=".json">
    <button class="big" id="sf_go" type="button">Upload files</button><div class="msg" id="sf_msg"></div></div>
   <div class="card"><h2><span class="hi">""" + _ic("key", "i s") + r"""</span>Who can use what</h2>
    <div class="help">When you create an <b>access key</b> (Sales &amp; plans) choose <b>All scripts</b> or <b>one script</b>. A key always makes exactly one bot: with All scripts the buyer picks one script (and a theme) and hosts one bot. <b>Hide</b> keeps a script off new buyers' list without touching running bots.</div></div>
  </div>
  <div class="bots" id="scripts"></div>
 </section>

 <section class="view" id="v-tools">
  <div class="g2e">
   <div class="card"><h2><span class="hi">""" + _ic("bot", "i s") + r"""</span>Host a bot<span class="r">owner</span></h2>
    <label class="fl">Bot token</label><input class="inp" id="o_token" placeholder="123456:ABC…" autocomplete="off" spellcheck="false">
    <div class="row2"><div><label class="fl">Admin Telegram ID</label><input class="inp" id="o_admin" placeholder="Numeric ID" inputmode="numeric"></div><div><label class="fl">Days</label><input class="inp" id="o_days" placeholder="Days" inputmode="numeric" value="__DEFDAYS__"></div></div>
    <div class="pkw" id="o_pk"></div>
    <button class="big" id="o_go">Host bot now</button><div class="msg" id="o_msg"></div></div>
   <div class="card"><h2><span class="hi">""" + _ic("mega", "i s") + r"""</span>Broadcast</h2>
    <label class="fl">Message to every hosted bot's admin</label>
    <textarea class="inp" id="b_text" maxlength="1000" placeholder="Write your announcement. It is sent on Telegram."></textarea>
    <button class="big alt" id="b_go">Send broadcast</button></div>
  </div>
 </section>

 <section class="view" id="v-log">
  <div class="card"><h2><span class="hi">""" + _ic("list", "i s") + r"""</span>Activity log</h2><div id="act" class="help"></div></div>
 </section>
</main>
</div>

<nav class="mnav">
 <button class="on" data-v="ov">""" + _ic("home") + r"""Overview</button>
 <button data-v="bots">""" + _ic("bot") + r"""Bots</button>
 <button data-v="sales">""" + _ic("cart") + r"""Sales</button>
 <button data-v="tools">""" + _ic("tool") + r"""Tools</button>
 <button data-v="log">""" + _ic("list") + r"""Activity</button>
</nav>

<div class="modal" id="lm"><div class="card"><h2 id="lt">Logs</h2><pre id="lp"></pre><button class="big" id="lc" style="margin-top:14px">Close</button></div></div>

<div class="modal" id="dm"><div class="card"><h2 id="dm_t">Database</h2>
<div class="help" style="margin-bottom:14px">Upload a store .db file. The current data is backed up first (last 5 kept).</div>
<input class="inp" type="file" id="dm_file" accept=".db,.sqlite,.sqlite3">
<select class="inp" id="dm_mode"><option value="apply">Apply now to this bot</option><option value="template">Save as demo template only</option></select>
<label class="chk"><input type="checkbox" id="dm_keep" checked> Keep this bot's current settings (UPI, store name)</label>
<div class="msg" id="dm_msg"></div>
<div class="btnrow" style="margin-top:6px"><button class="big alt" id="dm_close" type="button">Close</button><button class="big" id="dm_go" type="button">Upload</button></div></div></div>

<div class="modal drawer" id="sm"><div class="card">
 <div class="dh"><h2>Settings</h2><button class="tbtn ic" id="sc" type="button" aria-label="Close">""" + _ic("x") + r"""</button></div>
 <div class="db">
 <div class="sg"><h3>Appearance</h3>
  <div class="sw" id="sw"></div>
  <div class="row2"><div><label class="fl">Accent colour (optional)</label><input class="inp" type="color" id="s_accent" style="padding:4px;height:46px"></div>
  <div><label class="fl">&nbsp;</label><button class="big alt" id="s_accclr" type="button" style="padding:12px">Use theme colour</button></div></div></div>

 <div class="sg"><h3>Custom branding</h3>
  <div class="brandrow">
   <div class="bimg" id="bi_logo"><div class="logo" id="bp_logo">B</div></div>
   <div class="bt"><b>Logo</b><small>PNG, JPG or WEBP · square looks best · max 1.5 MB</small>
    <div class="btnrow" style="gap:8px;margin-top:8px"><button class="tbtn" type="button" id="bu_logo">Upload</button><button class="tbtn" type="button" id="br_logo" style="display:none">Remove</button></div></div>
  </div>
  <div class="brandrow">
   <div class="bimg" id="bi_fav"><div class="favp" id="bp_fav"></div></div>
   <div class="bt"><b>Favicon</b><small>Browser tab icon · PNG or ICO · max 600 KB. If empty, your logo is used.</small>
    <div class="btnrow" style="gap:8px;margin-top:8px"><button class="tbtn" type="button" id="bu_fav">Upload</button><button class="tbtn" type="button" id="br_fav" style="display:none">Remove</button></div></div>
  </div>
  <input type="file" id="bf_file" accept="image/png,image/jpeg,image/webp,image/gif,image/x-icon,.ico" style="display:none">
  <div class="row2" style="margin-top:6px"><div><label class="fl">Panel name</label><input class="inp" id="s_brand" placeholder="Brand name" maxlength="40"></div><div><label class="fl">Logo letter (if no image)</label><input class="inp" id="s_logo" placeholder="B" maxlength="4"></div></div>
  <label class="fl">Tagline shown on website</label><input class="inp" id="s_tag" placeholder="Tagline" maxlength="140">
  <label class="fl">Receipt: business name (optional)</label><input class="inp" id="s_inv_name" placeholder="Shown on receipts" maxlength="60">
  <label class="fl">Receipt: address (optional)</label><input class="inp" id="s_inv_addr" placeholder="City, State" maxlength="200">
  <label class="fl">Receipt: GSTIN (optional)</label><input class="inp" id="s_inv_gstin" placeholder="GST number" maxlength="20">
  <label class="fl">Receipt: footer note (optional)</label><input class="inp" id="s_inv_note" placeholder="Thank you for your purchase." maxlength="160">
  <label class="fl">Support link</label><input class="inp" id="s_support" placeholder="@username or https://t.me/..."></div>

 <div class="sg"><h3>Auto payment (FMPay)</h3>
  <label class="fl">API key</label><input class="inp" id="s_fmkey" placeholder="FMPay API key" autocomplete="off">
  <label class="fl">API URL</label><input class="inp" id="s_fmurl" placeholder="FMPay API URL">
  <div class="row2"><div><label class="fl">Your UPI ID</label><input class="inp" id="s_upi" placeholder="name@bank"></div><div><label class="fl">Payee name</label><input class="inp" id="s_upiname" placeholder="Payee name"></div></div></div>

 <div class="sg"><h3>Telegram alerts &amp; 2-step login</h3>
  <label class="fl">Your numeric Telegram ID</label><input class="inp" id="s_tgid" placeholder="From @userinfobot" inputmode="numeric">
  <label class="fl">Alert bot token</label><input class="inp" id="s_tgtoken" placeholder="Alert bot token (any bot you own)" autocomplete="off">
  <div class="help" style="margin-bottom:10px">Start that bot once on Telegram first, then press Test.</div>
  <button class="big alt" id="s_tgtest" type="button">Send test message</button>
  <label class="chk"><input type="checkbox" id="s_alerts"> Send me Telegram alerts (new bot, payments, crashes, expiries)</label>
  <label class="chk"><input type="checkbox" id="s_2fa"> Login needs Telegram code (2-step)</label></div>

 <div class="sg"><h3>Security</h3>
  <input class="inp" type="password" id="pw_old" placeholder="Current password" autocomplete="current-password"><input class="inp" type="password" id="pw_new" placeholder="New password (min 8)" autocomplete="new-password">
  <button class="big alt" id="pw_go" type="button">Change password</button></div>

 <div class="sg"><h3>Backup &amp; move to new VPS</h3>
  <div class="help" id="bk_info" style="margin-bottom:10px">Loading…</div>
  <div class="btnrow" style="gap:8px"><a class="big" href="/admin/backup/full">Download full backup</a><button class="big alt" id="bk_now" type="button">Send to Telegram now</button></div>
  <label class="fl">Auto backup to Telegram</label>
  <select class="inp" id="bk_hours"><option value="0">Off</option><option value="6">Every 6 hours</option><option value="12">Every 12 hours</option><option value="24">Every 24 hours</option><option value="48">Every 2 days</option><option value="168">Every week</option></select>
  <div class="help" id="bk_list" style="margin:8px 0 12px"></div>
  <label class="fl">Restore a backup (.tar.gz) onto this server</label>
  <input class="inp" type="file" id="bk_file" accept=".gz,.tgz,application/gzip">
  <input class="inp" id="bk_confirm" placeholder="Type RESTORE to confirm" autocomplete="off">
  <button class="big alt" id="bk_restore" type="button">Restore backup</button>
  <div class="help" style="margin-top:8px">Full backup = every bot + its database, all scripts &amp; themes, keys, orders, settings. It contains secrets (bot tokens, UPI): keep it private. <a href="/admin/backup" style="color:var(--ac)">Panel database only</a></div></div>
 </div>
 <div class="df"><div class="msg" id="s_msg" style="margin:0 0 10px"></div><button class="big" id="s_save" type="button">Save settings</button></div>
</div></div>

<div class="toast" id="toast"></div>
<script>const CSRF="__CSRF__";""" + JS_COMMON + r"""
csrf_login="/admin/login";
const A=(u,b)=>J(u,b,CSRF);
const IC=n=>'<svg class="i s"><use href="#i-'+n+'"/></svg>';
let D=null,S=null,THEME="lime",DBID=0,LAST=0;
const TITLES={ov:"Overview",bots:"Hosted bots",sales:"Sales & plans",tools:"Tools",scripts:"Scripts",log:"Activity"};
let SIG="";
function show(v){if(!TITLES[v])v="ov";
 document.querySelectorAll(".view").forEach(e=>e.classList.toggle("on",e.id==="v-"+v));
 document.querySelectorAll("[data-v]").forEach(e=>e.classList.toggle("on",e.dataset.v===v));
 $("ttl").textContent=TITLES[v];try{history.replaceState(null,"","#"+v)}catch(e){}window.scrollTo(0,0)}
document.querySelectorAll("[data-v]").forEach(b=>b.onclick=()=>show(b.dataset.v));
$("addb").onclick=()=>{show("tools");setTimeout(()=>$("o_token").focus(),60)};
const kpi=(l,v,s,hot,ic)=>'<div class="kpi'+(hot?' hot':'')+'"><div class="kh"><span class="ki">'+IC(ic)+'</span>'+l+'</div><b>'+v+'</b><i>'+s+'</i></div>';
function plan(b){
 if(!b.expires)return '<div class="pl"><div class="hl"><span>Plan</span><b>Lifetime</b></div><div class="meter"><span style="width:100%"></span></div></div>';
 const d=b.days_left,left=d>=0?Math.ceil(d)+" days left":"Expired",pc=Math.max(0,Math.min(100,d/30*100)),cl=d<0?"b":d<=7?"w":"";
 return '<div class="pl"><div class="hl"><span>Plan</span><b>'+left+'</b></div><div class="meter"><span class="'+cl+'" style="width:'+(d<0?100:Math.max(4,pc))+'%"></span></div></div>'}
function botCard(b){
 const id=' data-id="'+b.id+'"',nm=' data-n="'+esc(b.username)+'"';
 return '<div class="bot s-'+b.status+'"><div class="bh"><div class="av">'+esc(String(b.username||"?").charAt(0))+'</div><div class="bn"><b>@'+esc(b.username)+'</b><small>ID '+b.id+' · '+esc(b.script_name||b.script)+' · admin '+esc(b.admin_ids)+(b.key?' · key '+esc(b.key):'')+'</small></div><span class="badge '+b.status+'">'+b.status+'</span></div>'+
 '<div class="mm"><div><small>Revenue</small><b>'+inr(b.revenue)+'</b></div><div><small>Users</small><b>'+b.users.toLocaleString("en-IN")+'</b></div><div><small>Orders</small><b>'+b.orders.toLocaleString("en-IN")+'</b></div>'+
 '<div><small>Today</small><b>'+inr(b.today)+'</b></div><div><small>Deposits</small><b>'+inr(b.deposits)+'</b></div><div><small>Today orders</small><b>'+(b.today_orders||0)+'</b></div></div>'+plan(b)+
 '<div class="acts"><button class="g" data-a="start"'+id+'>'+IC("play")+'Start</button><button data-a="restart"'+id+'>'+IC("refresh")+'Restart</button><button data-a="stop"'+id+'>'+IC("stop")+'Stop</button>'+
 '<button data-a="log"'+id+'>'+IC("file")+'Logs</button><button data-a="extend"'+id+'>'+IC("plus")+'Days</button><button data-a="lifetime"'+id+'>'+IC("inf")+'Lifetime</button>'+
 '<button data-a="'+(b.suspended?'unsuspend':'suspend')+'"'+id+nm+'>'+IC("ban")+(b.suspended?'Unsuspend':'Suspend')+'</button>'+
 '<button data-a="dbup"'+id+nm+'>'+IC("up")+'DB upload</button><button data-a="dbdl"'+id+'>'+IC("down")+'DB download</button>'+
 (b.owner_bot?'<button data-a="demo"'+id+'>'+IC("flask")+'Demo '+(b.demo?'ON ('+b.demo_min+'m)':'OFF')+'</button>'+(b.demo?'<button data-a="demoreset"'+id+'>'+IC("refresh")+'Reset now</button>':''):'')+
 '<button class="r" data-a="delete"'+id+nm+'>'+IC("trash")+'Delete</button></div></div>'}
const STS=["running","stopped","crashed","expired","suspended"];
function drawChips(){const c={};D.bots.forEach(b=>c[b.status]=(c[b.status]||0)+1);const cur=$("fs").value;
 $("chips").innerHTML=[["","All",D.bots.length]].concat(STS.filter(s=>c[s]).map(s=>[s,s[0].toUpperCase()+s.slice(1),c[s]])).map(x=>'<button class="chip'+(cur===x[0]?' on':'')+'" data-st="'+x[0]+'">'+x[1]+' <b>'+x[2]+'</b></button>').join("")}
function drawBots(){if(!D)return;drawChips();const q=$("q").value.trim().toLowerCase().replace("@",""),fs=$("fs").value;
 const list=D.bots.filter(b=>(!fs||b.status===fs)&&(!q||String(b.username).toLowerCase().includes(q)||String(b.id)===q));
 $("bots").innerHTML=list.map(botCard).join("")||'<div class="empty" style="grid-column:1/-1">'+(D.bots.length?'No bots match your filter.':'No bots hosted yet. Use <b>Host bot</b> to add your first one.')+'</div>'}
const scriptName=id=>{const x=((D&&D.scripts)||[]).find(y=>y.id===id);return x?x.name:id};
function scriptCard(x){const st=x.status,bd=st==="ready"?"running":st==="failed"?"failed":"pending",id=' data-sid="'+esc(x.id)+'"';
 return '<div class="bot"><div class="bh"><div class="av">'+esc(x.name.charAt(0))+'</div><div class="bn"><b>'+esc(x.name)+'</b><small>'+esc(x.id)+' · v'+esc(x.version)+' · '+x.themes.length+' theme(s)</small></div><span class="badge '+bd+'">'+esc(st)+'</span></div>'+
 '<div class="help" style="margin:2px 0 10px">'+esc(x.description)+'</div>'+(x.msg?'<div class="help" style="color:var(--red);margin-bottom:10px">'+esc(x.msg)+'</div>':'')+
 '<div class="mm"><div><small>Bots</small><b>'+x.bots+'</b></div><div><small>Running</small><b>'+x.running+'</b></div><div><small>Buyers</small><b>'+(x.enabled?"Visible":"Hidden")+'</b></div></div>'+
 '<div class="acts"><button data-sa="reinstall"'+id+'>'+IC("refresh")+'Reinstall</button><button data-sa="log"'+id+'>'+IC("file")+'Install log</button><button data-sa="toggle"'+id+'>'+IC("eye")+(x.enabled?"Hide":"Show")+'</button>'+
 (x.builtin?"":'<button class="r" data-sa="delete"'+id+'>'+IC("trash")+'Delete</button>')+'</div></div>'}
function ordRow(o){return '<div class="tr"><code>'+esc(o.id.slice(0,8))+'</code><div class="t">'+esc(o.plan_name)+(o.bot_id?' · renewal':'')+'<small>'+esc(String(o.created_at||"").slice(0,16))+'</small></div><span class="v">'+inr(o.amount)+'</span><span class="badge '+(o.status==='paid'?'paid':(o.status==='failed'||o.status==='expired')?'failed':'pending')+'">'+esc(o.status)+'</span>'+(o.status==='paid'?'<a class="mini" target="_blank" rel="noopener" href="/invoice/'+esc(o.id)+'">Receipt</a>':'')+'</div>'}
function actRow(a){return '<div class="tr"><span class="mu" style="min-width:96px">'+esc(a.ts.slice(5,16))+'</span><div class="t" style="white-space:normal"><b>'+esc(a.who)+'</b> · '+esc(a.action)+(a.detail?'<small>'+esc(a.detail)+'</small>':'')+'</div></div>'}
function meter(l,v,txt,w,b){return '<div class="hl"><span>'+l+'</span><b>'+txt+'</b></div><div class="meter"><span class="'+(v>=b?'b':v>=w?'w':'')+'" style="width:'+Math.max(3,Math.min(100,v))+'%"></span></div>'}
const _CN={};
function animateCounters(root,sel){sel=sel||".kpi b";if(!root||(window.matchMedia&&matchMedia("(prefers-reduced-motion:reduce)").matches))return;
 root.querySelectorAll(sel).forEach((b,i)=>{const k=(root.id||"r")+sel+i,txt=b.textContent,re=/\d[\d,]*(?:\.\d+)?/g,raw=txt.match(re)||[],to=raw.map(s=>parseFloat(s.replace(/,/g,"")));
  const prev=_CN[k];_CN[k]={t:txt,n:to};if(!to.length||(prev&&prev.t===txt))return;
  const from=prev&&prev.n.length===to.length?prev.n:to.map(()=>0),dec=raw.map(s=>(s.split(".")[1]||"").length),t0=performance.now();
  (function f(now){const p=Math.min(1,(now-t0)/950),e=1-Math.pow(1-p,3);let j=0;
   b.textContent=txt.replace(re,()=>{const v=from[j]+(to[j]-from[j])*e,d=dec[j];j++;return v.toLocaleString("en-IN",{minimumFractionDigits:d,maximumFractionDigits:d})});
   if(p<1)requestAnimationFrame(f);else b.textContent=txt})(t0)})}
function chTip(){let t=document.querySelector(".chtip");if(!t){t=document.createElement("div");t.className="chtip";document.body.appendChild(t)}return t}
["pointermove","pointerdown"].forEach(ev=>document.addEventListener(ev,e=>{const t=chTip(),h=e.target.closest&&e.target.closest("[data-tip]");
 if(!h){t.style.display="none";return}t.textContent=h.getAttribute("data-tip");t.style.display="block";
 t.style.left=Math.max(6,Math.min(innerWidth-t.offsetWidth-8,e.clientX+12))+"px";t.style.top=Math.max(6,e.clientY-38)+"px"}));
const CW=320,CH=140,PL=8,PR=8,PT=10,PB=20;
function dlab(d){const p=String(d).split("-");return p.length>2?p[2]+"/"+p[1]:d}
function nice(m){m=Math.max(1,m);const p=Math.pow(10,Math.floor(Math.log10(m/3))),st=[1,2,2.5,5,10].map(x=>x*p).find(x=>x*3>=m);return st*3}
function grid3(max,fmt){let s="";for(let i=0;i<=3;i++){const y=PT+(CH-PT-PB)*i/3;s+='<line class="cgl" x1="'+PL+'" x2="'+(CW-PR)+'" y1="'+y+'" y2="'+y+'"/>'+(i<3?'<text x="'+PL+'" y="'+(y-2)+'">'+fmt(max*(3-i)/3)+'</text>':"")}return s}
function chBars(id,rows,key,fmt,tipf){const n=rows.length,max=nice(Math.max(1,...rows.map(r=>r[key]))),bw=(CW-PL-PR)/n,hh=CH-PT-PB;
 let s='<svg viewBox="0 0 '+CW+' '+CH+'"><defs><linearGradient id="'+id+'B" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--ac)"/><stop offset="1" style="stop-color:var(--ac);stop-opacity:.18"/></linearGradient></defs>'+grid3(max,fmt);
 rows.forEach((r,i)=>{const h=Math.max(r[key]>0?3:1,r[key]/max*hh),x=PL+i*bw+bw*.17,w=bw*.66,y=PT+hh-h;
  s+='<rect class="cbar" style="animation-delay:'+(i*40)+'ms" x="'+x.toFixed(1)+'" y="'+y.toFixed(1)+'" width="'+w.toFixed(1)+'" height="'+h.toFixed(1)+'" rx="3" fill="url(#'+id+'B)"/>'+
  '<rect class="chit" data-tip="'+esc(tipf(r))+'" x="'+(PL+i*bw).toFixed(1)+'" y="'+PT+'" width="'+bw.toFixed(1)+'" height="'+hh+'"/>'+(i%2===0||n<8?'<text x="'+(x+w/2).toFixed(1)+'" y="'+(CH-5)+'" text-anchor="middle">'+dlab(r.d)+'</text>':"")});
 return s+"</svg>"}
function chLines(id,rows,series,fmt,tipf,ymax,lab){const n=rows.length,hh=CH-PT-PB,max=ymax||nice(Math.max(1,...series.flatMap(s=>rows.map(r=>r[s.k])))),X=i=>PL+4+i*(CW-PL-PR-8)/Math.max(1,n-1),Y=v=>PT+hh-v/max*hh;
 let s='<svg viewBox="0 0 '+CW+' '+CH+'"><defs>'+series.map((x,j)=>'<linearGradient id="'+id+'A'+j+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:'+x.c+';stop-opacity:.38"/><stop offset="1" style="stop-color:'+x.c+';stop-opacity:0"/></linearGradient>').join("")+'</defs>'+grid3(max,fmt);
 series.forEach((x,j)=>{const pts=rows.map((r,i)=>[X(i),Y(r[x.k])]),d=pts.map((p,i)=>(i?"L":"M")+p[0].toFixed(1)+" "+p[1].toFixed(1)).join(" ");
  if(x.area)s+='<path class="cfade" d="'+d+" L"+X(n-1).toFixed(1)+" "+(PT+hh)+" L"+X(0).toFixed(1)+" "+(PT+hh)+' Z" fill="url(#'+id+'A'+j+')"/>';
  s+='<path class="cln" d="'+d+'" fill="none" stroke="'+x.c+'" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>'});
 rows.forEach((r,i)=>{s+='<rect class="chit" data-tip="'+esc(tipf(r))+'" x="'+(X(i)-(CW/n)/2).toFixed(1)+'" y="'+PT+'" width="'+(CW/n).toFixed(1)+'" height="'+hh+'"/>';
  if(i%2===0||n<=8)s+='<text x="'+X(i).toFixed(1)+'" y="'+(CH-5)+'" text-anchor="middle">'+(lab?lab(r):dlab(r.d))+'</text>'});
 series.forEach(x=>{const l=rows[n-1];if(l)s+='<circle class="cdot cfade" style="stroke:'+x.c+'" cx="'+X(n-1).toFixed(1)+'" cy="'+Y(l[x.k]).toFixed(1)+'" r="3.6"/>'});
 return s+"</svg>"}
function drawCharts(d){const r=d.series||[],S=r.reduce((a,x)=>a+x.sales,0),O=r.reduce((a,x)=>a+x.orders,0),K=r.reduce((a,x)=>a+x.keys,0),U=r.reduce((a,x)=>a+x.used,0);
 $("ch_sales").innerHTML='<div class="chh"><b>'+inr(S)+'</b><small>'+O+' sales</small></div>'+chBars("cs",r,"sales",v=>v>=1000?Math.round(v/1000)+"k":Math.round(v),x=>dlab(x.d)+" · "+inr(x.sales)+" · "+x.orders+" sold");
 $("ch_keys").innerHTML='<div class="chh"><b>'+K+' <small>created</small></b><small>'+U+' used</small></div>'+chLines("ck",r,[{k:"keys",c:"var(--ac)",area:1},{k:"used",c:"#ffb84d"}],v=>Math.round(v),x=>dlab(x.d)+" · "+x.keys+" created · "+x.used+" used")+
  '<div class="cleg"><span><i style="background:var(--ac)"></i>Created</span><span><i style="background:#ffb84d"></i>Used</span></div>';
 const u=d.uptime||[];
 $("ch_up").innerHTML=u.length?'<div class="chh"><b>'+d.uptime_avg+'%</b><small>'+d.now.running+' / '+d.now.total+' running now</small></div>'+chLines("cu",u,[{k:"pct",c:"#4ade80",area:1}],v=>Math.round(v)+"%",x=>x.h+" · "+x.pct+"% up",100,x=>x.h.slice(0,2)):'<div class="help">Uptime is sampled every 5 minutes. The graph fills in shortly.</div>';
 animateCounters($("ch_sales"),".chh b");animateCounters($("ch_up"),".chh b")}
async function loadCharts(){const d=await A("/api/charts");if(d&&d.ok)drawCharts(d)}
function render(d){
 D=d;const t=d.totals;
 let al="";const wi='<svg class="i"><use href="#i-alert"/></svg>';
 if(!d.pay_ready)al+='<div class="warn">'+wi+'<span>Auto payment is not set up. Open <b>Settings</b> and add your FMPay key and UPI ID so buyers can pay on the website.</span></div>';
 if(d.pay_ready&&!d.plans.length)al+='<div class="warn">'+wi+'<span>Add at least one plan under <b>Sales &amp; plans</b> so buyers can purchase.</span></div>';
 $("alerts").innerHTML=al;$("nbots").textContent=t.bots;
 $("tot").innerHTML=kpi("Bot revenue",inr(t.revenue),"Today "+inr(t.today),1,"trend")+kpi("Key sales",inr(d.sales.total),"Today "+inr(d.sales.today)+" · "+d.sales.count+" sold",1,"wallet")+kpi("Hosted bots",t.bots,t.running+" running now",0,"bot")+kpi("Users / orders",t.users.toLocaleString("en-IN")+" / "+t.orders.toLocaleString("en-IN"),"Deposits "+inr(t.deposits),0,"users");
 animateCounters($("tot"));const s=d.server;$("srv").innerHTML=s?'<h4>'+IC("pulse")+'Server health</h4>'+meter("RAM",s.ram,s.ram+"%",70,88)+'<div class="hl"><span>Load</span><b>'+s.load+'</b></div><div class="hl" style="margin:7px 0 0"><span>Disk free</span><b>'+s.disk_free+' GB</b></div>':'';
 const mx=Math.max(1,...d.bots.map(b=>b.revenue));
 $("rev").innerHTML=d.bots.length?d.bots.slice().sort((a,b)=>b.revenue-a.revenue).slice(0,8).map((b,i)=>'<div class="rv"><div class="hl"><span><i class="rk">'+(i+1)+'</i>@'+esc(b.username)+'</span><b>'+inr(b.revenue)+'</b></div><div class="meter"><span style="width:'+Math.max(2,b.revenue/mx*100)+'%"></span></div></div>').join(""):'<div class="empty">No bots yet.</div>';
 $("plans").innerHTML=d.plans.map(p=>'<div class="tr"><div class="t"><b>'+esc(p.name)+'</b><small>'+(p.days>=36500?'Lifetime':p.days+' days')+'</small></div><span class="v">'+inr(p.price)+'</span><button class="sw2'+(p.active?' on':'')+'" data-pt="'+p.id+'" title="'+(p.active?'Visible on website':'Hidden')+'"></button><button class="mini x" data-pd="'+p.id+'" title="Delete">'+IC("x")+'</button></div>').join("")||'<div class="empty">No plans yet.</div>';
 $("orders").innerHTML=d.orders.length?d.orders.map(ordRow).join(""):'<div class="empty">No orders yet.</div>';
 $("ordersMini").innerHTML=d.orders.length?d.orders.slice(0,5).map(ordRow).join(""):'<div class="empty">No orders yet.</div>';
 drawBots();
 $("keys").innerHTML=d.keys.map(k=>'<div class="tr"><code class="keyc">'+esc(k.code)+'</code><div class="t">'+k.days+' days · '+(k.script==="*"?"All scripts":esc(scriptName(k.script)))+(k.note?'<small>'+esc(k.note)+'</small>':'')+'</div>'+
  (k.used_by?'<span class="badge stopped">used</span>':'<button class="mini" data-copy="'+esc(k.code)+'">'+IC("copy")+'</button><button class="mini x" data-kdel="'+esc(k.code)+'">'+IC("x")+'</button>')+'</div>').join("")||'<div class="empty">No keys yet.</div>';
 $("nscripts").textContent=d.scripts.length;$("scripts").innerHTML=d.scripts.map(scriptCard).join("")||'<div class="empty">No scripts yet.</div>';
 const sig=d.scripts.map(x=>x.id+x.usable+x.themes.length).join();
 if(sig!==SIG){SIG=sig;const us=d.scripts.filter(x=>x.usable);pkMount("o_pk",us);const bx=$("o_pk");
  if(bx._pk&&us.some(x=>x.id==="storebot")){bx._pk.s="storebot";pkDraw(bx)}
  const ks=$("k_script"),cur=ks.value;ks.innerHTML='<option value="*">All scripts (buyer picks one)</option>'+d.scripts.map(x=>'<option value="'+esc(x.id)+'">'+esc(x.name)+' only</option>').join("");
  ks.value=[...ks.options].some(o=>o.value===cur)?cur:"*"}
 $("act").innerHTML=d.activity.map(actRow).join("")||'<div class="empty">Nothing yet.</div>';
 $("actMini").innerHTML=d.activity.slice(0,6).map(actRow).join("")||'<div class="empty">Nothing yet.</div>';
 LAST=Date.now();tick()}
function tick(){if(!LAST)return;const s=Math.round((Date.now()-LAST)/1000);$("liveT").textContent="Live · updated "+(s<5?"just now":s+"s ago")}
setInterval(tick,1000);
async function load(){const d=await A("/api/stats");if(d.ok)render(d)}
$("q").oninput=drawBots;
$("chips").onclick=e=>{const c=e.target.closest("[data-st]");if(!c)return;$("fs").value=c.dataset.st;drawBots()};
document.addEventListener("click",async e=>{
 const c=e.target.closest("[data-copy]");if(c){copy(c.dataset.copy);return}
 const kd=e.target.closest("[data-kdel]");if(kd){await A("/api/keys/"+kd.dataset.kdel+"/delete",{});load();return}
 const pt=e.target.closest("[data-pt]");if(pt){await A("/api/plans",{action:"toggle",id:+pt.dataset.pt});load();return}
 const pd=e.target.closest("[data-pd]");if(pd){if(confirm("Delete this plan?")){await A("/api/plans",{action:"delete",id:+pd.dataset.pd});load()}return}
 const b=e.target.closest("[data-a]");if(!b)return;const id=b.dataset.id,a=b.dataset.a;
 if(a==="log"){const j=await A("/api/bot/"+id+"/log");$("lt").textContent="Logs";$("lp").textContent=j.log||"";$("lm").classList.add("on");$("lp").scrollTop=1e9;return}
 if(a==="dbdl"){location.href="/api/bot/"+id+"/dbdownload";return}
 if(a==="dbup"){DBID=id;$("dm_t").textContent="Database · @"+b.dataset.n;$("dm_msg").textContent="";$("dm_msg").className="msg";$("dm").classList.add("on");return}
 if(a==="demoreset"){if(!confirm("Restore the demo template now? All current data of this bot is replaced."))return;const j=await A("/api/bot/"+id+"/demo",{action:"reset"});toast(j.message);load();return}
 if(a==="demo"){const bb=D.bots.find(x=>String(x.id)===String(id));
  if(bb.demo){if(!confirm("Turn demo mode OFF for @"+bb.username+"?"))return;const j=await A("/api/bot/"+id+"/demo",{action:"off"});toast(j.message);load();return}
  const v=prompt("Demo mode: reset this bot's data every how many minutes?","10");if(!v)return;
  let use=false;if(!bb.demo_tpl){if(!confirm("No demo template yet. Save this bot's CURRENT data as the template?"))return;use=true}
  if(!confirm("Demo mode wipes ALL data of @"+bb.username+" every "+v+" min and restores the template. Use it only on a demo bot. Continue?"))return;
  const j=await A("/api/bot/"+id+"/demo",{action:"on",minutes:parseInt(v,10),confirm:true,use_current:use});toast(j.message);load();return}
 let body={};
 if(a==="delete"&&!confirm("Delete @"+b.dataset.n+" and ALL its data (users, orders)? This cannot be undone."))return;
 if(a==="suspend"&&!confirm("Suspend @"+b.dataset.n+"? The bot stops and the user cannot start it."))return;
 if(a==="extend"){const v=prompt("Add how many days? (negative to remove)","30");if(!v)return;body={days:parseInt(v,10)}}
 b.disabled=true;const j=await A("/api/bot/"+id+"/"+a,body);toast(j.message||"Done");load()});
document.querySelectorAll(".modal").forEach(m=>m.addEventListener("mousedown",e=>{if(e.target===m&&m.id!=="sm")m.classList.remove("on")}));
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.querySelectorAll(".modal.on").forEach(m=>m.classList.remove("on"))});
$("lc").onclick=()=>$("lm").classList.remove("on");
$("dm_close").onclick=()=>$("dm").classList.remove("on");
$("dm_go").onclick=async()=>{const f=$("dm_file").files[0],m=$("dm_msg");if(!f){m.className="msg err";m.textContent="Choose a .db file first.";return}
 const mode=$("dm_mode").value;if(mode==="apply"&&!confirm("Replace this bot's data with the uploaded database? The bot restarts."))return;
 const fd=new FormData();fd.append("file",f);fd.append("mode",mode);fd.append("keep_settings",$("dm_keep").checked?"1":"0");
 $("dm_go").disabled=true;m.className="msg";m.textContent="Uploading…";const j=await UP("/api/bot/"+DBID+"/dbupload",fd,CSRF);$("dm_go").disabled=false;
 m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";if(j.ok){$("dm_file").value="";load()}};
document.addEventListener("click",async e=>{const b=e.target.closest("[data-sa]");if(!b)return;const a=b.dataset.sa,id=b.dataset.sid;
 if(a==="log"){const j=await A("/api/scripts/"+id+"/log",{});$("lt").textContent="Install log · "+id;$("lp").textContent=j.log||"";$("lm").classList.add("on");$("lp").scrollTop=1e9;return}
 if(a==="delete"&&!confirm("Delete script "+id+" and its libraries?"))return;
 if(a==="reinstall"&&!confirm("Reinstall the libraries of "+id+"? This can take a minute."))return;
 b.disabled=true;const j=await A("/api/scripts/"+id+"/"+a,{});toast(j.message||"Done");load()});
$("sz_go").onclick=async()=>{const f=$("sz_file").files[0],m=$("sz_msg");if(!f){m.className="msg err";m.textContent="Choose a .zip file first.";return}
 const fd=new FormData();fd.append("file",f);$("sz_go").disabled=true;m.className="msg";m.textContent="Uploading…";
 const j=await UP("/api/scripts/upload",fd,CSRF);$("sz_go").disabled=false;m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";if(j.ok){$("sz_file").value="";load()}};
$("sf_go").onclick=async()=>{const m=$("sf_msg"),id=$("sf_id").value.trim();if(!id){m.className="msg err";m.textContent="Enter a script id.";return}
 const fd=new FormData();fd.append("id",id);fd.append("name",$("sf_name").value);fd.append("description",$("sf_desc").value);
 const b=$("sf_bot").files[0],r=$("sf_req").files[0],mt=$("sf_meta").files[0];if(b)fd.append("bot",b);if(r)fd.append("req",r);if(mt)fd.append("meta",mt);
 for(const t of $("sf_themes").files)fd.append("themes",t);
 $("sf_go").disabled=true;m.className="msg";m.textContent="Uploading…";
 const j=await UP("/api/scripts/files",fd,CSRF);$("sf_go").disabled=false;m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";
 if(j.ok){["sf_bot","sf_req","sf_themes","sf_meta"].forEach(x=>$(x).value="");load()}};
$("rall").onclick=async()=>{if(!confirm("Restart every hosted bot with the latest template?"))return;const j=await A("/api/restart_all",{});toast(j.message);load()};
$("o_go").onclick=async()=>{const m=$("o_msg");m.className="msg";m.textContent="Starting…";$("o_go").disabled=true;
 const j=await A("/api/deploy_owner",Object.assign({token:$("o_token").value.trim(),admin:$("o_admin").value,days:parseInt($("o_days").value,10)||0},pkGet("o_pk")));
 m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";if(j.ok){$("o_token").value="";$("o_admin").value=""}$("o_go").disabled=false;load()};
$("k_go").onclick=async()=>{const m=$("k_msg");const j=await A("/api/keys",{days:parseInt($("k_days").value,10),count:parseInt($("k_count").value,10),note:$("k_note").value,script:$("k_script").value});
 m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";load()};
$("p_go").onclick=async()=>{const j=await A("/api/plans",{action:"add",name:$("p_name").value,days:parseInt($("p_days").value,10),price:parseFloat($("p_price").value)});
 toast(j.message||"Done");if(j.ok){$("p_name").value=$("p_days").value=$("p_price").value=""}load()};
$("b_go").onclick=async()=>{const t=$("b_text").value.trim();if(!t)return;if(!confirm("Send this message to every bot owner?"))return;
 const j=await A("/api/broadcast",{text:t});toast(j.message);if(j.ok)$("b_text").value=""};

/* settings */
function applyTheme(id){THEME=id;const t=S.themes[id];if(!t)return;const r=document.documentElement.style;
 ["bg","s1","s2","line","tx","mu","ac","red","glow"].forEach(k=>r.setProperty("--"+k,t[k]));
 const ac=$("s_accent").dataset.set==="1"?$("s_accent").value:t.ac;applyAccent(ac);
 document.querySelectorAll("#sw button").forEach(b=>b.classList.toggle("on",b.dataset.t===id))}
function applyAccent(c){const r=document.documentElement.style;r.setProperty("--ac",c);
 const n=parseInt(c.slice(1),16),R=n>>16,G=(n>>8)&255,B=n&255;r.setProperty("--acrgb",R+","+G+","+B);
 r.setProperty("--act",(0.299*R+0.587*G+0.114*B)>150?"#0b0f0a":"#ffffff")}
$("s_accent").oninput=()=>{$("s_accent").dataset.set="1";applyAccent($("s_accent").value)};
$("s_accclr").onclick=()=>{$("s_accent").dataset.set="";applyTheme(THEME)};
$("sw").onclick=e=>{const b=e.target.closest("[data-t]");if(b)applyTheme(b.dataset.t)};
async function openSettings(){const d=await A("/api/settings");if(!d.ok)return;S=d;const v=d.values;
 $("sw").innerHTML=Object.entries(d.themes).map(([k,t])=>'<button data-t="'+k+'"><i><s style="background:'+t.bg+'"></s><s style="background:'+t.s2+'"></s><s style="background:'+t.ac+'"></s></i>'+esc(t.name)+'</button>').join("");
 $("s_accent").dataset.set=v.accent?"1":"";$("s_accent").value=v.accent||d.themes[v.theme||"lime"].ac;
 $("s_brand").value=v.brand;$("s_logo").value=v.logo;$("s_tag").value=v.tagline;$("s_inv_name").value=v.inv_name||"";$("s_inv_addr").value=v.inv_addr||"";$("s_inv_gstin").value=v.inv_gstin||"";$("s_inv_note").value=v.inv_note||"";$("s_support").value=v.support_link;
 $("s_fmkey").value="";$("s_fmkey").placeholder=v.fmpay_key_mask||"FMPay API key";$("s_fmurl").value=v.fmpay_url;$("s_upi").value=v.upi_id;$("s_upiname").value=v.upi_name;
 $("s_tgid").value=v.owner_tg;$("s_tgtoken").value="";$("s_tgtoken").placeholder=v.alert_token_mask||"Alert bot token (any bot you own)";
 $("s_alerts").checked=v.alerts_on==="1";$("s_2fa").checked=v.twofa==="1";
 THEME=v.theme||"lime";applyTheme(THEME);brandPrev(v);$("sm").classList.add("on");loadBackup()}
let BKIND="";
function brandPrev(v){
 const L=v.logo_img,F=v.fav_img;
 $("bi_logo").innerHTML=L?'<img class="pv" src="'+esc(L)+'" alt="">':'<div class="logo" id="bp_logo">'+esc(v.logo||"B")+'</div>';
 $("bp_fav").style.backgroundImage=(F||L)?'url("'+esc(F||L)+'")':"none";
 $("br_logo").style.display=L?"":"none";$("br_fav").style.display=F?"":"none"}
$("bu_logo").onclick=()=>{BKIND="logo";$("bf_file").click()};
$("bu_fav").onclick=()=>{BKIND="favicon";$("bf_file").click()};
$("bf_file").onchange=async()=>{const f=$("bf_file").files[0];if(!f)return;const fd=new FormData();fd.append("kind",BKIND);fd.append("file",f);
 const j=await UP("/api/brand/upload",fd,CSRF);$("bf_file").value="";toast(j.message||"Done");
 if(j.ok){const d=await A("/api/settings");if(d.ok){S=d;brandPrev(d.values)}}};
$("br_logo").onclick=async()=>{const j=await A("/api/brand/remove",{kind:"logo"});toast(j.message);const d=await A("/api/settings");if(d.ok){S=d;brandPrev(d.values)}};
$("br_fav").onclick=async()=>{const j=await A("/api/brand/remove",{kind:"favicon"});toast(j.message);const d=await A("/api/settings");if(d.ok){S=d;brandPrev(d.values)}};
async function loadBackup(){const d=await A("/api/backup/info");if(!d.ok)return;
 $("bk_hours").value=d.hours;
 $("bk_info").innerHTML=(d.last?'Last backup: <b>'+esc(d.last)+'</b>. ':'No backup yet. ')+esc(d.msg||"")+(d.tg?'':' <b>Telegram not set up</b> (see section above) - backups are only kept on this server until you do.');
 $("bk_list").innerHTML=d.files.length?'Saved on this server: '+d.files.map(f=>'<a style="color:var(--ac)" href="/admin/backup/file/'+encodeURIComponent(f.name)+'">'+esc(f.t)+' ('+f.kb+' KB)</a>').join(" · "):""}
$("bk_hours").onchange=async()=>{const j=await A("/api/backup/settings",{hours:$("bk_hours").value});toast(j.message)};
$("bk_now").onclick=async()=>{const b=$("bk_now");b.disabled=true;toast("Making backup…");const j=await A("/api/backup/now",{});b.disabled=false;toast(j.message);loadBackup()};
$("bk_restore").onclick=async()=>{const f=$("bk_file").files[0];if(!f){toast("Choose the backup file first");return}
 if($("bk_confirm").value!=="RESTORE"){toast("Type RESTORE to confirm");return}
 if(!confirm("This REPLACES all bots, scripts, keys, orders and settings on this server with the backup. Continue?"))return;
 const fd=new FormData();fd.append("file",f);fd.append("confirm","RESTORE");$("bk_restore").disabled=true;toast("Restoring…");
 const j=await UP("/api/backup/restore",fd,CSRF);$("bk_restore").disabled=false;const m=$("s_msg");m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";
 if(j.ok)setTimeout(()=>location.href="/admin/login",6000)};
$("setb").onclick=openSettings;$("setb2").onclick=openSettings;
$("sc").onclick=()=>{$("sm").classList.remove("on");location.reload()};
$("s_save").onclick=async()=>{const m=$("s_msg");
 const body={theme:THEME,accent:$("s_accent").dataset.set==="1"?$("s_accent").value:"",brand:$("s_brand").value,logo:$("s_logo").value,tagline:$("s_tag").value,inv_name:$("s_inv_name").value,inv_addr:$("s_inv_addr").value,inv_gstin:$("s_inv_gstin").value,inv_note:$("s_inv_note").value,support_link:$("s_support").value,
  fmpay_key:$("s_fmkey").value.trim(),fmpay_url:$("s_fmurl").value,upi_id:$("s_upi").value,upi_name:$("s_upiname").value,owner_tg:$("s_tgid").value,alert_token:$("s_tgtoken").value.trim(),
  alerts_on:$("s_alerts").checked?"1":"0",twofa:$("s_2fa").checked?"1":"0"};
 const j=await A("/api/settings",body);m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";if(j.ok){toast("Saved");setTimeout(()=>location.reload(),700)}};
$("s_tgtest").onclick=async()=>{const m=$("s_msg");m.className="msg";m.textContent="Saving and sending…";
 const j=await A("/api/tgtest",{owner_tg:$("s_tgid").value,alert_token:$("s_tgtoken").value.trim()});m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||""};
$("pw_go").onclick=async()=>{const j=await A("/api/password",{old:$("pw_old").value,new:$("pw_new").value});toast(j.message);if(j.ok){$("pw_old").value=$("pw_new").value=""}};
show((location.hash||"").slice(1));
load();setInterval(load,8000);loadCharts();setInterval(loadCharts,60000);
</script></body></html>"""


# ───────────────────────── customer portal (premium) ─────────────────────────
USR_CSS = r"""
.adm .uhero{display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:22px;align-items:center}
.adm .uhero .ring{width:112px;height:112px}
.adm .uhero h2{margin:0 0 8px;font-size:20px;letter-spacing:-.4px;display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.adm .uhero .sub{color:var(--mu);font-size:12.5px;font-weight:600;line-height:1.7}
.adm .uhero .acts{justify-content:flex-end;flex-direction:column;align-items:stretch;min-width:150px}
.adm .uhero .acts button{justify-content:center;padding:10px 14px}
.adm .hsc{display:flex;gap:18px;align-items:center}
.adm .gauge{width:132px;height:132px;flex:none}
.adm .gauge circle{fill:none;stroke-width:9}
.adm .gauge .gb{stroke:var(--s2)}
.adm .gauge .gf{stroke:var(--ok);stroke-linecap:round;transition:stroke-dasharray .8s}
.adm .gauge.good .gf{stroke:var(--ac)}.adm .gauge.wr .gf{stroke:var(--warn)}.adm .gauge.bad .gf{stroke:var(--bad)}
.adm .gauge text{fill:var(--tx);font-size:26px;font-weight:900;font-family:inherit}
.adm .gauge tspan{fill:var(--mu);font-size:7.5px;font-weight:800;letter-spacing:.8px}
.adm .hsc h3{margin:0 0 4px;font-size:20px;letter-spacing:-.4px}
.adm .hsc p{margin:0;color:var(--mu);font-size:13px;line-height:1.55}
.adm .tiles{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:18px}
.adm .tile{border:1px solid var(--hair);background:rgba(255,255,255,.03);border-radius:14px;padding:13px}
.adm .tile small{display:flex;align-items:center;gap:7px;color:var(--mu);font-size:10.5px;font-weight:800;letter-spacing:.7px;text-transform:uppercase}
.adm .tile b{display:block;font-size:19px;margin-top:7px;font-variant-numeric:tabular-nums;letter-spacing:-.3px}
.adm .ci{width:30px;height:30px;border-radius:10px;display:grid;place-items:center;flex:none}
.adm .ci.ok{background:rgba(var(--okrgb),.14);color:var(--ok)}.adm .ci.wr{background:rgba(251,191,36,.14);color:var(--warn)}.adm .ci.fail{background:rgba(var(--badrgb),.14);color:var(--bad)}.adm .ci.skip{background:rgba(139,147,171,.16);color:var(--mu)}
.adm .hc{display:flex;gap:13px;align-items:center;padding:13px 2px;border-top:1px solid var(--hair)}
.adm .hc:first-child{border-top:0}
.adm .hc .t{flex:1;min-width:0}.adm .hc .t b{display:block;font-size:13.5px}.adm .hc .t small{display:block;color:var(--mu);font-size:12px;margin-top:2px;line-height:1.5}
.adm .pills{display:flex;flex-wrap:wrap;gap:8px}
.adm .pl2{display:inline-flex;align-items:center;gap:7px;border:1px solid var(--hair);border-radius:999px;padding:7px 12px;font-size:12px;font-weight:700;background:rgba(255,255,255,.03)}
.adm .pl2:before{content:"";width:7px;height:7px;border-radius:50%;background:var(--mu)}
.adm .pl2.ok:before{background:var(--ok)}.adm .pl2.wr:before{background:var(--warn)}.adm .pl2.fail:before{background:var(--bad)}
.adm .errbox{margin-top:14px;padding:12px 14px;border-radius:12px;border:1px solid rgba(var(--badrgb),.3);background:rgba(var(--badrgb),.08);font-size:12px;font-family:ui-monospace,Menlo,Consolas,monospace;color:var(--bad);word-break:break-all;line-height:1.5}
.adm .logbar{display:flex;gap:10px;align-items:center;margin-bottom:12px;flex-wrap:wrap}
.adm .logbar .sp{flex:1}
.adm .logbar label{display:flex;gap:8px;align-items:center;font-size:12.5px;font-weight:700;color:var(--mu);cursor:pointer}
.adm .logbar input{accent-color:var(--ac)}
.adm pre#lp2{max-height:46vh;margin:0;font-size:11.5px}
.adm .plansum{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-bottom:16px}
.adm .upl{border:1.5px dashed var(--line);border-radius:14px;padding:18px;text-align:center;margin-bottom:12px;cursor:pointer;transition:.15s;color:var(--mu);font-size:13px;font-weight:600}
.adm .upl:hover,.adm .upl.drag{border-color:var(--ac);background:rgba(var(--acrgb),.06)}
.adm .upl b{display:block;color:var(--tx);margin-bottom:3px}
.adm .plans{grid-template-columns:repeat(auto-fit,minmax(150px,1fr))}
.adm .plan{background:rgba(255,255,255,.03)}
@media(max-width:900px){.adm .uhero{grid-template-columns:auto 1fr}.adm .uhero .acts{grid-column:1/-1;flex-direction:row;flex-wrap:wrap}.adm .uhero .acts button{flex:1}.adm .tiles{grid-template-columns:repeat(2,minmax(0,1fr))}.adm .hsc{flex-direction:column;align-items:flex-start}}
@media(max-width:520px){.adm .uhero .ring{width:88px;height:88px}.adm .plansum{grid-template-columns:1fr 1fr}.adm .plansum>:first-child{grid-column:1/-1}}
"""

USR_ICONS = r"""<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
<symbol id="i-check" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></symbol>
<symbol id="i-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></symbol>
<symbol id="i-cpu" viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/></symbol>
<symbol id="i-db" viewBox="0 0 24 24"><ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/></symbol>
<symbol id="i-heart" viewBox="0 0 24 24"><path d="M12 21s-8-5.2-8-11a4.5 4.5 0 018-2.8A4.5 4.5 0 0120 10c0 5.8-8 11-8 11z"/></symbol>
<symbol id="i-card" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18M7 15h4"/></symbol>
<symbol id="i-ram" viewBox="0 0 24 24"><rect x="3" y="7" width="18" height="10" rx="2"/><path d="M7 11v2M11 11v2M15 11v2M7 17v3M12 17v3M17 17v3"/></symbol>
<symbol id="i-sig" viewBox="0 0 24 24"><path d="M4 20v-4M9 20v-8M14 20V8M19 20V4"/></symbol>
<symbol id="i-bolt" viewBox="0 0 24 24"><path d="M13 3L5 14h6l-1 7 8-11h-6z"/></symbol>
</defs></svg>"""

USR_HEAD = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><link rel="icon" href="__FAVICON__"><meta name="theme-color" content="#07090f"><title>__TITLE__ · __BRAND__</title><style>""" + CSS + ADM_CSS + USR_CSS + r"""__THEME__</style></head>"""

# ───────────────────────── customer login ─────────────────────────
USER_LOGIN = USR_HEAD + r"""<body class="adm lg">""" + ADM_ICONS + USR_ICONS + r"""
<div class="lgl">
 <div class="brand" style="padding:0"><div class="logo">__LOGO__</div><div><b>__BRAND__</b><small>Customer portal</small></div></div>
 <div><h2>Your store bot,<br>always <span class="grad">online and healthy</span>.</h2></div>
 <p>Track your bot's health, control it, manage your database and renew your plan, all in one clean dashboard.</p>
 <div class="lgf">
  <div><i>""" + _ic("heart") + r"""</i>Live bot health and uptime</div>
  <div><i>""" + _ic("db") + r"""</i>Database upload, download and CSV export</div>
  <div><i>""" + _ic("card") + r"""</i>Easy online renewal with UPI</div>
 </div>
</div>
<div class="lgr"><div class="lgc">
 <div class="logo">__LOGO__</div>
 <h1>Welcome back</h1><p class="sub">Sign in with the access key you used to launch your bot.</p>
 <label class="fl">Access key</label>
 <input class="inp" id="key" placeholder="XXXX-XXXX-XXXX-XXXX" autocomplete="off" autocapitalize="characters" autofocus style="letter-spacing:1px">
 <button class="big" id="go" type="button">Sign in</button>
 <div class="msg err" id="msg"></div>
 <div class="secure" style="margin-top:20px"><a style="color:var(--ac);font-weight:700;text-decoration:none" href="/">Buy a key or launch a bot</a></div>
</div></div>
<div class="toast" id="toast"></div>
<script>""" + JS_COMMON + r"""
$("go").onclick=async()=>{const m=$("msg");m.className="msg err";m.textContent="";$("go").disabled=true;
 const j=await J("/api/user/login",{key:$("key").value});
 if(j.ok)location.href="/dashboard";else{m.textContent=j.message||"Login failed."}$("go").disabled=false};
$("key").addEventListener("keydown",e=>{if(e.key==="Enter")$("go").click()});
</script></body></html>"""

# ───────────────────────── customer dashboard ─────────────────────────
USER_DASH = USR_HEAD + r"""<body class="adm">""" + ADM_ICONS + USR_ICONS + r"""
<div class="shell">
<aside class="side">
 <div class="brand"><div class="logo">__LOGO__</div><div><b>__BRAND__</b><small>Customer portal</small></div></div>
 <div class="navg">My bot</div>
 <button class="nv on" data-v="ov">""" + _ic("home") + r"""Overview</button>
 <button class="nv" data-v="hl">""" + _ic("heart") + r"""Bot health<em id="nh" style="display:none"></em></button>
 <button class="nv" data-v="st">""" + _ic("gear") + r"""Bot settings</button>
 <button class="nv" data-v="db">""" + _ic("db") + r"""Database</button>
 <button class="nv" data-v="pl">""" + _ic("card") + r"""Plan &amp; billing</button>
 <div class="sp"></div>
 <div class="health" id="sidehealth"></div>
 <a class="nv" href="/logout">""" + _ic("out") + r"""Logout</a>
</aside>

<main class="main">
 <div class="bar-top">
  <div style="flex:1;min-width:0"><h1 id="ttl">Overview</h1><p><i class="live"></i><span id="liveT">Syncing…</span></p></div>
  <a class="tbtn ic mob" href="/logout" title="Logout">""" + _ic("out") + r"""</a>
 </div>
 <div id="susp"></div>

 <section class="view on" id="v-ov">
  <div class="card"><div class="uhero" id="hero"></div></div>
  <div class="grid" id="kp"></div>
  <div class="g2e">
   <div class="card"><h2><span class="hi">""" + _ic("heart", "i s") + r"""</span>Health at a glance<span class="r"><a href="#hl" data-v="hl" style="color:var(--ac);text-decoration:none">Details</a></span></h2><div id="hmini" class="pills"></div></div>
   <div class="card"><h2><span class="hi">""" + _ic("bolt", "i s") + r"""</span>Quick actions</h2><div class="acts">
     <button onclick="location.href='/api/user/export/users.csv'">""" + _ic("down") + r"""Users CSV</button>
     <button onclick="location.href='/api/user/export/orders.csv'">""" + _ic("down") + r"""Orders CSV</button>
     <button data-v="hl" id="qlog">""" + _ic("file") + r"""View logs</button>
     <button data-v="pl">""" + _ic("card") + r"""Renew plan</button></div></div>
  </div>
 </section>

 <section class="view" id="v-hl">
  <div class="card">
   <div class="hsc" id="hsc"></div>
   <div class="tiles" id="tiles"></div>
  </div>
  <div class="g2e">
   <div class="card"><h2><span class="hi">""" + _ic("shield", "i s") + r"""</span>System checks</h2><div id="checks"></div><div id="errbox"></div></div>
   <div class="card"><h2><span class="hi">""" + _ic("file", "i s") + r"""</span>Live bot log</h2>
    <div class="logbar"><button class="tbtn" id="logr" type="button">""" + _ic("refresh") + r"""<span style="display:inline">Refresh</span></button><label><input type="checkbox" id="logauto" checked> Auto-refresh</label><span class="sp"></span></div>
    <pre id="lp2">Loading…</pre></div>
  </div>
 </section>

 <section class="view" id="v-st">
  <div class="card" id="th_card" style="display:none"><h2><span class="hi">""" + _ic("bolt", "i s") + r"""</span>Bot theme<span class="r" id="th_script"></span></h2>
   <div class="help" style="margin-bottom:12px">Pick how your bot looks (welcome text, buttons). The bot restarts for a moment when you change it.</div>
   <div class="pkt" id="th_box"></div></div>
  <div class="g2e">
   <div class="card"><h2><span class="hi">""" + _ic("key", "i s") + r"""</span>Bot token</h2><div class="help" style="margin-bottom:12px">Paste a new token from @BotFather. If it is a different bot, your store data stays safe, but customers must start the new bot.</div>
    <input class="inp" id="n_token" placeholder="New bot token" autocomplete="off" spellcheck="false"><button class="big" data-do="token">Change token</button></div>
   <div class="card"><h2><span class="hi">""" + _ic("shield", "i s") + r"""</span>Admin IDs</h2><div class="help" style="margin-bottom:12px">Numeric Telegram IDs. Use commas for more than one.</div>
    <input class="inp" id="n_admin" placeholder="Admin Telegram ID(s)" inputmode="numeric"><button class="big" data-do="admin">Save admin IDs</button></div>
  </div>
  <div class="card"><h2><span class="hi">""" + _ic("tag", "i s") + r"""</span>Store details</h2>
   <div class="row2"><div><label class="fl">Store name</label><input class="inp" id="n_name" placeholder="Store name" maxlength="40"></div><div><label class="fl">Support username</label><input class="inp" id="n_support" placeholder="@name" maxlength="33"></div></div>
   <button class="big" data-do="store">Save store details</button></div>
 </section>

 <section class="view" id="v-db">
  <div class="g2e">
   <div class="card"><h2><span class="hi">""" + _ic("up", "i s") + r"""</span>Upload database</h2>
    <div class="help" style="margin-bottom:14px">Upload a store database (.db). Your bot becomes exactly like it: users, products, plans and orders. Your current data is backed up first.</div>
    <label class="upl" id="drop"><input type="file" id="db_file" accept=".db,.sqlite,.sqlite3" style="display:none"><b id="db_name">Choose a .db file</b>or drop it here · max 25 MB</label>
    <label class="chk"><input type="checkbox" id="db_keep" checked> Keep my current settings (UPI, store name)</label>
    <button class="big" id="db_go" type="button">Upload &amp; apply</button><div class="help" id="db_demo" style="margin-top:10px"></div></div>
   <div class="card"><h2><span class="hi">""" + _ic("down", "i s") + r"""</span>Download &amp; export</h2>
    <div class="help" style="margin-bottom:14px">Your data stays yours. Download a full copy any time.</div>
    <div style="display:grid;gap:10px"><button class="big alt" id="db_dl" type="button">Download my database</button>
    <button class="big alt" onclick="location.href='/api/user/export/users.csv'">Export users (CSV)</button>
    <button class="big alt" onclick="location.href='/api/user/export/orders.csv'">Export orders (CSV)</button></div></div>
  </div>
 </section>

 <section class="view" id="v-pl">
  <div class="plansum" id="plansum"></div>
  <div class="g2e">
   <div class="card"><h2><span class="hi">""" + _ic("key", "i s") + r"""</span>Renew with a key</h2><div class="help" style="margin-bottom:12px">Have a new access key? Paste it here to extend your plan.</div>
    <input class="inp" id="n_key" placeholder="New access key" autocapitalize="characters" autocomplete="off"><button class="big alt" data-do="renew_key">Apply key</button></div>
   <div class="card"><h2><span class="hi">""" + _ic("card", "i s") + r"""</span>Renew online</h2><div class="plans" id="plans"></div></div>
  </div>
  """ + PAYBOX + r"""
 </section>
 <div class="msg" id="msg"></div>
</main>
</div>

<nav class="mnav">
 <button class="on" data-v="ov">""" + _ic("home") + r"""Home</button>
 <button data-v="hl">""" + _ic("heart") + r"""Health</button>
 <button data-v="st">""" + _ic("gear") + r"""Settings</button>
 <button data-v="db">""" + _ic("db") + r"""Data</button>
 <button data-v="pl">""" + _ic("card") + r"""Plan</button>
</nav>
<div class="toast" id="toast"></div>
<script>const CSRF="__CSRF__";""" + JS_COMMON + PAYJS + r"""
var PLANS=[];PAYMODE_RENEW=true;
const U=(url,body)=>J(url,body,CSRF);
const IC=n=>'<svg class="i s"><use href="#i-'+n+'"/></svg>';
let B=null,H=null,LAST=0,CV="ov";
const TITLES={ov:"Overview",hl:"Bot health",st:"Bot settings",db:"Database",pl:"Plan & billing"};
function tab(v){if(v==="plan")v="pl";if(!TITLES[v])v="ov";CV=v;
 document.querySelectorAll(".view").forEach(e=>e.classList.toggle("on",e.id==="v-"+v));
 document.querySelectorAll("[data-v]").forEach(e=>{if(e.matches(".nv,.mnav button"))e.classList.toggle("on",e.dataset.v===v)});
 $("ttl").textContent=TITLES[v];try{history.replaceState(null,"","#"+v)}catch(e){}window.scrollTo(0,0);if(v==="hl")loadLog()}
document.addEventListener("click",e=>{const t=e.target.closest("[data-v]");if(t){e.preventDefault();tab(t.dataset.v)}},true);
const fmtUp=s=>{s=Math.floor(s);if(s<60)return s+"s";const m=Math.floor(s/60);if(m<60)return m+"m";const h=Math.floor(m/60);if(h<24)return h+"h "+(m%60)+"m";const d=Math.floor(h/24);return d+"d "+(h%24)+"h"};
const kpi=(l,v,s,hot,ic)=>'<div class="kpi'+(hot?' hot':'')+'"><div class="kh"><span class="ki">'+IC(ic)+'</span>'+l+'</div><b>'+v+'</b><i>'+s+'</i></div>';
function ring(d){const dl=d.days_left,ex=!!d.expires,bad=ex&&dl<0,pct=ex?Math.max(0,Math.min(100,dl/d.plan_days*100)):100,C=2*Math.PI*34,cls=bad?"bad":(ex&&dl<=7?"low":"");
 return '<svg class="ring '+cls+'" viewBox="0 0 80 80"><circle class="rg-bg" cx="40" cy="40" r="34"/><circle class="rg-fg" cx="40" cy="40" r="34" stroke-dasharray="'+(C*pct/100)+' '+C+'" transform="rotate(-90 40 40)"/><text x="40" y="43" text-anchor="middle">'+(ex?Math.max(0,Math.ceil(dl)):"∞")+'<tspan x="40" y="55">'+(ex?"DAYS":"LIFETIME")+'</tspan></text></svg>'}
function fillEdit(d){$("n_admin").value=d.admin_ids;$("n_name").value=d.store_name||"";$("n_support").value=d.support||""}
function render(d){
 B=d;const dl=d.days_left,ex=!!d.expires,low=ex&&dl>=0&&dl<=3,bad=ex&&dl<0,wi='<svg class="i"><use href="#i-alert"/></svg>';
 $("susp").innerHTML=d.suspended?'<div class="warn">'+wi+'<span>This bot is suspended by the owner. Contact support.</span></div>':(bad?'<div class="warn">'+wi+'<span>Your plan has expired and the bot is stopped. Open <b>Plan &amp; billing</b> to renew.</span></div>':(low?'<div class="warn">'+wi+'<span>Your plan ends in '+Math.max(1,Math.ceil(dl))+' day(s). Renew now to avoid downtime.</span></div>':""));
 const left=ex?(dl>=0?Math.ceil(dl)+" days left":"Expired"):"Lifetime";
 $("hero").innerHTML=ring(d)+'<div style="min-width:0"><h2>@'+esc(d.username)+'<span class="badge '+d.status+'">'+d.status+'</span></h2><div class="sub">'+esc(d.store_name||"My store")+' · '+esc(d.script_name||"")+' · '+left+'<br>Key '+esc(d.key||"")+' · '+(ex?"Expires "+esc(String(d.expires).slice(0,10)):"Never expires")+'</div></div>'+
  '<div class="acts"><button class="g" data-do="start">'+IC("play")+'Start</button><button data-do="restart">'+IC("refresh")+'Restart</button><button data-do="stop">'+IC("stop")+'Stop</button></div>';
 $("kp").innerHTML=kpi("Revenue",inr(d.revenue),"Today "+inr(d.today),1,"trend")+kpi("Orders",d.orders.toLocaleString("en-IN"),"Deposits "+inr(d.deposits),0,"cart")+kpi("Users",d.users.toLocaleString("en-IN"),"Registered buyers",0,"users")+kpi("Plan",left,ex?"Expires "+esc(String(d.expires).slice(0,10)):"Never expires",0,"clock");
 $("plansum").innerHTML='<div class="kpi hot"><div class="kh"><span class="ki">'+IC("card")+'</span>Current plan</div><b>'+left+'</b><i>'+(ex?"Expires "+esc(String(d.expires).slice(0,16))+" UTC":"No expiry")+'</i></div>'+
  '<div class="kpi"><div class="kh"><span class="ki">'+IC("bot")+'</span>Status</div><b style="text-transform:capitalize">'+d.status+'</b><i>@'+esc(d.username)+'</i></div>'+
  '<div class="kpi"><div class="kh"><span class="ki">'+IC("key")+'</span>Access key</div><b style="font-size:15px;word-break:break-all">'+esc(d.key||"-")+'</b><i>Your dashboard login</i></div>';
 $("th_card").style.display=(d.themes||[]).length>1?"":"none";$("th_script").textContent=d.script_name||"";
 $("th_box").innerHTML=(d.themes||[]).map(t=>'<button type="button" data-do="theme" data-th="'+esc(t.id)+'" class="'+(t.id===d.theme?"on":"")+'" title="'+esc(t.description||"")+'">'+esc(t.emoji)+" "+esc(t.name)+'</button>').join("");
 document.querySelectorAll('[data-v="db"]').forEach(e=>e.style.display=d.store_db?"":"none");
 $("db_demo").textContent=d.demo?"Demo mode is ON: data resets every "+d.demo_min+" minutes. Upload is disabled.":"";
 LAST=Date.now();tick()}
function tick(){if(!LAST)return;const s=Math.round((Date.now()-LAST)/1000);$("liveT").textContent="Live · updated "+(s<5?"just now":s+"s ago")}
setInterval(tick,1000);
const W=x=>x==="warn"?"wr":x;const CI={ok:"check",warn:"alert",fail:"x",skip:"clock"};
function renderHealth(h){
 H=h;const cl=h.score>=90?"":h.score>=70?"good":h.score>=40?"wr":"bad",C=2*Math.PI*52;
 const gauge='<svg class="gauge '+cl+'" viewBox="0 0 120 120"><circle class="gb" cx="60" cy="60" r="52"/><circle class="gf" cx="60" cy="60" r="52" stroke-dasharray="'+(C*h.score/100)+' '+C+'" transform="rotate(-90 60 60)"/><text x="60" y="65" text-anchor="middle">'+h.score+'<tspan x="60" y="80">HEALTH</tspan></text></svg>';
 const msg=h.status==="running"?(h.score>=90?"Everything looks great. Your bot is online and responding.":"Your bot is online, but some checks need a look."):(h.status==="stopped"?"Your bot is stopped. Press Start on the Overview page.":"Your bot is offline. See the checks below.");
 $("hsc").innerHTML=gauge+'<div><h3>'+h.label+'</h3><p>'+msg+'</p></div>';
 const t=(ic,l,v)=>'<div class="tile"><small>'+IC(ic)+l+'</small><b>'+v+'</b></div>';
 $("tiles").innerHTML=t("clock","Uptime",h.uptime?fmtUp(h.uptime):"Offline")+t("ram","Memory",h.mem_mb?h.mem_mb+" MB":"-")+t("cpu","CPU",h.uptime?h.cpu+"%":"-")+t("sig","Telegram ping",h.tg_ms!=null?h.tg_ms+" ms":"-")+t("db","Database",h.db_mb+" MB")+t("refresh","Auto-restarts 24h",h.restarts24);
 $("checks").innerHTML=h.checks.map(c=>'<div class="hc"><span class="ci '+W(c.status)+'">'+IC(CI[c.status])+'</span><div class="t"><b>'+esc(c.title)+'</b><small>'+esc(c.detail)+'</small></div></div>').join("");
 $("errbox").innerHTML=h.last_error?'<div class="errbox">Last error: '+esc(h.last_error)+'</div>':"";
 $("hmini").innerHTML=h.checks.map(c=>'<span class="pl2 '+W(c.status)+'">'+esc(c.title)+'</span>').join("");
 const bad=h.checks.filter(c=>c.status==="fail"||c.status==="warn").length,nh=$("nh");nh.style.display=bad?"":"none";nh.textContent=bad;
 const sh=$("sidehealth");sh.innerHTML='<h4>'+IC("heart")+'Bot health</h4><div class="hl"><span>'+h.label+'</span><b>'+h.score+'%</b></div><div class="meter"><span class="'+(h.score<40?"b":h.score<70?"w":"")+'" style="width:'+Math.max(3,h.score)+'%"></span></div>'+(h.uptime?'<div class="hl" style="margin:9px 0 0"><span>Uptime</span><b>'+fmtUp(h.uptime)+'</b></div>':'')}
async function load(first){const d=await U("/api/user/me");if(!d.ok)return;render(d.bot);if(first){fillEdit(d.bot);PLANS=d.plans;
 $("plans").innerHTML=d.plans.length&&d.pay_ready?d.plans.map(p=>'<div class="plan" data-p="'+p.id+'"><b>'+esc(p.name)+'</b><div class="pr">'+inr(p.price)+'</div><small>'+(p.days>=36500?'Lifetime':p.days+' days')+'</small></div>').join(""):'<div class="help">Online renew is not available. Use a key.</div>'}}
async function loadHealth(){const j=await U("/api/user/health");if(j.ok)renderHealth(j.health)}
async function loadLog(){if(CV!=="hl")return;const j=await U("/api/user/log");const p=$("lp2"),end=p.scrollTop+p.clientHeight>=p.scrollHeight-30;p.textContent=j.log||j.message||"";if(end)p.scrollTop=1e9}
$("logr").onclick=loadLog;
window.onRenewed=()=>{load(false);loadHealth()};
document.addEventListener("click",async e=>{
 const p=e.target.closest("[data-p]");if(p){startOrder(parseInt(p.dataset.p,10),true);return}
 const b=e.target.closest("[data-do]");if(!b)return;const a=b.dataset.do;let body={};
 if(a==="token")body={token:$("n_token").value.trim()};
 if(a==="admin")body={admin:$("n_admin").value};
 if(a==="store")body={name:$("n_name").value,support:$("n_support").value};
 if(a==="renew_key")body={key:$("n_key").value};
 if(a==="theme")body={theme:b.dataset.th};
 if(a==="token"&&!confirm("Change the bot token now? The bot will restart."))return;
 if(a==="stop"&&!confirm("Stop your bot? Your customers will not be able to use it."))return;
 b.disabled=true;const j=await U("/api/user/"+a,body);b.disabled=false;
 const m=$("msg");m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";toast(j.message||"Done");
 if(j.ok){if(a==="token")$("n_token").value="";if(a==="renew_key")$("n_key").value="";load(a==="renew_key"||a==="token"||a==="admin"||a==="store");setTimeout(loadHealth,1500)}});
$("db_dl").onclick=()=>{location.href="/api/user/dbdownload"};
const dbf=$("db_file");dbf.onchange=()=>{$("db_name").textContent=dbf.files[0]?dbf.files[0].name:"Choose a .db file"};
const dz=$("drop");["dragover","dragenter"].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.add("drag")}));
["dragleave","drop"].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.remove("drag")}));
dz.addEventListener("drop",e=>{if(e.dataTransfer.files[0]){dbf.files=e.dataTransfer.files;dbf.onchange()}});
$("db_go").onclick=async()=>{const f=dbf.files[0];if(!f){toast("Choose a .db file first");return}
 if(!confirm("Replace your bot's data with this database? The bot restarts. Your old data is backed up."))return;
 const fd=new FormData();fd.append("file",f);fd.append("keep_settings",$("db_keep").checked?"1":"0");
 $("db_go").disabled=true;$("db_go").textContent="Uploading…";const j=await UP("/api/user/dbupload",fd,CSRF);
 $("db_go").disabled=false;$("db_go").textContent="Upload & apply";const m=$("msg");m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";toast(j.message||"Done");
 if(j.ok){dbf.value="";$("db_name").textContent="Choose a .db file";load(false)}};
tab((location.hash||"").slice(1));
load(true);loadHealth();setInterval(()=>load(false),10000);setInterval(loadHealth,15000);setInterval(()=>{if($("logauto").checked)loadLog()},5000);resumeOrder();
</script></body></html>"""


# ─────────────────────────── PWA (installable app) ───────────────────────────
# Service worker: only handles page navigations. If the network is down it shows the small offline page.
# Nothing private (dashboard, API, bot data) is ever cached.
PWA_SW = r"""const CACHE='hp-__VER__';
const OFFLINE='/pwa-offline';
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.add(new Request(OFFLINE,{cache:'reload'}))).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  if(e.request.mode==='navigate'){
    e.respondWith(fetch(e.request).catch(()=>caches.match(OFFLINE).then(r=>r||Response.error())));
  }
});
"""

PWA_OFFLINE = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><title>Offline</title>
<style>__THEME__
*{box-sizing:border-box}html,body{height:100%;margin:0}
body{display:grid;place-items:center;padding:24px;text-align:center;color:var(--tx);background:radial-gradient(70% 40% at 92% -6%,rgba(var(--glow),.24),transparent 65%),var(--bg);font-family:Inter,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
.b{max-width:340px}.i{width:72px;height:72px;margin:0 auto 18px;border-radius:22px;display:grid;place-items:center;font-size:34px;background:var(--s1);border:1px solid var(--line)}
h1{font-size:21px;margin:0 0 8px;letter-spacing:-.2px}p{color:var(--mu);font-size:14px;line-height:1.55;margin:0 0 22px}
button{border:0;border-radius:14px;padding:13px 26px;font-size:15px;font-weight:800;cursor:pointer;background:var(--ac);color:var(--act)}
</style></head><body><div class="b"><div class="i">📡</div><h1>You're offline</h1><p>__BRAND__ needs an internet connection. Check your network and try again.</p><button onclick="location.reload()">Retry</button></div></body></html>"""

# floating "Install app" pill + service-worker registration (injected before </body> of every panel page)
PWA_UI = r"""<style>
#pwaBar{position:fixed;right:14px;bottom:calc(84px + env(safe-area-inset-bottom,0px));z-index:25;display:none;align-items:center;gap:4px;background:var(--ac);color:var(--act);border-radius:999px;box-shadow:0 10px 28px -8px rgba(var(--acrgb),.7),0 0 0 1px rgba(0,0,0,.25);font:800 13.5px Inter,system-ui,sans-serif}
#pwaBar.on{display:flex}
#pwaBar button{border:0;background:none;color:inherit;font:inherit;cursor:pointer}
#pwaGo{padding:11px 6px 11px 16px}#pwaX{padding:11px 13px 11px 6px;opacity:.65;font-size:16px;line-height:1}
#pwaTip{position:fixed;left:14px;right:14px;bottom:calc(140px + env(safe-area-inset-bottom,0px));z-index:26;display:none;background:var(--s1);color:var(--tx);border:1px solid var(--line);border-radius:16px;padding:14px 16px;font:600 13.5px/1.5 Inter,system-ui,sans-serif;box-shadow:0 18px 40px -12px rgba(0,0,0,.7);max-width:420px;margin-left:auto}
#pwaTip.on{display:block}
</style>
<div id="pwaBar"><button id="pwaGo" type="button">⬇ Install app</button><button id="pwaX" type="button" aria-label="Hide">✕</button></div>
<div id="pwaTip"></div>
<script>(function(){
if('serviceWorker' in navigator){addEventListener('load',function(){navigator.serviceWorker.register('/sw.js?v=__VER__',{scope:'/'}).catch(function(){})})}
var bar=document.getElementById('pwaBar'),tip=document.getElementById('pwaTip'),dp=null,KEY='pwa_hide_until';
function standalone(){return matchMedia('(display-mode: standalone)').matches||navigator.standalone===true}
function hidden(){try{return +localStorage.getItem(KEY)>Date.now()}catch(e){return false}}
function show(){if(!standalone()&&!hidden())bar.classList.add('on')}
var ios=/iphone|ipad|ipod/i.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
addEventListener('beforeinstallprompt',function(e){e.preventDefault();dp=e;show()});
addEventListener('appinstalled',function(){bar.classList.remove('on');tip.classList.remove('on');dp=null});
if(ios&&!standalone()){show()}
document.getElementById('pwaGo').onclick=function(){
  if(dp){dp.prompt();dp.userChoice.finally(function(){dp=null;bar.classList.remove('on')});return}
  tip.innerHTML=ios?'iPhone: tap the <b>Share</b> button in Safari, then <b>Add to Home Screen</b>.':'Open the browser menu (⋮) and tap <b>Install app</b> / <b>Add to Home screen</b>.';
  tip.classList.toggle('on');
};
document.getElementById('pwaX').onclick=function(){bar.classList.remove('on');tip.classList.remove('on');try{localStorage.setItem(KEY,Date.now()+7*864e5)}catch(e){}};
})();</script>"""
