#!/usr/bin/env bash
# MOVE TO A NEW VPS (or recover after a crash) in one go:
#
#   apt update && apt install -y unzip python3 python3-venv curl
#   mkdir -p ~/hostpanel && cd ~/hostpanel
#   unzip -o ~/hostpanel_v12.zip            # the panel files (any v12+ zip)
#   bash restore.sh ~/hostpanel-backup-XXXX.tar.gz
#
# It puts back: panel password/brand, Cloudflare tunnel (same address), all bots with their databases,
# every script + theme, keys, orders, plans, settings. Libraries are rebuilt automatically.
# IMPORTANT: stop/delete the OLD server first, otherwise two copies of one bot token fight each other.
set -e
cd "$(dirname "$0")"
ARCH="$1"
[ -n "$ARCH" ] && [ -f "$ARCH" ] || { echo "Usage: bash restore.sh /path/to/hostpanel-backup-....tar.gz"; exit 1; }
[ -f hpbackup.py ] && [ -f app.py ] || { echo "Unzip the hostpanel zip into this folder first (app.py / hpbackup.py missing)."; exit 1; }
if [ "$(id -u)" = "0" ] && command -v apt-get >/dev/null; then
  for p in python3 python3-venv curl; do dpkg -s "$p" >/dev/null 2>&1 || NEED="$NEED $p"; done
  [ -n "$NEED" ] && { apt-get update -qq && apt-get install -y -qq $NEED; } || true
fi
echo "Checking backup..."
python3 hpbackup.py info "$ARCH" | head -8
# stop a panel / bots that may already run from this folder
if command -v systemctl >/dev/null && [ -f /etc/systemd/system/bothost.service ]; then systemctl stop bothost 2>/dev/null || true; fi
pkill -f "venv/bin/python app.py" 2>/dev/null || true
for c in /proc/[0-9]*/cwd; do
  t=$(readlink "$c" 2>/dev/null) || continue
  case "$t" in "$(pwd)"/bots/*) kill "$(echo "$c" | cut -d/ -f3)" 2>/dev/null || true;; esac
done
sleep 1
python3 hpbackup.py restore "$ARCH"
# bring the same Cloudflare tunnel address back (token was stored in the backup)
if [ -f panel.env ]; then
  T=$(grep -m1 '^CF_TUNNEL_TOKEN=' panel.env | cut -d= -f2- | tr -d "\"'")
  U=$(grep -m1 '^PUBLIC_URL=' panel.env | cut -d= -f2- | tr -d "\"'")
  [ -n "$T" ] && export CF_TUNNEL_TOKEN="$T"
  [ -n "$U" ] && export PUBLIC_URL="$U"
fi
bash install.sh
echo
echo "RESTORE DONE. Login with your OLD panel password (Owner: /admin)."
echo "Bots start by themselves in ~1-2 minutes (script libraries are rebuilding)."
echo "Check:  bash update.sh   (shows each script: ready / installing / failed)"
