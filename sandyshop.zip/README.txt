SANDY PANEL SHOP (sandyshop)  -  HostPanel script
Update:  cd ~/hostpanel && mkdir -p scripts/sandyshop && unzip -o ~/sandyshop.zip -d scripts/sandyshop && bash update.sh
Owner /admin -> Scripts -> sandyshop should show "ready". Make an access key for it and launch a bot.
Then open the bot and send /admin  (everything is set from there):
  Products  : Category -> Product -> Plans -> Keys.  Per product choose delivery: STOCK (admin keys), API (generated), BOTH.
  Payments  : UPI ID, FamPay key/url, auto/manual, min/max, quick amounts, service charge, bonus.
  Texts & Buttons : every text, every main button (label / colour / premium emoji ID), Premium Emoji ID Finder.
Premium emoji in buttons/texts need Telegram support for the bot; if Telegram refuses, the bot falls back to normal emoji automatically.
NEW v1.1: Product page me photo/video/GIF (Admin -> Product -> Media) aur Welcome Text + Photo/Video (Admin -> Texts & Buttons -> Welcome).
NEW v1.2: Product page, buy/receipt screens in quote-block + bold style, bold buttons (toggle: Admin -> Texts & Buttons -> Bold buttons).
NEW v1.3: Default catalog (NON ROOT / ROOT / IOS + products + 4 plans each) loads on empty store, or Admin -> Products -> Load Default Catalog. Product list shows 2 per row.
