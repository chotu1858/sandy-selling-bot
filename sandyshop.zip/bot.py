#!/usr/bin/env python3
# ============================================================
#  SANDY PANEL SHOP  -  key / license selling bot for the Bot Host panel
#  * everything is set from the bot's own admin panel (/admin)
#  * per product: keys from admin stock, from an API, or both
#  * coloured buttons + Telegram premium (custom) emoji by ID
# ============================================================
import os
import re
import json
import time
import html
import random
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from urllib.parse import quote_plus
from concurrent.futures import ThreadPoolExecutor

import requests

BASE = os.path.dirname(os.path.abspath(__file__))
IST = timezone(timedelta(hours=5, minutes=30))


def load_env(path):
    try:
        for line in open(path, encoding="utf-8").read().splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
    except OSError:
        pass


load_env(os.path.join(BASE, ".env"))
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
_ENV_ADMINS = [int(x) for x in os.getenv("ADMIN_IDS", "").replace(" ", "").split(",") if x.isdigit()]
OWNER = _ENV_ADMINS[0] if _ENV_ADMINS else 0
STORE_NAME = os.getenv("STORE_NAME", "") or "Sandy Panel Shop"
SUPPORT_USER = os.getenv("SUPPORT_USERNAME", "") or "@support"
DB_FILE = os.path.join(BASE, os.getenv("DB_NAME", "store.db"))
API = "https://api.telegram.org/bot" + BOT_TOKEN
FILE_API = "https://api.telegram.org/file/bot" + BOT_TOKEN
BOT_USER = ""

try:
    THEME = json.load(open(os.getenv("THEME_FILE", ""), encoding="utf-8"))
    if not isinstance(THEME, dict):
        THEME = {}
except Exception:
    THEME = {}


def log(msg):
    print("[%s] %s" % (datetime.now(IST).strftime("%H:%M:%S"), msg), flush=True)


def now_s():
    return datetime.now(IST).strftime("%d-%m-%Y %H:%M")


def esc(s):
    return html.escape(str(s if s is not None else ""), quote=False)


# ============================================================
# DATABASE
# ============================================================
DB = sqlite3.connect(DB_FILE, check_same_thread=False, timeout=30)
DB.row_factory = sqlite3.Row
DB.execute("PRAGMA journal_mode=WAL")
L = threading.RLock()


def q(sql, p=()):
    with L:
        return [dict(r) for r in DB.execute(sql, p).fetchall()]


def q1(sql, p=()):
    r = q(sql, p)
    return r[0] if r else None


def x(sql, p=()):
    with L:
        cur = DB.execute(sql, p)
        DB.commit()
        return cur.lastrowid


SCHEMA = """
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, username TEXT, balance REAL DEFAULT 0,
  tier TEXT DEFAULT 'user', joined TEXT, banned INTEGER DEFAULT 0, ref_by INTEGER DEFAULT 0, spun INTEGER DEFAULT 0,
  spent REAL DEFAULT 0, deposited REAL DEFAULT 0, ref_earn REAL DEFAULT 0, ref_paid INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS cats(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, emoji TEXT DEFAULT '', eid TEXT DEFAULT '',
  style TEXT DEFAULT '', sort INTEGER DEFAULT 0, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS prods(id INTEGER PRIMARY KEY AUTOINCREMENT, cat_id INTEGER DEFAULT 0, name TEXT, emoji TEXT DEFAULT '',
  eid TEXT DEFAULT '', style TEXT DEFAULT '', descr TEXT DEFAULT '', note TEXT DEFAULT '', mode TEXT DEFAULT 'stock',
  api_url TEXT DEFAULT '', api_method TEXT DEFAULT 'GET', api_body TEXT DEFAULT '', api_headers TEXT DEFAULT '',
  api_path TEXT DEFAULT '', sort INTEGER DEFAULT 0, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS plans(id INTEGER PRIMARY KEY AUTOINCREMENT, prod_id INTEGER, name TEXT, price REAL DEFAULT 0,
  rprice REAL DEFAULT 0, days INTEGER DEFAULT 0, sort INTEGER DEFAULT 0, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS keys(id INTEGER PRIMARY KEY AUTOINCREMENT, plan_id INTEGER, val TEXT, used INTEGER DEFAULT 0,
  order_id TEXT DEFAULT '', added TEXT);
CREATE INDEX IF NOT EXISTS ix_keys ON keys(plan_id, used);
CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY, user INTEGER, prod_id INTEGER, plan_id INTEGER, pname TEXT, plname TEXT,
  price REAL, val TEXT DEFAULT '', status TEXT, created TEXT, ts INTEGER);
CREATE TABLE IF NOT EXISTS pays(id TEXT PRIMARY KEY, user INTEGER, amount REAL, payable REAL, utr TEXT DEFAULT '',
  status TEXT, kind TEXT DEFAULT '', created INTEGER, file_id TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS utrs(utr TEXT PRIMARY KEY, user INTEGER, amount REAL, ts INTEGER);
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY);
"""
with L:
    DB.executescript(SCHEMA)
    DB.commit()
    for _col in ("media_type", "media_id"):          # media on products (added in v1.1, safe for old DBs)
        try:
            DB.execute("ALTER TABLE prods ADD COLUMN %s TEXT DEFAULT ''" % _col)
            DB.commit()
        except sqlite3.OperationalError:
            pass


# ============================================================
# SETTINGS  (DB override  ->  theme file  ->  built-in default)
# ============================================================
DEFAULTS = {
    "store_name": STORE_NAME, "currency": "₹", "support_user": SUPPORT_USER, "log_channel": "", "maint": "0",
    "upi_id": "", "upi_name": STORE_NAME, "fam_key": "", "fam_url": "https://famapi-sas5.onrender.com", "fam_path": "",
    "bold_btn": "1", "pay_auto": "1", "pay_manual": "1", "dep_min": "10", "dep_max": "5000", "quick": "90,180,360,650,999,1999",
    "charge_pct": "0", "bonus_pct": "0", "qr_valid": "5",
    "reseller_min": "499", "show_stock": "1",
    "ref_on": "1", "ref_pct": "10",
    "spin_on": "1", "spin_hours": "24", "spin_min_dep": "0", "spin_prizes": "0:40,1:25,2:15,5:10,10:7,20:3",
    "txt_welcome": "<blockquote><b>✅ LICENSE DASHBOARD</b></blockquote>\n<blockquote><b>👋 Welcome, {name}!</b></blockquote>\n"
                   "<blockquote><b>├── 🔑 Premium Game Keys at Best Prices\n├── ⚡ Fast Delivery · Secure Payments\n├── 🎁 Refer Friends &amp; Earn Rewards\n"
                   "├── 🍀 Try Your Luck with Lucky Spin\n└── 🛡 Trusted Store · 24/7 Support</b></blockquote>\n"
                   "<blockquote><b>💳 Wallet Balance: {balance}</b></blockquote>\n<b>Select an option below to get started.</b>",
    "txt_cat_title": "<blockquote><b>🗂 CHOOSE A CATEGORY 👇</b></blockquote>\n<blockquote><b>Neeche se category chunein, uske andar ke saare products dikhenge.</b></blockquote>",
    "txt_prod_title": "<blockquote><b>🛍 CHOOSE YOUR PRODUCT 👇</b></blockquote>\n<blockquote><b>Neeche se product chunein, plan aur price agle step mein dikhenge.</b></blockquote>",
    "txt_howto": "📖 <b>HOW TO USE</b>\n━━━━━━━━━━━━━━\n1️⃣ <b>Add Balance</b> dabake wallet me paise daalo\n"
                 "2️⃣ <b>Products</b> me category → product → plan chuno\n3️⃣ Confirm karo, key turant mil jayegi\n"
                 "4️⃣ Key <b>My Orders</b> me hamesha saved rahegi\n\nHelp chahiye? Support se contact karo.",
    "txt_support": "🛟 <b>SUPPORT</b>\n━━━━━━━━━━━━━━\nKoi problem ho to humse contact karo:\n{support}\n\n⏰ 24/7 Available",
    "txt_refer": "🎁 <b>REFER &amp; EARN</b>\n━━━━━━━━━━━━━━\nDost ko invite karo, uske <b>pehle deposit</b> par aapko "
                 "<b>{pct}%</b> reward milega.\n\n🔗 <b>Your link:</b>\n<code>{link}</code>\n\n👥 Referrals: <b>{count}</b>\n"
                 "💰 Total earned: <b>{earned}</b>\n\n<i>Reward seedhe aapke bot balance mein jud jayegi.</i>",
    "txt_addbal": "💰 <b>ADD BALANCE</b>\n━━━━━━━━━━━━━━\n\n🔹 <b>Method:</b> 💳 Instant QR Pay\n🔹 <b>Min:</b> {min}   <b>Max:</b> {max}\n"
                  "🔹 <b>Valid for:</b> {valid} minutes\n\n💡 Amount chunein ya ✏️ Custom Amount likhein. "
                  "Payment hote hi balance apne aap add ho jaata hai.\n\n{note}",
    "txt_addbal_note": "💎 <b>{reseller_min}</b> ya zyada deposit par <b>Reseller price</b> apne aap mil jaata hai.",
}

_SC = {}
_SC_L = threading.Lock()


def _load_settings():
    with _SC_L:
        _SC.clear()
        for r in q("SELECT k,v FROM settings"):
            _SC[r["k"]] = r["v"]


_load_settings()


def S(k):
    with _SC_L:
        if k in _SC:
            return _SC[k]
    t = (THEME.get("texts") or {}).get(k)
    if isinstance(t, str) and t:
        return t
    return DEFAULTS.get(k, "")


def setS(k, v):
    x("INSERT OR REPLACE INTO settings VALUES(?,?)", (k, str(v)))
    with _SC_L:
        _SC[k] = str(v)


def delS(k):
    x("DELETE FROM settings WHERE k=?", (k,))
    with _SC_L:
        _SC.pop(k, None)


def SN(k, d=0.0):
    try:
        return float(str(S(k)).replace(",", "").strip())
    except ValueError:
        return d


def m(v):
    v = float(v or 0)
    s = str(int(round(v))) if abs(v - round(v)) < 0.005 else "%.2f" % v
    return S("currency") + s


# ---- main-menu buttons (label / colour / premium emoji / on-off) ----
DEFBTN = {
    "products": ("🛒 Products", "success"), "addbal": ("💰 Add Balance", "success"),
    "orders": ("📦 My Orders", "primary"), "profile": ("👤 My Profile", "primary"),
    "refer": ("🎁 Refer & Earn", "success"), "howto": ("📖 How To Use", "primary"),
    "spin": ("🎰 Lucky Spin", "success"), "support": ("🛟 Support", "primary"),
}


def bcfg(key):
    t, s = DEFBTN[key]
    c = {"t": t, "s": s, "e": "", "on": 1}
    th = (THEME.get("buttons") or {}).get(key)
    if isinstance(th, dict):
        if th.get("text"):
            c["t"] = th["text"]
        if th.get("style"):
            c["s"] = th["style"]
        if th.get("emoji_id"):
            c["e"] = str(th["emoji_id"])
    try:
        c.update(json.loads(S("btn_" + key) or "{}"))
    except ValueError:
        pass
    return c


# ============================================================
# TELEGRAM LAYER
# ============================================================
SESSION = requests.Session()
STATE = {}
STATE_L = threading.Lock()


def bad(res):
    return isinstance(res, dict) and "_err" in res


def tg(method, params=None, files=None, timeout=35):
    for _ in range(3):
        try:
            if files:
                r = SESSION.post(API + "/" + method, data=params, files=files, timeout=timeout)
            else:
                r = SESSION.post(API + "/" + method, json=params or {}, timeout=timeout)
            j = r.json()
        except (requests.RequestException, ValueError):
            time.sleep(1)
            continue
        if j.get("ok"):
            return j.get("result")
        ra = (j.get("parameters") or {}).get("retry_after")
        if ra and j.get("error_code") == 429:
            time.sleep(min(int(ra), 10))
            continue
        return {"_err": str(j.get("description", "error"))}
    return {"_err": "network error"}


def _strip_kb(kb, level):
    out = {"inline_keyboard": []}
    for row in kb.get("inline_keyboard", []):
        nr = []
        for b in row:
            b = dict(b)
            b.pop("icon_custom_emoji_id", None)
            if level >= 2:
                b.pop("style", None)
            nr.append(b)
        out["inline_keyboard"].append(nr)
    return out


_TGE = re.compile(r'<tg-emoji emoji-id="\d+">(.*?)</tg-emoji>', re.S)


def call(method, p):
    """tg() with graceful fallback: premium-emoji / colour not accepted -> retry plain."""
    res = tg(method, p)
    if bad(res) and "not modified" not in res["_err"]:
        kb = p.get("reply_markup")
        if kb and re.search(r"(?i)button|emoji|style|reply markup", res["_err"]):
            for lvl in (1, 2):
                p2 = dict(p)
                p2["reply_markup"] = _strip_kb(kb, lvl)
                res = tg(method, p2)
                if not bad(res):
                    return res
        for f in ("text", "caption"):
            if "tg-emoji" in str(p.get(f, "")) and res and bad(res):
                p2 = dict(p)
                p2[f] = _TGE.sub(r"\1", p[f])
                if kb:
                    p2["reply_markup"] = _strip_kb(kb, 2)
                res = tg(method, p2)
    return res


def cut(t, n=4000):
    t = str(t)
    return t if len(t) <= n else t[:n - 3] + "..."


def send(c, text, kb=None):
    p = {"chat_id": c, "text": cut(text), "parse_mode": "HTML", "disable_web_page_preview": True}
    if kb:
        p["reply_markup"] = {"inline_keyboard": kb}
    return call("sendMessage", p)


def show(c, mid, text, kb=None):
    """Edit the menu message in place (falls back to a fresh message)."""
    drop_orphan(c)
    if not mid:
        return send(c, text, kb)
    p = {"chat_id": c, "message_id": mid, "text": cut(text), "parse_mode": "HTML", "disable_web_page_preview": True,
         "reply_markup": {"inline_keyboard": kb or []}}
    res = call("editMessageText", p)
    if bad(res):
        if "not modified" in res["_err"]:
            return None
        tg("deleteMessage", {"chat_id": c, "message_id": mid})
        return send(c, text, kb)
    return res


def send_photo(c, photo, cap, kb=None):
    p = {"chat_id": c, "photo": photo, "caption": cut(cap, 1000), "parse_mode": "HTML"}
    if kb:
        p["reply_markup"] = {"inline_keyboard": kb}
    return call("sendPhoto", p)


def delete(c, mid):
    if mid:
        tg("deleteMessage", {"chat_id": c, "message_id": mid})


# ---------- media (photo / video / GIF / file) on menu pages ----------
MEDIA_METHODS = {"photo": "sendPhoto", "video": "sendVideo", "animation": "sendAnimation", "document": "sendDocument"}
MEDIA_ICON = {"photo": "🖼 photo", "video": "🎬 video", "animation": "🎞 GIF", "document": "📎 file"}
_ORPHAN = {}


def drop_orphan(c):
    o = _ORPHAN.pop(c, None)
    if o:
        delete(c, o)


def plain_len(t):
    return len(re.sub(r"<[^>]+>", "", str(t)))


def extract_media(msg):
    if msg.get("photo"):
        return "photo", msg["photo"][-1]["file_id"]
    for k in ("video", "animation", "document"):
        if msg.get(k):
            return k, msg[k]["file_id"]
    return "", ""


def show_media(c, mid, text, kb, mtype, fid):
    """Media + text. Text goes as caption when it fits (<=1024), else media first and text/buttons below it."""
    drop_orphan(c)
    if mtype not in MEDIA_METHODS or not fid:
        return show(c, mid, text, kb)
    delete(c, mid)
    method = MEDIA_METHODS[mtype]
    p = {"chat_id": c, mtype: fid}
    if plain_len(text) <= 1000:
        p["parse_mode"] = "HTML"
        p["caption"] = text
        if kb:
            p["reply_markup"] = {"inline_keyboard": kb}
        res = call(method, p)
        if bad(res):                                   # bad/expired file id -> still show the text menu
            return send(c, text, kb)
        return res
    res = call(method, p)
    if not bad(res) and isinstance(res, dict) and res.get("message_id"):
        _ORPHAN[c] = res["message_id"]
    return send(c, text, kb)


def ack(cid, text="", alert=False):
    tg("answerCallbackQuery", {"callback_query_id": cid, "text": text[:190], "show_alert": alert}, timeout=10)


def auto_style(t, cb):
    t = t or ""
    c = cb or ""
    if any(w in t for w in ("❌", "🗑", "🚫", "Cancel", "Reject", "Delete", "Ban", "Deduct")):
        return "danger"
    if any(w in t for w in ("✅", "➕", "Confirm", "Verify", "Add", "Approve", "SPIN", "🎰", "🛒", "Unban")):
        return "success"
    return "primary"


def bold_u(t):
    """Normal letters/digits -> bold sans-serif unicode (works inside button labels)."""
    out = []
    for ch in str(t):
        o = ord(ch)
        if 65 <= o <= 90:
            out.append(chr(0x1D5D4 + o - 65))
        elif 97 <= o <= 122:
            out.append(chr(0x1D5EE + o - 97))
        elif 48 <= o <= 57:
            out.append(chr(0x1D7EC + o - 48))
        else:
            out.append(ch)
    return "".join(out)


def bq(t):
    return "<blockquote>%s</blockquote>" % t


def tree(lines, bold=True):
    """├── / └── list inside one quote block."""
    n = len(lines)
    body = "\n".join(("└── " if i == n - 1 else "├── ") + l for i, l in enumerate(lines))
    return bq("<b>%s</b>" % body if bold else body)


def B(text, cb=None, url=None, style="auto", eid=None):
    st0 = auto_style(text, cb) if style in ("auto", "", None) else style
    if S("bold_btn") == "1":
        text = bold_u(text)
    b = {"text": str(text)[:60]}
    if url:
        b["url"] = url
    else:
        b["callback_data"] = str(cb)[:64]
    st = st0
    if st in ("primary", "success", "danger"):
        b["style"] = st
    if eid and str(eid).isdigit():
        b["icon_custom_emoji_id"] = str(eid)
    return b


def grid(btns, per=2):
    return [btns[i:i + per] for i in range(0, len(btns), per)]


# ---- Telegram entities  ->  HTML  (keeps premium emoji the admin types) ----
def ent_html(text, ents):
    if not ents:
        return esc(text)
    u = text.encode("utf-16-le")
    marks = []
    for i, e in enumerate(ents):
        t, o, ln = e.get("type"), e["offset"], e["length"]
        op = cl = ""
        if t == "bold":
            op, cl = "<b>", "</b>"
        elif t == "italic":
            op, cl = "<i>", "</i>"
        elif t == "underline":
            op, cl = "<u>", "</u>"
        elif t == "strikethrough":
            op, cl = "<s>", "</s>"
        elif t == "code":
            op, cl = "<code>", "</code>"
        elif t == "pre":
            op, cl = "<pre>", "</pre>"
        elif t == "spoiler":
            op, cl = "<tg-spoiler>", "</tg-spoiler>"
        elif t == "blockquote":
            op, cl = "<blockquote>", "</blockquote>"
        elif t == "text_link":
            op, cl = '<a href="%s">' % html.escape(e.get("url", ""), quote=True), "</a>"
        elif t == "custom_emoji":
            op, cl = '<tg-emoji emoji-id="%s">' % e.get("custom_emoji_id", ""), "</tg-emoji>"
        if op:
            marks.append((o, 1, -ln, i, op))
            marks.append((o + ln, 0, ln, -i, cl))
    marks.sort(key=lambda z: (z[0], z[1], z[2], z[3]))
    out, pos = [], 0
    for at, _k, _l, _i, tag in marks:
        if at > pos:
            out.append(esc(u[pos * 2:at * 2].decode("utf-16-le", "ignore")))
            pos = at
        out.append(tag)
    out.append(esc(u[pos * 2:].decode("utf-16-le", "ignore")))
    return "".join(out)


def fmt(t, **kw):
    for k, v in kw.items():
        t = t.replace("{" + k + "}", str(v))
    return t


def st_set(uid, s, **xx):
    with STATE_L:
        STATE[uid] = (s, xx)


def st_get(uid):
    with STATE_L:
        return STATE.get(uid, ("", {}))


def st_clear(uid):
    with STATE_L:
        STATE.pop(uid, None)


# ============================================================
# USERS / HOME
# ============================================================
def is_admin(uid):
    return uid == OWNER or uid in _ENV_ADMINS or bool(q1("SELECT 1 FROM admins WHERE id=?", (uid,)))


def is_owner(uid):
    return uid == OWNER


def get_user(uid):
    return q1("SELECT * FROM users WHERE id=?", (uid,))


def ensure_user(fr, ref=0):
    uid = fr["id"]
    name = (fr.get("first_name") or "User")[:40]
    un = fr.get("username") or ""
    u = get_user(uid)
    if not u:
        rb = ref if ref and ref != uid and get_user(ref) else 0
        x("INSERT INTO users(id,name,username,joined,ref_by) VALUES(?,?,?,?,?)", (uid, name, un, now_s(), rb))
        u = get_user(uid)
    elif u["name"] != name or (u["username"] or "") != un:
        x("UPDATE users SET name=?, username=? WHERE id=?", (name, un, uid))
        u["name"], u["username"] = name, un
    return u


def tier_label(u):
    return "RESELLER" if u and u["tier"] == "reseller" else "USER"


def support_url():
    s = S("support_user").strip().lstrip("@").replace("https://t.me/", "")
    return "https://t.me/" + s if re.match(r"^[A-Za-z0-9_]{4,}$", s) else ""


HOME_LAYOUT = [["products"], ["addbal", "orders"], ["profile", "refer"], ["howto", "spin"], ["support"]]


def home_kb(uid):
    kb = []
    for row in HOME_LAYOUT:
        r = []
        for k in row:
            c = bcfg(k)
            if not int(c.get("on", 1)):
                continue
            if (k == "spin" and S("spin_on") != "1") or (k == "refer" and S("ref_on") != "1"):
                continue
            if k == "support" and support_url():
                r.append(B(c["t"], url=support_url(), style=c["s"], eid=c["e"]))
            else:
                r.append(B(c["t"], "m:" + k, style=c["s"], eid=c["e"]))
        if r:
            kb.append(r)
    if is_admin(uid):
        kb.append([B("⚙️ Admin Panel", "a", style="danger")])
    return kb


def home(c, mid, uid):
    u = get_user(uid) or {"name": "User", "balance": 0, "tier": "user"}
    t = fmt(S("txt_welcome"), name=esc(u["name"]), balance=m(u["balance"]), tier=tier_label(u),
            store=esc(S("store_name")), id=uid, currency=S("currency"))
    if S("welcome_media_id"):
        return show_media(c, mid, t, home_kb(uid), S("welcome_media_type"), S("welcome_media_id"))
    show(c, mid, t, home_kb(uid))


def back_home():
    return [B("⬅️ Back", "home", style="primary")]


# ============================================================
# CATALOG
# ============================================================
PALETTE = ["success", "primary", "danger", "primary"]


def label(r):
    return ("%s " % r["emoji"] if r.get("emoji") and not r.get("eid") else "") + r["name"]


def show_cats(c, mid, uid):
    cats = q("SELECT * FROM cats WHERE active=1 ORDER BY sort,id")
    ids = [r["id"] for r in cats]
    others = [p for p in q("SELECT id,cat_id FROM prods WHERE active=1") if p["cat_id"] not in ids]
    if not cats:
        return show_prods(c, mid, uid, -1)
    btns = [B(label(r), "c:%d" % r["id"], style=r["style"] or PALETTE[i % 3], eid=r["eid"]) for i, r in enumerate(cats)]
    if others:
        btns.append(B("📦 Other Products", "c:0", style="primary"))
    show(c, mid, S("txt_cat_title"), grid(btns, 2) + [back_home()])


def show_prods(c, mid, uid, cid):
    if cid == -1:
        ps = q("SELECT * FROM prods WHERE active=1 ORDER BY sort,id")
    elif cid == 0:
        ids = [r["id"] for r in q("SELECT id FROM cats WHERE active=1")]
        ps = [p for p in q("SELECT * FROM prods WHERE active=1 ORDER BY sort,id") if p["cat_id"] not in ids]
    else:
        ps = q("SELECT * FROM prods WHERE active=1 AND cat_id=? ORDER BY sort,id", (cid,))
    if not ps:
        show(c, mid, "📭 <b>Is category me abhi koi product nahi hai.</b>",
             [[B("⬅️ Back", "m:products", style="primary")]])
        return
    btns = [B(label(p), "p:%d" % p["id"], style=p["style"] or "success", eid=p["eid"]) for p in ps]
    back = "m:products" if cid != -1 else "home"
    show(c, mid, S("txt_prod_title"), grid(btns, 2) + [[B("⬅️ Back", back, style="primary")]])


def stock_n(plid):
    return q1("SELECT COUNT(*) n FROM keys WHERE plan_id=? AND used=0", (plid,))["n"]


def avail(pr, pl):
    mode = pr["mode"]
    api = bool(pr["api_url"].strip())
    if mode == "api":
        return api
    if mode == "both":
        return stock_n(pl["id"]) > 0 or api
    return stock_n(pl["id"]) > 0


def price_for(pl, u):
    return pl["rprice"] if (u and u["tier"] == "reseller" and pl["rprice"] > 0) else pl["price"]


def show_prod(c, mid, uid, pid):
    pr = q1("SELECT * FROM prods WHERE id=? AND active=1", (pid,))
    if not pr:
        return show_cats(c, mid, uid)
    u = get_user(uid)
    pls = q("SELECT * FROM plans WHERE prod_id=? AND active=1 ORDER BY sort,price,id", (pid,))
    t = bq("<b>%s%s</b>" % (pr["emoji"] + " " if pr["emoji"] else "", esc(pr["name"]).upper()))
    if pr["descr"]:
        t += "\n" + bq(pr["descr"])
    t += "\n" + bq("👑 <b>Your Account Tier: %s</b>" % tier_label(u))
    if not pls:
        t += "\n" + bq("📭 <b>Abhi koi plan available nahi hai.</b>")
    else:
        t += "\n" + bq("🛒 <b>Choose your access plan:</b>")
        rows = []
        for pl in pls:
            st = ""
            if S("show_stock") == "1" and pr["mode"] != "api":
                n = stock_n(pl["id"])
                st = "  ·  📦 %d" % n if (n or pr["mode"] == "stock") else ""
            rows.append("%s — 💰 %s%s" % (m(price_for(pl, u)), esc(pl["name"]).upper(), st))
        t += "\n" + tree(rows)
    btns = []
    for pl in pls:
        if avail(pr, pl):
            btns.append([B("💰 %s — %s" % (pl["name"].upper(), m(price_for(pl, u))), "b:%d" % pl["id"], style="success")])
        else:
            btns.append([B("❌ %s — Out of stock" % pl["name"].upper(), "oos", style="danger")])
    btns.append([B("⬅️ Back", "c:%d" % pr["cat_id"] if q1("SELECT 1 FROM cats WHERE id=? AND active=1", (pr["cat_id"],))
                   else "m:products", style="danger")])
    if pr.get("media_id"):
        return show_media(c, mid, t, btns, pr["media_type"], pr["media_id"])
    show(c, mid, t, btns)


def show_buy(c, mid, uid, plid):
    pl = q1("SELECT * FROM plans WHERE id=? AND active=1", (plid,))
    pr = q1("SELECT * FROM prods WHERE id=? AND active=1", (pl["prod_id"],)) if pl else None
    if not pl or not pr:
        return show_cats(c, mid, uid)
    u = get_user(uid)
    price = price_for(pl, u)
    if not avail(pr, pl):
        return show_prod(c, mid, uid, pr["id"])
    if u["balance"] + 1e-9 < price:
        t = (bq("<b>❌ INSUFFICIENT BALANCE</b>") + "\n" +
             tree(["💰 Required: %s" % m(price), "💳 Your balance: %s" % m(u["balance"]), "⚠️ Short by: %s" % m(price - u["balance"])]) +
             "\n" + bq("<b>➕ Add Balance dabakar balance badhayein.</b>"))
        show(c, mid, t, [[B("➕ Add Balance", "ab", style="success"), B("⬅️ Back", "p:%d" % pr["id"], style="primary")]])
        return
    t = (bq("<b>🧾 CONFIRM ORDER</b>") + "\n" +
         tree(["📦 Product: %s" % esc(pr["name"]).upper(), "📋 Plan: %s" % esc(pl["name"]).upper(), "💰 Price: %s" % m(price),
               "💳 Balance: %s" % m(u["balance"]), "🧮 After purchase: %s" % m(u["balance"] - price)]))
    show(c, mid, t, [[B("✅ Confirm Purchase", "cf:%d" % plid, style="success"), B("❌ Cancel", "p:%d" % pr["id"], style="danger")]])


# ============================================================
# KEY GENERATION  (stock keys  /  per-product API)
# ============================================================
def _jsonpick(j, path):
    cur = j
    for part in [p for p in path.replace("[", ".").replace("]", "").split(".") if p != ""]:
        if isinstance(cur, list):
            try:
                cur = cur[int(part)]
            except (ValueError, IndexError):
                return None
        elif isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return None
    return cur


def api_gen(pr, pl, uid, oid):
    """Returns (ok, value_or_error, raw_text)."""
    url = pr["api_url"].strip()
    if not url:
        return False, "API URL not set", ""
    ph = {"days": pl.get("days", 0), "plan": pl.get("name", ""), "product": pr["name"], "user": uid, "order": oid,
          "price": pl.get("price", 0), "plan_id": pl.get("id", 0), "prod_id": pr["id"]}

    def sub(s, mode):
        for k, v in ph.items():
            vv = quote_plus(str(v)) if mode == "url" else json.dumps(str(v))[1:-1]
            s = s.replace("{" + k + "}", vv)
        return s
    method = (pr["api_method"] or "GET").upper()
    hdr = {}
    try:
        if pr["api_headers"].strip():
            hdr = json.loads(sub(pr["api_headers"], "json"))
    except ValueError:
        return False, "Headers JSON invalid", ""
    body = sub(pr["api_body"], "json") if pr["api_body"].strip() else None
    try:
        kw = {"headers": hdr, "timeout": (10, 40)}
        if body is not None and method != "GET":
            if body.lstrip().startswith(("{", "[")):
                hdr.setdefault("Content-Type", "application/json")
            kw["data"] = body.encode("utf-8")
        r = requests.request(method, sub(url, "url"), **kw)
    except requests.RequestException as e:
        return False, "API not reachable: %s" % str(e)[:80], ""
    raw = r.text.strip()
    if r.status_code >= 400:
        return False, "API HTTP %s" % r.status_code, raw
    try:
        j = r.json()
    except ValueError:
        j = None
    val = None
    if j is not None:
        if isinstance(j, dict):
            for k in ("success", "ok"):
                if k in j and j[k] in (False, 0, "false", "False", "0"):
                    return False, str(j.get("message") or j.get("error") or j.get("msg") or "API said failure")[:120], raw
            if str(j.get("status", "")).lower() in ("error", "failed", "fail", "false"):
                return False, str(j.get("message") or j.get("error") or j.get("msg") or "API said failure")[:120], raw
        if pr["api_path"].strip():
            val = _jsonpick(j, pr["api_path"].strip())
        elif isinstance(j, dict):
            flat = dict(j)
            for k in ("data", "result", "response"):
                if isinstance(j.get(k), dict):
                    flat.update(j[k])
            for k in ("key", "license", "license_key", "licence", "token", "code", "data", "result", "message"):
                if flat.get(k) not in (None, "", [], {}) and not isinstance(flat.get(k), (dict, list)):
                    val = flat[k]
                    break
        elif isinstance(j, str):
            val = j
    else:
        val = raw
    if val is None or str(val).strip() == "":
        return False, "Key not found in API response", raw
    return True, str(val).strip()[:1500], raw


def new_oid():
    return "SP%s%03d" % (str(int(time.time()))[-7:], random.randint(0, 999))


def do_buy(uid, plid):
    """Returns (status, order_row|None).  status: ok | nobal | nostock | apifail | gone"""
    need_api = False
    with L:
        u = get_user(uid)
        pl = q1("SELECT * FROM plans WHERE id=? AND active=1", (plid,))
        pr = q1("SELECT * FROM prods WHERE id=? AND active=1", (pl["prod_id"],)) if pl else None
        if not u or not pl or not pr:
            return "gone", None
        price = price_for(pl, u)
        if u["balance"] + 1e-9 < price:
            return "nobal", None
        val = None
        keyid = None
        if pr["mode"] in ("stock", "both"):
            k = q1("SELECT id,val FROM keys WHERE plan_id=? AND used=0 ORDER BY id LIMIT 1", (plid,))
            if k:
                val, keyid = k["val"], k["id"]
        if val is None:
            if pr["mode"] in ("api", "both") and pr["api_url"].strip():
                need_api = True
            else:
                return "nostock", None
        oid = new_oid()
        DB.execute("UPDATE users SET balance=balance-?, spent=spent+? WHERE id=?", (price, price, uid))
        if keyid:
            DB.execute("UPDATE keys SET used=1, order_id=? WHERE id=?", (oid, keyid))
        DB.execute("INSERT INTO orders(id,user,prod_id,plan_id,pname,plname,price,val,status,created,ts) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                   (oid, uid, pr["id"], plid, pr["name"], pl["name"], price, val or "", "pending" if need_api else "done",
                    now_s(), int(time.time())))
        DB.commit()
    if need_api:
        ok, res, _raw = api_gen(pr, pl, uid, oid)
        if not ok:
            with L:
                DB.execute("UPDATE users SET balance=balance+?, spent=spent-? WHERE id=?", (price, price, uid))
                DB.execute("UPDATE orders SET status='failed' WHERE id=?", (oid,))
                DB.commit()
            log("API gen failed for %s: %s" % (pr["name"], res))
            for a in admin_ids():
                send(a, "⚠️ <b>Key API failed</b>\n📦 %s — %s\n👤 <code>%s</code>\n❗ %s\n<i>User ka paisa refund ho gaya.</i>"
                     % (esc(pr["name"]), esc(pl["name"]), uid, esc(res)))
            return "apifail", None
        x("UPDATE orders SET val=?, status='done' WHERE id=?", (res, oid))
    return "ok", q1("SELECT * FROM orders WHERE id=?", (oid,))


def receipt(o, head="✅ PURCHASE SUCCESSFUL"):
    pr = q1("SELECT note FROM prods WHERE id=?", (o["prod_id"],))
    head = re.sub(r"</?b>", "", head)
    t = (bq("<b>%s</b>" % head) + "\n" +
         tree(["📦 Product: %s" % esc(o["pname"]).upper(), "📋 Plan: %s" % esc(o["plname"]).upper(), "💰 Paid: %s" % m(o["price"]),
               "🧾 Order: <code>%s</code>" % o["id"], "🕒 %s" % o["created"]]) +
         "\n" + bq("🔑 <b>Your Key:</b>\n<code>%s</code>\n<i>(tap key to copy)</i>" % esc(o["val"])))
    if pr and pr["note"]:
        t += "\n\n" + fmt(pr["note"], key=esc(o["val"]), order=o["id"])
    return t


def buy_confirm(c, mid, uid, plid, cid_cb):
    st, o = do_buy(uid, plid)
    if st == "ok":
        show(c, mid, receipt(o), [[B("📦 My Orders", "m:orders", style="primary"), B("🏠 Menu", "home", style="success")]])
        u = get_user(uid)
        log_ch("🛒 <b>NEW ORDER</b>\n━━━━━━━━━━\n📦 %s — %s\n💰 %s\n👤 %s <code>%s</code>\n🧾 <code>%s</code>\n🕒 %s"
               % (esc(o["pname"]), esc(o["plname"]), m(o["price"]), esc(u["name"]), uid, o["id"], o["created"]))
    elif st == "nobal":
        show_buy(c, mid, uid, plid)
    elif st == "nostock":
        show(c, mid, "❌ <b>Out of stock!</b>\n\nYe plan abhi khatam ho gaya hai. Thodi der baad try karein.",
             [[B("⬅️ Back", cid_cb, style="primary")]])
    elif st == "apifail":
        show(c, mid, "⚠️ <b>Key abhi generate nahi ho payi.</b>\n\nAapka paisa wapas wallet me aa gaya hai. Thodi der baad "
                     "try karein ya support se contact karein.", [[B("⬅️ Back", cid_cb, style="primary")]])
    else:
        show_cats(c, mid, uid)


def log_ch(t):
    ch = S("log_channel").strip()
    if ch:
        send(ch, t)


def admin_ids():
    return list(dict.fromkeys(([OWNER] if OWNER else []) + _ENV_ADMINS + [r["id"] for r in q("SELECT id FROM admins")]))


# ============================================================
# ORDERS / PROFILE / REFER / HOW / SUPPORT
# ============================================================
def show_orders(c, mid, uid):
    os_ = q("SELECT * FROM orders WHERE user=? AND status='done' ORDER BY ts DESC LIMIT 15", (uid,))
    if not os_:
        show(c, mid, "📦 <b>MY ORDERS</b>\n━━━━━━━━━━━━━━\n\nAbhi tak aapne koi purchase nahi kiya hai.", [back_home()])
        return
    btns = [[B("%s · %s · %s" % (o["pname"], o["plname"], m(o["price"])), "ov:" + o["id"], style="primary")] for o in os_]
    show(c, mid, "📦 <b>MY ORDERS</b>\n━━━━━━━━━━━━━━\n\nKey dekhne ke liye order pe tap karein 👇", btns + [back_home()])


def show_order(c, mid, uid, oid):
    o = q1("SELECT * FROM orders WHERE id=? AND user=?", (oid, uid))
    if not o:
        return show_orders(c, mid, uid)
    show(c, mid, receipt(o, "📦 <b>ORDER DETAILS</b>"), [[B("⬅️ Back", "m:orders", style="primary")]])


def show_profile(c, mid, uid):
    u = get_user(uid)
    n = q1("SELECT COUNT(*) n FROM orders WHERE user=? AND status='done'", (uid,))["n"]
    t = ("👤 <b>MY PROFILE</b>\n━━━━━━━━━━━━━━\n🆔 ID: <code>%s</code>\n📛 Name: <b>%s</b>\n🏅 Tier: <b>%s</b>\n"
         "💳 Balance: <b>%s</b>\n🛒 Orders: <b>%d</b>\n💸 Total spent: <b>%s</b>\n📥 Total deposited: <b>%s</b>\n📅 Joined: %s") % (
        uid, esc(u["name"]), tier_label(u), m(u["balance"]), n, m(u["spent"]), m(u["deposited"]), u["joined"])
    if u["tier"] != "reseller" and SN("reseller_min") > 0:
        t += "\n\n💎 Reseller banne ke liye total deposit <b>%s</b> karein." % m(SN("reseller_min"))
    show(c, mid, t, [[B("➕ Add Balance", "ab", style="success"), B("⬅️ Back", "home", style="primary")]])


def show_refer(c, mid, uid):
    u = get_user(uid)
    cnt = q1("SELECT COUNT(*) n FROM users WHERE ref_by=?", (uid,))["n"]
    link = "https://t.me/%s?start=r%d" % (BOT_USER, uid)
    t = fmt(S("txt_refer"), pct=("%g" % SN("ref_pct")), link=link, count=cnt, earned=m(u["ref_earn"]))
    show(c, mid, t, [[B("📤 Share Link", url="https://t.me/share/url?url=" + quote_plus(link), style="success")], back_home()])


def show_text(c, mid, key, **kw):
    show(c, mid, fmt(S(key), **kw), [back_home()])


# ============================================================
# ADD BALANCE  (QR  ->  Verify Payment  ->  UTR check / manual approval)
# ============================================================
def pay_ready():
    return bool(S("upi_id").strip()) and (S("pay_auto") == "1" or S("pay_manual") == "1")


def auto_ready():
    return S("pay_auto") == "1" and bool(S("fam_key").strip()) and bool(S("fam_url").strip())


def show_addbal(c, mid, uid):
    if not pay_ready():
        show(c, mid, "⚠️ <b>Payments abhi set nahi hain.</b>\n\nAdmin se contact karein.", [back_home()])
        return
    quick = [int(v) for v in re.findall(r"\d+", S("quick"))][:9]
    note = fmt(S("txt_addbal_note"), reseller_min=m(SN("reseller_min"))) if SN("reseller_min") > 0 else ""
    t = fmt(S("txt_addbal"), min=m(SN("dep_min", 1)), max=m(SN("dep_max", 100000)), valid=int(SN("qr_valid", 5)), note=note)
    btns = [B(m(a), "dep:%d" % a, style="success") for a in quick]
    kb = grid(btns, 3)
    kb.append([B("✏️ Custom Amount", "dep:c", style="primary")])
    kb.append([B("⬅️ Back", "home", style="primary")])
    show(c, mid, t, kb)


def start_pay(c, uid, amount):
    lo, hi = SN("dep_min", 1), SN("dep_max", 100000)
    amount = round(float(amount), 2)
    if amount < lo or amount > hi:
        send(c, "❌ Amount <b>%s</b> se <b>%s</b> ke beech hona chahiye." % (m(lo), m(hi)),
             [[B("⬅️ Back", "ab", style="primary")]])
        return
    charge = round(amount * SN("charge_pct") / 100, 2)
    payable = round(amount + charge, 2)
    x("UPDATE pays SET status='cancel' WHERE user=? AND status='wait'", (uid,))
    pid = "ORD" + str(int(time.time() * 1000))[-12:]
    x("INSERT INTO pays(id,user,amount,payable,status,created) VALUES(?,?,?,?,?,?)", (pid, uid, amount, payable, "wait", int(time.time())))
    upi = "upi://pay?pa=%s&pn=%s&am=%.2f&cu=INR&tn=%s" % (S("upi_id").strip(), quote_plus(S("upi_name") or S("store_name")), payable, pid)
    qr = "https://api.qrserver.com/v1/create-qr-code/?size=520x520&margin=12&data=" + quote_plus(upi)
    cap = "💳 <b>PAY %s</b>\n━━━━━━━━━━━━━━\n🧾 Order ID: <code>%s</code>\n💰 Balance mein judega: <b>%s</b>\n" % (m(payable), pid, m(amount))
    if charge > 0:
        cap += "🧮 Service charge: %s\n" % m(charge)
    cap += ("\n1️⃣ Kisi bhi UPI app se QR scan karein\n2️⃣ Bilkul <b>%s</b> hi bhejein\n3️⃣ Payment ke baad <b>Verify Payment</b> dabayein\n\n"
            "💳 UPI ID: <code>%s</code>\n⚠️ Ye QR sirf %d minute valid hai.") % (m(payable), esc(S("upi_id")), int(SN("qr_valid", 5)))
    kb = [[B("✅ Verify Payment", "vp:" + pid, style="success")], [B("❌ Cancel Payment", "cp:" + pid, style="danger")]]
    if bad(send_photo(c, qr, cap, kb)):
        send(c, cap + "\n\n<i>QR load nahi hua, UPI ID par pay karein.</i>", kb)


def cancel_pay(c, mid, uid, pid):
    x("UPDATE pays SET status='cancel' WHERE id=? AND user=? AND status IN ('wait')", (pid, uid))
    st_clear(uid)
    delete(c, mid)
    send(c, "❌ <b>Payment cancelled.</b>", [[B("➕ Add Balance", "ab", style="success")], [B("⬅️ Back", "home", style="primary")]])


def verify_prompt(c, mid, uid, pid):
    p = q1("SELECT * FROM pays WHERE id=? AND user=?", (pid, uid))
    if not p or p["status"] != "wait":
        send(c, "ℹ️ Ye payment pehle hi process ho chuka hai.", [[B("⬅️ Menu", "home", style="primary")]])
        return
    if time.time() - p["created"] > SN("qr_valid", 5) * 60:
        x("UPDATE pays SET status='expired' WHERE id=?", (pid,))
        send(c, "⌛ <b>QR expire ho gaya.</b>\n\nNaya payment banane ke liye Add Balance dabayein.",
             [[B("➕ Add Balance", "ab", style="success")]])
        return
    if auto_ready():
        st_set(uid, "utr", pid=pid)
        send(c, "📝 <b>UTR bhejein</b>\n━━━━━━━━━━━━━━\nPayment ke baad UPI app me <b>UTR / Ref No. (12 digit)</b> milta hai, wo yahan bhejein.\n\n"
                "💰 Amount: <b>%s</b>" % m(p["payable"]), [[B("❌ Cancel Payment", "cp:" + pid, style="danger")]])
    elif S("pay_manual") == "1":
        st_set(uid, "proof", pid=pid)
        send(c, "📸 <b>Payment proof bhejein</b>\n━━━━━━━━━━━━━━\nPayment ka <b>screenshot</b> ya <b>UTR number</b> bhejein. Admin check karke balance add karega.",
             [[B("❌ Cancel Payment", "cp:" + pid, style="danger")]])
    else:
        send(c, "⚠️ Payment verify abhi available nahi hai. Admin se contact karein.", [[B("⬅️ Menu", "home", style="primary")]])


def credit_pay(pid, via, utr=""):
    """Credit a deposit exactly once. Returns info dict or None."""
    up = None
    with L:
        p = q1("SELECT * FROM pays WHERE id=?", (pid,))
        if not p or p["status"] not in ("wait", "review"):
            return None
        uid, amt = p["user"], p["amount"]
        bonus = round(amt * SN("bonus_pct") / 100, 2)
        DB.execute("UPDATE pays SET status='ok', kind=?, utr=? WHERE id=?", (via, utr or p["utr"], pid))
        DB.execute("UPDATE users SET balance=balance+?, deposited=deposited+? WHERE id=?", (amt + bonus, amt, uid))
        u = get_user(uid)
        rm = SN("reseller_min")
        upgraded = bool(rm > 0 and u["tier"] != "reseller" and u["deposited"] >= rm)
        if upgraded:
            DB.execute("UPDATE users SET tier='reseller' WHERE id=?", (uid,))
        reward = 0
        if S("ref_on") == "1" and u["ref_by"] and not u["ref_paid"]:
            reward = round(amt * SN("ref_pct") / 100, 2)
            DB.execute("UPDATE users SET ref_paid=1 WHERE id=?", (uid,))
            if reward > 0:
                DB.execute("UPDATE users SET balance=balance+?, ref_earn=ref_earn+? WHERE id=?", (reward, reward, u["ref_by"]))
        DB.commit()
        up = {"uid": uid, "amt": amt, "bonus": bonus, "upgraded": upgraded, "reward": reward, "ref": u["ref_by"],
              "bal": get_user(uid)["balance"], "name": u["name"]}
    t = "✅ <b>PAYMENT SUCCESSFUL</b>\n━━━━━━━━━━━━━━\n💰 Credited: <b>%s</b>\n" % m(up["amt"])
    if up["bonus"]:
        t += "🎁 Bonus: <b>%s</b>\n" % m(up["bonus"])
    t += "💳 New balance: <b>%s</b>" % m(up["bal"])
    if up["upgraded"]:
        t += "\n\n💎 <b>Congrats! Aap ab RESELLER ho — products par Reseller price milega.</b>"
    send(up["uid"], t, [[B("🛒 Shop Now", "m:products", style="success"), B("🏠 Menu", "home", style="primary")]])
    if up["reward"] > 0:
        send(up["ref"], "🎁 <b>Referral reward!</b>\nAapke dost ke deposit par <b>%s</b> aapke balance me add hue." % m(up["reward"]))
    log_ch("💎 <b>NEW DEPOSIT</b>\n━━━━━━━━━━\n💵 %s\n👤 %s <code>%s</code>\n🧾 <code>%s</code>\n📅 %s IST" % (
        m(up["amt"]), esc(up["name"]), up["uid"], pid, now_s()))
    return up


def clean_utr(s):
    return re.sub(r"[^A-Za-z0-9]", "", str(s).strip()).upper()


def notify_review(pid, extra=""):
    p = q1("SELECT * FROM pays WHERE id=?", (pid,))
    u = get_user(p["user"])
    cap = ("🔔 <b>PAYMENT REVIEW</b>\n━━━━━━━━━━━━━━\n👤 %s <code>%s</code>\n💰 Amount: <b>%s</b> (paid %s)\n🧾 <code>%s</code>\n"
           "🔖 UTR: <code>%s</code>\n%s") % (esc(u["name"]), p["user"], m(p["amount"]), m(p["payable"]), pid, esc(p["utr"] or "-"), extra)
    kb = [[B("✅ Approve", "ap:" + pid, style="success"), B("❌ Reject", "rj:" + pid, style="danger")]]
    for a in admin_ids():
        if p["file_id"]:
            if bad(send_photo(a, p["file_id"], cap, kb)):
                send(a, cap, kb)
        else:
            send(a, cap, kb)


def handle_utr(c, uid, text):
    s, xx = st_get(uid)
    pid = xx.get("pid")
    p = q1("SELECT * FROM pays WHERE id=? AND user=?", (pid, uid))
    back = [[B("⬅️ Menu", "home", style="primary")]]
    if not p or p["status"] != "wait":
        st_clear(uid)
        send(c, "❌ Session expire ho gaya. Dobara Add Balance karein.", back)
        return
    utr = clean_utr(text)
    if len(utr) < 6:
        send(c, "❌ <b>Invalid UTR.</b> Kam se kam 6 letters/digits chahiye. Dobara bhejein:")
        return
    if q1("SELECT 1 FROM utrs WHERE utr=?", (utr,)):
        send(c, "❌ <b>Ye UTR pehle use ho chuka hai.</b>", [[B("⬅️ Menu", "home", style="primary")]])
        return
    send(c, "⏳ <b>Verifying...</b> Please wait.")
    res = verify_utr(utr, p["payable"])
    if res.get("type") == "not_found":
        time.sleep(3)
        res = verify_utr(utr, p["payable"])
    if res.get("ok"):
        with L:
            if q1("SELECT 1 FROM utrs WHERE utr=?", (utr,)):
                send(c, "❌ <b>Ye UTR pehle use ho chuka hai.</b>", back)
                return
            DB.execute("INSERT INTO utrs VALUES(?,?,?,?)", (utr, uid, p["payable"], int(time.time())))
            DB.commit()
        st_clear(uid)
        credit_pay(pid, "auto", utr)
        return
    if res.get("type") == "api_error":
        if S("pay_manual") == "1":
            x("UPDATE pays SET status='review', utr=? WHERE id=?", (utr, pid))
            st_clear(uid)
            send(c, "⚠️ <b>Auto verification abhi available nahi.</b>\n\nAapka payment <b>manually verify</b> hoga.\n🧾 <code>%s</code>" % pid, back)
            notify_review(pid, "⚠️ Auto API failed: %s" % esc(res.get("msg", "")))
        else:
            send(c, "⚠️ Verification service abhi down hai. Thodi der baad Verify Payment dabayein.", back)
        return
    kb = [[B("🔄 Try Again", "vp:" + pid, style="primary")]]
    if S("pay_manual") == "1":
        kb.append([B("📸 Send Screenshot", "vm:" + pid, style="success")])
    kb.append([B("❌ Cancel Payment", "cp:" + pid, style="danger")])
    send(c, "❌ <b>Transaction not found</b>\n━━━━━━━━━━━━━━\n%s\n\n💡 UTR sahi hai aur payment complete hui hai? Check karke dobara try karein." % esc(res.get("msg") or "Payment nahi mila"), kb)


def handle_proof(c, uid, msg):
    s, xx = st_get(uid)
    pid = xx.get("pid")
    p = q1("SELECT * FROM pays WHERE id=? AND user=?", (pid, uid))
    if not p or p["status"] != "wait":
        st_clear(uid)
        send(c, "❌ Session expire ho gaya.", [[B("⬅️ Menu", "home", style="primary")]])
        return
    fid = ""
    if msg.get("photo"):
        fid = msg["photo"][-1]["file_id"]
    txt = clean_utr(msg.get("text") or msg.get("caption") or "")
    if not fid and len(txt) < 6:
        send(c, "❌ Screenshot ya valid UTR bhejein.")
        return
    x("UPDATE pays SET status='review', utr=?, file_id=? WHERE id=?", (txt, fid, pid))
    st_clear(uid)
    send(c, "✅ <b>Proof mil gaya!</b>\n\nAdmin verify karke balance add kar dega.\n🧾 <code>%s</code>" % pid,
         [[B("⬅️ Menu", "home", style="primary")]])
    notify_review(pid)


def approve_pay(c, mid, aid, pid, ok_):
    p = q1("SELECT * FROM pays WHERE id=?", (pid,))
    if not p or p["status"] not in ("wait", "review"):
        return "Already processed"
    if ok_:
        if p["utr"]:
            x("INSERT OR IGNORE INTO utrs VALUES(?,?,?,?)", (p["utr"], p["user"], p["amount"], int(time.time())))
        credit_pay(pid, "manual", p["utr"])
        return "✅ Approved"
    x("UPDATE pays SET status='rej' WHERE id=?", (pid,))
    send(p["user"], "❌ <b>Payment reject ho gaya.</b>\n🧾 <code>%s</code>\n\nGalti se hua ho to support se contact karein." % pid)
    return "❌ Rejected"


# ---- FamPay (UTR verification) ----
_SUCCESS = ["true", "1", "yes", "success", "paid", "completed", "approved", "received", "ok", "200"]
_FAIL = ["false", "0", "no", "failed", "failure", "error", "invalid", "pending", "not found", "unpaid", "rejected", "cancelled", "not received"]
_POS = ["success", "received", "paid", "completed", "approved"]
_API_PATHS = ["/verify", "/api/verify", "/verify_utr", "/api/verify_utr", "/check", "/api/check", "/verify-payment", "/api/verify-payment"]


def _ps(v):
    if v is True:
        return "1"
    if v is False or v is None:
        return ""
    return "Array" if isinstance(v, (list, dict)) else str(v)


def _parse_verify(res):
    if not res:
        return {"ok": False, "type": "api_error", "msg": "Verification service not reachable."}
    try:
        j = json.loads(res)
    except ValueError:
        j = None
    if isinstance(j, (dict, list)):
        flat = dict(j) if isinstance(j, dict) else {}
        if isinstance(j, dict):
            for key in ("data", "result", "response", "payment", "transaction"):
                if isinstance(j.get(key), dict):
                    flat.update(j[key])
        for k in ("success", "paid", "completed", "verified", "utr_status", "payment_status", "transaction_status"):
            if flat.get(k) is not None:
                v = flat[k]
                if v is True or (isinstance(v, int) and not isinstance(v, bool) and v == 1):
                    return {"ok": True}
                if isinstance(v, str) and v.strip().lower() in _SUCCESS:
                    return {"ok": True}
        for k in ("status", "state", "result", "code", "response_code"):
            if flat.get(k) is not None and _ps(flat[k]).strip().lower() in _SUCCESS:
                return {"ok": True}
        msg = ""
        for k in ("message", "msg", "response", "remark", "description"):
            if flat.get(k) is not None:
                msg = _ps(flat[k])
                break
        if msg:
            ml = msg.lower()
            if any(w in ml for w in _POS) and not any(w in ml for w in _FAIL):
                return {"ok": True}
        return {"ok": False, "type": "not_found", "msg": msg if msg not in ("", "0") else "Payment not found"}
    low = res.strip().lower().strip("\"'")
    if low in _SUCCESS[:8]:
        return {"ok": True}
    if any(w in low for w in _POS) and not any(w in low for w in _FAIL):
        return {"ok": True}
    return {"ok": False, "type": "not_found", "msg": "Payment not found. Please verify UTR."}


def verify_utr(utr, amount):
    key, base = S("fam_key").strip(), S("fam_url").strip().rstrip("/")
    if not key:
        return {"ok": False, "type": "api_error", "msg": "FamPay API key not set."}
    if not base:
        return {"ok": False, "type": "api_error", "msg": "FamPay URL not set."}
    utr = clean_utr(utr)
    has_path = "?" in base or bool(re.match(r"^https?://[^/]+/.+", base))
    paths = [""] if has_path else list(_API_PATHS)
    known = S("fam_path")
    if not has_path and known in paths:
        paths.remove(known)
        paths.insert(0, known)
    qs = "api_key=%s&key=%s&utr=%s&txn_id=%s&amount=%s" % tuple(quote_plus(v) for v in (key, key, utr, utr, "%.2f" % float(amount)))
    for pth in paths:
        url = base + pth
        try:
            r = requests.get(url + ("&" if "?" in url else "?") + qs, timeout=(10, 45))
            code, res = r.status_code, r.text
        except requests.RequestException:
            return {"ok": False, "type": "api_error", "msg": "Verification service not reachable."}
        log("verify %s -> [%s] %s" % (utr, code, res[:300]))
        if code in (401, 403):
            return {"ok": False, "type": "api_error", "msg": "API key rejected."}
        if code >= 500:
            return {"ok": False, "type": "api_error", "msg": "Verification service error."}
        if code in (404, 405):
            try:
                j = json.loads(res)
            except ValueError:
                j = None
            if not (isinstance(j, dict) and j and set(j.keys()) != {"detail"}):
                continue
        out = _parse_verify(res)
        if pth and not has_path and S("fam_path") != pth:
            setS("fam_path", pth)
        return out
    return {"ok": False, "type": "api_error", "msg": "Verification endpoint not found. Set the full URL in Payments."}


# ============================================================
# LUCKY SPIN
# ============================================================
def prizes():
    out = []
    for part in S("spin_prizes").replace("\n", ",").split(","):
        if ":" in part:
            a, w = part.split(":", 1)
            try:
                out.append((float(a), max(float(w), 0)))
            except ValueError:
                pass
    return out or [(0.0, 1.0)]


def spin_left(u):
    return int(u["spun"] + SN("spin_hours", 24) * 3600 - time.time())


def show_spin(c, mid, uid):
    u = get_user(uid)
    t = "🎰 <b>LUCKY SPIN</b>\n━━━━━━━━━━━━━━\nHar <b>%g</b> ghante me 1 free spin! Wallet balance jeetein 🍀\n\n🎁 <b>Prizes:</b> %s\n" % (
        SN("spin_hours", 24), "  ".join("<b>%s</b>" % m(a) for a, _w in sorted(prizes(), key=lambda z: z[0]) if a > 0))
    kb = []
    left = spin_left(u)
    if u["deposited"] + 1e-9 < SN("spin_min_dep"):
        t += "\n🔒 Spin unlock karne ke liye total deposit <b>%s</b> chahiye (aapka: %s)." % (m(SN("spin_min_dep")), m(u["deposited"]))
    elif left > 0:
        t += "\n⏳ Next spin: <b>%dh %dm</b> baad" % (left // 3600, (left % 3600) // 60)
    else:
        t += "\n✅ <b>Aapka spin ready hai!</b>"
        kb.append([B("🎰 SPIN NOW", "spin:go", style="success")])
    kb.append(back_home())
    show(c, mid, t, kb)


def do_spin(c, mid, uid):
    with L:
        u = get_user(uid)
        if u["deposited"] + 1e-9 < SN("spin_min_dep") or spin_left(u) > 0:
            return show_spin(c, mid, uid)
        ps = prizes()
        prize = random.choices([a for a, _w in ps], weights=[w if w > 0 else 0.0001 for _a, w in ps])[0]
        DB.execute("UPDATE users SET spun=?, balance=balance+? WHERE id=?", (int(time.time()), prize, uid))
        DB.commit()
    show(c, mid, "🎰 <b>Spinning...</b>\n\n🎲  🎲  🎲")
    time.sleep(0.9)
    show(c, mid, "🎰 <b>Spinning...</b>\n\n🍀  🎁  💰")
    time.sleep(0.9)
    if prize > 0:
        t = "🎉 <b>YOU WON %s!</b>\n\nPrize aapke wallet me add ho gaya.\n💳 Balance: <b>%s</b>" % (m(prize), m(get_user(uid)["balance"]))
    else:
        t = "😅 <b>Better luck next time!</b>\n\nIs baar kuch nahi mila. Agla spin %g ghante baad." % SN("spin_hours", 24)
    show(c, mid, t, [back_home()])


# ============================================================
# DEFAULT CATALOG  (categories + products + plans; all editable / removable from /admin)
# ============================================================
DEFAULT_PLANS = [("3 DAYS", 99, 3), ("7 DAYS", 149, 7), ("15 DAYS", 229, 15), ("30 DAYS", 349, 30)]
DEFAULT_CATALOG = [
    ("NON ROOT", [("HAXX-CKER PRO", ""), ("RAPID CORE", "")]),
    ("ROOT", [("PATO TEAM", ""), ("PC5", ""), ("BALA MOD V6", ""), ("DRIP WIRE", ""), ("ABCD PANEL", ""),
              ("PANTHOM MOD 🔴", "danger"), ("X REG 🔴", "danger"), ("DRIP CLIENT", "")]),
    ("IOS", [("ALPHA REGEDIT", "")]),
]


def seed_defaults():
    """Adds the default categories/products/plans that are not there yet. Returns (cats, prods) added."""
    nc = npr = 0
    for ci, (cname, prods) in enumerate(DEFAULT_CATALOG, 1):
        cat = q1("SELECT id FROM cats WHERE name=?", (cname,))
        if cat:
            cid = cat["id"]
        else:
            cid = x("INSERT INTO cats(name,sort) VALUES(?,?)", (cname, ci))
            nc += 1
        for pi, (pname, pstyle) in enumerate(prods, 1):
            if q1("SELECT id FROM prods WHERE name=? AND cat_id=?", (pname, cid)):
                continue
            pid = x("INSERT INTO prods(cat_id,name,style,sort) VALUES(?,?,?,?)", (cid, pname, pstyle, pi))
            npr += 1
            for li, (ln, lp, ld) in enumerate(DEFAULT_PLANS, 1):
                x("INSERT INTO plans(prod_id,name,price,days,sort) VALUES(?,?,?,?,?)", (pid, ln, lp, ld, li))
    return nc, npr


# ============================================================
# ADMIN PANEL
# ============================================================
FIELDS = {
    "c": ("cats", {"name": ("Name", "plain"), "emoji": ("Emoji (normal)", "plain"), "eid": ("Premium emoji (send it or its ID)", "eid"),
                   "sort": ("Sort number (small = first)", "int")}),
    "p": ("prods", {"name": ("Product name", "plain"), "emoji": ("Emoji (normal)", "plain"),
                    "eid": ("Premium emoji (send it or its ID)", "eid"), "descr": ("Description (shown on product page)", "html"),
                    "note": ("After-buy note (shown with the key; {key} {order} allowed)", "html"), "sort": ("Sort number", "int"),
                    "api_url": ("API URL (placeholders allowed)", "plain"), "api_body": ("API body (JSON or form text)", "plain"),
                    "api_headers": ("API headers as JSON", "plain"), "api_path": ("Response key path e.g. data.key", "plain")}),
    "l": ("plans", {"name": ("Plan name e.g. 3 DAYS", "plain"), "price": ("Price", "float"), "rprice": ("Reseller price (0 = same)", "float"),
                    "days": ("Days (sent to API as {days})", "int"), "sort": ("Sort number", "int")}),
}
SETS = {
    "store_name": ("Store name", "plain"), "currency": ("Currency symbol", "plain"), "support_user": ("Support @username", "plain"),
    "log_channel": ("Log channel (-100… ID or @channel) - bot must be admin there", "plain"),
    "upi_id": ("UPI ID", "plain"), "upi_name": ("UPI payee name", "plain"), "fam_key": ("FamPay API key", "secret"),
    "fam_url": ("FamPay API URL (https://…)", "url"), "dep_min": ("Minimum deposit", "float"), "dep_max": ("Maximum deposit", "float"),
    "quick": ("Quick amount buttons, comma separated", "plain"), "charge_pct": ("Service charge % added to QR amount", "float"),
    "bonus_pct": ("Deposit bonus %", "float"), "qr_valid": ("QR valid minutes", "int"),
    "reseller_min": ("User becomes RESELLER after total deposit of (0 = off)", "float"),
    "ref_pct": ("Referral reward % of friend's first deposit", "float"), "spin_hours": ("Spin cooldown in hours", "float"),
    "spin_min_dep": ("Minimum total deposit needed to spin", "float"),
    "spin_prizes": ("Spin prizes as amount:chance, comma separated  e.g. 0:40,1:25,5:10", "plain"),
    "txt_welcome": ("Dashboard / welcome text", "html"), "txt_cat_title": ("Category list text", "html"),
    "txt_prod_title": ("Product list text", "html"), "txt_howto": ("How To Use text", "html"), "txt_support": ("Support text", "html"),
    "txt_refer": ("Refer & Earn text", "html"), "txt_addbal": ("Add Balance text", "html"),
    "txt_addbal_note": ("Add Balance reseller note", "html"),
}
HINTS = {
    "txt_welcome": "{name} {balance} {tier} {store} {id}", "txt_support": "{support}", "txt_refer": "{pct} {link} {count} {earned}",
    "txt_addbal": "{min} {max} {valid} {note}", "txt_addbal_note": "{reseller_min}",
}
TOGGLES = {"bold_btn": "🔠 Bold buttons", "pay_auto": "⚡ Auto verify (FamPay)", "pay_manual": "✋ Manual approve", "show_stock": "📦 Show stock count",
           "ref_on": "🎁 Refer & Earn", "spin_on": "🎰 Lucky Spin", "maint": "🛠 Maintenance"}
SET_BACK = {"pay": "a:pay", "txt": "a:look", "ref": "a:sr", "spin": "a:sr"}


def set_back(key):
    if key == "txt_welcome":
        return "a:wel"
    return SET_BACK.get(key.split("_")[0], "a:set")


def tog_btn(key):
    on = S(key) == "1"
    return B("%s %s" % ("🟢" if on else "⚪", TOGGLES[key]), "st:" + key, style="success" if on else "danger")


def adm_home(c, mid, uid):
    pend = q1("SELECT COUNT(*) n FROM pays WHERE status='review'")["n"]
    kb = [[B("📦 Products", "a:cats", style="success"), B("💳 Payments", "a:pay", style="primary")],
          [B("🎨 Texts & Buttons", "a:look", style="primary"), B("👥 Users", "a:usr", style="success")],
          [B("🎁 Spin & Refer", "a:sr", style="success"), B("📢 Broadcast", "a:bc", style="primary")],
          [B("📊 Stats", "a:stats", style="primary"), B("⚙️ Settings", "a:set", style="success")],
          [B("🕒 Pending Payments (%d)" % pend, "a:pend", style="danger" if pend else "primary")],
          [B("⬅️ Back to Menu", "home", style="primary")]]
    show(c, mid, "⚙️ <b>ADMIN PANEL</b> — %s\n━━━━━━━━━━━━━━\nSab kuch yahin se set hota hai: products, keys, payments, texts, buttons, premium emoji." % esc(S("store_name")), kb)


# ---------- generic field / setting editors ----------
def prompt_field(c, uid, t, id_, f, back):
    lab, kind = FIELDS[t][1][f]
    cur = q1("SELECT %s v FROM %s WHERE id=?" % (f, FIELDS[t][0]), (id_,))
    cur = cur["v"] if cur else ""
    tip = "\n\n💎 Premium emoji seedha message me daal sakte ho." if kind == "html" else ""
    if kind == "eid":
        tip = "\n\n💎 Premium emoji bhejein (ya uski numeric ID). <code>-</code> bhejein clear karne ke liye."
    st_set(uid, "ef", t=t, id=id_, f=f, back=back)
    send(c, "✏️ <b>%s</b>\n\nAbhi: <code>%s</code>\n\nNaya value bhejein.%s\n<i><code>-</code> = khali karein</i>" % (
        esc(lab), esc(str(cur)[:400]) or "—", tip), [[B("❌ Cancel", back, style="danger")]])


def prompt_setting(c, uid, key):
    lab, kind = SETS[key]
    back = set_back(key)
    cur = S(key)
    shown = "••••" + cur[-4:] if kind == "secret" and cur else cur
    tip = ""
    if kind == "html":
        tip = "\n\n💎 Premium emoji aur formatting (bold/italic) seedha message me use kar sakte ho.\n📌 Placeholders: <code>%s</code>\n" \
              "↩️ /reset = default text" % esc(HINTS.get(key, "(none)"))
    st_set(uid, "ss", key=key, back=back)
    send(c, "✏️ <b>%s</b>\n\nAbhi:\n<code>%s</code>%s" % (esc(lab), esc(shown[:900]) or "—", tip), [[B("❌ Cancel", back, style="danger")]])


def parse_val(kind, msg):
    text = msg.get("text") or msg.get("caption") or ""
    raw = text.strip()
    ents = msg.get("entities") or msg.get("caption_entities") or []
    if kind == "eid":
        for e in ents:
            if e.get("type") == "custom_emoji":
                return True, e["custom_emoji_id"]
        if raw == "-":
            return True, ""
        return (True, raw) if raw.isdigit() else (False, "Premium emoji bhejein ya numeric ID likhein.")
    if not raw:
        return False, "Text bhejein."
    if kind == "html":
        return True, "" if raw == "-" else ent_html(text, ents).strip()
    if kind in ("int", "float"):
        if raw == "-":
            return True, 0
        try:
            v = float(raw.replace(",", ""))
        except ValueError:
            return False, "Number bhejein."
        return True, int(v) if kind == "int" else v
    if kind == "url":
        return (True, "") if raw == "-" else ((True, raw) if raw.startswith("http") else (False, "https:// se shuru hone wala URL bhejein."))
    return True, "" if raw == "-" else raw


# ---------- categories ----------
def adm_cats(c, mid):
    cats = q("SELECT c.*, (SELECT COUNT(*) FROM prods p WHERE p.cat_id=c.id) n FROM cats c ORDER BY sort,id")
    btns = [B("%s%s (%d)" % ("" if r["active"] else "🙈 ", label(r), r["n"]), "a:c:%d" % r["id"], style=r["style"] or PALETTE[i % 3], eid=r["eid"])
            for i, r in enumerate(cats)]
    ids = [r["id"] for r in cats]
    if [p for p in q("SELECT cat_id FROM prods") if p["cat_id"] not in ids]:
        btns.append(B("📦 Other / No category", "a:c:0", style="primary"))
    kb = grid(btns, 2) + [[B("➕ Add Category", "cadd", style="success")],
                          [B("📥 Load Default Catalog", "seed", style="primary")], [B("⬅️ Back", "a", style="primary")]]
    show(c, mid, "📦 <b>CATEGORIES</b>\n━━━━━━━━━━━━━━\nCategory pe tap karke uske products manage karein.\n"
                 "<i>Category na banao to products seedhe list me dikhenge.</i>", kb)


def adm_cat(c, mid, cid):
    if cid == 0:
        ids = [r["id"] for r in q("SELECT id FROM cats")]
        ps = [p for p in q("SELECT * FROM prods ORDER BY sort,id") if p["cat_id"] not in ids]
        r = None
    else:
        r = q1("SELECT * FROM cats WHERE id=?", (cid,))
        if not r:
            return adm_cats(c, mid)
        ps = q("SELECT * FROM prods WHERE cat_id=? ORDER BY sort,id", (cid,))
    kb = [[B("%s%s" % ("" if p["active"] else "🙈 ", label(p)), "a:p:%d" % p["id"], style=p["style"] or "success", eid=p["eid"])] for p in ps]
    kb.append([B("➕ Add Product", "padd:%d" % cid, style="success")])
    if r:
        kb += [[B("✏️ Name", "ef:c:%d:name" % cid, style="primary"), B("😀 Emoji", "ef:c:%d:emoji" % cid, style="primary")],
               [B("💎 Premium Emoji", "ef:c:%d:eid" % cid, style="success"), B("🎨 Color: %s" % (r["style"] or "auto"), "cy:c:%d:style" % cid, style=r["style"] or "primary")],
               [B("%s Visible" % ("🟢" if r["active"] else "⚪"), "tg:c:%d:active" % cid, style="success" if r["active"] else "danger"),
                B("🔢 Sort: %d" % r["sort"], "ef:c:%d:sort" % cid, style="primary")],
               [B("🗑 Delete Category", "del:c:%d" % cid, style="danger")]]
    kb.append([B("⬅️ Back", "a:cats", style="primary")])
    show(c, mid, "📂 <b>%s</b>\n━━━━━━━━━━━━━━\nProducts: <b>%d</b>" % (esc(r["name"]) if r else "Other products", len(ps)), kb)


# ---------- products ----------
def adm_prod(c, mid, pid):
    p = q1("SELECT * FROM prods WHERE id=?", (pid,))
    if not p:
        return adm_cats(c, mid)
    cat = q1("SELECT name FROM cats WHERE id=?", (p["cat_id"],))
    pls = q("SELECT * FROM plans WHERE prod_id=? ORDER BY sort,price,id", (pid,))
    mode = {"stock": "📦 Admin stock keys", "api": "🔌 API key generation", "both": "📦 Stock first, then 🔌 API"}[p["mode"]]
    t = ("📦 <b>%s</b>\n━━━━━━━━━━━━━━\n📂 Category: <b>%s</b>\n👁 Visible: <b>%s</b>\n🔑 Key delivery: <b>%s</b>\n" % (
        esc(p["name"]), esc(cat["name"]) if cat else "—", "Yes" if p["active"] else "Hidden", mode))
    if p["mode"] != "stock":
        t += "🔌 API: %s\n" % ("✅ set" if p["api_url"].strip() else "⚠️ URL not set")
    t += "🖼 Media: <b>%s</b>\n" % (MEDIA_ICON.get(p.get("media_type"), "✅") if p.get("media_id") else "— (none)")
    t += "\n🧾 <b>Plans</b>\n"
    t += "".join("▫️ %s — %s / %s  ·  📦 %d\n" % (esc(pl["name"]), m(pl["price"]), m(pl["rprice"]) if pl["rprice"] else "-", stock_n(pl["id"])) for pl in pls) or "(koi plan nahi)\n"
    kb = [[B("✏️ Name", "ef:p:%d:name" % pid, style="primary"), B("📝 Description", "ef:p:%d:descr" % pid, style="primary")],
          [B("😀 Emoji", "ef:p:%d:emoji" % pid, style="primary"), B("💎 Premium Emoji", "ef:p:%d:eid" % pid, style="success")],
          [B("🎨 Button color: %s" % (p["style"] or "auto"), "cy:p:%d:style" % pid, style=p["style"] or "success"),
           B("🎁 After-buy note", "ef:p:%d:note" % pid, style="primary")],
          [B("🔁 Delivery: %s" % p["mode"].upper(), "cy:p:%d:mode" % pid, style="success")],
          [B("🖼 Media: %s" % ("change" if p.get("media_id") else "add photo / video"), "mp:%d" % pid, style="success")]
         + ([B("🗑 Remove media", "mpx:%d" % pid, style="danger")] if p.get("media_id") else [])]
    if p["mode"] != "stock":
        kb.append([B("🔌 API Settings", "a:api:%d" % pid, style="success")])
    kb += [[B("📋 Plans & Keys (%d)" % len(pls), "a:pl:%d" % pid, style="success")],
           [B("📂 Move Category", "mvl:%d" % pid, style="primary"), B("%s Visible" % ("🟢" if p["active"] else "⚪"), "tg:p:%d:active" % pid, style="success" if p["active"] else "danger")],
           [B("🔢 Sort: %d" % p["sort"], "ef:p:%d:sort" % pid, style="primary"), B("🗑 Delete", "del:p:%d" % pid, style="danger")],
           [B("⬅️ Back", "a:c:%d" % p["cat_id"], style="primary")]]
    show(c, mid, t, kb)


def adm_api(c, mid, pid):
    p = q1("SELECT * FROM prods WHERE id=?", (pid,))
    if not p:
        return adm_cats(c, mid)

    def sh(v):
        return esc(v[:70]) if v else "—"
    t = ("🔌 <b>API KEY GENERATION</b> — %s\n━━━━━━━━━━━━━━\n🔗 URL: <code>%s</code>\n📡 Method: <b>%s</b>\n📦 Body: <code>%s</code>\n"
         "🧾 Headers: <code>%s</code>\n🎯 Key path: <code>%s</code>\n\n"
         "📌 <b>Placeholders</b> (URL/body/headers me):\n<code>{days} {plan} {product} {user} {order} {price}</code>\n"
         "Example URL: <code>https://panel.com/api/gen?token=XXX&amp;days={days}</code>\n\n"
         "Response JSON ho to <b>Key path</b> (jaise <code>data.key</code>) se key nikalti hai; khali ho to <code>key / license / token / data</code> auto-detect hota hai. "
         "JSON na ho to poora text key maana jata hai.") % (esc(p["name"]), sh(p["api_url"]), p["api_method"], sh(p["api_body"]), sh(p["api_headers"]), sh(p["api_path"]))
    kb = [[B("🔗 API URL", "ef:p:%d:api_url" % pid, style="success"), B("📡 Method: %s" % p["api_method"], "cy:p:%d:api_method" % pid, style="primary")],
          [B("📦 Body", "ef:p:%d:api_body" % pid, style="primary"), B("🧾 Headers", "ef:p:%d:api_headers" % pid, style="primary")],
          [B("🎯 Key path", "ef:p:%d:api_path" % pid, style="primary"), B("🧪 Test API", "apit:%d" % pid, style="success")],
          [B("⬅️ Back", "a:p:%d" % pid, style="primary")]]
    show(c, mid, t, kb)


def api_test(c, mid, pid):
    p = q1("SELECT * FROM prods WHERE id=?", (pid,))
    pl = q1("SELECT * FROM plans WHERE prod_id=? ORDER BY sort,price,id LIMIT 1", (pid,)) or {"id": 0, "name": "TEST", "days": 1, "price": 0}
    ok, res, raw = api_gen(p, pl, 0, "TEST")
    t = "🧪 <b>API TEST</b>\n━━━━━━━━━━━━━━\n%s\n\n" % ("✅ <b>Key mil gayi:</b>\n<code>%s</code>" % esc(res) if ok else "❌ <b>Failed:</b> %s" % esc(res))
    t += "📄 <b>Raw response:</b>\n<code>%s</code>\n\n<i>Test se koi order/balance nahi kata. Dhyan rahe API panel pe real key ban sakti hai.</i>" % (esc(raw[:700]) or "(empty)")
    show(c, mid, t, [[B("⬅️ Back", "a:api:%d" % pid, style="primary")]])


def adm_plans(c, mid, pid):
    p = q1("SELECT name FROM prods WHERE id=?", (pid,))
    pls = q("SELECT * FROM plans WHERE prod_id=? ORDER BY sort,price,id", (pid,))
    kb = [[B("%s%s — %s · 📦 %d" % ("" if pl["active"] else "🙈 ", pl["name"], m(pl["price"]), stock_n(pl["id"])), "a:l:%d" % pl["id"], style="success")] for pl in pls]
    kb.append([B("➕ Add Plan", "ladd:%d" % pid, style="success")])
    kb.append([B("⬅️ Back", "a:p:%d" % pid, style="primary")])
    show(c, mid, "📋 <b>PLANS</b> — %s\n━━━━━━━━━━━━━━\nPlan pe tap karke price / keys manage karein." % esc(p["name"] if p else ""), kb)


def adm_plan(c, mid, plid):
    pl = q1("SELECT * FROM plans WHERE id=?", (plid,))
    if not pl:
        return adm_cats(c, mid)
    pr = q1("SELECT * FROM prods WHERE id=?", (pl["prod_id"],))
    used = q1("SELECT COUNT(*) n FROM keys WHERE plan_id=? AND used=1", (plid,))["n"]
    t = ("📋 <b>%s</b> — %s\n━━━━━━━━━━━━━━\n💰 Price: <b>%s</b>\n💎 Reseller price: <b>%s</b>\n📅 Days: <b>%d</b>\n"
         "📦 Stock left: <b>%d</b>   ✅ Sold: <b>%d</b>\n👁 Visible: <b>%s</b>") % (
        esc(pl["name"]), esc(pr["name"]), m(pl["price"]), m(pl["rprice"]) if pl["rprice"] else "same", pl["days"],
        stock_n(plid), used, "Yes" if pl["active"] else "Hidden")
    if pr["mode"] == "api":
        t += "\n\n<i>Is product ka delivery mode API hai, stock keys ki zarurat nahi.</i>"
    kb = [[B("✏️ Name", "ef:l:%d:name" % plid, style="primary"), B("💰 Price", "ef:l:%d:price" % plid, style="success")],
          [B("💎 Reseller price", "ef:l:%d:rprice" % plid, style="primary"), B("📅 Days", "ef:l:%d:days" % plid, style="primary")],
          [B("➕ Add Keys", "kadd:%d" % plid, style="success"), B("📄 View Keys", "kview:%d" % plid, style="primary")],
          [B("🧹 Clear unused keys", "kclr:%d" % plid, style="danger"), B("%s Visible" % ("🟢" if pl["active"] else "⚪"), "tg:l:%d:active" % plid, style="success" if pl["active"] else "danger")],
          [B("🔢 Sort: %d" % pl["sort"], "ef:l:%d:sort" % plid, style="primary"), B("🗑 Delete Plan", "del:l:%d" % plid, style="danger")],
          [B("⬅️ Back", "a:pl:%d" % pl["prod_id"], style="primary")]]
    show(c, mid, t, kb)


def go_entity(t, id_, f=""):
    return {"c": lambda c, mid: adm_cat(c, mid, id_), "l": lambda c, mid: adm_plan(c, mid, id_),
            "p": (lambda c, mid: adm_api(c, mid, id_)) if f.startswith("api_") else (lambda c, mid: adm_prod(c, mid, id_))}[t]


def parent_after_delete(t, id_, pid_):
    return {"c": lambda c, mid: adm_cats(c, mid), "p": lambda c, mid: adm_cat(c, mid, pid_), "l": lambda c, mid: adm_plans(c, mid, pid_)}[t]


def add_keys_text(c, uid, plid, text):
    pl = q1("SELECT * FROM plans WHERE id=?", (plid,))
    if not pl:
        return
    have = {r["val"] for r in q("SELECT val FROM keys WHERE plan_id=?", (plid,))}
    new = []
    for ln in text.replace("\r", "").split("\n"):
        k = ln.strip()
        if k and k not in have:
            have.add(k)
            new.append(k)
    with L:
        for k in new:
            DB.execute("INSERT INTO keys(plan_id,val,added) VALUES(?,?,?)", (plid, k, now_s()))
        DB.commit()
    st_clear(uid)
    send(c, "✅ <b>%d keys add ho gayi</b> (duplicate skip). Total stock: <b>%d</b>" % (len(new), stock_n(plid)))
    adm_plan(c, None, plid)


# ---------- payments / settings pages ----------
def adm_pay(c, mid):
    def v(k, secret=False):
        s = S(k)
        return ("••••" + s[-4:]) if secret and s else (esc(s) or "—")
    t = ("💳 <b>PAYMENTS</b>\n━━━━━━━━━━━━━━\n💳 UPI ID: <code>%s</code>\n👤 Payee: <code>%s</code>\n🔑 FamPay key: <code>%s</code>\n🌐 FamPay URL: <code>%s</code>\n\n"
         "💵 Min / Max: <b>%s / %s</b>\n🧮 Service charge: <b>%g%%</b>   🎁 Bonus: <b>%g%%</b>\n⏰ QR valid: <b>%d min</b>\n⚡ Quick: <code>%s</code>\n\n"
         "⚡ <b>Auto</b> = user UTR bhejta hai, FamPay verify karta hai, balance turant.\n✋ <b>Manual</b> = aap Pending me Approve karte ho.") % (
        v("upi_id"), v("upi_name"), v("fam_key", True), v("fam_url"), m(SN("dep_min")), m(SN("dep_max")), SN("charge_pct"), SN("bonus_pct"),
        SN("qr_valid", 5), v("quick"))
    kb = [[tog_btn("pay_auto"), tog_btn("pay_manual")],
          [B("💳 UPI ID", "ss:upi_id", style="success"), B("👤 Payee name", "ss:upi_name", style="primary")],
          [B("🔑 FamPay key", "ss:fam_key", style="success"), B("🌐 FamPay URL", "ss:fam_url", style="primary")],
          [B("⬇️ Min", "ss:dep_min", style="primary"), B("⬆️ Max", "ss:dep_max", style="primary")],
          [B("⚡ Quick amounts", "ss:quick", style="success"), B("⏰ QR minutes", "ss:qr_valid", style="primary")],
          [B("🧮 Service charge %", "ss:charge_pct", style="primary"), B("🎁 Bonus %", "ss:bonus_pct", style="success")],
          [B("🧪 Test FamPay", "fptest", style="success"), B("🕒 Pending", "a:pend", style="primary")],
          [B("⬅️ Back", "a", style="primary")]]
    show(c, mid, t, kb)


def adm_look(c, mid):
    rows = [("txt_welcome", "🏠 Dashboard text"), ("txt_cat_title", "🗂 Category text"), ("txt_prod_title", "🛍 Product list text"),
            ("txt_howto", "📖 How To Use"), ("txt_support", "🛟 Support text"), ("txt_refer", "🎁 Refer text"),
            ("txt_addbal", "💰 Add Balance text"), ("txt_addbal_note", "💎 Reseller note")]
    kb = [[B("👋 Welcome Text + Photo/Video", "a:wel", style="success")]]
    kb += grid([B(lbl, "ss:" + k, style=["success", "primary"][i % 2]) for i, (k, lbl) in enumerate(rows)], 2)
    kb += [[B("🎛 Main Buttons (name / color / premium emoji)", "a:btn", style="success")],
           [B("🆔 Premium Emoji ID Finder", "idf", style="primary"), tog_btn("show_stock")],
           [tog_btn("bold_btn")],
           [B("⬅️ Back", "a", style="primary")]]
    show(c, mid, "🎨 <b>TEXTS &amp; BUTTONS</b>\n━━━━━━━━━━━━━━\nBot ke saare messages aur buttons yahan se badlo. Texts me <b>premium emoji</b> seedha bhej sakte ho.", kb)


def adm_welcome(c, mid):
    has = bool(S("welcome_media_id"))
    t = ("👋 <b>WELCOME SETUP</b>\n━━━━━━━━━━━━━━\n"
         "🎬 Media: <b>%s</b>\n\n📝 <b>Welcome text:</b>\n<code>%s</code>\n\n"
         "<i>/start par user ko ye text + photo/video milega. Text: {name} {balance} {tier} {store} {id}</i>") % (
        MEDIA_ICON.get(S("welcome_media_type"), "✅") if has else "— (none)", esc(S("txt_welcome")[:500]))
    kb = [[B("📝 Edit Welcome Text", "ss:txt_welcome", style="primary")],
          [B("🎬 %s Welcome Photo / Video" % ("Change" if has else "Add"), "wm", style="success")]]
    if has:
        kb.append([B("🗑 Remove Welcome Media", "wmx", style="danger")])
    kb += [[B("👁 Preview", "wp", style="primary")], [B("⬅️ Back", "a:look", style="primary")]]
    show(c, mid, t, kb)


def adm_btns(c, mid):
    kb = []
    for k in DEFBTN:
        cf = bcfg(k)
        kb.append(B(("" if int(cf.get("on", 1)) else "🙈 ") + cf["t"], "a:b:" + k, style=cf["s"], eid=cf["e"]))
    show(c, mid, "🎛 <b>MAIN BUTTONS</b>\n━━━━━━━━━━━━━━\nButton pe tap karke naam, color, premium emoji ya hide/show set karein.",
         grid(kb, 2) + [[B("⬅️ Back", "a:look", style="primary")]])


def adm_btn(c, mid, k):
    cf = bcfg(k)
    t = "🎛 <b>%s</b>\n━━━━━━━━━━━━━━\n🏷 Label: <b>%s</b>\n🎨 Color: <b>%s</b>\n💎 Premium emoji ID: <code>%s</code>\n👁 Visible: <b>%s</b>" % (
        k.upper(), esc(cf["t"]), cf["s"], cf["e"] or "—", "Yes" if int(cf.get("on", 1)) else "No")
    kb = [[B("✏️ Label", "bf:%s:t" % k, style="primary"), B("💎 Premium emoji", "bf:%s:e" % k, style="success")],
          [B("🎨 Color: %s" % cf["s"], "bcy:" + k, style=cf["s"]), B("%s Visible" % ("🟢" if int(cf.get("on", 1)) else "⚪"), "btg:" + k, style="success" if int(cf.get("on", 1)) else "danger")],
          [B("↩️ Reset", "brs:" + k, style="danger"), B("⬅️ Back", "a:btn", style="primary")]]
    show(c, mid, t, kb)


def save_btn(k, f, v):
    cf = bcfg(k)
    cf[f] = v
    setS("btn_" + k, json.dumps(cf, ensure_ascii=False))


def adm_set(c, mid, uid):
    t = ("⚙️ <b>SETTINGS</b>\n━━━━━━━━━━━━━━\n🏪 Store: <b>%s</b>\n💱 Currency: <b>%s</b>\n🛟 Support: <b>%s</b>\n📢 Log channel: <b>%s</b>\n"
         "💎 Reseller after deposit: <b>%s</b>") % (esc(S("store_name")), esc(S("currency")), esc(S("support_user")), esc(S("log_channel")) or "—", m(SN("reseller_min")))
    kb = [[B("🏪 Store name", "ss:store_name", style="success"), B("💱 Currency", "ss:currency", style="primary")],
          [B("🛟 Support user", "ss:support_user", style="primary"), B("📢 Log channel", "ss:log_channel", style="success")],
          [B("💎 Reseller min deposit", "ss:reseller_min", style="success")], [tog_btn("maint")]]
    if is_owner(uid):
        kb.append([B("👮 Admins", "a:adm", style="primary")])
    kb.append([B("⬅️ Back", "a", style="primary")])
    show(c, mid, t, kb)


def adm_adm(c, mid):
    ads = q("SELECT id FROM admins")
    kb = [[B("🗑 %s" % a["id"], "admdel:%d" % a["id"], style="danger")] for a in ads]
    kb += [[B("➕ Add Admin", "admadd", style="success")], [B("⬅️ Back", "a:set", style="primary")]]
    show(c, mid, "👮 <b>ADMINS</b>\n━━━━━━━━━━━━━━\nOwner: <code>%s</code>\nExtra admins: %s" % (OWNER, ", ".join("<code>%s</code>" % a["id"] for a in ads) or "—"), kb)


def adm_sr(c, mid):
    t = ("🎁 <b>SPIN &amp; REFER</b>\n━━━━━━━━━━━━━━\n🎁 Referral reward: <b>%g%%</b> of friend's first deposit\n🎰 Spin every <b>%g</b> hours\n"
         "🔒 Min deposit to spin: <b>%s</b>\n🎲 Prizes: <code>%s</code>") % (SN("ref_pct"), SN("spin_hours", 24), m(SN("spin_min_dep")), esc(S("spin_prizes")))
    kb = [[tog_btn("ref_on"), tog_btn("spin_on")],
          [B("🎁 Referral %", "ss:ref_pct", style="success"), B("⏱ Spin hours", "ss:spin_hours", style="primary")],
          [B("🔒 Spin min deposit", "ss:spin_min_dep", style="primary"), B("🎲 Prizes", "ss:spin_prizes", style="success")],
          [B("⬅️ Back", "a", style="primary")]]
    show(c, mid, t, kb)


# ---------- users / stats / pending ----------
def adm_usr(c, mid):
    n = q1("SELECT COUNT(*) n, COALESCE(SUM(balance),0) b FROM users")
    show(c, mid, "👥 <b>USERS</b>\n━━━━━━━━━━━━━━\nTotal users: <b>%d</b>\nTotal wallet balance: <b>%s</b>" % (n["n"], m(n["b"])),
         [[B("🔍 Find User (ID / @username)", "ufind", style="success")], [B("💰 Top 10 balances", "utop", style="primary")],
          [B("⬅️ Back", "a", style="primary")]])


def adm_user(c, mid, target):
    u = get_user(target)
    if not u:
        return adm_usr(c, mid)
    n = q1("SELECT COUNT(*) n FROM orders WHERE user=? AND status='done'", (target,))["n"]
    t = ("👤 <b>%s</b> %s\n━━━━━━━━━━━━━━\n🆔 <code>%s</code>\n💳 Balance: <b>%s</b>\n🏅 Tier: <b>%s</b>\n🛒 Orders: <b>%d</b>  💸 Spent: <b>%s</b>\n"
         "📥 Deposited: <b>%s</b>\n📅 Joined: %s\n🚫 Banned: <b>%s</b>") % (esc(u["name"]), "@" + u["username"] if u["username"] else "", target, m(u["balance"]),
                                                                       tier_label(u), n, m(u["spent"]), m(u["deposited"]), u["joined"], "Yes" if u["banned"] else "No")
    kb = [[B("➕ Add Balance", "ub:%d:a" % target, style="success"), B("➖ Deduct Balance", "ub:%d:s" % target, style="danger")],
          [B("%s" % ("✅ Unban" if u["banned"] else "🚫 Ban"), "ubn:%d" % target, style="success" if u["banned"] else "danger"),
           B("💎 Make %s" % ("USER" if u["tier"] == "reseller" else "RESELLER"), "urs:%d" % target, style="primary")],
          [B("✉️ Message", "um:%d" % target, style="primary"), B("⬅️ Back", "a:usr", style="primary")]]
    show(c, mid, t, kb)


def adm_stats(c, mid):
    u = q1("SELECT COUNT(*) n, COALESCE(SUM(balance),0) b FROM users")
    o = q1("SELECT COUNT(*) n, COALESCE(SUM(price),0) s FROM orders WHERE status='done'")
    today = datetime.now(IST).strftime("%d-%m-%Y")
    ot = q1("SELECT COUNT(*) n, COALESCE(SUM(price),0) s FROM orders WHERE status='done' AND created LIKE ?", (today + "%",))
    d = q1("SELECT COALESCE(SUM(amount),0) s FROM pays WHERE status='ok'")
    stock = q1("SELECT COUNT(*) n FROM keys WHERE used=0")["n"]
    t = ("📊 <b>STATS</b>\n━━━━━━━━━━━━━━\n👥 Users: <b>%d</b>\n💳 Wallet total: <b>%s</b>\n📥 Total deposits: <b>%s</b>\n\n🛒 Orders: <b>%d</b>  (%s)\n"
         "📅 Today: <b>%d</b> orders, <b>%s</b>\n\n🔑 Unused keys in stock: <b>%d</b>") % (u["n"], m(u["b"]), m(d["s"]), o["n"], m(o["s"]), ot["n"], m(ot["s"]), stock)
    low = q("SELECT p.name pn, l.name ln, (SELECT COUNT(*) FROM keys k WHERE k.plan_id=l.id AND k.used=0) n FROM plans l JOIN prods p ON p.id=l.prod_id "
            "WHERE p.mode='stock' AND l.active=1 ORDER BY n LIMIT 5")
    if low:
        t += "\n\n⚠️ <b>Lowest stock</b>\n" + "\n".join("▫️ %s — %s: <b>%d</b>" % (esc(r["pn"]), esc(r["ln"]), r["n"]) for r in low)
    show(c, mid, t, [[B("⬅️ Back", "a", style="primary")]])


def adm_pend(c, mid):
    ps = q("SELECT * FROM pays WHERE status='review' ORDER BY created LIMIT 20")
    if not ps:
        show(c, mid, "🕒 <b>PENDING PAYMENTS</b>\n━━━━━━━━━━━━━━\n\n✅ Koi pending payment nahi hai.", [[B("⬅️ Back", "a", style="primary")]])
        return
    kb = [[B("%s · %s · %s" % (p["id"], p["user"], m(p["amount"])), "pv:" + p["id"], style="success")] for p in ps]
    show(c, mid, "🕒 <b>PENDING PAYMENTS</b> (%d)\n━━━━━━━━━━━━━━\nTap karke check karein 👇" % len(ps), kb + [[B("⬅️ Back", "a", style="primary")]])


def broadcast(c, html_text):
    ids = [r["id"] for r in q("SELECT id FROM users WHERE banned=0")]
    ok = fail = 0
    for i in ids:
        r = send(i, html_text)
        if bad(r):
            fail += 1
        else:
            ok += 1
        time.sleep(0.05)
    send(c, "📢 <b>Broadcast done</b>\n✅ Sent: %d\n❌ Failed: %d" % (ok, fail), [[B("⬅️ Admin", "a", style="primary")]])


# ============================================================
# ROUTING
# ============================================================
CYCLES = {"style": ["", "primary", "success", "danger"], "mode": ["stock", "api", "both"], "api_method": ["GET", "POST"]}


def ent_back(t, id_, f=""):
    return {"c": "a:c:%d" % id_, "l": "a:l:%d" % id_, "p": ("a:api:%d" % id_ if f.startswith("api_") else "a:p:%d" % id_)}[t]


def route(c, mid, uid, d):
    a = d.split(":")
    k = a[0]
    I = lambda i: int(a[i])
    if d == "home":
        return home(c, mid, uid)
    if k == "m":
        return {"products": lambda: show_cats(c, mid, uid), "addbal": lambda: show_addbal(c, mid, uid), "orders": lambda: show_orders(c, mid, uid),
                "profile": lambda: show_profile(c, mid, uid), "refer": lambda: show_refer(c, mid, uid),
                "howto": lambda: show_text(c, mid, "txt_howto"), "spin": lambda: show_spin(c, mid, uid),
                "support": lambda: show_text(c, mid, "txt_support", support=esc(S("support_user")))}.get(a[1], lambda: home(c, mid, uid))()
    if d == "ab":
        return show_addbal(c, mid, uid)
    if k == "c":
        return show_prods(c, mid, uid, I(1))
    if k == "p":
        return show_prod(c, mid, uid, I(1))
    if k == "b":
        return show_buy(c, mid, uid, I(1))
    if k == "cf":
        pl = q1("SELECT prod_id FROM plans WHERE id=?", (I(1),))
        return buy_confirm(c, mid, uid, I(1), "p:%d" % pl["prod_id"] if pl else "m:products")
    if k == "ov":
        return show_order(c, mid, uid, a[1])
    if k == "dep":
        if a[1] == "c":
            st_set(uid, "dep_amt")
            return send(c, "✏️ <b>Custom amount likhein</b>\n\nMin <b>%s</b> · Max <b>%s</b>" % (m(SN("dep_min", 1)), m(SN("dep_max", 100000))),
                        [[B("❌ Cancel", "ab", style="danger")]])
        return start_pay(c, uid, float(a[1]))
    if k == "vp":
        return verify_prompt(c, mid, uid, a[1])
    if k == "vm":
        p = q1("SELECT status FROM pays WHERE id=? AND user=?", (a[1], uid))
        if p and p["status"] == "wait":
            st_set(uid, "proof", pid=a[1])
            send(c, "📸 <b>Payment screenshot ya UTR bhejein.</b>", [[B("❌ Cancel Payment", "cp:" + a[1], style="danger")]])
        return
    if k == "cp":
        return cancel_pay(c, mid, uid, a[1])
    if d == "spin:go":
        return do_spin(c, mid, uid)

    if not is_admin(uid):
        return home(c, mid, uid)
    # ---------------- admin ----------------
    if d == "a":
        return adm_home(c, mid, uid)
    if k == "mp":
        st_set(uid, "media", t="p", id=I(1), back="a:p:%d" % I(1))
        return send(c, "🖼 <b>Product Media</b>\n\nAb is product ke liye <b>photo / video / GIF</b> bhejein. "
                    "Ye product page par text ke saath dikhega.", [[B("❌ Cancel", "a:p:%d" % I(1), style="danger")]])
    if k == "mpx":
        x("UPDATE prods SET media_type='', media_id='' WHERE id=?", (I(1),))
        return adm_prod(c, mid, I(1))
    if d == "seed":
        nc, npr = seed_defaults()
        send(c, "📥 <b>Default catalog loaded</b>\n\nNew categories: <b>%d</b>\nNew products: <b>%d</b>\n\n"
                "<i>Jo pehle se tha wo nahi badla. Ab sab kuch edit / delete kar sakte ho; plans me price badlo.</i>" % (nc, npr))
        return adm_cats(c, None)
    if d == "wm":
        st_set(uid, "media", t="w", id=0, back="a:wel")
        return send(c, "🎬 <b>Welcome Media</b>\n\n<b>Photo / video / GIF</b> bhejein. Ye /start par welcome text ke saath dikhega.",
                    [[B("❌ Cancel", "a:wel", style="danger")]])
    if d == "wmx":
        delS("welcome_media_id")
        delS("welcome_media_type")
        return adm_welcome(c, mid)
    if d == "wp":
        return home(c, None, uid)
    if k == "a":
        sub = a[1]
        simple = {"wel": lambda: adm_welcome(c, mid), "cats": lambda: adm_cats(c, mid), "pay": lambda: adm_pay(c, mid), "look": lambda: adm_look(c, mid), "btn": lambda: adm_btns(c, mid),
                  "usr": lambda: adm_usr(c, mid), "sr": lambda: adm_sr(c, mid), "set": lambda: adm_set(c, mid, uid),
                  "adm": lambda: adm_adm(c, mid), "stats": lambda: adm_stats(c, mid), "pend": lambda: adm_pend(c, mid)}
        if sub in simple:
            return simple[sub]()
        if sub == "bc":
            st_set(uid, "bc")
            return send(c, "📢 <b>BROADCAST</b>\n\nSabhi users ko bhejne ka message likhein (premium emoji / bold chalega).",
                        [[B("❌ Cancel", "a", style="danger")]])
        tgt = {"c": adm_cat, "p": adm_prod, "api": adm_api, "pl": adm_plans, "l": adm_plan}.get(sub)
        if tgt:
            return tgt(c, mid, I(2))
        if sub == "b":
            return adm_btn(c, mid, a[2])
        if sub == "u":
            return adm_user(c, mid, I(2))
    if k == "ef":
        t, i, f = a[1], I(2), a[3]
        return prompt_field(c, uid, t, i, f, ent_back(t, i, f))
    if k == "ss":
        return prompt_setting(c, uid, a[1])
    if k == "st" and a[1] in TOGGLES:
        setS(a[1], "0" if S(a[1]) == "1" else "1")
        pg = {"pay": "a:pay", "show": "a:look", "bold": "a:look", "ref": "a:sr", "spin": "a:sr"}.get(a[1].split("_")[0], "a:set")
        return route(c, mid, uid, pg)
    if k == "tg":
        t, i, f = a[1], I(2), a[3]
        if f == "active":
            x("UPDATE %s SET active=1-active WHERE id=?" % FIELDS[t][0], (i,))
        return go_entity(t, i)(c, mid)
    if k == "cy":
        t, i, f = a[1], I(2), a[3]
        r = q1("SELECT %s v FROM %s WHERE id=?" % (f, FIELDS[t][0]), (i,))
        seq = CYCLES[f]
        nv = seq[(seq.index(r["v"]) + 1) % len(seq)] if r and r["v"] in seq else seq[0]
        x("UPDATE %s SET %s=? WHERE id=?" % (FIELDS[t][0], f), (nv, i))
        return go_entity(t, i, f)(c, mid)
    if k == "del":
        t, i = a[1], I(2)
        what = {"c": "category (products 'Other' me chale jayenge)", "p": "product, uske plans aur unused keys", "l": "plan aur uski unused keys"}[t]
        back = ent_back(t, i)
        return show(c, mid, "🗑 <b>Delete?</b>\n\nYe <b>%s</b> delete hoga. Pichhle orders safe rahenge." % what,
                    [[B("✅ Yes, delete", "dly:%s:%d" % (t, i), style="danger"), B("❌ No", back, style="primary")]])
    if k == "dly":
        t, i = a[1], I(2)
        par = 0
        with L:
            if t == "p":
                r = q1("SELECT cat_id FROM prods WHERE id=?", (i,))
                par = r["cat_id"] if r else 0
                DB.execute("DELETE FROM keys WHERE used=0 AND plan_id IN (SELECT id FROM plans WHERE prod_id=?)", (i,))
                DB.execute("DELETE FROM plans WHERE prod_id=?", (i,))
                DB.execute("DELETE FROM prods WHERE id=?", (i,))
            elif t == "l":
                r = q1("SELECT prod_id FROM plans WHERE id=?", (i,))
                par = r["prod_id"] if r else 0
                DB.execute("DELETE FROM keys WHERE used=0 AND plan_id=?", (i,))
                DB.execute("DELETE FROM plans WHERE id=?", (i,))
            else:
                DB.execute("UPDATE prods SET cat_id=0 WHERE cat_id=?", (i,))
                DB.execute("DELETE FROM cats WHERE id=?", (i,))
            DB.commit()
        return parent_after_delete(t, i, par)(c, mid)
    if d == "cadd":
        st_set(uid, "add_cat")
        return send(c, "➕ <b>New Category</b>\n\nCategory ka naam bhejein (jaise NON ROOT).", [[B("❌ Cancel", "a:cats", style="danger")]])
    if k == "padd":
        st_set(uid, "add_prod", cid=I(1))
        return send(c, "➕ <b>New Product</b>\n\nProduct ka naam bhejein (jaise BALA MOD V6).", [[B("❌ Cancel", "a:c:%d" % I(1), style="danger")]])
    if k == "ladd":
        st_set(uid, "add_plan", pid=I(1), step="name")
        return send(c, "➕ <b>New Plan</b>\n\n1/4 Plan ka naam bhejein (jaise <code>3 DAYS</code>).", [[B("❌ Cancel", "a:pl:%d" % I(1), style="danger")]])
    if k == "kadd":
        st_set(uid, "add_keys", plid=I(1))
        return send(c, "🔑 <b>Add Keys</b>\n\nKeys bhejein — <b>har line me ek key</b>. Ya .txt file bhej do.",
                    [[B("❌ Cancel", "a:l:%d" % I(1), style="danger")]])
    if k == "kview":
        ks = q("SELECT val FROM keys WHERE plan_id=? AND used=0 ORDER BY id LIMIT 25", (I(1),))
        t = "📄 <b>Unused keys</b> (first 25 / %d)\n\n" % stock_n(I(1)) + ("\n".join("<code>%s</code>" % esc(r["val"]) for r in ks) or "—")
        return show(c, mid, t, [[B("⬅️ Back", "a:l:%d" % I(1), style="primary")]])
    if k == "kclr":
        return show(c, mid, "🧹 <b>Saari unused keys delete karni hain?</b> (%d keys)" % stock_n(I(1)),
                    [[B("✅ Yes, clear", "kcly:%d" % I(1), style="danger"), B("❌ No", "a:l:%d" % I(1), style="primary")]])
    if k == "kcly":
        x("DELETE FROM keys WHERE plan_id=? AND used=0", (I(1),))
        return adm_plan(c, mid, I(1))
    if k == "mvl":
        cats = q("SELECT * FROM cats ORDER BY sort,id")
        kb = [[B(label(r), "mv:%d:%d" % (I(1), r["id"]), style="primary", eid=r["eid"])] for r in cats]
        kb.append([B("⬅️ Back", "a:p:%d" % I(1), style="primary")])
        return show(c, mid, "📂 <b>Kis category me move karein?</b>", kb)
    if k == "mv":
        x("UPDATE prods SET cat_id=? WHERE id=?", (I(2), I(1)))
        return adm_prod(c, mid, I(1))
    if k == "apit":
        return api_test(c, mid, I(1))
    if d == "fptest":
        r = verify_utr("TEST000000000", 1)
        t = "🧪 <b>FAMPAY TEST</b>\n━━━━━━━━━━━━━━\n"
        if r.get("type") == "api_error":
            t += "❌ <b>Problem:</b> %s\nAPI key / URL check karein." % esc(r.get("msg", ""))
        else:
            t += "✅ <b>API reachable hai.</b>\nResponse: %s\n<i>(Test UTR nahi mila, ye normal hai.)</i>" % esc(r.get("msg", "ok"))
        return show(c, mid, t, [[B("⬅️ Back", "a:pay", style="primary")]])
    if k == "bf":
        st_set(uid, "bf", k=a[1], f=a[2])
        tip = "Naya label bhejein (emoji ke bina bhi chalega)." if a[2] == "t" else "💎 Premium emoji bhejein ya numeric ID. <code>-</code> = hatao."
        return send(c, "🎛 <b>%s</b>\n\n%s" % (a[1].upper(), tip), [[B("❌ Cancel", "a:b:" + a[1], style="danger")]])
    if k == "bcy":
        seq = ["primary", "success", "danger"]
        cur = bcfg(a[1])["s"]
        save_btn(a[1], "s", seq[(seq.index(cur) + 1) % 3] if cur in seq else "primary")
        return adm_btn(c, mid, a[1])
    if k == "btg":
        save_btn(a[1], "on", 0 if int(bcfg(a[1]).get("on", 1)) else 1)
        return adm_btn(c, mid, a[1])
    if k == "brs":
        delS("btn_" + a[1])
        return adm_btn(c, mid, a[1])
    if d == "ufind":
        st_set(uid, "ufind")
        return send(c, "🔍 User ka <b>ID</b> ya <b>@username</b> bhejein.", [[B("❌ Cancel", "a:usr", style="danger")]])
    if d == "utop":
        us = q("SELECT * FROM users ORDER BY balance DESC LIMIT 10")
        kb = [[B("%s · %s" % (u["name"], m(u["balance"])), "a:u:%d" % u["id"], style="primary")] for u in us]
        return show(c, mid, "💰 <b>TOP BALANCES</b>", kb + [[B("⬅️ Back", "a:usr", style="primary")]])
    if k == "ub":
        st_set(uid, "ub", target=I(1), mode=a[2])
        return send(c, "%s <b>Amount</b> bhejein." % ("➕" if a[2] == "a" else "➖"), [[B("❌ Cancel", "a:u:%d" % I(1), style="danger")]])
    if k == "ubn":
        x("UPDATE users SET banned=1-banned WHERE id=?", (I(1),))
        return adm_user(c, mid, I(1))
    if k == "urs":
        u = get_user(I(1))
        x("UPDATE users SET tier=? WHERE id=?", ("user" if u["tier"] == "reseller" else "reseller", I(1)))
        return adm_user(c, mid, I(1))
    if k == "um":
        st_set(uid, "um", target=I(1))
        return send(c, "✉️ User ko bhejne ka message likhein.", [[B("❌ Cancel", "a:u:%d" % I(1), style="danger")]])
    if d == "bcgo":
        s, xx = st_get(uid)
        if s == "bc_ok":
            st_clear(uid)
            send(c, "📢 Broadcast shuru ho gaya...")
            threading.Thread(target=broadcast, args=(c, xx["html"]), daemon=True).start()
        return
    if k == "pv":
        p = q1("SELECT * FROM pays WHERE id=?", (a[1],))
        if p:
            notify_review(a[1])
        return
    if k in ("ap", "rj"):
        res = approve_pay(c, mid, uid, a[1], k == "ap")
        tg("editMessageReplyMarkup", {"chat_id": c, "message_id": mid, "reply_markup": {"inline_keyboard": []}})
        return send(c, "%s — <code>%s</code>" % (res, a[1]))
    if d == "admadd" and is_owner(uid):
        st_set(uid, "admadd")
        return send(c, "👮 Naye admin ka <b>Telegram ID</b> bhejein.", [[B("❌ Cancel", "a:adm", style="danger")]])
    if k == "admdel" and is_owner(uid):
        x("DELETE FROM admins WHERE id=?", (I(1),))
        return adm_adm(c, mid)
    if d == "idf":
        st_set(uid, "idf")
        return send(c, "🆔 <b>Premium Emoji ID Finder</b>\n\nKoi bhi premium emoji bhejein, main uski ID bata dunga.", [[B("⬅️ Done", "a:look", style="primary")]])


def get_file_text(file_id):
    r = tg("getFile", {"file_id": file_id})
    if bad(r) or not r.get("file_path"):
        return ""
    try:
        return requests.get(FILE_API + "/" + r["file_path"], timeout=30).content[:2_000_000].decode("utf-8", "ignore")
    except requests.RequestException:
        return ""


def handle_state(c, uid, msg):
    s, xx = st_get(uid)
    if not s:
        return False
    raw = (msg.get("text") or "").strip()
    if s == "dep_amt":
        try:
            v = float(raw.replace(",", "").replace(S("currency"), "").strip())
        except ValueError:
            send(c, "❌ Sirf number likhein (jaise 250).")
            return True
        st_clear(uid)
        start_pay(c, uid, v)
        return True
    if s == "utr":
        handle_utr(c, uid, raw)
        return True
    if s == "proof":
        handle_proof(c, uid, msg)
        return True
    if not is_admin(uid):
        st_clear(uid)
        return False

    if s == "media":
        mtype, fid = extract_media(msg)
        if not fid:
            send(c, "❌ Photo, video ya GIF bhejein (text nahi chalega).", [[B("❌ Cancel", xx["back"], style="danger")]])
            return True
        if xx["t"] == "p":
            x("UPDATE prods SET media_type=?, media_id=? WHERE id=?", (mtype, fid, xx["id"]))
        else:
            setS("welcome_media_type", mtype)
            setS("welcome_media_id", fid)
        st_clear(uid)
        route(c, None, uid, xx["back"])
        return True
    if s == "ef":
        t, i, f = xx["t"], xx["id"], xx["f"]
        kind = FIELDS[t][1][f][1]
        ok, val = parse_val(kind, msg)
        if not ok or (f == "name" and not val):
            send(c, "❌ %s" % (val if not ok else "Naam khali nahi ho sakta."))
            return True
        x("UPDATE %s SET %s=? WHERE id=?" % (FIELDS[t][0], f), (val, i))
        st_clear(uid)
        go_entity(t, i, f)(c, None)
        return True
    if s == "ss":
        key = xx["key"]
        kind = SETS[key][1]
        if raw == "/reset" and key.startswith("txt_"):
            delS(key)
        else:
            ok, val = parse_val(kind, msg)
            if not ok:
                send(c, "❌ %s" % val)
                return True
            if kind == "secret":
                tg("deleteMessage", {"chat_id": c, "message_id": msg["message_id"]})
            setS(key, val)
        st_clear(uid)
        route(c, None, uid, xx["back"])
        return True
    if s == "add_cat":
        if not raw:
            return True
        i = x("INSERT INTO cats(name,sort) VALUES(?,?)", (raw[:40], q1("SELECT COALESCE(MAX(sort),0)+1 n FROM cats")["n"]))
        st_clear(uid)
        send(c, "✅ Category ban gayi. Ab uska emoji / premium emoji / color set kar sakte ho.")
        adm_cat(c, None, i)
        return True
    if s == "add_prod":
        if not raw:
            return True
        i = x("INSERT INTO prods(cat_id,name,sort) VALUES(?,?,?)", (xx["cid"], raw[:50], q1("SELECT COALESCE(MAX(sort),0)+1 n FROM prods")["n"]))
        st_clear(uid)
        send(c, "✅ Product ban gaya. Ab description, plans aur delivery mode (stock / API) set karein.")
        adm_prod(c, None, i)
        return True
    if s == "add_plan":
        step = xx["step"]
        if step == "name":
            if not raw:
                return True
            st_set(uid, "add_plan", pid=xx["pid"], step="price", name=raw[:30])
            send(c, "2/4 <b>Price</b> bhejein (jaise 99).", [[B("❌ Cancel", "a:pl:%d" % xx["pid"], style="danger")]])
            return True
        try:
            v = float(raw.replace(",", ""))
        except ValueError:
            send(c, "❌ Number bhejein.")
            return True
        if step == "price":
            st_set(uid, "add_plan", pid=xx["pid"], step="rprice", name=xx["name"], price=v)
            send(c, "3/4 <b>Reseller price</b> bhejein (same rakhna ho to 0).", [[B("❌ Cancel", "a:pl:%d" % xx["pid"], style="danger")]])
        elif step == "rprice":
            st_set(uid, "add_plan", pid=xx["pid"], step="days", name=xx["name"], price=xx["price"], rprice=v)
            send(c, "4/4 <b>Days</b> bhejein (API me {days} ke liye; nahi chahiye to 0).", [[B("❌ Cancel", "a:pl:%d" % xx["pid"], style="danger")]])
        else:
            i = x("INSERT INTO plans(prod_id,name,price,rprice,days,sort) VALUES(?,?,?,?,?,?)",
                  (xx["pid"], xx["name"], xx["price"], xx["rprice"], int(v), q1("SELECT COALESCE(MAX(sort),0)+1 n FROM plans")["n"]))
            st_clear(uid)
            send(c, "✅ Plan ban gaya. Ab <b>Add Keys</b> se keys daalo (ya product ko API mode me karo).")
            adm_plan(c, None, i)
        return True
    if s == "add_keys":
        text = raw
        if msg.get("document"):
            text = get_file_text(msg["document"]["file_id"])
        if not text:
            send(c, "❌ Keys bhejein (har line me ek).")
            return True
        add_keys_text(c, uid, xx["plid"], text)
        return True
    if s == "ufind":
        key = raw.lstrip("@")
        u = get_user(int(key)) if key.isdigit() else q1("SELECT * FROM users WHERE lower(username)=?", (key.lower(),))
        if not u:
            send(c, "❌ User nahi mila. Dobara try karein.")
            return True
        st_clear(uid)
        adm_user(c, None, u["id"])
        return True
    if s == "ub":
        try:
            v = abs(float(raw.replace(",", "")))
        except ValueError:
            send(c, "❌ Number bhejein.")
            return True
        sign = 1 if xx["mode"] == "a" else -1
        x("UPDATE users SET balance=MAX(0,balance+?) WHERE id=?", (sign * v, xx["target"]))
        st_clear(uid)
        send(xx["target"], ("💰 Aapke wallet me <b>%s</b> add hue." if sign > 0 else "💸 Aapke wallet se <b>%s</b> deduct hue.") % m(v))
        adm_user(c, None, xx["target"])
        return True
    if s == "um":
        r = send(xx["target"], "📩 <b>Message from %s</b>\n\n%s" % (esc(S("store_name")), ent_html(msg.get("text") or "", msg.get("entities"))))
        st_clear(uid)
        send(c, "✅ Bhej diya." if not bad(r) else "❌ User ko message nahi gaya (bot block kiya ho sakta hai).")
        return True
    if s == "bc":
        if not raw:
            return True
        h = ent_html(msg.get("text") or "", msg.get("entities"))
        st_set(uid, "bc_ok", html=h)
        n = q1("SELECT COUNT(*) n FROM users WHERE banned=0")["n"]
        send(c, "📢 <b>Preview</b> (%d users ko jayega):\n━━━━━━━━━━━━━━\n%s" % (n, h),
             [[B("✅ Send to all", "bcgo", style="success"), B("❌ Cancel", "a", style="danger")]])
        return True
    if s == "bf":
        k, f = xx["k"], xx["f"]
        if f == "t":
            if not raw:
                return True
            save_btn(k, "t", raw[:40])
        else:
            ok, val = parse_val("eid", msg)
            if not ok:
                send(c, "❌ %s" % val)
                return True
            save_btn(k, "e", val)
        st_clear(uid)
        adm_btn(c, None, k)
        return True
    if s == "admadd" and is_owner(uid):
        if raw.isdigit():
            x("INSERT OR IGNORE INTO admins VALUES(?)", (int(raw),))
            st_clear(uid)
            adm_adm(c, None)
        else:
            send(c, "❌ Numeric Telegram ID bhejein.")
        return True
    if s == "idf":
        ids = [e["custom_emoji_id"] for e in (msg.get("entities") or []) if e.get("type") == "custom_emoji"]
        send(c, ("💎 <b>Premium emoji ID:</b>\n" + "\n".join("<code>%s</code>" % i for i in ids)) if ids else
             "❌ Isme premium emoji nahi mila. Premium emoji bhejein.", [[B("⬅️ Done", "a:look", style="primary")]])
        return True
    return False


# ============================================================
# UPDATE HANDLER + MAIN LOOP
# ============================================================
USER_LOCKS = {}
USER_LOCKS_L = threading.Lock()


def user_lock(uid):
    with USER_LOCKS_L:
        return USER_LOCKS.setdefault(uid, threading.Lock())


def gate(c, uid, u):
    if u["banned"] and not is_admin(uid):
        send(c, "🚫 <b>Aap is bot se ban hain.</b>")
        return False
    if S("maint") == "1" and not is_admin(uid):
        send(c, "🛠 <b>Bot maintenance me hai.</b>\n\nThodi der baad wapas aayein.")
        return False
    return True


def handle_update(upd):
    try:
        if "callback_query" in upd:
            cq = upd["callback_query"]
            fr = cq["from"]
            uid = fr["id"]
            msg = cq.get("message") or {}
            c = (msg.get("chat") or {}).get("id", uid)
            mid = msg.get("message_id")
            d = cq.get("data", "")
            u = ensure_user(fr)
            if not gate(c, uid, u):
                return ack(cq["id"])
            st_clear(uid)
            if d == "oos":
                return ack(cq["id"], "❌ Ye plan abhi out of stock hai", True)
            ack(cq["id"])
            route(c, mid, uid, d)
        elif "message" in upd:
            msg = upd["message"]
            if (msg.get("chat") or {}).get("type") != "private" or "from" not in msg:
                return
            fr = msg["from"]
            uid = fr["id"]
            c = msg["chat"]["id"]
            text = (msg.get("text") or "").strip()
            ref = 0
            if text.startswith("/start"):
                mt = re.match(r"^/start\s+r(\d+)", text)
                ref = int(mt.group(1)) if mt else 0
            existed = get_user(uid)
            u = ensure_user(fr, 0 if existed else ref)
            if not gate(c, uid, u):
                return
            if text.startswith("/start"):
                st_clear(uid)
                return home(c, None, uid)
            if text.startswith("/admin") and is_admin(uid):
                st_clear(uid)
                return adm_home(c, None, uid)
            if text.startswith("/cancel"):
                st_clear(uid)
                return home(c, None, uid)
            if not handle_state(c, uid, msg):
                home(c, None, uid)
    except Exception as e:      # never let one bad update stop the bot
        import traceback
        log("update error: %s\n%s" % (e, traceback.format_exc()[-900:]))


def safe_handle(group):
    for upd in group:
        uid = None
        try:
            uid = (upd.get("callback_query") or upd.get("message") or {}).get("from", {}).get("id")
        except AttributeError:
            pass
        with user_lock(uid or 0):
            handle_update(upd)


def main():
    global BOT_USER
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN missing")
    me = tg("getMe")
    if bad(me):
        raise SystemExit("Invalid BOT_TOKEN: %s" % me["_err"])
    BOT_USER = me.get("username", "")
    if S("catalog_seeded") != "1" and not q1("SELECT 1 FROM cats") and not q1("SELECT 1 FROM prods"):
        nc, npr = seed_defaults()
        setS("catalog_seeded", "1")
        log("default catalog loaded: %d categories, %d products" % (nc, npr))
    tg("deleteWebhook", {"drop_pending_updates": True})
    tg("setMyCommands", {"commands": [{"command": "start", "description": "Open the shop"}, {"command": "admin", "description": "Admin panel"}]})
    log("Sandy Panel Shop started: @%s owner=%s theme=%s" % (BOT_USER, OWNER, os.getenv("THEME", "")))
    pool = ThreadPoolExecutor(max_workers=16)
    offset = 0
    while True:
        try:
            r = SESSION.post(API + "/getUpdates", json={"offset": offset, "timeout": 50, "allowed_updates": ["message", "callback_query"]}, timeout=65)
            j = r.json()
        except (requests.RequestException, ValueError):
            time.sleep(3)
            continue
        if not j.get("ok"):
            log("getUpdates: %s" % str(j)[:200])
            time.sleep(5)
            continue
        groups = {}
        for upd in j.get("result", []):
            offset = max(offset, upd["update_id"] + 1)
            uid = (upd.get("callback_query") or upd.get("message") or {}).get("from", {}).get("id", 0)
            groups.setdefault(uid, []).append(upd)
        for g in groups.values():
            pool.submit(safe_handle, g)


if __name__ == "__main__":
    main()
