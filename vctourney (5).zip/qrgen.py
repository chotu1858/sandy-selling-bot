"""Tiny pure-Python QR code generator (byte mode, error correction M, versions 1-10 = up to 213 bytes).

No third-party libraries needed - used to draw dynamic UPI payment QR codes (amount included) for the bot and the Mini App.
    matrix = make("upi://pay?pa=name@upi&am=100")   -> list of rows of 0/1
    png_bytes(matrix, scale=10, border=4)            -> PNG image bytes
    svg_text(matrix, border=2)                       -> SVG markup
"""
import struct
import zlib

# version -> (EC codewords per block, [(block count, data codewords per block), ...])   error correction level M
ECC_M = {1: (10, [(1, 16)]), 2: (16, [(1, 28)]), 3: (26, [(1, 44)]), 4: (18, [(2, 32)]), 5: (24, [(2, 43)]),
         6: (16, [(4, 27)]), 7: (18, [(4, 31)]), 8: (22, [(2, 38), (2, 39)]), 9: (22, [(3, 36), (2, 37)]), 10: (26, [(4, 43), (1, 44)])}
ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50]}

# GF(256) tables (polynomial 0x11D)
EXP = [0] * 512
LOG = [0] * 256
_v = 1
for _i in range(255):
    EXP[_i] = _v
    LOG[_v] = _i
    _v <<= 1
    if _v & 0x100:
        _v ^= 0x11D
for _i in range(255, 512):
    EXP[_i] = EXP[_i - 255]


def _mul(a, b):
    return 0 if a == 0 or b == 0 else EXP[LOG[a] + LOG[b]]


def _rs_generator(n):
    g = [1]
    for i in range(n):
        nxt = [0] * (len(g) + 1)
        for j, c in enumerate(g):
            nxt[j] ^= c
            nxt[j + 1] ^= _mul(c, EXP[i])
        g = nxt
    return g


def _rs_remainder(data, n):
    gen = _rs_generator(n)
    rem = [0] * n
    for b in data:
        f = b ^ rem[0]
        rem = rem[1:] + [0]
        if f:
            for i in range(n):
                rem[i] ^= _mul(gen[i + 1], f)
    return rem


def _bch(value, poly, bits_total, bits_data):
    v = value << (bits_total - bits_data)
    for i in range(bits_data - 1, -1, -1):
        if (v >> (i + bits_total - bits_data)) & 1:
            v ^= poly << i
    return (value << (bits_total - bits_data)) | v


def _data_codewords(data, ver):
    bits = []

    def put(val, n):
        for i in range(n - 1, -1, -1):
            bits.append((val >> i) & 1)
    put(0b0100, 4)
    put(len(data), 8 if ver < 10 else 16)
    for b in data:
        put(b, 8)
    total = sum(c * d for c, d in ECC_M[ver][1]) * 8
    put(0, min(4, total - len(bits)))
    while len(bits) % 8:
        bits.append(0)
    out = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = (0xEC, 0x11)
    i = 0
    while len(out) < total // 8:
        out.append(pad[i % 2])
        i += 1
    return out


def _interleave(cw, ver):
    ec_len, groups = ECC_M[ver]
    blocks, pos = [], 0
    for count, size in groups:
        for _ in range(count):
            blocks.append(cw[pos:pos + size])
            pos += size
    ecs = [_rs_remainder(b, ec_len) for b in blocks]
    out = []
    for i in range(max(len(b) for b in blocks)):
        for b in blocks:
            if i < len(b):
                out.append(b[i])
    for i in range(ec_len):
        for e in ecs:
            out.append(e[i])
    return out


class _Grid:
    def __init__(self, ver):
        self.n = ver * 4 + 17
        self.m = [[0] * self.n for _ in range(self.n)]
        self.f = [[False] * self.n for _ in range(self.n)]   # function-pattern modules (not data, not masked)
        self.ver = ver

    def setf(self, x, y, v):
        if 0 <= x < self.n and 0 <= y < self.n:
            self.m[y][x] = 1 if v else 0
            self.f[y][x] = True

    def finder(self, cx, cy):
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                d = max(abs(dx), abs(dy))
                self.setf(cx + dx, cy + dy, d not in (2, 4))

    def align(self, cx, cy):
        for dy in range(-2, 3):
            for dx in range(-2, 3):
                self.setf(cx + dx, cy + dy, max(abs(dx), abs(dy)) != 1)

    def draw_function(self):
        n = self.n
        for i in range(n):
            self.setf(6, i, i % 2 == 0)
            self.setf(i, 6, i % 2 == 0)
        self.finder(3, 3)
        self.finder(n - 4, 3)
        self.finder(3, n - 4)
        pos = ALIGN[self.ver]
        for i, a in enumerate(pos):
            for j, b in enumerate(pos):
                if (i == 0 and j == 0) or (i == 0 and j == len(pos) - 1) or (i == len(pos) - 1 and j == 0):
                    continue
                self.align(a, b)
        self.draw_format(0)   # reserve
        if self.ver >= 7:
            v = _bch(self.ver, 0x1F25, 18, 6)
            for i in range(18):
                bit = (v >> i) & 1
                a, b = n - 11 + i % 3, i // 3
                self.setf(a, b, bit)
                self.setf(b, a, bit)

    def draw_format(self, mask):
        n = self.n
        bits = _bch((0b00 << 3) | mask, 0x537, 15, 5) ^ 0x5412   # ECC level M = 00
        g = lambda i: (bits >> i) & 1
        for i in range(0, 6):
            self.setf(8, i, g(i))
        self.setf(8, 7, g(6))
        self.setf(8, 8, g(7))
        self.setf(7, 8, g(8))
        for i in range(9, 15):
            self.setf(14 - i, 8, g(i))
        for i in range(0, 8):
            self.setf(n - 1 - i, 8, g(i))
        for i in range(8, 15):
            self.setf(8, n - 15 + i, g(i))
        self.setf(8, n - 8, True)   # dark module

    def place(self, data):
        n = self.n
        bits = [(b >> (7 - i)) & 1 for b in data for i in range(8)]
        k = 0
        x = n - 1
        up = True
        while x > 0:
            if x == 6:
                x -= 1
            ys = range(n - 1, -1, -1) if up else range(n)
            for y in ys:
                for dx in (0, 1):
                    xx = x - dx
                    if not self.f[y][xx]:
                        self.m[y][xx] = bits[k] if k < len(bits) else 0
                        k += 1
            up = not up
            x -= 2

    def apply_mask(self, mask):
        fn = [lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0, lambda x, y: x % 3 == 0, lambda x, y: (x + y) % 3 == 0,
              lambda x, y: (x // 3 + y // 2) % 2 == 0, lambda x, y: (x * y) % 2 + (x * y) % 3 == 0,
              lambda x, y: ((x * y) % 2 + (x * y) % 3) % 2 == 0, lambda x, y: ((x + y) % 2 + (x * y) % 3) % 2 == 0][mask]
        for y in range(self.n):
            for x in range(self.n):
                if not self.f[y][x] and fn(x, y):
                    self.m[y][x] ^= 1


def _penalty(m):
    n = len(m)
    score = 0
    for rows in (m, [list(c) for c in zip(*m)]):
        for row in rows:
            run, prev = 1, row[0]
            for v in row[1:]:
                if v == prev:
                    run += 1
                else:
                    if run >= 5:
                        score += run - 2
                    run, prev = 1, v
            if run >= 5:
                score += run - 2
            s = "".join(map(str, row))
            score += 40 * (s.count("10111010000") + s.count("00001011101"))
    for y in range(n - 1):
        for x in range(n - 1):
            if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                score += 3
    dark = sum(map(sum, m))
    score += 10 * (abs(dark * 20 - n * n * 10) // (n * n))
    return score


def make(text):
    data = text.encode("utf-8")
    ver = None
    for v in range(1, 11):
        cap = sum(c * d for c, d in ECC_M[v][1])
        if len(data) + (2 if v < 10 else 3) <= cap:
            ver = v
            break
    if ver is None:
        raise ValueError("QR text too long (max ~210 characters)")
    codewords = _interleave(_data_codewords(data, ver), ver)
    best, best_s = None, None
    for mask in range(8):
        g = _Grid(ver)
        g.draw_function()
        g.place(codewords)
        g.apply_mask(mask)
        g.draw_format(mask)
        s = _penalty(g.m)
        if best is None or s < best_s:
            best, best_s = g.m, s
    return best


def png_bytes(matrix, scale=10, border=4):
    n = len(matrix)
    size = (n + border * 2) * scale
    raw = bytearray()
    blank = b"\xff" * size
    for _ in range(border * scale):
        raw += b"\x00" + blank
    for row in matrix:
        line = bytearray(b"\xff" * (border * scale))
        for v in row:
            line += (b"\x00" if v else b"\xff") * scale
        line += b"\xff" * (border * scale)
        raw += (b"\x00" + bytes(line)) * scale
    for _ in range(border * scale):
        raw += b"\x00" + blank

    def chunk(tag, body):
        c = struct.pack(">I", len(body)) + tag + body
        return c + struct.pack(">I", zlib.crc32(tag + body) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 0, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b""))


def svg_text(matrix, border=2):
    n = len(matrix)
    parts = []
    for y, row in enumerate(matrix):
        for x, v in enumerate(row):
            if v:
                parts.append("M%d,%dh1v1h-1z" % (x + border, y + border))
    s = n + border * 2
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" shape-rendering="crispEdges"><rect width="100%%" height="100%%" fill="#fff"/>'
            '<path d="%s" fill="#000"/></svg>') % (s, s, "".join(parts))
