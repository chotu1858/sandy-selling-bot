#!/usr/bin/env python3
"""VC TOURNAMENT BOT (vctourney) - HostPanel script.

A complete esports-tournament bot, built from the VC Tournament web app idea:
games -> tournaments -> join with entry fee -> room ID/password -> results -> prize to wallet.
Wallet = Deposit balance + Winning balance. Add money by UPI (admin approves), withdraw winnings by UPI.
Everything (games, tournaments, rooms, results, deposits, withdrawals, users, welcome studio, settings, reports, broadcast) is run
from the in-bot /admin console. Environment from HostPanel:
  BOT_TOKEN, ADMIN_IDS, STORE_NAME, SUPPORT_USERNAME, DB_NAME, THEME_FILE
"""
import os
import re
import json
import time
import html
import sqlite3
import sys
import threading
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor

import requests

BASE = os.path.dirname(os.path.abspath(__file__))
IST = timezone(timedelta(hours=5, minutes=30))


def load_env(path):
    try:
        for line in open(path, encoding="utf-8").read().splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
    except OSError:
        pass


load_env(os.path.join(BASE, ".env"))
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMINS = [int(x) for x in os.getenv("ADMIN_IDS", "").replace(" ", "").split(",") if x.isdigit()]
BRAND_ENV = os.getenv("STORE_NAME", "") or os.getenv("BOT_NAME", "") or "Tournament Arena"
SUPPORT_ENV = os.getenv("SUPPORT_USERNAME", "").strip().lstrip("@")
DB_FILE = os.path.join(BASE, os.getenv("DB_NAME", "tourney.db"))
API = "https://api.telegram.org/bot" + BOT_TOKEN
SESSION = requests.Session()
RT = {"url": os.getenv("WEBAPP_URL", "").strip().rstrip("/")}   # live Mini App URL (set by Cloudflare tunnel or env)
WEB_PORT = int(os.getenv("WEB_PORT", "0") or 0)

try:
    THEME = json.load(open(os.getenv("THEME_FILE", ""), encoding="utf-8"))
    if not isinstance(THEME, dict):
        THEME = {}
except Exception:
    THEME = {}


def log(msg):
    print("[%s] %s" % (datetime.now(IST).strftime("%H:%M:%S"), msg), flush=True)


def now_s():
    return datetime.now(IST).strftime("%d-%m-%Y %H:%M")


# ============================================================ DATABASE
DB = sqlite3.connect(DB_FILE, check_same_thread=False, timeout=30)
DB.row_factory = sqlite3.Row
DB.execute("PRAGMA journal_mode=WAL")
L = threading.RLock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, username TEXT, joined TEXT, banned INTEGER DEFAULT 0,
  dep REAL DEFAULT 0, win REAL DEFAULT 0, played INTEGER DEFAULT 0, wins INTEGER DEFAULT 0, last_seen TEXT);
CREATE TABLE IF NOT EXISTS games(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, emoji TEXT, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS tournaments(id INTEGER PRIMARY KEY AUTOINCREMENT, gid INTEGER, title TEXT, mode TEXT, fee REAL, pool REAL,
  per_kill REAL, slots INTEGER, start TEXT, status TEXT DEFAULT 'upcoming', room_id TEXT DEFAULT '', room_pass TEXT DEFAULT '', created TEXT);
CREATE TABLE IF NOT EXISTS parts(id INTEGER PRIMARY KEY AUTOINCREMENT, tid INTEGER, uid INTEGER, ign TEXT, slot INTEGER, joined TEXT,
  prize REAL DEFAULT 0, kills INTEGER DEFAULT 0, rank INTEGER DEFAULT 0, UNIQUE(tid, uid), UNIQUE(tid, slot));
CREATE TABLE IF NOT EXISTS txns(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, kind TEXT, amount REAL, note TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS deposits(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, amount REAL, utr TEXT, proof TEXT,
  status TEXT DEFAULT 'pending', created TEXT);
CREATE TABLE IF NOT EXISTS withdrawals(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, amount REAL, upi TEXT,
  status TEXT DEFAULT 'pending', created TEXT);
CREATE TABLE IF NOT EXISTS ign(uid INTEGER, gid INTEGER, name TEXT, PRIMARY KEY(uid, gid));
CREATE TABLE IF NOT EXISTS state(uid INTEGER PRIMARY KEY, s TEXT, data TEXT);
CREATE TABLE IF NOT EXISTS banners(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, sub TEXT, emoji TEXT, grad TEXT, active INTEGER DEFAULT 1);
"""
MIGRATE = [("games", "color", "TEXT DEFAULT ''"), ("games", "logo", "TEXT DEFAULT ''"), ("games", "sort", "INTEGER DEFAULT 0"),
           ("tournaments", "start_ts", "INTEGER DEFAULT 0"), ("tournaments", "map", "TEXT DEFAULT ''"),
           ("deposits", "gw", "TEXT DEFAULT ''"), ("deposits", "ref", "TEXT DEFAULT ''"),
           ("users", "photo", "TEXT DEFAULT ''"),
           ("tournaments", "banner", "TEXT DEFAULT ''"), ("banners", "img", "TEXT DEFAULT ''"),
           ("tournaments", "team_size", "INTEGER DEFAULT 0"), ("tournaments", "remind_sent", "INTEGER DEFAULT 0"),
           ("tournaments", "result_img", "TEXT DEFAULT ''"), ("tournaments", "result_fid", "TEXT DEFAULT ''"),
           ("parts", "team", "TEXT DEFAULT ''"), ("parts", "team_name", "TEXT DEFAULT ''")]
with L:
    DB.executescript(SCHEMA)
    for _t, _c, _d in MIGRATE:
        if _c not in {r[1] for r in DB.execute("PRAGMA table_info(%s)" % _t)}:
            DB.execute("ALTER TABLE %s ADD COLUMN %s %s" % (_t, _c, _d))
    DB.commit()


def q(sql, p=()):
    with L:
        return DB.execute(sql, p).fetchall()


def q1(sql, p=()):
    with L:
        return DB.execute(sql, p).fetchone()


def x(sql, p=()):
    with L:
        cur = DB.execute(sql, p)
        DB.commit()
        return cur.lastrowid


DEFAULTS = {
    "brand": BRAND_ENV,
    "upi": "",
    "qr": "",
    "min_dep": "10",
    "min_wd": "50",
    "support": SUPPORT_ENV,
    "maint": "0",
    "webapp_url": "",
    "notice": "",
    "gw": "none",
    "rzp_key": "", "rzp_secret": "", "rzp_hook": "",
    "upig_key": "",
    "fam_base": "", "fam_path": "/api/check", "fam_method": "GET", "fam_key_param": "key", "fam_key": "",
    "fam_utr_param": "utr", "fam_paid_field": "status", "fam_paid_value": "success", "fam_amount_field": "",
    "hero_on": "1", "hero_tag": "PLAY • COMPETE • WIN", "hero_btn": "Join Tournament", "app_logo": "",
    "prize_tpls": json.dumps([{"name": "Top 3 · 50/30/20", "pcts": [50, 30, 20]}, {"name": "Winner takes all", "pcts": [100]},
                              {"name": "Top 2 · 60/40", "pcts": [60, 40]}, {"name": "Top 5 · 40/25/15/12/8", "pcts": [40, 25, 15, 12, 8]}]),
    "welcome_img": "", "welcome_img_file": "", "welcome_btn": "🚀 OPEN TOURNAMENT APP", "dash": "1", "qr_gen": "1",
    "txt_welcome": ("<blockquote><b>🏆 WELCOME TO {brand}</b></blockquote>\n"
                    "<blockquote><b>├── 🎮 Join paid &amp; free tournaments\n├── 🔑 Get Room ID &amp; password here\n"
                    "├── 💰 Instant prize in your wallet\n└── 💸 Easy UPI withdrawal</b></blockquote>\n"
                    "<b>Hey {name}, choose an option 👇</b>"),
    "txt_terms": ("<blockquote><b>📜 TERMS &amp; CONDITIONS</b></blockquote>\n"
                  "<blockquote><b>01.</b> You must be of legal age to play in your region.\n"
                  "<b>02.</b> Use your own correct in-game name. Wrong or fake names can be disqualified.\n"
                  "<b>03.</b> Cheating, hacking or teaming up is banned. No refund and wallet can be frozen.\n"
                  "<b>04.</b> Entry fee is not refunded once a match has started, except when the admin cancels it.\n"
                  "<b>05.</b> Withdrawals only from Winning balance and are paid to your UPI after admin approval.\n"
                  "<b>06.</b> Admin decision on results and disputes is final.</blockquote>"),
}
for _k, _v in (THEME.get("texts") or {}).items():
    if isinstance(_v, str) and _k in DEFAULTS:
        DEFAULTS[_k] = _v


def S(k):
    r = q1("SELECT v FROM settings WHERE k=?", (k,))
    return r["v"] if r else DEFAULTS.get(k, "")


def set_S(k, v):
    x("INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, v))


def fnum(k, d=0.0):
    try:
        return float(S(k))
    except ValueError:
        return d


def fm(v):
    v = round(float(v or 0), 2)
    return "₹" + (str(int(v)) if v == int(v) else "%.2f" % v)


def esc(t):
    return html.escape(str(t if t is not None else ""), quote=False)


def is_admin(uid):
    return uid in ADMINS


# ============================================================ TELEGRAM
def bad(res):
    return isinstance(res, dict) and "_err" in res


def tg(method, params=None, timeout=35):
    for _ in range(3):
        try:
            r = SESSION.post(API + "/" + method, json=params or {}, timeout=timeout)
            j = r.json()
        except (requests.RequestException, ValueError):
            time.sleep(1)
            continue
        if j.get("ok"):
            return j.get("result")
        ra = (j.get("parameters") or {}).get("retry_after")
        if ra and j.get("error_code") == 429:
            time.sleep(min(int(ra), 10))
            continue
        return {"_err": str(j.get("description", "error"))}
    return {"_err": "network error"}


def B(text, cb=None, url=None, style=None, web=None):
    b = {"text": text}
    if web:
        b["web_app"] = {"url": web}
    elif url:
        b["url"] = url
    else:
        b["callback_data"] = cb or "home"
    if style:
        b["style"] = style
    return b


def _strip_style(kb):
    return {"inline_keyboard": [[{k: v for k, v in b.items() if k != "style"} for b in row] for row in kb.get("inline_keyboard", [])]}


def plain(t):
    return html.unescape(re.sub(r"<[^>]+>", "", str(t)))


def call(method, p):
    """tg() with fallbacks: coloured buttons not accepted -> plain buttons; bad HTML -> plain text."""
    res = tg(method, p)
    if bad(res) and "not modified" not in res["_err"]:
        kb = p.get("reply_markup")
        if kb and re.search(r"(?i)button|style|reply markup", res["_err"]):
            p = dict(p)
            p["reply_markup"] = _strip_style(kb)
            res = tg(method, p)
        if bad(res) and re.search(r"(?i)parse entities|can't find end", res["_err"]):
            p = dict(p)
            p.pop("parse_mode", None)
            for f in ("text", "caption"):
                if f in p:
                    p[f] = plain(p[f])
            res = tg(method, p)
    return res


def cut(t, n=4000):
    t = str(t)
    return t if len(t) <= n else t[:n - 3] + "..."


def send(c, text, kb=None):
    p = {"chat_id": c, "text": cut(text), "parse_mode": "HTML", "disable_web_page_preview": True}
    if kb:
        p["reply_markup"] = {"inline_keyboard": kb}
    return call("sendMessage", p)


def send_photo(c, fid, cap, kb=None):
    p = {"chat_id": c, "photo": fid, "caption": cut(cap, 1000), "parse_mode": "HTML"}
    if kb:
        p["reply_markup"] = {"inline_keyboard": kb}
    return call("sendPhoto", p)


def show(c, mid, text, kb=None):
    """Edit the menu message in place (falls back to a fresh message)."""
    if not mid:
        return send(c, text, kb)
    p = {"chat_id": c, "message_id": mid, "text": cut(text), "parse_mode": "HTML", "disable_web_page_preview": True,
         "reply_markup": {"inline_keyboard": kb or []}}
    res = call("editMessageText", p)
    if bad(res):
        if "not modified" in res["_err"]:
            return None
        tg("deleteMessage", {"chat_id": c, "message_id": mid})
        return send(c, text, kb)
    return res


def ack(cid, text="", alert=False):
    tg("answerCallbackQuery", {"callback_query_id": cid, "text": text[:190], "show_alert": alert}, timeout=10)


def notify_admins(text, kb=None, photo=None):
    for a in ADMINS:
        if photo:
            send_photo(a, photo, text, kb)
        else:
            send(a, text, kb)


# ============================================================ STATE
def st_set(uid, s, data=None):
    x("INSERT INTO state(uid,s,data) VALUES(?,?,?) ON CONFLICT(uid) DO UPDATE SET s=excluded.s, data=excluded.data",
      (uid, s, json.dumps(data or {})))


def st_get(uid):
    r = q1("SELECT s, data FROM state WHERE uid=?", (uid,))
    if not r:
        return "", {}
    try:
        return r["s"], json.loads(r["data"] or "{}")
    except ValueError:
        return r["s"], {}


def st_clear(uid):
    x("DELETE FROM state WHERE uid=?", (uid,))


# ============================================================ USERS / WALLET
def ensure_user(fr):
    uid = fr["id"]
    name = ((fr.get("first_name") or "") + " " + (fr.get("last_name") or "")).strip()[:60] or "Player"
    with L:
        DB.execute("INSERT OR IGNORE INTO users(id,name,username,joined) VALUES(?,?,?,?)", (uid, name, fr.get("username") or "", now_s()))
        DB.execute("UPDATE users SET name=?, username=?, last_seen=? WHERE id=?", (name, fr.get("username") or "", now_s(), uid))
        DB.commit()
    return q1("SELECT * FROM users WHERE id=?", (uid,))


def txn(uid, kind, amt, note=""):
    DB.execute("INSERT INTO txns(uid,kind,amount,note,created) VALUES(?,?,?,?,?)", (uid, kind, round(amt, 2), note[:80], now_s()))


def spend(uid, amt):
    """Take amt from deposit balance first, then winning balance. Call while holding L."""
    u = DB.execute("SELECT dep, win FROM users WHERE id=?", (uid,)).fetchone()
    if not u or round(u["dep"] + u["win"], 2) < round(amt, 2):
        return False
    from_dep = min(u["dep"], amt)
    from_win = round(amt - from_dep, 2)
    DB.execute("UPDATE users SET dep=?, win=? WHERE id=?", (round(u["dep"] - from_dep, 2), round(u["win"] - from_win, 2), uid))
    return True


def balances(uid):
    u = q1("SELECT dep, win FROM users WHERE id=?", (uid,))
    return (u["dep"], u["win"]) if u else (0.0, 0.0)


# ============================================================ MENUS
STATUS = {"upcoming": "🕒 Upcoming", "live": "🔴 LIVE", "completed": "✅ Completed", "cancelled": "❌ Cancelled"}


def bt(key, default, style="primary"):
    o = (THEME.get("buttons") or {}).get(key)
    if isinstance(o, dict):
        return o.get("text") or default, o.get("style") or style
    return default, style


def app_url(path=""):
    base = (S("webapp_url") or RT["url"]).rstrip("/")
    return (base + path) if base else ""


RULE = "━━━━━━━━━━━━━━━━━━"
MEDALS = ["🥇", "🥈", "🥉"]
WEL_KEYS = {"txt_welcome", "welcome_btn", "app_title", "app_sub"}

PRESETS = {
    "premium": ("👑 Premium",
                "<blockquote><b>👑 {brand}</b>\n<i>Play. Win. Get paid.</i></blockquote>\n"
                "<blockquote><b>🎮 Paid &amp; free tournaments\n🔑 Room ID &amp; password inside the bot\n💰 Prize straight to your wallet\n💸 Fast UPI withdrawal</b></blockquote>\n"
                "<b>Welcome, {name} 👇</b>"),
    "classic": ("🏆 Classic",
                "<blockquote><b>🏆 WELCOME TO {brand}</b></blockquote>\n"
                "<blockquote><b>├── 🎮 Join paid &amp; free tournaments\n├── 🔑 Get Room ID &amp; password here\n├── 💰 Instant prize in your wallet\n└── 💸 Easy UPI withdrawal</b></blockquote>\n"
                "<b>Hey {name}, choose an option 👇</b>"),
    "neon": ("⚡ Neon Arena",
             "<blockquote><b>⚡ {brand} · ARENA</b></blockquote>\n"
             "<blockquote><b>🔥 Squads · Duos · Solos\n🔑 Room ID drops here\n💎 Winnings straight to wallet\n💸 UPI payout</b></blockquote>\n"
             "<b>Ready, {name}? Pick your battle 👇</b>"),
    "stats": ("📊 Live Stats",
              "<blockquote><b>🏆 {brand}</b></blockquote>\n"
              "<blockquote><b>👥 {players} players  ·  🔴 {live} live now\n💰 Your wallet: {balance}</b></blockquote>\n"
              "<b>Hi {name}, jump into a match 👇</b>"),
    "minimal": ("🎮 Minimal",
                "<b>{brand}</b>\nHi {name}, join a tournament, win real prizes."),
}


def hd(icon, title, sub=""):
    return "<blockquote><b>%s %s</b></blockquote>" % (icon, title) + (("\n<i>%s</i>" % sub) if sub else "")


def today_s():
    return datetime.now(IST).strftime("%d-%m-%Y")


def live_count():
    return q1("SELECT COUNT(*) c FROM tournaments WHERE status='live'")["c"]


def render(text, uid, nm):
    """Fill welcome-text placeholders."""
    d, w = balances(uid)
    rep = (("{brand}", esc(S("brand"))), ("{name}", esc(nm)), ("{balance}", fm(d + w)), ("{live}", str(live_count())),
           ("{players}", str(q1("SELECT COUNT(*) c FROM users")["c"])), ("{id}", str(uid)))
    for k, v in rep:
        text = text.replace(k, v)
    return text


def parse_start(text):
    """Admin typed start time -> epoch seconds (IST) or 0 when the format is not recognised."""
    t = " ".join(str(text).split())
    for f in ("%d-%m-%Y %H:%M", "%d/%m/%Y %H:%M", "%d-%m-%Y %I:%M %p", "%d/%m/%Y %I:%M %p", "%Y-%m-%d %H:%M"):
        try:
            return int(datetime.strptime(t, f).replace(tzinfo=IST).timestamp())
        except ValueError:
            pass
    return 0


def home(c, mid, uid, name=""):
    u = q1("SELECT name FROM users WHERE id=?", (uid,))
    nm = name or (u["name"] if u else "Player")
    text = render(S("txt_welcome"), uid, nm)
    if S("notice"):
        text += "\n\n📢 <b>%s</b>" % esc(S("notice"))
    if S("dash") != "0":
        d, w = balances(uid)
        pl = q1("SELECT played FROM users WHERE id=?", (uid,))
        text += "\n\n<code>%s</code>\n💰 <b>%s</b>  ·  🏆 <b>%d</b> played  ·  🔴 <b>%d</b> live" % (RULE, fm(d + w), pl["played"] if pl else 0, live_count())
    sup = S("support").lstrip("@")

    def b(key, d, cb, st="primary"):
        t, s = bt(key, d, st)
        return B(t, cb, style=s)
    t_s, s_s = bt("sup", "📞 Support", "primary")
    kb = []
    if app_url():
        kb.append([B(S("welcome_btn") or "🚀 OPEN TOURNAMENT APP", web=app_url("/"), style="success")])
    kb += [[b("tour", "🎮 Tournaments", "g", "success"), b("mm", "🏆 My Matches", "mm")],
           [b("wallet", "💰 Wallet", "w", "success"), b("add", "➕ Add Money", "add", "success")],
           [b("wd", "💸 Withdraw", "wd"), b("lb", "🏅 Leaderboard", "lb")],
           [b("pf", "👤 Profile", "pf"), B(t_s, url="https://t.me/" + sup, style=s_s) if sup else B(t_s, "help", style=s_s)],
           [b("terms", "📜 Terms & Rules", "terms")]]
    if is_admin(uid):
        kb.append([B("🛠 Admin Panel", "adm", style="danger")])
    if S("welcome_img"):
        # welcome photo set from the admin panel: photo + caption (long text goes as a separate message)
        if mid:
            tg("deleteMessage", {"chat_id": c, "message_id": mid})
        if len(text) <= 1000:
            r = send_photo(c, S("welcome_img"), text, kb)
            if r and not bad(r):
                return r
        else:
            r = send_photo(c, S("welcome_img"), "", None)
            if r and not bad(r):
                return show(c, None, text, kb)
        mid = None
    return show(c, mid, text, kb)


def show_games(c, mid):
    gs = q("SELECT * FROM games WHERE active=1 ORDER BY sort, id")
    if not gs:
        return show(c, mid, "<b>🎮 No games added yet.</b>\nPlease check again soon.", [back()])
    kb = []
    for i in range(0, len(gs), 2):
        row = []
        for g in gs[i:i + 2]:
            n = q1("SELECT COUNT(*) c FROM tournaments WHERE gid=? AND status IN ('upcoming','live')", (g["id"],))["c"]
            row.append(B("%s %s%s" % (g["emoji"], g["name"], (" · %d" % n) if n else ""), "gm:%d" % g["id"], style="success" if n else "primary"))
        kb.append(row)
    kb.append(back())
    return show(c, mid, hd("🎮", "CHOOSE A GAME", "Number = open tournaments") , kb)


def show_lb(c, mid):
    rows = q("SELECT u.name, SUM(p.prize) s, SUM(p.kills) k, SUM(CASE WHEN p.rank=1 THEN 1 ELSE 0 END) w FROM parts p JOIN users u ON u.id=p.uid "
             "WHERE p.prize>0 GROUP BY p.uid ORDER BY s DESC LIMIT 10")
    if not rows:
        return show(c, mid, hd("🏅", "LEADERBOARD") + "\n<b>No winners yet. Be the first!</b>", [[B("🎮 Play Now", "g", style="success")], back()])
    lines = []
    for i, r in enumerate(rows):
        lines.append("%s <b>%s</b>\n      💰 %s · 🎯 %d kills · 🏆 %d wins" % (MEDALS[i] if i < 3 else "<b>%d.</b>" % (i + 1), esc(r["name"][:20]), fm(r["s"]), r["k"], r["w"]))
    return show(c, mid, hd("🏅", "TOP 10 PLAYERS", "Ranked by total winnings") + "\n\n" + "\n\n".join(lines), [[B("🎮 Play Now", "g", style="success")], back()])


def show_profile(c, mid, uid):
    u = q1("SELECT * FROM users WHERE id=?", (uid,))
    tot = q1("SELECT COALESCE(SUM(prize),0) s, COALESCE(SUM(kills),0) k FROM parts WHERE uid=?", (uid,))
    rate = int(round(100.0 * u["wins"] / u["played"])) if u["played"] else 0
    rank = ""
    if tot["s"] > 0:
        r = q1("SELECT COUNT(*) c FROM (SELECT uid, SUM(prize) s FROM parts GROUP BY uid HAVING s > ?)", (tot["s"],))["c"] + 1
        rank = "\n├── Global rank: <b>#%d</b>" % r
    txt = (hd("👤", "MY PROFILE") + "\n<blockquote><b>├── Name: %s\n├── ID: <code>%d</code>\n├── Matches played: %d\n├── Matches won: %d (%d%%)\n├── Total kills: %d\n"
           "├── Total won: %s%s\n├── Deposit: %s\n├── Winning: %s\n└── Joined: %s</b></blockquote>") % (
        esc(u["name"]), uid, u["played"], u["wins"], rate, tot["k"], fm(tot["s"]), rank, fm(u["dep"]), fm(u["win"]), esc(u["joined"]))
    return show(c, mid, txt, [[B("💰 Wallet", "w", style="success"), B("🏆 My Matches", "mm", style="primary")], [B("🏅 Leaderboard", "lb", style="primary")], back()])


def back(cb="home", label="⬅️ Back"):
    return [B(label, cb, style="primary")]


def filled(tid):
    return q1("SELECT COUNT(*) c FROM parts WHERE tid=?", (tid,))["c"]


def show_game(c, mid, gid):
    g = q1("SELECT * FROM games WHERE id=?", (gid,))
    if not g:
        return show_games(c, mid)
    ts = q("SELECT * FROM tournaments WHERE gid=? AND status IN ('upcoming','live') ORDER BY id DESC LIMIT 20", (gid,))
    if not ts:
        return show(c, mid, "<blockquote><b>%s %s</b></blockquote>\n<b>No tournament is open right now.</b>" % (g["emoji"], esc(g["name"])), [back("g")])
    kb = [[B("%s %s · %s · %d/%d" % ("🔴" if t["status"] == "live" else "🟢", t["title"][:22], fm(t["fee"]) if t["fee"] else "FREE", filled(t["id"]), t["slots"]),
             "t:%d" % t["id"], style="success" if t["status"] == "upcoming" else "danger")] for t in ts]
    kb.append(back("g"))
    return show(c, mid, "<blockquote><b>%s %s · TOURNAMENTS</b></blockquote>" % (g["emoji"], esc(g["name"])), kb)


def tour_text(t, uid=None, admin=False):
    g = q1("SELECT name, emoji FROM games WHERE id=?", (t["gid"],))
    n = filled(t["id"])
    txt = ("<blockquote><b>%s %s</b></blockquote>\n<blockquote><b>├── Game: %s\n├── Mode: %s%s\n├── Entry: %s\n├── Prize pool: %s\n├── Per kill: %s\n"
           "├── Slots: %d/%d\n├── Start: %s\n└── Status: %s</b></blockquote>") % (
        g["emoji"] if g else "🎮", esc(t["title"]), esc(g["name"]) if g else "-", esc(t["mode"]), (" (%d players/team)" % tsize(t)) if tsize(t) > 1 else "", fm(t["fee"]) if t["fee"] else "FREE",
        fm(t["pool"]), fm(t["per_kill"]), n, t["slots"], esc(t["start"]), STATUS.get(t["status"], t["status"]))
    mine = q1("SELECT * FROM parts WHERE tid=? AND uid=?", (t["id"], uid)) if uid else None
    if mine:
        txt += "\n✅ <b>You joined</b> · Slot #%d · <code>%s</code>" % (mine["slot"], esc(team_line(mine)))
        if mine["team_name"]:
            txt += "\n🛡 Team: <b>%s</b>" % esc(mine["team_name"])
        if t["room_id"] and t["status"] in ("upcoming", "live"):
            txt += "\n\n<blockquote><b>🔑 ROOM DETAILS\nRoom ID: <code>%s</code>\nPassword: <code>%s</code></b></blockquote>" % (esc(t["room_id"]), esc(t["room_pass"]))
        elif t["status"] in ("upcoming", "live"):
            txt += "\n<i>Room ID &amp; password will appear here before the match.</i>"
        if t["status"] == "completed":
            txt += "\n🏅 Your result: rank %s · kills %d · won <b>%s</b>" % (mine["rank"] or "-", mine["kills"], fm(mine["prize"]))
    if admin and t["room_id"]:
        txt += "\n\n🔑 Room: <code>%s</code> / <code>%s</code>" % (esc(t["room_id"]), esc(t["room_pass"]))
    return txt


def show_tour(c, mid, uid, tid):
    t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t:
        return show(c, mid, "❌ Tournament not found.", [back("g")])
    mine = q1("SELECT 1 FROM parts WHERE tid=? AND uid=?", (tid, uid))
    kb = []
    if t["status"] == "upcoming" and not mine:
        if filled(tid) >= t["slots"]:
            kb.append([B("🚫 Slots full", "t:%d" % tid, style="danger")])
        else:
            kb.append([B("✅ Join · %s" % (fm(t["fee"]) if t["fee"] else "FREE"), "jn:%d" % tid, style="success")])
    kb.append([B("👥 Participants", "tp:%d" % tid, style="primary"), B("🔄 Refresh", "t:%d" % tid, style="primary")])
    if share_url(t) and t["status"] in ("upcoming", "live"):
        kb.append([B("🔗 Share with friends", url=share_url(t), style="primary")])
    if t["status"] == "completed":
        kb.append([B("🏅 Results", "tr:%d" % tid, style="success")])
    kb.append(back("gm:%d" % t["gid"]))
    return show(c, mid, tour_text(t, uid), kb)


def show_parts(c, mid, tid, admin=False):
    t = q1("SELECT title FROM tournaments WHERE id=?", (tid,))
    ps = q("SELECT * FROM parts WHERE tid=? ORDER BY slot LIMIT 100", (tid,))
    lines = ["#%d · %s%s%s" % (p["slot"], ("<b>%s</b> · " % esc(p["team_name"])) if p["team_name"] else "", esc(team_line(p)), (" · <code>%d</code>" % p["uid"]) if admin else "") for p in ps]
    body = "\n".join(lines) or "No players yet."
    return show(c, mid, "<blockquote><b>👥 PARTICIPANTS · %s</b></blockquote>\n%s" % (esc(t["title"]) if t else "", body),
                [back(("ato:%d" if admin else "t:%d") % tid)])


def show_results(c, mid, tid):
    t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    ps = q("SELECT * FROM parts WHERE tid=? AND (rank>0 OR prize>0) ORDER BY rank", (tid,))
    lines = ["#%d %s · kills %d · <b>%s</b>" % (p["rank"], esc(p["team_name"] or team_line(p)), p["kills"], fm(p["prize"])) for p in ps]
    r = show(c, mid, "<blockquote><b>🏅 RESULTS · %s</b></blockquote>\n%s" % (esc(t["title"]) if t else "", "\n".join(lines) or "No result yet."), [back("t:%d" % tid)])
    if t and t["result_fid"]:
        send_photo(c, t["result_fid"], "📸 <b>Result screenshot · %s</b>" % esc(t["title"]))
    return r


def show_my_matches(c, mid, uid):
    rows = q("SELECT t.id, t.title, t.status, p.prize FROM parts p JOIN tournaments t ON t.id=p.tid WHERE p.uid=? ORDER BY p.id DESC LIMIT 15", (uid,))
    if not rows:
        return show(c, mid, "<b>🏆 You have not joined any match yet.</b>", [[B("🎮 Browse Tournaments", "g", style="success")], back()])
    kb = [[B("%s %s%s" % ({"upcoming": "🕒", "live": "🔴", "completed": "✅", "cancelled": "❌"}.get(r["status"], "•"), r["title"][:26],
                          (" · " + fm(r["prize"])) if r["prize"] else ""), "t:%d" % r["id"], style="primary")] for r in rows]
    kb.append(back())
    return show(c, mid, "<blockquote><b>🏆 MY MATCHES</b></blockquote>", kb)


def show_wallet(c, mid, uid):
    d, w = balances(uid)
    txt = ("<blockquote><b>💰 MY WALLET</b></blockquote>\n<blockquote><b>├── Deposit balance: %s\n├── Winning balance: %s\n└── Total: %s</b></blockquote>\n"
           "<i>Entry fee is taken from Deposit first. Only Winning balance can be withdrawn.</i>") % (fm(d), fm(w), fm(d + w))
    return show(c, mid, txt, [[B("➕ Add Money", "add", style="success"), B("💸 Withdraw", "wd", style="primary")],
                              [B("🧾 History", "wh", style="primary")], back()])


def show_history(c, mid, uid):
    rows = q("SELECT * FROM txns WHERE uid=? ORDER BY id DESC LIMIT 15", (uid,))
    sign = {"deposit": "+", "prize": "+", "refund": "+", "adjust": "±", "join": "-", "withdraw": "-"}
    lines = ["%s%s %s · %s\n<i>%s</i>" % (sign.get(r["kind"], ""), fm(r["amount"]).replace("₹-", "₹"), r["kind"], esc(r["note"]), r["created"]) for r in rows]
    return show(c, mid, "<blockquote><b>🧾 LAST 15 TRANSACTIONS</b></blockquote>\n" + ("\n\n".join(lines) or "No transactions yet."), [back("w")])


# ============================================================ TEAMS / LINKS / PRIZE TEMPLATES
def tsize(t):
    """Players per team: admin override, else guessed from the mode text (Solo 1, Duo 2, Trio 3, Squad 4, 2v2...)."""
    try:
        n = int(t["team_size"] or 0)
    except (KeyError, TypeError, ValueError):
        n = 0
    if n > 0:
        return min(n, 6)
    m = str(t["mode"] or "").lower()
    mm = re.search(r"(\d)\s*v\s*\d", m)
    if mm:
        return max(1, min(int(mm.group(1)), 6))
    for w, n in (("squad", 4), ("quad", 4), ("trio", 3), ("duo", 2), ("solo", 1)):
        if w in m:
            return n
    return 1


def team_list(p):
    try:
        v = json.loads(p["team"] or "[]")
        return [str(i) for i in v] if isinstance(v, list) else []
    except (ValueError, TypeError, KeyError):
        return []


def team_line(p, sep=" + "):
    names = [p["ign"]] + team_list(p)
    return sep.join(names)


def tour_link(tid):
    u = RT.get("bot") or ""
    return ("https://t.me/%s?start=t_%d" % (u, tid)) if u else ""


def share_url(t):
    from urllib.parse import quote
    lk = tour_link(t["id"])
    if not lk:
        return ""
    txt = "🏆 %s · Prize %s · Entry %s · %s - join now!" % (t["title"], fm(t["pool"]), fm(t["fee"]) if t["fee"] else "FREE", t["start"])
    return "https://t.me/share/url?url=%s&text=%s" % (quote(lk, safe=""), quote(txt, safe=""))


def prize_tpls():
    try:
        v = json.loads(S("prize_tpls"))
        out = [{"name": str(i["name"])[:30], "pcts": [float(x) for x in i["pcts"]]} for i in v if i.get("pcts")]
        return out or json.loads(DEFAULTS["prize_tpls"])
    except Exception:
        return json.loads(DEFAULTS["prize_tpls"])


def split_prizes(pool, pcts):
    """pool x percentages -> rounded amounts (last winner gets the rounding remainder when pcts total 100)."""
    amts = [round(pool * pc / 100.0, 2) for pc in pcts]
    if abs(sum(pcts) - 100) < 0.01 and amts:
        amts[-1] = round(pool - sum(amts[:-1]), 2)
    return amts


def tpl_text(tp):
    return " / ".join(("%g" % pc) + "%" for pc in tp["pcts"])


# ============================================================ JOIN FLOW
def join_start(c, mid, uid, tid):
    t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t or t["status"] != "upcoming":
        return show(c, mid, "❌ This tournament is not open for joining.", [back("g")])
    if q1("SELECT 1 FROM parts WHERE tid=? AND uid=?", (tid, uid)):
        return show_tour(c, mid, uid, tid)
    if filled(tid) >= t["slots"]:
        return show(c, mid, "🚫 <b>Slots are full.</b>", [back("t:%d" % tid)])
    d, w = balances(uid)
    if round(d + w, 2) < t["fee"]:
        return show(c, mid, "❌ <b>Not enough balance.</b>\nEntry: <b>%s</b> · Your wallet: <b>%s</b>\nShort by <b>%s</b>." % (fm(t["fee"]), fm(d + w), fm(t["fee"] - d - w)),
                    [[B("➕ Add Money", "add", style="success")], back("t:%d" % tid)])
    saved = q1("SELECT name FROM ign WHERE uid=? AND gid=?", (uid, t["gid"]))
    kb = []
    if saved:
        kb.append([B("✅ Use: %s" % saved["name"][:25], "ju:%d" % tid, style="success")])
    kb.append(back("t:%d" % tid, "❌ Cancel"))
    st_set(uid, "ign", {"tid": tid, "team": [], "name": "", "step": "me"})
    n = tsize(t)
    extra = ("\n👥 <b>%s mode</b> - you are the captain. After your IGN I will ask for %d teammate IGN%s%s.\n<i>Entry fee is paid once by you for the whole team.</i>" % (
        esc(t["mode"]), n - 1, "s" if n > 2 else "", " and a team name")) if n > 1 else ""
    return show(c, mid, "<blockquote><b>🎮 JOIN · %s</b></blockquote>\n<b>Send your exact in-game name (IGN) / player ID now.</b>\nEntry: <b>%s</b>%s" % (esc(t["title"]), fm(t["fee"]) if t["fee"] else "FREE", extra), kb)


def join_confirm(c, mid, uid, tid, ign, team=None, tname=""):
    t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t:
        return send(c, "❌ Tournament not found.", [back("g")])
    team = team or []
    if tsize(t) > 1 and len(team) < tsize(t) - 1:
        # captain IGN known -> collect teammates one by one
        st_set(uid, "ign", {"tid": tid, "ign": ign, "team": team, "name": "", "step": "mate"})
        k = len(team) + 2
        txt = "<blockquote><b>👥 TEAMMATE %d of %d</b></blockquote>\nCaptain: <code>%s</code>%s\n<b>Send teammate #%d IGN / player ID now.</b>" % (
            k, tsize(t), esc(ign), ("\nTeam so far: <code>%s</code>" % esc(" + ".join([ign] + team))) if team else "", k)
        kb = [back("t:%d" % tid, "❌ Cancel")]
        return show(c, mid, txt, kb) if mid else send(c, txt, kb)
    if tsize(t) > 1 and not tname:
        st_set(uid, "ign", {"tid": tid, "ign": ign, "team": team, "name": "", "step": "tname"})
        txt = "<blockquote><b>🛡 TEAM NAME</b></blockquote>\nTeam: <code>%s</code>\n<b>Send a team name</b> (max 20 characters) or send <code>-</code> to skip." % esc(" + ".join([ign] + team))
        kb = [back("t:%d" % tid, "❌ Cancel")]
        return show(c, mid, txt, kb) if mid else send(c, txt, kb)
    tname = "" if tname == "-" else tname
    st_set(uid, "join_ok", {"tid": tid, "ign": ign, "team": team, "tname": tname})
    txt = "<blockquote><b>🧾 CONFIRM JOIN</b></blockquote>\nTournament: <b>%s</b>\n%sIGN: <code>%s</code>\n%sEntry fee: <b>%s</b>" % (
        esc(t["title"]), ("Team: <b>%s</b>\n" % esc(tname)) if tname else "", esc(ign),
        ("Teammates: <code>%s</code>\n" % esc(" + ".join(team))) if team else "", fm(t["fee"]) if t["fee"] else "FREE")
    kb = [[B("✅ Confirm & Pay", "jc:%d" % tid, style="success"), B("❌ Cancel", "t:%d" % tid, style="danger")]]
    return show(c, mid, txt, kb) if mid else send(c, txt, kb)


def ign_taken(tid, names, skip_uid=0):
    """True when any of these IGNs (captain or teammate) is already registered in this tournament."""
    low = {n.strip().lower() for n in names if n}
    for p in q("SELECT uid, ign, team FROM parts WHERE tid=?", (tid,)):
        if p["uid"] == skip_uid:
            continue
        if {n.lower() for n in [p["ign"]] + team_list(p)} & low:
            return True
    return False


def do_join(uid, tid, ign, team=None, tname=""):
    team = [str(n).strip()[:40] for n in (team or []) if str(n).strip()]
    tname = str(tname or "").strip()[:20]
    with L:
        t = DB.execute("SELECT * FROM tournaments WHERE id=?", (tid,)).fetchone()
        if not t or t["status"] != "upcoming":
            return "closed", 0
        if DB.execute("SELECT 1 FROM parts WHERE tid=? AND uid=?", (tid, uid)).fetchone():
            return "dup", 0
        need = tsize(t) - 1
        if len(team) != need:
            return "team", 0
        if len({n.lower() for n in [ign] + team}) != len(team) + 1:
            return "sameign", 0
        if ign_taken(tid, [ign] + team, uid):
            return "igntaken", 0
        n = DB.execute("SELECT COALESCE(MAX(slot),0) m FROM parts WHERE tid=?", (tid,)).fetchone()["m"]
        cnt = DB.execute("SELECT COUNT(*) c FROM parts WHERE tid=?", (tid,)).fetchone()["c"]
        if cnt >= t["slots"]:
            return "full", 0
        if not spend(uid, t["fee"]):
            return "funds", 0
        DB.execute("INSERT INTO parts(tid,uid,ign,slot,joined,team,team_name) VALUES(?,?,?,?,?,?,?)", (tid, uid, ign, n + 1, now_s(), json.dumps(team, ensure_ascii=False) if team else "", tname))
        if t["fee"]:
            txn(uid, "join", t["fee"], t["title"])
        DB.execute("UPDATE users SET played=played+1 WHERE id=?", (uid,))
        DB.execute("INSERT INTO ign(uid,gid,name) VALUES(?,?,?) ON CONFLICT(uid,gid) DO UPDATE SET name=excluded.name", (uid, t["gid"], ign))
        DB.commit()
        return "ok", n + 1


# ============================================================ UPI LINKS + GENERATED QR
UPI_APPS = [("gpay", "Google Pay", "🟦", "tez://upi/pay"), ("phonepe", "PhonePe", "🟪", "phonepe://pay"),
            ("paytm", "Paytm", "🟦", "paytmmp://pay"), ("bhim", "BHIM / Any UPI", "🟧", "upi://pay")]


def upi_link(amt, note="Wallet"):
    """Standard UPI deep link with the amount filled in (works in every UPI app and inside a QR code)."""
    from urllib.parse import quote
    pn = re.sub(r"[^A-Za-z0-9 ]", "", S("brand"))[:30].strip() or "Tournament"
    return "upi://pay?pa=%s&pn=%s&am=%s&cu=INR&tn=%s" % (quote(S("upi"), safe="@"), quote(pn), ("%.2f" % float(amt)), quote(note))


def upi_app_link(app, amt, note="Wallet"):
    link = upi_link(amt, note)
    for k, _n, _e, scheme in UPI_APPS:
        if k == app:
            return link.replace("upi://pay", scheme, 1)
    return link


def qr_png(text, scale=9, border=4):
    import qrgen
    return qrgen.png_bytes(qrgen.make(text), scale, border)


def qr_auto():
    """Generated QR is used when the admin turned it on and a UPI ID exists."""
    return S("qr_gen") != "0" and bool(S("upi"))


def send_photo_bytes(c, png, cap, kb=None):
    p = {"chat_id": str(c), "caption": cut(cap, 1000), "parse_mode": "HTML"}
    for strip in (False, True):
        if kb:
            p["reply_markup"] = json.dumps(_strip_style({"inline_keyboard": kb}) if strip else {"inline_keyboard": kb})
        try:
            r = SESSION.post(API + "/sendPhoto", data=p, files={"photo": ("upi-qr.png", png, "image/png")}, timeout=40).json()
        except (requests.RequestException, ValueError):
            return None
        if r.get("ok"):
            return r.get("result")
        if not re.search(r"(?i)button|style|reply markup", str(r.get("description", ""))):
            break
    return None


# ============================================================ MONEY FLOWS
UTR_RE = re.compile(r"^[A-Za-z0-9]{6,30}$")
UPI_RE = re.compile(r"^[A-Za-z0-9._\-]{2,}@[A-Za-z0-9]{2,}$")


def add_money_start(c, mid, uid):
    if not S("upi") and not S("qr"):
        return show(c, mid, "⚠️ <b>Add Money is not set up yet.</b>\nPlease contact support.", [back()])
    st_set(uid, "dep_amt")
    return show(c, mid, "<blockquote><b>➕ ADD MONEY</b></blockquote>\n<b>Send the amount you want to add</b> (minimum %s)." % fm(fnum("min_dep", 10)), [back("w", "❌ Cancel")])


def dep_pay_info(c, uid, amt):
    st_set(uid, "dep_pay", {"amt": amt})
    gen = qr_auto()
    steps = ("<blockquote><b>1️⃣ Scan the QR or tap a UPI app below\n2️⃣ Pay exactly %s\n3️⃣ Tap “I have paid” and send the UTR</b></blockquote>\n" % fm(amt)) if gen else \
            ("1️⃣ Pay exactly <b>%s</b> by any UPI app.\n2️⃣ Tap <b>I have paid</b> and send the <b>UTR / transaction ID</b>.\n" % fm(amt))
    txt = (hd("💳", "PAY %s" % fm(amt), "Secure UPI payment") + "\n<b>UPI ID:</b> <code>%s</code>\n<b>Amount:</b> <code>%s</code>\n\n%s"
           "<i>Money is added after the payment is verified.</i>") % (esc(S("upi") or "-"), ("%.2f" % amt).rstrip("0").rstrip("."), steps)
    kb = []
    if gen and app_url():
        row = [B("%s %s" % (e, n), url=app_url("/pay/go?app=%s&am=%s" % (k, ("%.2f" % amt))), style="primary") for k, n, e, _s in UPI_APPS]
        kb += [row[0:2], row[2:4]]
    kb += [[B("✅ I have paid", "dpaid", style="success")], back("w", "❌ Cancel")]
    if gen:
        try:
            r = send_photo_bytes(c, qr_png(upi_link(amt)), txt, kb)
        except Exception as e:
            log("QR generation failed: %r" % (e,))
            r = None
        if r:
            return r
    if S("qr"):
        return send_photo(c, S("qr"), txt, kb)
    return send(c, txt, kb)


def dep_submit(c, uid, amt, utr, proof=""):
    utr = utr.strip().upper()
    if not UTR_RE.match(utr):
        return send(c, "❌ <b>Invalid UTR.</b> It is 6-30 letters/numbers. Send it again (or /cancel).")
    with L:
        if DB.execute("SELECT 1 FROM deposits WHERE utr=? AND status!='rejected'", (utr,)).fetchone():
            dup = True
        elif DB.execute("SELECT COUNT(*) c FROM deposits WHERE uid=? AND status='pending'", (uid,)).fetchone()["c"] >= 3:
            dup = None
        else:
            dup = False
            did = DB.execute("INSERT INTO deposits(uid,amount,utr,proof,created) VALUES(?,?,?,?,?)", (uid, amt, utr, proof, now_s())).lastrowid
            DB.commit()
    if dup:
        return send(c, "❌ <b>This UTR was already submitted.</b>")
    if dup is None:
        return send(c, "⏳ You already have 3 pending deposits. Please wait for approval.")
    st_clear(uid)
    u = q1("SELECT name, username FROM users WHERE id=?", (uid,))
    cap = "<blockquote><b>📥 NEW DEPOSIT #%d</b></blockquote>\nUser: %s (<code>%d</code>)\nAmount: <b>%s</b>\nUTR: <code>%s</code>" % (did, esc(u["name"]), uid, fm(amt), utr)
    notify_admins(cap, [[B("✅ Approve", "dp:a:%d" % did, style="success"), B("❌ Reject", "dp:r:%d" % did, style="danger")]], proof or None)
    return send(c, "✅ <b>Deposit request sent.</b>\nAmount: <b>%s</b> · UTR: <code>%s</code>\nWe will add it to your wallet after checking." % (fm(amt), utr), [back("home", "🏠 Menu")])


def dep_decide(did, approve):
    with L:
        d = DB.execute("SELECT * FROM deposits WHERE id=?", (did,)).fetchone()
        if not d or d["status"] not in ("pending", "awaiting"):
            return None
        if approve:
            DB.execute("UPDATE users SET dep=dep+? WHERE id=?", (d["amount"], d["uid"]))
            txn(d["uid"], "deposit", d["amount"], ("AUTO " if d["gw"] else "UPI ") + d["utr"])
        DB.execute("UPDATE deposits SET status=? WHERE id=?", ("approved" if approve else "rejected", did))
        DB.commit()
        return d


def wd_start(c, mid, uid):
    d, w = balances(uid)
    mn = fnum("min_wd", 50)
    if w < mn:
        return show(c, mid, "<blockquote><b>💸 WITHDRAW</b></blockquote>\nWinning balance: <b>%s</b>\nMinimum withdrawal: <b>%s</b>\n<i>Only winning balance can be withdrawn.</i>" % (fm(w), fm(mn)),
                    [[B("🎮 Play & Win", "g", style="success")], back()])
    st_set(uid, "wd_amt")
    return show(c, mid, "<blockquote><b>💸 WITHDRAW</b></blockquote>\nWinning balance: <b>%s</b>\n<b>Send the amount to withdraw</b> (min %s)." % (fm(w), fm(mn)), [back("w", "❌ Cancel")])


def wd_create(uid, amt, upi):
    with L:
        u = DB.execute("SELECT win FROM users WHERE id=?", (uid,)).fetchone()
        if not u or u["win"] < amt:
            return None
        if DB.execute("SELECT COUNT(*) c FROM withdrawals WHERE uid=? AND status='pending'", (uid,)).fetchone()["c"] >= 2:
            return -1
        DB.execute("UPDATE users SET win=? WHERE id=?", (round(u["win"] - amt, 2), uid))
        wid = DB.execute("INSERT INTO withdrawals(uid,amount,upi,created) VALUES(?,?,?,?)", (uid, amt, upi, now_s())).lastrowid
        txn(uid, "withdraw", amt, "request #%d" % wid)
        DB.commit()
        return wid


def wd_decide(wid, paid):
    with L:
        w = DB.execute("SELECT * FROM withdrawals WHERE id=?", (wid,)).fetchone()
        if not w or w["status"] != "pending":
            return None
        if not paid:
            DB.execute("UPDATE users SET win=win+? WHERE id=?", (w["amount"], w["uid"]))
            txn(w["uid"], "refund", w["amount"], "withdraw rejected #%d" % wid)
        DB.execute("UPDATE withdrawals SET status=? WHERE id=?", ("paid" if paid else "rejected", wid))
        DB.commit()
        return w


# ============================================================ ADMIN
def parse_results(text, t):
    rows, seen = [], set()
    for raw in text.strip().splitlines():
        if not raw.strip():
            continue
        parts = [p for p in re.split(r"[\s,|]+", raw.strip()) if p]
        try:
            slot, prize = int(parts[0].lstrip("#")), float(parts[1].lstrip("₹"))
            kills = int(parts[2]) if len(parts) > 2 else 0
        except (ValueError, IndexError):
            return None, "Wrong line: <code>%s</code>\nUse: slot prize kills" % esc(raw[:60])
        if slot in seen or not q1("SELECT 1 FROM parts WHERE tid=? AND slot=?", (t["id"], slot)) or prize < 0 or kills < 0:
            return None, "Bad or repeated slot #%d (slot must exist, no duplicates, no negatives)." % slot
        seen.add(slot)
        rows.append((slot, prize, kills))
    if not rows:
        return None, "Send at least one line."
    return rows, ""


def apply_results(tid, rows):
    with L:
        t = DB.execute("SELECT * FROM tournaments WHERE id=?", (tid,)).fetchone()
        if not t or t["status"] in ("completed", "cancelled"):
            return None
        out = []
        for rank, (slot, prize, kills) in enumerate(rows, 1):
            p = DB.execute("SELECT * FROM parts WHERE tid=? AND slot=?", (tid, slot)).fetchone()
            if not p:
                continue
            total = round(prize + kills * t["per_kill"], 2)
            DB.execute("UPDATE parts SET prize=?, kills=?, rank=? WHERE id=?", (total, kills, rank, p["id"]))
            if total > 0:
                DB.execute("UPDATE users SET win=win+? WHERE id=?", (total, p["uid"]))
                txn(p["uid"], "prize", total, t["title"])
            if rank == 1:
                DB.execute("UPDATE users SET wins=wins+1 WHERE id=?", (p["uid"],))
            out.append((p["uid"], (p["team_name"] or team_line(p)), rank, kills, total, bool(team_list(p))))
        DB.execute("UPDATE tournaments SET status='completed' WHERE id=?", (tid,))
        DB.commit()
        return out


def res_confirm(c, uid, t, rows, shot="", mid=None):
    """Show the payout preview (manual or auto-split) with confirm / screenshot / cancel buttons."""
    lines, total = [], 0.0
    for i, (slot, prize, kills) in enumerate(rows, 1):
        p = q1("SELECT * FROM parts WHERE tid=? AND slot=?", (t["id"], slot))
        amt = round(prize + kills * t["per_kill"], 2)
        total += amt
        lines.append("%d. #%d %s → <b>%s</b>%s" % (i, slot, esc((p["team_name"] or team_line(p)) if p else "?"), fm(amt), (" (%d kills)" % kills) if kills else ""))
    st_set(uid, "res_ok", {"tid": t["id"], "rows": [list(r) for r in rows], "shot": shot})
    warn = "\n⚠️ <b>Payout is more than the prize pool!</b>" if total > t["pool"] + 0.01 else ""
    txt = "<blockquote><b>🏁 CONFIRM RESULTS</b></blockquote>\n%s\n\nTotal payout: <b>%s</b> (pool %s)%s\n📸 Screenshot: <b>%s</b>" % (
        "\n".join(lines), fm(total), fm(t["pool"]), warn, "added ✅" if shot else "not added (optional)")
    kb = [[B("✅ Confirm & pay", "atrc:%d" % t["id"], style="success"), B("❌ Cancel", "ato:%d" % t["id"], style="danger")],
          [B("📸 %s screenshot" % ("Change" if shot else "Add result"), "atrs:%d" % t["id"], style="primary")]]
    return show(c, mid, txt, kb) if mid else send(c, txt, kb)


def finish_result_media(tid, fid="", fname=""):
    """Store the result screenshot (Telegram file_id + local copy for the Mini App) and send it to the joined players."""
    t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t or not fid:
        return
    local = fname or save_tg_photo(fid, "res%d_%d.jpg" % (tid, int(time.time())))
    x("UPDATE tournaments SET result_fid=?, result_img=? WHERE id=?", (fid, ("file:" + local) if local else "", tid))
    for pr in q("SELECT uid FROM parts WHERE tid=?", (tid,)):
        send_photo(pr["uid"], fid, "📸 <b>Result screenshot · %s</b>" % esc(t["title"]))
        time.sleep(0.05)


def reminder_loop():
    """Every 30s: tournaments starting within 15 minutes -> remind every joined player (once) and warn admins if the room is missing."""
    while True:
        time.sleep(30)
        try:
            now = int(time.time())
            for t in q("SELECT * FROM tournaments WHERE status='upcoming' AND start_ts>0 AND remind_sent=0 AND start_ts-?<=900 AND start_ts-?>-300", (now, now)):
                x("UPDATE tournaments SET remind_sent=1 WHERE id=?", (t["id"],))
                mins = max(1, int(round((t["start_ts"] - now) / 60.0)))
                when = ("in about <b>%d min</b>" % mins) if t["start_ts"] > now else "<b>now</b>"
                kb = [[B("🏟 Open Tournament", "t:%d" % t["id"], style="success")]]
                if app_url():
                    kb.insert(0, [B("🚀 Open App", web=app_url("/#t/%d" % t["id"]), style="success")])
                for pr in q("SELECT * FROM parts WHERE tid=?", (t["id"],)):
                    room = ("\n\n<blockquote><b>🔑 Room ID: <code>%s</code>\nPassword: <code>%s</code></b></blockquote>" % (esc(t["room_id"]), esc(t["room_pass"]))) if t["room_id"] else "\n<i>Room ID &amp; password will be sent here as soon as the admin adds it.</i>"
                    send(pr["uid"], "<blockquote><b>⏰ MATCH REMINDER</b></blockquote>\n<b>%s</b> starts %s.\n🕒 %s%s\n<b>Be ready in the lobby! 🎮</b>" % (esc(t["title"]), when, esc(t["start"]), room), kb)
                    time.sleep(0.05)
                if not t["room_id"]:
                    notify_admins("⚠️ <b>%s</b> starts in ~%d min but <b>Room ID is not set</b>." % (esc(t["title"]), mins), [[B("🔑 Set Room ID", "atroom:%d" % t["id"], style="danger")]])
            x("UPDATE tournaments SET remind_sent=1 WHERE remind_sent=0 AND start_ts>0 AND start_ts-?<=-300", (now,))
        except Exception as e:
            log("reminder error: %r" % (e,))


def cancel_tour(tid):
    with L:
        t = DB.execute("SELECT * FROM tournaments WHERE id=?", (tid,)).fetchone()
        if not t or t["status"] in ("completed", "cancelled"):
            return None
        ps = DB.execute("SELECT uid FROM parts WHERE tid=?", (tid,)).fetchall()
        for p in ps:
            if t["fee"]:
                DB.execute("UPDATE users SET dep=dep+? WHERE id=?", (t["fee"], p["uid"]))
                txn(p["uid"], "refund", t["fee"], "cancelled: " + t["title"])
        DB.execute("UPDATE tournaments SET status='cancelled' WHERE id=?", (tid,))
        DB.commit()
        return [p["uid"] for p in ps], t


def adm_deposits(c, mid):
    ds = q("SELECT d.*, u.name FROM deposits d LEFT JOIN users u ON u.id=d.uid WHERE d.status='pending' ORDER BY d.id LIMIT 8")
    if not ds:
        return show(c, mid, "<b>📥 No pending deposits.</b>", [back("adm")])
    show(c, mid, "<blockquote><b>📥 PENDING DEPOSITS (%d shown)</b></blockquote>" % len(ds), [back("adm")])
    for d in ds:
        send(c, "<b>#%d</b> · %s (<code>%d</code>)\nAmount <b>%s</b> · UTR <code>%s</code>\n<i>%s</i>" % (d["id"], esc(d["name"]), d["uid"], fm(d["amount"]), esc(d["utr"]), d["created"]),
             [[B("✅ Approve", "dp:a:%d" % d["id"], style="success"), B("❌ Reject", "dp:r:%d" % d["id"], style="danger")]])


def adm_withdrawals(c, mid):
    ws = q("SELECT w.*, u.name FROM withdrawals w LEFT JOIN users u ON u.id=w.uid WHERE w.status='pending' ORDER BY w.id LIMIT 8")
    if not ws:
        return show(c, mid, "<b>📤 No pending withdrawals.</b>", [back("adm")])
    show(c, mid, "<blockquote><b>📤 PENDING WITHDRAWALS (%d shown)</b></blockquote>\n<i>Pay the UPI first, then tap Paid.</i>" % len(ws), [back("adm")])
    for w in ws:
        send(c, "<b>#%d</b> · %s (<code>%d</code>)\nAmount <b>%s</b>\nUPI: <code>%s</code>\n<i>%s</i>" % (w["id"], esc(w["name"]), w["uid"], fm(w["amount"]), esc(w["upi"]), w["created"]),
             [[B("✅ Paid", "wr:p:%d" % w["id"], style="success"), B("❌ Reject & refund", "wr:r:%d" % w["id"], style="danger")]])


def pend_counts():
    return (q1("SELECT COUNT(*) c FROM deposits WHERE status='pending'")["c"], q1("SELECT COUNT(*) c FROM withdrawals WHERE status='pending'")["c"])


def gw_name():
    try:
        import pay
        return {"none": "Manual UPI + UTR", "razorpay": "Razorpay", "upigateway": "UPIGateway", "fampay": "FamPay / Custom API"}.get(pay.mode(sys.modules[__name__]), "Manual")
    except Exception:
        return "Manual UPI + UTR"


def adm_home(c, mid):
    pd, pw = pend_counts()
    td = today_s() + "%"
    nu = q1("SELECT COUNT(*) c FROM users WHERE joined LIKE ?", (td,))["c"]
    dsum = q1("SELECT COALESCE(SUM(amount),0) s FROM txns WHERE kind='deposit' AND created LIKE ?", (td,))["s"]
    jn = q1("SELECT COUNT(*) c FROM parts WHERE joined LIKE ?", (td,))["c"]
    up = q1("SELECT COUNT(*) c FROM tournaments WHERE status='upcoming'")["c"]
    tot = q1("SELECT COUNT(*) c FROM users")["c"]
    txt = (hd("🛠", "ADMIN CONSOLE · " + esc(S("brand")), "Everything you need to run your arena")
           + "\n<blockquote><b>📅 TODAY · %s\n├── 🆕 New users: %d\n├── 💰 Deposits: %s\n├── 🎟 Joins: %d\n└── 🔴 Live: %d  ·  🕒 Upcoming: %d</b></blockquote>"
           "\n<blockquote><b>├── 👥 Total users: %d\n├── 💳 Payments: %s\n├── 🖼 Welcome photo: %s\n└── 🛠 Maintenance: %s</b></blockquote>") % (
        today_s(), nu, fm(dsum), jn, live_count(), up, tot, gw_name(), "ON ✅" if S("welcome_img") else "not set", "🔴 ON" if S("maint") == "1" else "OFF")
    kb = [[B("🏟 Tournaments", "at", style="success"), B("🎮 Games", "ag", style="primary")],
          [B("📥 Deposits%s" % ((" (%d)" % pd) if pd else ""), "ad", style="success" if pd else "primary"),
           B("📤 Withdrawals%s" % ((" (%d)" % pw) if pw else ""), "aw", style="danger" if pw else "primary")],
          [B("👥 Users", "au", style="primary"), B("📢 Broadcast", "ab", style="primary")],
          [B("🎨 Welcome Studio", "aws", style="success"), B("⚙️ Settings", "as", style="primary")],
          [B("📊 Reports", "arp", style="primary"), B("💾 Backup DB", "abk", style="primary")],
          [B("🔄 Refresh", "adm", style="primary"), back("home", "⬅️ Menu")[0]]]
    if app_url():
        kb.insert(0, [B("🚀 OPEN ADMIN APP (easy mode)", web=app_url("/#admin"), style="success")])
    return show(c, mid, txt, kb)


# ---------------------------------------------------------------- welcome studio
def adm_welcome(c, mid):
    stored = {r["k"] for r in q("SELECT k FROM settings")}
    txt = (hd("🎨", "WELCOME STUDIO", "Design what players see on /start")
           + "\n<blockquote><b>├── 🖼 Photo: %s\n├── ✏️ Text: %s\n├── 🔘 App button: %s\n├── 📊 Quick stats strip: %s\n├── 📱 App title: %s\n└── 📱 App subtitle: %s</b></blockquote>"
           "\n<i>Placeholders: {name} {brand} {balance} {live} {players} {id}</i>") % (
        "set ✅" if S("welcome_img") else "none", "custom ✅" if "txt_welcome" in stored else "default", esc(S("welcome_btn") or "default"),
        "ON" if S("dash") != "0" else "OFF", esc((S("app_title") or "default")[:30]), esc((S("app_sub") or "default")[:30]))
    kb = [[B("🖼 Set Photo", "awp", style="success"), B("🗑 Remove Photo", "awx", style="danger")],
          [B("✏️ Edit Text", "set:txt_welcome", style="primary"), B("🔘 Button Text", "set:welcome_btn", style="primary")],
          [B("🎨 Templates", "awt", style="success"), B("👁 Preview", "awv", style="success")],
          [B("📊 Quick stats: %s" % ("ON" if S("dash") != "0" else "OFF"), "awd", style="primary"), B("♻️ Reset Text", "awr", style="danger")],
          [B("📱 App Title", "set:app_title", style="primary"), B("📱 App Subtitle", "set:app_sub", style="primary")],
          back("adm")]
    return show(c, mid, txt, kb)


def adm_templates(c, mid):
    kb = [[B(v[0], "awtp:" + k, style="primary")] for k, v in PRESETS.items()]
    kb.append(back("aws"))
    return show(c, mid, hd("🎨", "WELCOME TEMPLATES", "Tap one to preview, then apply") , kb)


def save_tg_photo(fid, name):
    """Download a Telegram photo into logos/ so the Mini App hero image can use it too. Returns file name or ''."""
    try:
        r = tg("getFile", {"file_id": fid})
        if bad(r) or not r.get("file_path"):
            return ""
        raw = SESSION.get("https://api.telegram.org/file/bot%s/%s" % (BOT_TOKEN, r["file_path"]), timeout=40).content
        if not raw or len(raw) > 5 * 1024 * 1024:
            return ""
        d = os.path.join(BASE, "logos")
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, name), "wb") as f:
            f.write(raw)
        return name
    except Exception:
        return ""


# ---------------------------------------------------------------- games
def adm_games(c, mid):
    gs = q("SELECT * FROM games ORDER BY sort, id")
    kb = [[B("%s %s%s" % (g["emoji"], g["name"], "" if g["active"] else " · hidden"), "agm:%d" % g["id"], style="primary" if g["active"] else "danger")] for g in gs]
    kb.append([B("➕ Add Game", "aga", style="success")])
    kb.append(back("adm"))
    return show(c, mid, hd("🎮", "GAMES", "Tap a game to rename, hide or delete") + "\n<i>Add logos & colours from the Mini App → Admin → Games.</i>", kb)


def adm_game(c, mid, gid):
    g = q1("SELECT * FROM games WHERE id=?", (gid,))
    if not g:
        return adm_games(c, mid)
    n = q1("SELECT COUNT(*) c FROM tournaments WHERE gid=?", (gid,))["c"]
    txt = hd(g["emoji"], esc(g["name"])) + "\n<blockquote><b>├── Status: %s\n└── Tournaments: %d</b></blockquote>" % ("✅ visible" if g["active"] else "🙈 hidden", n)
    kb = [[B("🙈 Hide" if g["active"] else "👁 Show", "agt:%d" % gid, style="primary"), B("✏️ Rename", "agr:%d" % gid, style="primary")],
          [B("🏟 New Tournament", "atg:%d" % gid, style="success"), B("🗑 Delete", "agd:%d" % gid, style="danger")], back("ag")]
    return show(c, mid, txt, kb)


# ---------------------------------------------------------------- tournaments
ICON = {"upcoming": "🕒", "live": "🔴", "completed": "✅", "cancelled": "❌"}


def adm_tours(c, mid, hist=False):
    if hist:
        ts = q("SELECT * FROM tournaments WHERE status IN ('completed','cancelled') ORDER BY id DESC LIMIT 20")
    else:
        ts = q("SELECT * FROM tournaments WHERE status IN ('upcoming','live') ORDER BY id DESC LIMIT 20")
    kb = [[B("➕ Create Tournament", "atn", style="success"), B("🟢 Active" if hist else "📜 History", "at" if hist else "at:h", style="primary")]]
    kb += [[B("%s #%d %s · %d/%d" % (ICON.get(t["status"], "•"), t["id"], t["title"][:20], filled(t["id"]), t["slots"]), "ato:%d" % t["id"], style="primary")] for t in ts]
    kb.append(back("adm"))
    sub = "Completed & cancelled" if hist else "Upcoming & live"
    return show(c, mid, hd("🏟", "TOURNAMENTS", sub) + ("" if ts else "\n<b>Nothing here yet.</b>"), kb)


def adm_tour(c, mid, tid):
    t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t:
        return adm_tours(c, mid)
    kb = []
    if t["status"] in ("upcoming", "live"):
        kb.append([B("🔑 Room ID/Pass", "atroom:%d" % tid, style="success"), B("🏁 Enter Results", "atr:%d" % tid, style="success")])
        row = []
        if t["status"] == "upcoming":
            row.append(B("▶️ Go Live", "ats:%d:live" % tid, style="danger"))
        row.append(B("❌ Cancel & Refund", "atc:%d" % tid, style="danger"))
        kb.append(row)
        kb.append([B("✏️ Edit", "ate:%d" % tid, style="primary"), B("📣 Announce", "atan:%d" % tid, style="success")])
    kb.append([B("📋 Duplicate", "atd:%d" % tid, style="primary"), B("👥 Participants", "atp:%d" % tid, style="primary")])
    last = [B("🔄 Refresh", "ato:%d" % tid, style="primary")]
    if t["status"] == "cancelled" or not filled(tid):
        last.append(B("🗑 Delete", "atdel:%d" % tid, style="danger"))
    kb.append(last)
    kb.append(back("at"))
    lk = tour_link(tid)
    return show(c, mid, tour_text(t, admin=True) + (("\n\n🔗 Share link:\n<code>%s</code>" % esc(lk)) if lk else ""), kb)


def parse_new_tour(text):
    ln = [l.strip() for l in text.strip().splitlines() if l.strip()]
    if len(ln) < 7:
        return None, "Send all 7 lines (title, mode, entry fee, prize pool, per kill, slots, start time)."
    try:
        fee, pool, pk = float(ln[2].lstrip("₹")), float(ln[3].lstrip("₹")), float(ln[4].lstrip("₹"))
        slots = int(ln[5])
    except ValueError:
        return None, "Entry fee, prize pool, per kill and slots must be numbers."
    if min(fee, pool, pk) < 0 or not 2 <= slots <= 1000:
        return None, "Amounts cannot be negative and slots must be 2-1000."
    return {"title": ln[0][:40], "mode": ln[1][:20], "fee": fee, "pool": pool, "pk": pk, "slots": slots, "start": ln[6][:40],
            "ts": parse_start(ln[6]), "map": ln[7][:30] if len(ln) > 7 else ""}, ""


EDIT_FIELDS = [("title", "Title"), ("mode", "Mode"), ("fee", "Entry fee"), ("pool", "Prize pool"), ("pk", "Per kill"), ("slots", "Slots"), ("start", "Start time"), ("map", "Map")]


def adm_edit_menu(c, mid, tid):
    t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t:
        return adm_tours(c, mid)
    kb = [[B("✏️ " + EDIT_FIELDS[i][1], "atf:%d:%s" % (tid, EDIT_FIELDS[i][0]), style="primary"),
           B("✏️ " + EDIT_FIELDS[i + 1][1], "atf:%d:%s" % (tid, EDIT_FIELDS[i + 1][0]), style="primary")] for i in range(0, len(EDIT_FIELDS), 2)]
    kb.append(back("ato:%d" % tid))
    return show(c, mid, hd("✏️", "EDIT · " + esc(t["title"]), "Pick what you want to change") + "\n<i>Entry fee cannot change after players joined. Start time like <code>05-11-2026 21:00</code> enables the app countdown.</i>", kb)


def announce_tour(c, tid):
    t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t:
        return
    txt = hd("📣", "NEW TOURNAMENT") + "\n" + tour_text(t) + "\n\n<b>🔥 Slots are filling fast. Join now!</b>"
    kb = [[B("✅ Join Now", "t:%d" % tid, style="success")]]
    if share_url(t):
        kb.append([B("🔗 Share", url=share_url(t), style="primary")])
    if app_url():
        kb.insert(0, [B("🚀 Open App", web=app_url("/#t/%d" % tid), style="success")])
    broadcast(c, txt, "", kb)


# ---------------------------------------------------------------- users
def adm_users_menu(c, mid):
    tot = q1("SELECT COUNT(*) c FROM users")["c"]
    ban = q1("SELECT COUNT(*) c FROM users WHERE banned=1")["c"]
    kb = [[B("🔍 Find User", "auf", style="success")],
          [B("🆕 Recent", "ul:new", style="primary"), B("💎 Top Balance", "ul:bal", style="primary")],
          [B("🏅 Top Winners", "ul:win", style="primary"), B("🚫 Banned (%d)" % ban, "ul:ban", style="danger" if ban else "primary")], back("adm")]
    return show(c, mid, hd("👥", "USERS", "%d registered" % tot) + "\n<i>Find by Telegram ID, @username or name.</i>", kb)


def user_buttons(rows, back_cb="au"):
    kb = [[B("%s%s · %s" % ("🚫 " if r["banned"] else "", r["name"][:18], fm(r["dep"] + r["win"])), "uv:%d" % r["id"], style="primary")] for r in rows]
    kb.append(back(back_cb))
    return kb


def adm_ulist(c, mid, kind):
    order = "substr(joined,7,4)||substr(joined,4,2)||substr(joined,1,2)||substr(joined,12,5)"
    qs = {"new": ("🆕 RECENT USERS", "SELECT * FROM users ORDER BY %s DESC LIMIT 10" % order),
          "bal": ("💎 TOP BALANCES", "SELECT * FROM users WHERE dep+win>0 ORDER BY dep+win DESC LIMIT 10"),
          "win": ("🏅 TOP WINNERS", "SELECT u.* FROM users u JOIN (SELECT uid, SUM(prize) s FROM parts GROUP BY uid HAVING s>0) t ON t.uid=u.id ORDER BY t.s DESC LIMIT 10"),
          "ban": ("🚫 BANNED USERS", "SELECT * FROM users WHERE banned=1 LIMIT 15")}
    title, sql = qs.get(kind, qs["new"])
    rows = q(sql)
    return show(c, mid, "<blockquote><b>%s</b></blockquote>%s" % (title, "" if rows else "\n<b>Nobody here yet.</b>"), user_buttons(rows))


def adm_user(c, mid, uid2):
    u = q1("SELECT * FROM users WHERE id=?", (uid2,))
    if not u:
        return send(c, "❌ User not found.", [back("au")])
    tot = q1("SELECT COALESCE(SUM(prize),0) s FROM parts WHERE uid=?", (uid2,))["s"]
    txt = (hd("👤", "USER %d" % uid2) + "\n<blockquote><b>├── Name: %s %s\n├── Deposit: %s\n├── Winning: %s\n├── Played: %d  ·  Won: %d\n├── Total prize: %s\n"
           "├── Joined: %s\n├── Last seen: %s\n└── Status: %s</b></blockquote>") % (
        esc(u["name"]), ("(@%s)" % esc(u["username"])) if u["username"] else "", fm(u["dep"]), fm(u["win"]), u["played"], u["wins"], fm(tot),
        esc(u["joined"]), esc(u["last_seen"]), "🚫 BANNED" if u["banned"] else "✅ active")
    kb = [[B("➕ Add balance", "uab:%d" % uid2, style="success"), B("➖ Deduct", "uad:%d" % uid2, style="danger")],
          [B("✉️ Message", "umsg:%d" % uid2, style="primary"), B("🧾 History", "uh:%d" % uid2, style="primary")],
          [B("✅ Unban" if u["banned"] else "🚫 Ban", "ubn:%d" % uid2, style="primary")], back("au")]
    return show(c, mid, txt, kb) if mid else send(c, txt, kb)


def adm_user_hist(c, mid, uid2):
    rows = q("SELECT * FROM txns WHERE uid=? ORDER BY id DESC LIMIT 12", (uid2,))
    sign = {"deposit": "+", "prize": "+", "refund": "+", "adjust": "±", "join": "-", "withdraw": "-"}
    lines = ["%s%s <b>%s</b> · %s <i>%s</i>" % (sign.get(r["kind"], ""), fm(r["amount"]).replace("₹-", "₹"), r["kind"], esc(r["note"]), r["created"]) for r in rows]
    return show(c, mid, hd("🧾", "USER %d · LAST 12" % uid2) + "\n" + ("\n".join(lines) or "No transactions."), [back("uv:%d" % uid2)])


# ---------------------------------------------------------------- settings
SET_KEYS = [("upi", "UPI ID"), ("qr", "UPI QR (photo)"), ("min_dep", "Min deposit"), ("min_wd", "Min withdraw"),
            ("support", "Support username"), ("brand", "Brand name"), ("notice", "Home notice"),
            ("txt_welcome", "Welcome text"), ("txt_terms", "Terms text"), ("welcome_btn", "App button text"),
            ("app_title", "App title"), ("app_sub", "App subtitle")]
OPTIONAL = {"notice", "support", "app_sub", "welcome_btn", "app_title"}


def adm_settings(c, mid):
    stored = {r["k"] for r in q("SELECT k FROM settings")}
    rows = []
    keys = [(k, l) for k, l in SET_KEYS if k not in WEL_KEYS]
    for k, label in keys:
        v = S(k)
        if k == "qr":
            shown = "set ✅" if v else "—"
        elif k.startswith("txt_"):
            shown = "custom ✅" if k in stored else "default"
        else:
            shown = esc(v[:28] + ("…" if len(v) > 28 else "")) if v else "—"
        rows.append("├── <b>%s:</b> %s" % (label, shown))
    rows[-1] = rows[-1].replace("├──", "└──", 1)
    kb = []
    for i in range(0, len(keys), 2):
        kb.append([B("✏️ " + l, "set:" + k, style="primary") for k, l in keys[i:i + 2]])
    kb.append([B("🔳 Auto UPI QR: %s" % ("ON" if S("qr_gen") != "0" else "OFF"), "setq", style="success" if S("qr_gen") != "0" else "danger")])
    kb.append([B("🎨 Welcome Studio", "aws", style="success")])
    kb.append([B("🛠 Maintenance: %s" % ("ON" if S("maint") == "1" else "OFF"), "setm", style="danger" if S("maint") == "1" else "success")])
    kb.append(back("adm"))
    txt = (hd("⚙️", "SETTINGS") + "\n<blockquote><b>%s</b></blockquote>\n<b>💳 Payments:</b> %s\n<b>🔳 Auto QR:</b> %s\n<i>Razorpay / UPIGateway / FamPay API keys: Mini App → Admin → Settings → Auto Payment.</i>"
           % ("\n".join(rows), gw_name(), ("generated with amount ✅" if qr_auto() else ("uploaded image" if S("qr") else "off / UPI ID missing"))))
    return show(c, mid, txt, kb)


# ---------------------------------------------------------------- reports / exports
def adm_reports(c, mid):
    g = lambda sql, p=(): q1(sql, p)[0] or 0
    td = today_s() + "%"
    top = q("SELECT u.name, SUM(p.prize) s FROM parts p JOIN users u ON u.id=p.uid WHERE p.prize>0 GROUP BY p.uid ORDER BY s DESC LIMIT 5")
    tops = "\n".join("%s %s · %s" % (MEDALS[i] if i < 3 else "▫️", esc(r["name"][:18]), fm(r["s"])) for i, r in enumerate(top)) or "—"
    txt = (hd("📊", "REPORTS")
           + "\n<blockquote><b>📅 TODAY · %s\n├── 🆕 New users: %d\n├── 🎟 Joins: %d\n├── 💰 Deposits: %s\n├── 📤 Withdraw requests: %s\n└── 🏆 Prizes paid: %s</b></blockquote>"
           "\n<blockquote><b>📈 ALL TIME\n├── 👥 Users: %d (banned %d)\n├── 💼 Wallet total: %s\n├── 📥 Deposits: %s · pending %d\n├── 💸 Withdrawals paid: %s · pending %d\n"
           "├── 🏟 Tournaments: %d up · %d live · %d done · %d cancelled\n├── 🎟 Entry fees: %s\n└── 🏆 Prizes paid: %s</b></blockquote>"
           "\n<blockquote><b>🏅 TOP 5 EARNERS</b>\n%s</blockquote>") % (
        today_s(), g("SELECT COUNT(*) FROM users WHERE joined LIKE ?", (td,)), g("SELECT COUNT(*) FROM parts WHERE joined LIKE ?", (td,)),
        fm(g("SELECT SUM(amount) FROM txns WHERE kind='deposit' AND created LIKE ?", (td,))), fm(g("SELECT SUM(amount) FROM txns WHERE kind='withdraw' AND created LIKE ?", (td,))),
        fm(g("SELECT SUM(amount) FROM txns WHERE kind='prize' AND created LIKE ?", (td,))),
        g("SELECT COUNT(*) FROM users"), g("SELECT COUNT(*) FROM users WHERE banned=1"), fm(g("SELECT SUM(dep+win) FROM users")),
        fm(g("SELECT SUM(amount) FROM deposits WHERE status='approved'")), g("SELECT COUNT(*) FROM deposits WHERE status='pending'"),
        fm(g("SELECT SUM(amount) FROM withdrawals WHERE status='paid'")), g("SELECT COUNT(*) FROM withdrawals WHERE status='pending'"),
        g("SELECT COUNT(*) FROM tournaments WHERE status='upcoming'"), g("SELECT COUNT(*) FROM tournaments WHERE status='live'"),
        g("SELECT COUNT(*) FROM tournaments WHERE status='completed'"), g("SELECT COUNT(*) FROM tournaments WHERE status='cancelled'"),
        fm(g("SELECT SUM(amount) FROM txns WHERE kind='join'")), fm(g("SELECT SUM(amount) FROM txns WHERE kind='prize'")), tops)
    kb = [[B("👥 Users CSV", "aex:u", style="primary"), B("📥 Deposits CSV", "aex:d", style="primary")],
          [B("📤 Withdrawals CSV", "aex:w", style="primary"), B("💾 DB Backup", "abk", style="success")],
          [B("🔄 Refresh", "arp", style="primary")], back("adm")]
    return show(c, mid, txt, kb)


def csv_bytes(header, rows):
    import csv
    import io
    s = io.StringIO()
    w = csv.writer(s)
    w.writerow(header)
    for r in rows:
        w.writerow([("'" + v) if isinstance(v, str) and v[:1] in ("=", "+", "-", "@") else v for v in r])
    return s.getvalue().encode("utf-8-sig")


def send_doc(c, name, data, caption=""):
    try:
        return SESSION.post(API + "/sendDocument", data={"chat_id": c, "caption": caption[:900], "parse_mode": "HTML"}, files={"document": (name, data)}, timeout=120).json()
    except (requests.RequestException, ValueError):
        return {"ok": False}


def export_csv(c, kind):
    stamp = datetime.now(IST).strftime("%Y%m%d-%H%M")
    if kind == "u":
        rows = q("SELECT id,name,username,joined,last_seen,dep,win,played,wins,banned FROM users ORDER BY id")
        data = csv_bytes(["id", "name", "username", "joined", "last_seen", "deposit", "winning", "played", "wins", "banned"], [tuple(r) for r in rows])
        name = "users-%s.csv" % stamp
    elif kind == "d":
        rows = q("SELECT id,uid,amount,utr,status,gw,created FROM deposits ORDER BY id")
        data = csv_bytes(["id", "uid", "amount", "utr", "status", "gateway", "created"], [tuple(r) for r in rows])
        name = "deposits-%s.csv" % stamp
    else:
        rows = q("SELECT id,uid,amount,upi,status,created FROM withdrawals ORDER BY id")
        data = csv_bytes(["id", "uid", "amount", "upi", "status", "created"], [tuple(r) for r in rows])
        name = "withdrawals-%s.csv" % stamp
    r = send_doc(c, name, data, "📄 <b>%s</b> · %d rows" % (name, len(rows)))
    if not r.get("ok"):
        send(c, "❌ Could not send the file: %s" % esc(str(r.get("description", "error"))[:100]))


def backup_db(c):
    tmp = os.path.join(BASE, "backup_tmp.db")
    try:
        with L:
            dst = sqlite3.connect(tmp)
            DB.backup(dst)
            dst.close()
        with open(tmp, "rb") as f:
            data = f.read()
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    if len(data) > 49 * 1024 * 1024:
        return send(c, "❌ Database is bigger than 49 MB - copy tourney.db from the server instead.")
    r = send_doc(c, "tourney-backup-%s.db" % datetime.now(IST).strftime("%Y%m%d-%H%M"), data, "💾 <b>Database backup</b>\nKeep this file private - it holds user data and balances.")
    if not r.get("ok"):
        send(c, "❌ Backup could not be sent: %s" % esc(str(r.get("description", "error"))[:100]))


def broadcast(c, html_text, photo="", kb=None):
    ids = [r["id"] for r in q("SELECT id FROM users WHERE banned=0")]
    ok = fail = 0
    for i in ids:
        if photo:
            p = {"chat_id": i, "photo": photo, "caption": cut(html_text, 1000), "parse_mode": "HTML"}
            m = "sendPhoto"
        else:
            p = {"chat_id": i, "text": cut(html_text), "parse_mode": "HTML", "disable_web_page_preview": True}
            m = "sendMessage"
        if kb:
            p["reply_markup"] = {"inline_keyboard": kb}
        r = call(m, p)
        if bad(r):
            fail += 1
        else:
            ok += 1
        time.sleep(0.05)
    send(c, "<blockquote><b>📢 BROADCAST DONE</b></blockquote>\n✅ Sent: <b>%d</b>\n❌ Failed: <b>%d</b> <i>(blocked the bot)</i>" % (ok, fail), [back("adm")])


# ============================================================ GATE
def gate(c, uid, u):
    if u and u["banned"] and not is_admin(uid):
        send(c, "🚫 <b>You are banned from this bot.</b>")
        return False
    if S("maint") == "1" and not is_admin(uid):
        send(c, "🛠 <b>Bot is under maintenance.</b>\nPlease try again later.")
        return False
    return True


# ============================================================ ROUTER (buttons)
ADMIN_KEYS = {"adm", "ag", "aga", "agd", "agm", "agt", "agr", "at", "atn", "atg", "ato", "atroom", "ats", "atr", "atrc", "atrm", "atrt", "atrs", "aptl", "aptd", "aptn", "atc", "atcc", "atp",
              "ate", "atf", "atd", "atan", "atdel", "atdelc", "ad", "dp", "aw", "wr", "au", "auf", "ul", "uv", "uh", "umsg", "uab", "uad", "ubn",
              "as", "set", "setm", "setq", "ab", "abc", "ast", "arp", "aex", "abk", "aws", "awp", "awx", "awt", "awtp", "awta", "awv", "awd", "awr"}
KEEP_STATE = {"jc", "atrc", "atrs", "abc", "wdc", "dpaid"}


def route(c, mid, uid, d, stt):
    a = d.split(":")
    k = a[0]
    arg = a[1] if len(a) > 1 else ""
    iarg = int(arg) if arg.lstrip("-").isdigit() else 0
    if k in ADMIN_KEYS and not is_admin(uid):
        return send(c, "❌ Admin only.")
    if d == "home":
        return home(c, mid, uid)
    if k == "g":
        return show_games(c, mid)
    if k == "gm":
        return show_game(c, mid, iarg)
    if k == "t":
        return show_tour(c, mid, uid, iarg)
    if k == "tp":
        return show_parts(c, mid, iarg)
    if k == "tr":
        return show_results(c, mid, iarg)
    if k == "jn":
        return join_start(c, mid, uid, iarg)
    if k == "ju":
        t = q1("SELECT gid FROM tournaments WHERE id=?", (iarg,))
        s = q1("SELECT name FROM ign WHERE uid=? AND gid=?", (uid, t["gid"])) if t else None
        return join_confirm(c, mid, uid, iarg, s["name"], [], "") if s else show_tour(c, mid, uid, iarg)
    if k == "jc":
        s, data = stt
        if s != "join_ok" or data.get("tid") != iarg:
            return show(c, mid, "⌛ Session expired. Please try joining again.", [back("t:%d" % iarg)])
        st_clear(uid)
        res, slot = do_join(uid, iarg, data["ign"], data.get("team"), data.get("tname", ""))
        msgs = {"closed": "❌ This tournament is not open any more.", "dup": "✅ You already joined this tournament.",
                "full": "🚫 Sorry, all slots just got filled.", "funds": "❌ Not enough balance.",
                "team": "❌ Team size is wrong. Please join again.", "sameign": "❌ Every player in the team needs a different IGN.",
                "igntaken": "❌ One of these IGNs is already registered in this tournament. Check the names and join again."}
        if res != "ok":
            kb = [back("t:%d" % iarg)]
            if res == "funds":
                kb.insert(0, [B("➕ Add Money", "add", style="success")])
            return show(c, mid, msgs[res], kb)
        tt = q1("SELECT * FROM tournaments WHERE id=?", (iarg,))
        kb = [[B("🏟 Open Tournament", "t:%d" % iarg, style="success")]]
        if tt and share_url(tt):
            kb.append([B("🔗 Invite friends", url=share_url(tt), style="primary")])
        kb.append(back("home", "🏠 Menu"))
        who = " + ".join([data["ign"]] + (data.get("team") or []))
        return show(c, mid, "🎉 <b>Joined successfully!</b>\nSlot <b>#%d</b> · <code>%s</code>%s\nRoom ID &amp; password will be shown in the tournament page and sent here.\n⏰ You will get a reminder 15 minutes before the match." % (
            slot, esc(who), ("\n🛡 Team: <b>%s</b>" % esc(data["tname"])) if data.get("tname") else ""), kb)
    if k == "mm":
        return show_my_matches(c, mid, uid)
    if k == "w":
        return show_wallet(c, mid, uid)
    if k == "wh":
        return show_history(c, mid, uid)
    if k == "add":
        return add_money_start(c, mid, uid)
    if k == "dpaid":
        s, data = stt
        if s != "dep_pay":
            return show(c, mid, "⌛ Session expired. Start Add Money again.", [back("w")])
        st_set(uid, "dep_utr", data)
        return send(c, "<b>Send the UTR / transaction ID now.</b>\nYou can also send the payment <b>screenshot</b> with the UTR in the caption.", [back("w", "❌ Cancel")])
    if k == "wd":
        return wd_start(c, mid, uid)
    if k == "wdc":
        s, data = stt
        if s != "wd_ok":
            return show(c, mid, "⌛ Session expired.", [back("w")])
        st_clear(uid)
        wid = wd_create(uid, data["amt"], data["upi"])
        if wid is None:
            return show(c, mid, "❌ Not enough winning balance.", [back("w")])
        if wid == -1:
            return show(c, mid, "⏳ You already have 2 pending withdrawals. Wait for them to finish.", [back("w")])
        u = q1("SELECT name FROM users WHERE id=?", (uid,))
        notify_admins("<blockquote><b>📤 NEW WITHDRAWAL #%d</b></blockquote>\nUser: %s (<code>%d</code>)\nAmount: <b>%s</b>\nUPI: <code>%s</code>" % (wid, esc(u["name"]), uid, fm(data["amt"]), esc(data["upi"])),
                      [[B("✅ Paid", "wr:p:%d" % wid, style="success"), B("❌ Reject & refund", "wr:r:%d" % wid, style="danger")]])
        return show(c, mid, "✅ <b>Withdrawal requested.</b>\nAmount: <b>%s</b> · UPI: <code>%s</code>\nThe amount is held. You get a message when it is paid." % (fm(data["amt"]), esc(data["upi"])), [back("home", "🏠 Menu")])
    if k == "pf":
        return show_profile(c, mid, uid)
    if k == "lb":
        return show_lb(c, mid)
    if k == "terms":
        return show(c, mid, S("txt_terms"), [back()])
    if k == "help":
        return show(c, mid, "<b>ℹ️ Need help?</b>\nContact the admin of this bot.", [back()])
    # ---------------- admin ----------------
    if k == "adm":
        return adm_home(c, mid)
    if k == "ag":
        return adm_games(c, mid)
    if k == "aga":
        st_set(uid, "g_add")
        return show(c, mid, "<b>Send the game as:</b> <code>emoji name</code>\nExample: <code>🔥 Free Fire</code>", [back("ag", "❌ Cancel")])
    if k == "agd":
        if q1("SELECT 1 FROM tournaments WHERE gid=?", (iarg,)):
            return send(c, "❌ This game has tournaments, it cannot be deleted.", [back("ag")])
        x("DELETE FROM games WHERE id=?", (iarg,))
        return adm_games(c, mid)
    if k == "agm":
        return adm_game(c, mid, iarg)
    if k == "agt":
        x("UPDATE games SET active = 1 - active WHERE id=?", (iarg,))
        return adm_game(c, mid, iarg)
    if k == "agr":
        st_set(uid, "g_ren", {"gid": iarg})
        return show(c, mid, "<b>Send the new name for this game</b> (2-30 characters).", [back("agm:%d" % iarg, "❌ Cancel")])
    if k == "at":
        return adm_tours(c, mid, arg == "h")
    if k == "atn":
        gs = q("SELECT * FROM games WHERE active=1")
        if not gs:
            return show(c, mid, "❌ Add a game first.", [[B("➕ Add Game", "aga", style="success")], back("at")])
        kb = [[B("%s %s" % (g["emoji"], g["name"]), "atg:%d" % g["id"], style="success")] for g in gs]
        kb.append(back("at", "❌ Cancel"))
        return show(c, mid, "<b>Choose the game for the new tournament:</b>", kb)
    if k == "atg":
        st_set(uid, "t_new", {"gid": iarg})
        return show(c, mid, "<b>Send tournament details, one per line:</b>\n<code>Title\nMode (Solo/Duo/Squad)\nEntry fee\nPrize pool\nPer kill\nSlots\nStart time\nMap (optional)</code>\n\nExample:\n<code>Sunday Squad Rush\nSquad\n20\n500\n2\n48\n05-11-2026 20:00\nErangel</code>\n<i>Start time as DD-MM-YYYY HH:MM turns on the countdown in the app.</i>", [back("at", "❌ Cancel")])
    if k == "ato":
        return adm_tour(c, mid, iarg)
    if k == "atp":
        return show_parts(c, mid, iarg, admin=True)
    if k == "ate":
        return adm_edit_menu(c, mid, iarg)
    if k == "atf" and len(a) > 2 and a[2] in dict(EDIT_FIELDS):
        st_set(uid, "t_edit", {"tid": iarg, "field": a[2]})
        t = q1("SELECT * FROM tournaments WHERE id=?", (iarg,))
        cur = {"title": t["title"], "mode": t["mode"], "fee": t["fee"], "pool": t["pool"], "pk": t["per_kill"], "slots": t["slots"], "start": t["start"], "map": t["map"]}[a[2]] if t else ""
        return show(c, mid, "<b>Send the new %s.</b>\nCurrent: <code>%s</code>" % (dict(EDIT_FIELDS)[a[2]].lower(), esc(cur)), [back("ate:%d" % iarg, "❌ Cancel")])
    if k == "atd":
        t = q1("SELECT * FROM tournaments WHERE id=?", (iarg,))
        if not t:
            return adm_tours(c, mid)
        nid = x("INSERT INTO tournaments(gid,title,mode,fee,pool,per_kill,slots,start,start_ts,map,banner,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (t["gid"], t["title"], t["mode"], t["fee"], t["pool"], t["per_kill"], t["slots"], t["start"], t["start_ts"], t["map"], t["banner"], now_s()))
        send(c, "✅ <b>Duplicated as #%d.</b> Edit the start time and announce it." % nid, [[B("✏️ Edit", "ate:%d" % nid, style="primary"), B("🏟 Manage", "ato:%d" % nid, style="success")]])
        return
    if k == "atan":
        if len(a) < 3:
            n = q1("SELECT COUNT(*) c FROM users WHERE banned=0")["c"]
            return show(c, mid, "<b>📣 Announce this tournament to %d users?</b>" % n, [[B("✅ Send now", "atan:%d:y" % iarg, style="success"), B("❌ No", "ato:%d" % iarg, style="danger")]])
        threading.Thread(target=announce_tour, args=(c, iarg), daemon=True).start()
        return show(c, mid, "📣 <b>Announcement is being sent…</b>", [back("ato:%d" % iarg)])
    if k == "atdel":
        return show(c, mid, "<b>⚠️ Delete tournament #%d permanently?</b>" % iarg, [[B("🗑 Yes, delete", "atdelc:%d" % iarg, style="danger"), B("No", "ato:%d" % iarg, style="primary")]])
    if k == "atdelc":
        t = q1("SELECT status FROM tournaments WHERE id=?", (iarg,))
        if not t or (t["status"] != "cancelled" and filled(iarg)):
            return show(c, mid, "❌ Only empty or cancelled tournaments can be deleted.", [back("at")])
        with L:
            DB.execute("DELETE FROM parts WHERE tid=?", (iarg,))
            DB.execute("DELETE FROM tournaments WHERE id=?", (iarg,))
            DB.commit()
        return adm_tours(c, mid)
    if k == "atroom":
        st_set(uid, "room", {"tid": iarg})
        return show(c, mid, "<b>Send Room ID and Password:</b> <code>RoomID | Password</code>\nPlayers who joined get it instantly.", [back("ato:%d" % iarg, "❌ Cancel")])
    if k == "ats":
        if len(a) > 2 and a[2] == "live":
            x("UPDATE tournaments SET status='live' WHERE id=? AND status='upcoming'", (iarg,))
            for p in q("SELECT uid FROM parts WHERE tid=?", (iarg,)):
                send(p["uid"], "🔴 <b>Your match is LIVE now!</b> Open the tournament for details.", [[B("🏟 Open", "t:%d" % iarg, style="success")]])
        return adm_tour(c, mid, iarg)
    if k == "atr":
        t = q1("SELECT * FROM tournaments WHERE id=?", (iarg,))
        if not t or t["status"] in ("completed", "cancelled"):
            return adm_tour(c, mid, iarg)
        tp = prize_tpls()
        kb = [[B("📊 %s" % x_["name"], "atrt:%d:%d" % (iarg, i), style="success")] for i, x_ in enumerate(tp)]
        kb.append([B("✍️ Manual prize entry", "atrm:%d" % iarg, style="primary")])
        kb.append([B("🧩 Edit templates", "aptl:%d" % iarg, style="primary")])
        kb.append(back("ato:%d" % iarg))
        return show(c, mid, hd("🏁", "ENTER RESULTS", "Pick an auto prize split or enter prizes by hand")
                    + "\n<blockquote><b>Prize pool: %s\nPer kill: %s\nPlayers: %d</b></blockquote>\n<i>Auto split: choose a template, then send only the winners' slot numbers (and kills). Prizes are calculated from the pool.</i>" % (fm(t["pool"]), fm(t["per_kill"]), filled(iarg)), kb)
    if k == "atrm":
        t = q1("SELECT * FROM tournaments WHERE id=?", (iarg,))
        if not t or t["status"] in ("completed", "cancelled"):
            return adm_tour(c, mid, iarg)
        st_set(uid, "res", {"tid": iarg})
        return show(c, mid, ("<b>🏁 Send results, one winner per line, 1st place first:</b>\n<code>slot prize kills</code>\n\nExample:\n<code>7 300 5\n12 150 3\n3 0 4</code>\n"
                             "Prize + kills × %s per kill is credited. Slot numbers are in Participants. Players not listed get nothing.") % fm(t["per_kill"]), [back("atr:%d" % iarg, "❌ Cancel")])
    if k == "atrt" and len(a) > 2:
        t = q1("SELECT * FROM tournaments WHERE id=?", (iarg,))
        tp = prize_tpls()
        if not t or t["status"] in ("completed", "cancelled") or not a[2].isdigit() or int(a[2]) >= len(tp):
            return adm_tour(c, mid, iarg)
        ti = tp[int(a[2])]
        amts = split_prizes(t["pool"], ti["pcts"])
        st_set(uid, "res_auto", {"tid": iarg, "idx": int(a[2])})
        lines = ["%s <b>%s</b> (%g%%)" % (MEDALS[i] if i < 3 else "#%d" % (i + 1), fm(amt), ti["pcts"][i]) for i, amt in enumerate(amts)]
        return show(c, mid, hd("📊", ti["name"].upper(), "Pool %s" % fm(t["pool"])) + "\n" + "\n".join(lines)
                    + "\n\n<b>Send the winners now, 1st place first, one per line:</b>\n<code>slot kills</code>\nExample:\n<code>7 5\n12 3\n3 4</code>\n<i>Send up to %d line(s). Kills are optional (per-kill money is added on top).</i>" % len(amts),
                    [back("atr:%d" % iarg, "❌ Cancel")])
    if k == "atrs":
        s_, data = stt
        if s_ != "res_ok" or data.get("tid") != iarg:
            return show(c, mid, "⌛ Session expired.", [back("ato:%d" % iarg)])
        st_set(uid, "res_shot", data)
        return show(c, mid, "<b>📸 Send the result screenshot now</b> (as a normal photo).\nIt is sent to every joined player with the result and shown on the tournament page.", [back("ato:%d" % iarg, "❌ Cancel")])
    if k == "aptl":
        tp = prize_tpls()
        kb = [[B("🗑 %s" % x_["name"], "aptd:%d:%d" % (iarg, i), style="danger")] for i, x_ in enumerate(tp)]
        kb.append([B("➕ Add template", "aptn:%d" % iarg, style="success")])
        kb.append(back("atr:%d" % iarg))
        return show(c, mid, hd("🧩", "PRIZE TEMPLATES", "Tap one to delete it") + "\n<blockquote><b>%s</b></blockquote>" % "\n".join("%s → %s" % (esc(x_["name"]), tpl_text(x_)) for x_ in tp), kb)
    if k == "aptd" and len(a) > 2:
        tp = prize_tpls()
        if a[2].isdigit() and int(a[2]) < len(tp) and len(tp) > 1:
            tp.pop(int(a[2]))
            set_S("prize_tpls", json.dumps(tp))
        return route(c, mid, uid, "aptl:%d" % iarg, stt)
    if k == "aptn":
        st_set(uid, "tpl_new", {"tid": iarg})
        return show(c, mid, "<b>➕ New prize template</b>\nSend like:\n<code>Top 4 | 40,30,20,10</code>\nPercentages of the prize pool, 1st place first (total max 100).", [back("aptl:%d" % iarg, "❌ Cancel")])
    if k == "atrc":
        s, data = stt
        if s != "res_ok" or data.get("tid") != iarg:
            return show(c, mid, "⌛ Session expired.", [back("ato:%d" % iarg)])
        st_clear(uid)
        out = apply_results(iarg, [tuple(r) for r in data["rows"]])
        if out is None:
            return show(c, mid, "❌ Results already done or tournament cancelled.", [back("ato:%d" % iarg)])
        t = q1("SELECT title FROM tournaments WHERE id=?", (iarg,))
        for puid, ign, rank, kills, total, is_team in out:
            send(puid, "🏆 <b>Result · %s</b>\nRank <b>#%d</b> · Kills <b>%d</b>\n%s" % (esc(t["title"]), rank, kills, (("💰 <b>%s</b> added to your Winning balance!" % fm(total)) + ("\n<i>Team prize goes to the captain - share it with your teammates.</i>" if is_team else "")) if total else "Thanks for playing!"))
        for p in q("SELECT uid FROM parts WHERE tid=? AND rank=0", (iarg,)):
            send(p["uid"], "🏁 <b>Result is out for %s.</b> Check the tournament page." % esc(t["title"]))
        if data.get("shot"):
            finish_result_media(iarg, data["shot"])
        return show(c, mid, "✅ <b>Results saved.</b> %d winner(s) paid, tournament completed." % len(out), [back("at")])
    if k == "atc":
        return show(c, mid, "<b>⚠️ Cancel this tournament and refund every player's entry fee?</b>", [[B("✅ Yes, cancel & refund", "atcc:%d" % iarg, style="danger"), B("No", "ato:%d" % iarg, style="primary")]])
    if k == "atcc":
        r = cancel_tour(iarg)
        if r is None:
            return show(c, mid, "❌ Already completed or cancelled.", [back("at")])
        uids, t = r
        for u2 in uids:
            send(u2, "❌ <b>%s was cancelled.</b>%s" % (esc(t["title"]), ("\n💰 %s refunded to your Deposit balance." % fm(t["fee"])) if t["fee"] else ""))
        return show(c, mid, "✅ Cancelled. %d player(s) refunded." % len(uids), [back("at")])
    if k == "ad":
        return adm_deposits(c, mid)
    if k == "dp" and len(a) > 2:
        dep = dep_decide(int(a[2]), a[1] == "a")
        if not dep:
            return send(c, "ℹ️ Deposit #%s already handled." % a[2])
        if a[1] == "a":
            send(dep["uid"], "✅ <b>%s added to your wallet.</b> Good luck!" % fm(dep["amount"]), [[B("🎮 Play Now", "g", style="success")]])
        else:
            send(dep["uid"], "❌ <b>Your deposit of %s (UTR %s) was rejected.</b> Contact support if this is a mistake." % (fm(dep["amount"]), esc(dep["utr"])))
        return send(c, "%s Deposit #%s %s." % ("✅" if a[1] == "a" else "❌", a[2], "approved" if a[1] == "a" else "rejected"))
    if k == "aw":
        return adm_withdrawals(c, mid)
    if k == "wr" and len(a) > 2:
        w = wd_decide(int(a[2]), a[1] == "p")
        if not w:
            return send(c, "ℹ️ Withdrawal #%s already handled." % a[2])
        if a[1] == "p":
            send(w["uid"], "✅ <b>%s sent to your UPI</b> <code>%s</code>." % (fm(w["amount"]), esc(w["upi"])))
        else:
            send(w["uid"], "❌ <b>Withdrawal of %s rejected.</b> The amount is back in your Winning balance." % fm(w["amount"]))
        return send(c, "%s Withdrawal #%s %s." % ("✅" if a[1] == "p" else "❌", a[2], "marked paid" if a[1] == "p" else "rejected & refunded"))
    if k == "au":
        return adm_users_menu(c, mid)
    if k == "auf":
        st_set(uid, "u_find")
        return show(c, mid, "<b>Send the user's Telegram ID, @username or name.</b>", [back("au", "❌ Cancel")])
    if k == "ul":
        return adm_ulist(c, mid, arg)
    if k == "uv":
        return adm_user(c, mid, iarg)
    if k == "uh":
        return adm_user_hist(c, mid, iarg)
    if k == "umsg":
        st_set(uid, "u_msg", {"uid": iarg})
        return show(c, mid, "<b>Send the message for this user</b> (HTML allowed). They get it from the bot.", [back("uv:%d" % iarg, "❌ Cancel")])
    if k in ("uab", "uad"):
        st_set(uid, "u_amt", {"uid": iarg, "sign": 1 if k == "uab" else -1})
        return show(c, mid, "<b>Send the amount to %s</b> (Deposit balance)." % ("add" if k == "uab" else "deduct"), [back("uv:%d" % iarg, "❌ Cancel")])
    if k == "ubn":
        x("UPDATE users SET banned = 1 - banned WHERE id=?", (iarg,))
        return adm_user(c, mid, iarg)
    if k == "as":
        return adm_settings(c, mid)
    if k == "set":
        back_cb = "aws" if arg in WEL_KEYS else "as"
        if arg == "qr":
            st_set(uid, "set_qr")
            return show(c, mid, "<b>Send your UPI QR as a photo.</b>", [back("as", "❌ Cancel")])
        if arg not in dict(SET_KEYS):
            return adm_settings(c, mid)
        st_set(uid, "set", {"key": arg})
        label = dict(SET_KEYS)[arg]
        extra = ""
        if arg.startswith("txt_"):
            extra = "\n<i>HTML tags like &lt;b&gt; &lt;i&gt; &lt;blockquote&gt; are allowed.</i>"
            if arg == "txt_welcome":
                extra += "\n<i>Placeholders: {name} {brand} {balance} {live} {players} {id}</i>"
            extra += "\n\n<b>Current (copy &amp; edit):</b>\n<pre>%s</pre>" % esc(cut(S(arg), 1500))
        elif arg in OPTIONAL:
            extra = "\n<i>Send <code>-</code> to clear it.</i>"
        return show(c, mid, "<b>Send the new value for %s.</b>%s" % (label, extra), [back(back_cb, "❌ Cancel")])
    if k == "setq":
        set_S("qr_gen", "0" if S("qr_gen") != "0" else "1")
        return adm_settings(c, mid)
    if k == "setm":
        set_S("maint", "0" if S("maint") == "1" else "1")
        return adm_settings(c, mid)
    # ---------------- welcome studio ----------------
    if k == "aws":
        return adm_welcome(c, mid)
    if k == "awp":
        st_set(uid, "wel_photo")
        return show(c, mid, "<b>🖼 Send the welcome photo now.</b>\n<i>Send it as a normal photo (not a file). It appears on /start and as the app home image.</i>", [back("aws", "❌ Cancel")])
    if k == "awx":
        set_S("welcome_img", "")
        set_S("welcome_img_file", "")
        return adm_welcome(c, mid)
    if k == "awd":
        set_S("dash", "0" if S("dash") != "0" else "1")
        return adm_welcome(c, mid)
    if k == "awr":
        x("DELETE FROM settings WHERE k='txt_welcome'")
        return adm_welcome(c, mid)
    if k == "awt":
        return adm_templates(c, mid)
    if k == "awtp" and arg in PRESETS:
        u = q1("SELECT name FROM users WHERE id=?", (uid,))
        return show(c, mid, render(PRESETS[arg][1], uid, u["name"] if u else "Player") + "\n\n<code>%s</code>\n<i>Preview · %s</i>" % (RULE, esc(PRESETS[arg][0])),
                    [[B("✅ Apply this", "awta:" + arg, style="success"), B("⬅️ Templates", "awt", style="primary")]])
    if k == "awta" and arg in PRESETS:
        set_S("txt_welcome", PRESETS[arg][1])
        return adm_welcome(c, mid)
    if k == "awv":
        u = q1("SELECT name FROM users WHERE id=?", (uid,))
        home(c, None, uid, u["name"] if u else "Player")
        return send(c, "👆 <b>This is exactly what players see on /start.</b>", [[B("🎨 Back to Studio", "aws", style="success")]])
    if k == "ab":
        st_set(uid, "bc")
        return show(c, mid, "<b>📢 Send the broadcast now.</b>\nText (HTML allowed) or a <b>photo with caption</b>. It goes to every user.", [back("adm", "❌ Cancel")])
    if k == "abc":
        s, data = stt
        if s != "bc_ok":
            return show(c, mid, "⌛ Session expired.", [back("adm")])
        st_clear(uid)
        show(c, mid, "📢 Sending…", [])
        threading.Thread(target=broadcast, args=(c, data["html"], data.get("photo", "")), daemon=True).start()
        return
    if k in ("ast", "arp"):
        return adm_reports(c, mid)
    if k == "aex":
        export_csv(c, arg if arg in ("u", "d", "w") else "u")
        return
    if k == "abk":
        backup_db(c)
        return
    return home(c, mid, uid)


# ============================================================ ROUTER (typed messages)
def num(text):
    try:
        v = float(text.strip().lstrip("₹").replace(",", ""))
        return round(v, 2) if v > 0 else None
    except ValueError:
        return None


def state_input(c, uid, s, data, msg):
    text = (msg.get("text") or "").strip()
    cap = (msg.get("caption") or "").strip()
    photo = msg["photo"][-1]["file_id"] if msg.get("photo") else ""
    if s == "ign":
        step = data.get("step", "me")
        tid = data["tid"]
        if step == "tname":
            if not text or len(text) > 20:
                return send(c, "❌ Team name must be 1-20 characters (or send <code>-</code> to skip).")
            return join_confirm(c, None, uid, tid, data["ign"], data.get("team") or [], text)
        if not text or len(text) > 40:
            return send(c, "❌ Send the in-game name (max 40 characters).")
        if step == "mate":
            team = list(data.get("team") or [])
            if text.lower() in {n.lower() for n in [data["ign"]] + team}:
                return send(c, "❌ This IGN is already in your team. Send a different teammate IGN.")
            if ign_taken(tid, [text], uid):
                return send(c, "❌ This IGN is already registered in this tournament. Send the correct IGN.")
            return join_confirm(c, None, uid, tid, data["ign"], team + [text], "")
        if ign_taken(tid, [text], uid):
            return send(c, "❌ This IGN is already registered in this tournament. Send your own IGN.")
        return join_confirm(c, None, uid, tid, text, [], "")
    if s == "dep_amt":
        v = num(text)
        mn = fnum("min_dep", 10)
        if v is None or v < mn or v > 100000:
            return send(c, "❌ Send a valid amount (minimum %s)." % fm(mn))
        return dep_pay_info(c, uid, v)
    if s == "dep_utr":
        return dep_submit(c, uid, data["amt"], text or cap, photo)
    if s == "wd_amt":
        v = num(text)
        d, w = balances(uid)
        mn = fnum("min_wd", 50)
        if v is None or v < mn or v > w:
            return send(c, "❌ Send an amount between %s and your winning balance %s." % (fm(mn), fm(w)))
        st_set(uid, "wd_upi", {"amt": v})
        return send(c, "<b>Now send your UPI ID</b> (example <code>name@upi</code>).", [back("w", "❌ Cancel")])
    if s == "wd_upi":
        if not UPI_RE.match(text):
            return send(c, "❌ Invalid UPI ID. Example: <code>name@okaxis</code>")
        st_set(uid, "wd_ok", {"amt": data["amt"], "upi": text})
        return send(c, "<blockquote><b>🧾 CONFIRM WITHDRAWAL</b></blockquote>\nAmount: <b>%s</b>\nUPI: <code>%s</code>" % (fm(data["amt"]), esc(text)),
                    [[B("✅ Confirm", "wdc", style="success"), B("❌ Cancel", "w", style="danger")]])
    if not is_admin(uid) or s in ("join_ok", "dep_pay", "wd_ok", "res_ok", "bc_ok"):
        st_clear(uid)
        return home(c, None, uid)
    if s == "wel_photo":
        if not photo:
            return send(c, "❌ Send a photo (not a file).", [back("aws", "❌ Cancel")])
        set_S("welcome_img", photo)
        set_S("welcome_img_file", save_tg_photo(photo, "welcome_%d.jpg" % int(time.time())))
        st_clear(uid)
        return send(c, "✅ <b>Welcome photo saved.</b>", [[B("👁 Preview", "awv", style="success"), B("🎨 Studio", "aws", style="primary")]])
    if s == "g_ren":
        if not 2 <= len(text) <= 30:
            return send(c, "❌ Name must be 2-30 characters.")
        x("UPDATE games SET name=? WHERE id=?", (text, data["gid"]))
        st_clear(uid)
        return send(c, "✅ Renamed.", [[B("🎮 Game", "agm:%d" % data["gid"], style="primary")]])
    if s == "t_edit":
        tid, f = data["tid"], data["field"]
        t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
        if not t or t["status"] not in ("upcoming", "live"):
            st_clear(uid)
            return send(c, "❌ This tournament can no longer be edited.", [back("at")])
        if f in ("title", "mode", "map", "start"):
            if not text or len(text) > 40:
                return send(c, "❌ Send 1-40 characters.")
            if f == "start":
                x("UPDATE tournaments SET start=?, start_ts=?, remind_sent=0 WHERE id=?", (text, parse_start(text), tid))
            else:
                x("UPDATE tournaments SET %s=? WHERE id=?" % f, (text, tid))
        else:
            try:
                v = float(text.replace("₹", "").replace(",", ""))
            except ValueError:
                v = -1
            if v < 0:
                return send(c, "❌ Send a valid number.")
            col = {"fee": "fee", "pool": "pool", "pk": "per_kill", "slots": "slots"}[f]
            if f == "slots":
                v = int(v)
                if v < max(2, filled(tid)) or v > 1000:
                    return send(c, "❌ Slots must be between %d and 1000." % max(2, filled(tid)))
            if f == "fee" and filled(tid):
                st_clear(uid)
                return send(c, "❌ Entry fee cannot change after players joined.", [back("ate:%d" % tid)])
            x("UPDATE tournaments SET %s=? WHERE id=?" % col, (v, tid))
        st_clear(uid)
        return send(c, "✅ <b>Updated.</b>", [[B("✏️ Edit more", "ate:%d" % tid, style="primary"), B("🏟 Manage", "ato:%d" % tid, style="success")]])
    if s == "u_msg":
        if not text:
            return send(c, "❌ Send some text.")
        r = send(data["uid"], hd("📩", "MESSAGE FROM ADMIN") + "\n" + cut(text, 3500))
        st_clear(uid)
        return send(c, "✅ Message sent." if r and not bad(r) else "❌ Could not deliver (user blocked the bot?).", [back("uv:%d" % data["uid"])])
    if s == "g_add":
        parts = text.split(None, 1)
        if len(parts) < 2 or len(parts[1]) > 30:
            return send(c, "❌ Send like: <code>🔥 Free Fire</code>")
        x("INSERT INTO games(name,emoji) VALUES(?,?)", (parts[1].strip(), parts[0]))
        st_clear(uid)
        return send(c, "✅ Game added.", [[B("🎮 Games", "ag", style="primary")], back("adm")])
    if s == "t_new":
        v, err = parse_new_tour(text)
        if not v:
            return send(c, "❌ " + esc(err))
        tid = x("INSERT INTO tournaments(gid,title,mode,fee,pool,per_kill,slots,start,start_ts,map,created) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (data["gid"], v["title"], v["mode"], v["fee"], v["pool"], v["pk"], v["slots"], v["start"], v["ts"], v["map"], now_s()))
        st_clear(uid)
        return send(c, "✅ <b>Tournament #%d created.</b> Players can join now." % tid,
                    [[B("📣 Announce to all", "atan:%d" % tid, style="success"), B("🏟 Manage", "ato:%d" % tid, style="primary")], back("at")])
    if s == "room":
        rid, _, rpw = text.partition("|")
        if not rid.strip():
            return send(c, "❌ Send like: <code>RoomID | Password</code>")
        x("UPDATE tournaments SET room_id=?, room_pass=? WHERE id=?", (rid.strip()[:40], rpw.strip()[:40], data["tid"]))
        st_clear(uid)
        t = q1("SELECT title FROM tournaments WHERE id=?", (data["tid"],))
        n = 0
        for p in q("SELECT uid FROM parts WHERE tid=?", (data["tid"],)):
            send(p["uid"], "<blockquote><b>🔑 ROOM DETAILS · %s</b></blockquote>\nRoom ID: <code>%s</code>\nPassword: <code>%s</code>" % (esc(t["title"]), esc(rid.strip()), esc(rpw.strip())),
                 [[B("🏟 Open Tournament", "t:%d" % data["tid"], style="success")]])
            n += 1
        return send(c, "✅ Room saved and sent to %d player(s)." % n, [back("ato:%d" % data["tid"])])
    if s == "res":
        t = q1("SELECT * FROM tournaments WHERE id=?", (data["tid"],))
        rows, err = parse_results(text, t)
        if not rows:
            return send(c, "❌ " + err)
        return res_confirm(c, uid, t, rows, "")
    if s == "res_auto":
        t = q1("SELECT * FROM tournaments WHERE id=?", (data["tid"],))
        tp = prize_tpls()
        if not t or data["idx"] >= len(tp):
            st_clear(uid)
            return send(c, "❌ Template not found.", [back("at")])
        amts = split_prizes(t["pool"], tp[data["idx"]]["pcts"])
        rows, seen = [], set()
        for raw in text.strip().splitlines():
            if not raw.strip():
                continue
            pr = [w for w in re.split(r"[\s,|]+", raw.strip()) if w]
            try:
                slot = int(pr[0].lstrip("#"))
                kills = int(pr[1]) if len(pr) > 1 else 0
            except (ValueError, IndexError):
                return send(c, "❌ Wrong line: <code>%s</code>\nUse: <code>slot kills</code>" % esc(raw[:60]))
            if slot in seen or kills < 0 or not q1("SELECT 1 FROM parts WHERE tid=? AND slot=?", (t["id"], slot)):
                return send(c, "❌ Bad or repeated slot #%d (slot must exist, no duplicates)." % slot)
            seen.add(slot)
            rows.append(slot)
            if len(rows) > len(amts):
                return send(c, "❌ This template pays only %d winner(s)." % len(amts))
            rows[-1] = (slot, amts[len(rows) - 1], kills)
        if not rows:
            return send(c, "❌ Send at least one line.")
        return res_confirm(c, uid, t, rows, "")
    if s == "res_shot":
        if not photo:
            return send(c, "❌ Send a photo (not a file).", [back("ato:%d" % data["tid"], "❌ Cancel")])
        t = q1("SELECT * FROM tournaments WHERE id=?", (data["tid"],))
        if not t:
            st_clear(uid)
            return send(c, "❌ Tournament not found.", [back("at")])
        return res_confirm(c, uid, t, [tuple(r) for r in data["rows"]], photo)
    if s == "tpl_new":
        name, _, pc = text.partition("|")
        try:
            pcts = [float(v) for v in re.split(r"[\s,/]+", pc.strip().replace("%", "")) if v]
        except ValueError:
            pcts = []
        if not name.strip() or not pcts or min(pcts) <= 0 or sum(pcts) > 100.01 or len(pcts) > 20:
            return send(c, "❌ Send like <code>Top 4 | 40,30,20,10</code> (percentages, total max 100).")
        tp = prize_tpls()
        tp.append({"name": name.strip()[:30], "pcts": pcts})
        set_S("prize_tpls", json.dumps(tp[:12]))
        st_clear(uid)
        return send(c, "✅ Template saved.", [[B("🧩 Templates", "aptl:%d" % data["tid"], style="primary")], back("atr:%d" % data["tid"], "🏁 Results")])
    if s == "u_find":
        if not text:
            return send(c, "❌ Send an ID, @username or name.")
        st_clear(uid)
        if text.isdigit():
            return adm_user(c, None, int(text))
        key = "%" + text.lstrip("@").replace("%", "").replace("_", "") + "%"
        rows = q("SELECT * FROM users WHERE username LIKE ? OR name LIKE ? ORDER BY last_seen DESC LIMIT 10", (key, key))
        if not rows:
            return send(c, "❌ No user found.", [back("au")])
        return send(c, hd("🔍", "SEARCH RESULTS"), user_buttons(rows))
    if s == "u_amt":
        v = num(text)
        if v is None:
            return send(c, "❌ Send a valid amount.")
        with L:
            u = DB.execute("SELECT dep FROM users WHERE id=?", (data["uid"],)).fetchone()
            if not u:
                return send(c, "❌ User not found.")
            new = round(max(0.0, u["dep"] + data["sign"] * v), 2)
            DB.execute("UPDATE users SET dep=? WHERE id=?", (new, data["uid"]))
            txn(data["uid"], "adjust", abs(new - u["dep"]), "admin %s" % ("credit" if data["sign"] > 0 else "debit"))
            DB.commit()
        st_clear(uid)
        send(data["uid"], "ℹ️ Your wallet was %s by admin: <b>%s</b>." % ("credited" if data["sign"] > 0 else "debited", fm(v)))
        return adm_user(c, None, data["uid"])
    if s == "set":
        key = data.get("key")
        back_cb = "aws" if key in WEL_KEYS else "as"
        if key in OPTIONAL and text == "-":
            text = ""
        elif key in ("min_dep", "min_wd"):
            v = num(text)
            if v is None:
                return send(c, "❌ Send a number.")
            text = str(v)
        elif key == "support":
            text = text.lstrip("@")
            if not re.match(r"^[A-Za-z0-9_]{4,32}$", text):
                return send(c, "❌ Send a Telegram username (or <code>-</code> to clear).")
        elif key == "upi" and not UPI_RE.match(text):
            return send(c, "❌ Invalid UPI ID.")
        elif not text or len(text) > 3500:
            return send(c, "❌ Send some text (max 3500 characters).")
        set_S(key, text)
        st_clear(uid)
        if key == "txt_welcome":
            home(c, None, uid)
            return send(c, "✅ <b>Welcome text saved</b> - preview above.", [[B("🎨 Welcome Studio", "aws", style="success")]])
        if key == "welcome_btn":
            set_menu_button((S("webapp_url") or RT["url"]).rstrip("/"))
        return send(c, "✅ <b>Saved.</b>", [[B("🎨 Studio" if back_cb == "aws" else "⚙️ Settings", back_cb, style="primary")]])
    if s == "set_qr":
        if not photo:
            return send(c, "❌ Send a photo.")
        set_S("qr", photo)
        st_clear(uid)
        return send(c, "✅ QR saved.", [[B("⚙️ Settings", "as", style="primary")]])
    if s == "bc":
        body = text or cap
        if not body and not photo:
            return send(c, "❌ Send text or a photo.")
        st_set(uid, "bc_ok", {"html": body, "photo": photo})
        n = q1("SELECT COUNT(*) c FROM users WHERE banned=0")["c"]
        kb = [[B("✅ Send to %d users" % n, "abc", style="success"), B("❌ Cancel", "adm", style="danger")]]
        if photo:
            return send_photo(c, photo, "<b>Preview:</b>\n\n%s\n\nSend to <b>%d</b> users?" % (cut(body, 800), n), kb)
        return send(c, "<b>Preview:</b>\n\n%s\n\nSend to <b>%d</b> users?" % (cut(body, 3000), n), kb)


def handle_update(upd):
    if "callback_query" in upd:
        cq = upd["callback_query"]
        fr = cq["from"]
        uid = fr["id"]
        msg = cq.get("message") or {}
        c = (msg.get("chat") or {}).get("id", uid)
        mid = msg.get("message_id")
        d = cq.get("data", "")
        u = ensure_user(fr)
        if not gate(c, uid, u):
            return ack(cq["id"])
        ack(cq["id"])
        stt = st_get(uid)
        if d.split(":")[0] not in KEEP_STATE:
            st_clear(uid)
        return route(c, mid, uid, d, stt)
    msg = upd.get("message")
    if not msg or (msg.get("chat") or {}).get("type") != "private" or "from" not in msg:
        return
    fr = msg["from"]
    uid = fr["id"]
    c = msg["chat"]["id"]
    text = (msg.get("text") or "").strip()
    u = ensure_user(fr)
    if not gate(c, uid, u):
        return
    if text.startswith("/"):
        cmd = text.split()[0].split("@")[0].lower()
        st_clear(uid)
        if cmd in ("/start", "/menu"):
            pl = text.split(None, 1)[1].strip() if cmd == "/start" and len(text.split(None, 1)) > 1 else ""
            m_ = re.match(r"^t_(\d{1,9})$", pl)
            if m_:
                if q1("SELECT 1 FROM tournaments WHERE id=?", (int(m_.group(1)),)):
                    return show_tour(c, None, uid, int(m_.group(1)))
                send(c, "❌ This tournament link is not valid any more.")
            return home(c, None, uid, u["name"])
        if cmd == "/admin":
            return adm_home(c, None) if is_admin(uid) else send(c, "❌ Admin only.")
        if cmd in ("/wallet", "/w"):
            return show_wallet(c, None, uid)
        if cmd in ("/matches", "/mymatches"):
            return show_my_matches(c, None, uid)
        if cmd in ("/tournaments", "/games", "/play"):
            return show_games(c, None)
        if cmd == "/profile":
            return show_profile(c, None, uid)
        if cmd in ("/top", "/leaderboard"):
            return show_lb(c, None)
        if cmd == "/stats" and is_admin(uid):
            return adm_reports(c, None)
        if cmd == "/cancel":
            return send(c, "✅ Cancelled.", [back("home", "🏠 Menu")])
        if cmd == "/help":
            return send(c, "<b>ℹ️ How it works</b>\n1. Add money to your wallet\n2. Pick a game and join a tournament\n3. Get Room ID &amp; password here\n4. Win, then withdraw to UPI", [back("home", "🏠 Menu")])
        return home(c, None, uid, u["name"])
    s, data = st_get(uid)
    if s:
        return state_input(c, uid, s, data, msg)
    return home(c, None, uid, u["name"])


def safe_handle(group):
    for upd in group:
        try:
            handle_update(upd)
        except Exception as e:
            log("handler error: %r" % (e,))


def set_menu_button(url):
    if url:
        tg("setChatMenuButton", {"menu_button": {"type": "web_app", "text": "🏆 PLAY", "web_app": {"url": url + "/"}}})


def on_tunnel_url(url):
    RT["url"] = url.rstrip("/")
    log("Mini App URL: %s" % RT["url"])
    if not S("webapp_url"):
        set_menu_button(RT["url"])
    notify_admins("<blockquote><b>🚀 MINI APP ONLINE</b></blockquote>\n<code>%s</code>" % esc(RT["url"]),
                  [[B("🚀 Open App", web=RT["url"] + "/", style="success")]])


def start_web_stack(me):
    """Mini App web server + Cloudflare tunnel + auto-payment checker."""
    try:
        import webapp
        import tunnel
    except Exception as e:  # keep the classic bot alive even if web part is broken
        log("web app disabled: %r" % (e,))
        return
    me_mod = sys.modules[__name__]
    port = webapp.start(me_mod, WEB_PORT)
    log("web app listening on 127.0.0.1:%d" % port)
    if S("webapp_url"):
        set_menu_button(S("webapp_url").rstrip("/"))
    if os.getenv("DISABLE_TUNNEL", "") != "1":
        tunnel.start(BASE, port, on_tunnel_url, log)
    elif RT["url"]:
        set_menu_button(RT["url"])


def main():
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN missing")
    if not ADMINS:
        log("WARNING: ADMIN_IDS is empty - nobody can open /admin")
    me = tg("getMe")
    if bad(me):
        raise SystemExit("Invalid BOT_TOKEN: %s" % me["_err"])
    tg("deleteWebhook", {"drop_pending_updates": True})
    RT["bot"] = me.get("username", "")
    start_web_stack(me)
    threading.Thread(target=reminder_loop, daemon=True).start()
    user_cmds = [{"command": "start", "description": "Open the main menu"}, {"command": "tournaments", "description": "Browse tournaments"},
                 {"command": "wallet", "description": "Your wallet"}, {"command": "matches", "description": "Your matches"},
                 {"command": "top", "description": "Leaderboard"}, {"command": "profile", "description": "Your profile"},
                 {"command": "help", "description": "How it works"}, {"command": "cancel", "description": "Cancel current action"}]
    tg("setMyCommands", {"commands": user_cmds})
    for a in ADMINS:
        tg("setMyCommands", {"commands": user_cmds + [{"command": "admin", "description": "Admin console"}, {"command": "stats", "description": "Reports"}],
                             "scope": {"type": "chat", "chat_id": a}})
    tg("setMyShortDescription", {"short_description": ("%s · join tournaments, win real prizes" % S("brand"))[:120]})
    tg("setMyDescription", {"description": "Join paid & free esports tournaments, get Room ID & password instantly, win prizes in your wallet and withdraw to UPI."})
    log("%s started: @%s admins=%s" % (S("brand"), me.get("username", ""), ADMINS))
    pool = ThreadPoolExecutor(max_workers=16)
    offset = 0
    while True:
        try:
            r = SESSION.post(API + "/getUpdates", json={"offset": offset, "timeout": 50, "allowed_updates": ["message", "callback_query"]}, timeout=65)
            j = r.json()
        except (requests.RequestException, ValueError):
            time.sleep(3)
            continue
        if not j.get("ok"):
            log("getUpdates: %s" % str(j)[:200])
            time.sleep(5)
            continue
        groups = {}
        for upd in j.get("result", []):
            offset = max(offset, upd["update_id"] + 1)
            uid = (upd.get("callback_query") or upd.get("message") or {}).get("from", {}).get("id", 0)
            groups.setdefault(uid, []).append(upd)
        for g in groups.values():
            pool.submit(safe_handle, g)


if __name__ == "__main__":
    main()
