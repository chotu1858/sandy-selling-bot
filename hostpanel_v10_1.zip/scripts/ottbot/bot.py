#!/usr/bin/env python3
"""OTT BOT - small SAMPLE script for the multi-script panel (v9).

Shows how a hosted script receives its settings from the panel (environment of the bot folder):
  BOT_TOKEN, ADMIN_IDS, STORE_NAME, SUPPORT_USERNAME, DB_NAME, THEME_FILE (path to the chosen theme json)
It keeps its users in a SQLite file (DB_NAME) so the panel can count them.
Edit the PLANS list below, or replace this whole file with your own bot.
"""
import os
import json
import sqlite3
import html
import logging

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes

BASE = os.path.dirname(os.path.abspath(__file__))


def load_env(path):
    try:
        for line in open(path, encoding="utf-8").read().splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
    except OSError:
        pass


load_env(os.path.join(BASE, ".env"))
TOKEN = os.getenv("BOT_TOKEN", "")
ADMINS = {int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
STORE = os.getenv("STORE_NAME", "OTT Store")
SUPPORT = os.getenv("SUPPORT_USERNAME", "@support")
DB = os.path.join(BASE, os.getenv("DB_NAME", "store.db"))

PLANS = [("Basic - 1 month", 99), ("Standard - 3 months", 249), ("Premium - 12 months", 799)]

try:
    THEME = json.load(open(os.getenv("THEME_FILE", ""), encoding="utf-8"))
except Exception:
    THEME = {}
T = lambda k, d: THEME.get(k) if isinstance(THEME.get(k), str) and THEME.get(k) else d

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


def db():
    con = sqlite3.connect(DB)
    con.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT, joined TEXT DEFAULT CURRENT_TIMESTAMP)")
    con.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
    return con


def menu():
    return InlineKeyboardMarkup([[InlineKeyboardButton(T("button_plans", "📺 Plans"), callback_data="plans"),
                                  InlineKeyboardButton(T("button_support", "💬 Support"), callback_data="support")]])


async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    con = db()
    con.execute("INSERT OR IGNORE INTO users (id, name) VALUES (?, ?)", (u.id, u.full_name))
    con.commit()
    con.close()
    text = T("welcome", "🎬 <b>{store}</b>").replace("{store}", html.escape(STORE))
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=menu())


async def buttons(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.data == "plans":
        lines = "\n".join(f"• {html.escape(n)}: <b>₹{p}</b>" for n, p in PLANS)
        await q.message.reply_text(f"{T('plans_title', '📺 <b>Our plans</b>')}\n\n{lines}\n\nTo buy, message {html.escape(SUPPORT)}",
                                   parse_mode="HTML")
    elif q.data == "support":
        await q.message.reply_text(f"Support: {SUPPORT}")


async def stats(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMINS:
        return
    con = db()
    n = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    con.close()
    await update.message.reply_text(f"Users: {n}")


def main():
    if not TOKEN:
        raise SystemExit("BOT_TOKEN missing")
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(CallbackQueryHandler(buttons))
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
