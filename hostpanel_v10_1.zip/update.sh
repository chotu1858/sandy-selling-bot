#!/usr/bin/env bash
# Run after copying new files:  bash update.sh
# Restarts the panel, then reloads every hosted bot with the new scripts.
# Every script in scripts/<name>/ gets its OWN virtual environment (venvs/<name>) built from its requirements.txt,
# only when that file changed. Your data, keys, bots and panel.env are kept.
cd "$(dirname "$0")" || exit 1
[ -d venv ] || { echo "venv missing - run: bash install.sh"; exit 1; }
[ -f scripts/storebot/bot.py ] || [ -f storebot_template.py ] || { echo "scripts/storebot/bot.py missing - unzip the whole hostpanel zip first"; exit 1; }
./venv/bin/pip install -q flask "python-telegram-bot[job-queue]" requests qrcode pillow
mkdir -p data scripts venvs && touch data/restart_all.flag
if [ "$(id -u)" = "0" ] && command -v systemctl >/dev/null 2>&1 && [ -f /etc/systemd/system/bothost.service ]; then
  systemctl restart bothost
else
  pkill -f "venv/bin/python app.py" 2>/dev/null || true
  sleep 1
  nohup ./venv/bin/python app.py > panel.log 2>&1 &
fi
sleep 4
tail -n 5 panel.log 2>/dev/null
echo
echo "Installing script libraries (first time can take 1-2 minutes)..."
for i in $(seq 1 90); do
  sleep 2
  if [ -f data/scripts_state.json ] && ! grep -q '"installing"' data/scripts_state.json; then break; fi
done
./venv/bin/python - <<'PY'
import json, os
try:
    st = json.load(open("data/scripts_state.json"))
except Exception:
    st = {}
for sid in sorted(d for d in os.listdir("scripts") if os.path.isfile(f"scripts/{d}/bot.py")):
    x = st.get(sid, {})
    print(f"  script {sid:<14} {x.get('status', 'pending'):<11} {x.get('msg', '')}")
PY
echo
echo "Panel updated. Hosted bots reload within ~10 seconds."
echo "Website : /        Buyer login : /login        Owner : /admin   (Scripts tab: upload / status / logs)"
