#!/usr/bin/env bash
# One-time setup:  bash install.sh
set -e
cd "$(dirname "$0")"
DIR="$(pwd)"
command -v python3 >/dev/null || { echo "python3 not found. Install it first: apt install -y python3 python3-venv"; exit 1; }
[ -f scripts/storebot/bot.py ] || [ -f storebot_template.py ] || { echo "scripts/storebot/bot.py missing next to install.sh (unzip the whole hostpanel zip)"; exit 1; }
mkdir -p scripts venvs data
[ -d venv ] || python3 -m venv venv
./venv/bin/pip install -q --upgrade pip
./venv/bin/pip install -q flask "python-telegram-bot[job-queue]" requests qrcode pillow
if [ ! -f panel.env ]; then
  read -r -s -p "Choose a PANEL PASSWORD (min 6 chars): " PW; echo
  read -r -p "Brand name shown on the website [Bot Host]: " BR; BR="${BR:-Bot Host}"
  printf 'PANEL_PASSWORD=%s\nPANEL_PORT=8000\nBRAND=%s\nDEFAULT_DAYS=30\n' "$PW" "$BR" > panel.env
  chmod 600 panel.env
fi

# ── Cloudflare tunnel (gives the hosted bots' Web App pay page a public https address) ──
if ! command -v cloudflared >/dev/null; then
  ARCH=$(uname -m); case "$ARCH" in aarch64|arm64) CA=arm64;; *) CA=amd64;; esac
  curl -fsSL -o /usr/local/bin/cloudflared "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-$CA" \
    && chmod +x /usr/local/bin/cloudflared || echo "WARNING: could not download cloudflared"
fi
if [ "$(id -u)" = "0" ] && command -v systemctl >/dev/null && command -v cloudflared >/dev/null; then
  if [ -n "$CF_TUNNEL_TOKEN" ]; then
    # Named tunnel (recommended, fixed address). In Cloudflare Zero Trust: Tunnels -> your tunnel ->
    # Public hostname -> your domain -> Service  HTTP  localhost:8000
    # Run:  CF_TUNNEL_TOKEN=xxxx PUBLIC_URL=https://panel.yourdomain.com bash install.sh
    [ -n "$PUBLIC_URL" ] && sed -i '/^PUBLIC_URL=/d' panel.env && echo "PUBLIC_URL=${PUBLIC_URL%/}" >> panel.env
    cat > /etc/systemd/system/cftunnel.service <<UNIT
[Unit]
Description=Cloudflare Tunnel
After=network-online.target
[Service]
ExecStart=/usr/local/bin/cloudflared tunnel --no-autoupdate run --token $CF_TUNNEL_TOKEN
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
UNIT
  else
    # Quick tunnel (no account, free). The address changes if the tunnel restarts.
    cat > /etc/systemd/system/cftunnel.service <<UNIT
[Unit]
Description=Cloudflare Quick Tunnel
After=network-online.target
[Service]
ExecStartPre=/bin/rm -f $DIR/cloudflared.log
ExecStart=/bin/sh -c 'exec /usr/local/bin/cloudflared tunnel --no-autoupdate --url http://localhost:8000 > $DIR/cloudflared.log 2>&1'
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
UNIT
  fi
  systemctl daemon-reload
  systemctl enable --now cftunnel
  for i in $(seq 1 20); do
    if [ -n "$PUBLIC_URL" ] || grep -q trycloudflare.com cloudflared.log 2>/dev/null; then break; fi
    sleep 1
  done
fi

if [ "$(id -u)" = "0" ] && command -v systemctl >/dev/null; then
  cat > /etc/systemd/system/bothost.service <<UNIT
[Unit]
Description=Bot Host Panel
After=network-online.target cftunnel.service
[Service]
WorkingDirectory=$DIR
ExecStart=$DIR/venv/bin/python $DIR/app.py
Restart=always
RestartSec=3
# keep hosted bots alive when only the panel restarts
KillMode=process
[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload
  systemctl enable --now bothost
  sleep 2
  systemctl --no-pager --lines=5 status bothost || true
else
  echo "Not root: starting with nohup instead."
  nohup ./venv/bin/python app.py > panel.log 2>&1 &
  sleep 2; tail -n 5 panel.log
fi
IP=$(curl -s -4 ifconfig.me 2>/dev/null || echo YOUR_VPS_IP)
CFU="${PUBLIC_URL:-$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' cloudflared.log 2>/dev/null | tail -1)}"
echo
echo "Website : http://$IP:8000/"
[ -n "$CFU" ] && echo "Cloudflare: $CFU   (Web App pay page: $CFU/pay/<bot id>/...)"
echo "Owner   : /admin     Buyers: /login"
echo "Next    : open /admin -> Settings -> add FMPay key + UPI ID, then add Plans."
echo "(open port 8000 in your VPS firewall if you also want direct access:  ufw allow 8000)"
