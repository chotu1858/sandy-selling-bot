#!/usr/bin/env python3
"""VC TOURNAMENT BOT (vctourney) - HostPanel script.

A complete esports-tournament bot, built from the VC Tournament web app idea:
games -> tournaments -> join with entry fee -> room ID/password -> results -> prize to wallet.
Wallet = Deposit balance + Winning balance. Add money by UPI (admin approves), withdraw winnings by UPI.
Everything (games, tournaments, rooms, results, deposits, withdrawals, users, settings, broadcast) is run
from the in-bot /admin panel. Environment from HostPanel:
  BOT_TOKEN, ADMIN_IDS, STORE_NAME, SUPPORT_USERNAME, DB_NAME, THEME_FILE
"""
import os
import re
import json
import time
import html
import sqlite3
import sys
import threading
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor

import requests

BASE = os.path.dirname(os.path.abspath(__file__))
IST = timezone(timedelta(hours=5, minutes=30))


def load_env(path):
    try:
        for line in open(path, encoding="utf-8").read().splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
    except OSError:
        pass


load_env(os.path.join(BASE, ".env"))
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMINS = [int(x) for x in os.getenv("ADMIN_IDS", "").replace(" ", "").split(",") if x.isdigit()]
BRAND_ENV = os.getenv("STORE_NAME", "") or os.getenv("BOT_NAME", "") or "VC Tournament"
SUPPORT_ENV = os.getenv("SUPPORT_USERNAME", "").strip().lstrip("@")
DB_FILE = os.path.join(BASE, os.getenv("DB_NAME", "tourney.db"))
API = "https://api.telegram.org/bot" + BOT_TOKEN
SESSION = requests.Session()
RT = {"url": os.getenv("WEBAPP_URL", "").strip().rstrip("/")}   # live Mini App URL (set by Cloudflare tunnel or env)
WEB_PORT = int(os.getenv("WEB_PORT", "0") or 0)

try:
    THEME = json.load(open(os.getenv("THEME_FILE", ""), encoding="utf-8"))
    if not isinstance(THEME, dict):
        THEME = {}
except Exception:
    THEME = {}


def log(msg):
    print("[%s] %s" % (datetime.now(IST).strftime("%H:%M:%S"), msg), flush=True)


def now_s():
    return datetime.now(IST).strftime("%d-%m-%Y %H:%M")


# ============================================================ DATABASE
DB = sqlite3.connect(DB_FILE, check_same_thread=False, timeout=30)
DB.row_factory = sqlite3.Row
DB.execute("PRAGMA journal_mode=WAL")
L = threading.RLock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, username TEXT, joined TEXT, banned INTEGER DEFAULT 0,
  dep REAL DEFAULT 0, win REAL DEFAULT 0, played INTEGER DEFAULT 0, wins INTEGER DEFAULT 0, last_seen TEXT);
CREATE TABLE IF NOT EXISTS games(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, emoji TEXT, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS tournaments(id INTEGER PRIMARY KEY AUTOINCREMENT, gid INTEGER, title TEXT, mode TEXT, fee REAL, pool REAL,
  per_kill REAL, slots INTEGER, start TEXT, status TEXT DEFAULT 'upcoming', room_id TEXT DEFAULT '', room_pass TEXT DEFAULT '', created TEXT);
CREATE TABLE IF NOT EXISTS parts(id INTEGER PRIMARY KEY AUTOINCREMENT, tid INTEGER, uid INTEGER, ign TEXT, slot INTEGER, joined TEXT,
  prize REAL DEFAULT 0, kills INTEGER DEFAULT 0, rank INTEGER DEFAULT 0, UNIQUE(tid, uid), UNIQUE(tid, slot));
CREATE TABLE IF NOT EXISTS txns(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, kind TEXT, amount REAL, note TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS deposits(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, amount REAL, utr TEXT, proof TEXT,
  status TEXT DEFAULT 'pending', created TEXT);
CREATE TABLE IF NOT EXISTS withdrawals(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, amount REAL, upi TEXT,
  status TEXT DEFAULT 'pending', created TEXT);
CREATE TABLE IF NOT EXISTS ign(uid INTEGER, gid INTEGER, name TEXT, PRIMARY KEY(uid, gid));
CREATE TABLE IF NOT EXISTS state(uid INTEGER PRIMARY KEY, s TEXT, data TEXT);
CREATE TABLE IF NOT EXISTS banners(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, sub TEXT, emoji TEXT, grad TEXT, active INTEGER DEFAULT 1);
"""
MIGRATE = [("games", "color", "TEXT DEFAULT ''"), ("games", "logo", "TEXT DEFAULT ''"), ("games", "sort", "INTEGER DEFAULT 0"),
           ("tournaments", "start_ts", "INTEGER DEFAULT 0"), ("tournaments", "map", "TEXT DEFAULT ''"),
           ("deposits", "gw", "TEXT DEFAULT ''"), ("deposits", "ref", "TEXT DEFAULT ''"),
           ("users", "photo", "TEXT DEFAULT ''"),
           ("tournaments", "banner", "TEXT DEFAULT ''"), ("banners", "img", "TEXT DEFAULT ''")]
with L:
    DB.executescript(SCHEMA)
    for _t, _c, _d in MIGRATE:
        if _c not in {r[1] for r in DB.execute("PRAGMA table_info(%s)" % _t)}:
            DB.execute("ALTER TABLE %s ADD COLUMN %s %s" % (_t, _c, _d))
    DB.commit()


def q(sql, p=()):
    with L:
        return DB.execute(sql, p).fetchall()


def q1(sql, p=()):
    with L:
        return DB.execute(sql, p).fetchone()


def x(sql, p=()):
    with L:
        cur = DB.execute(sql, p)
        DB.commit()
        return cur.lastrowid


DEFAULTS = {
    "brand": BRAND_ENV,
    "upi": "",
    "qr": "",
    "min_dep": "10",
    "min_wd": "50",
    "support": SUPPORT_ENV,
    "maint": "0",
    "webapp_url": "",
    "notice": "",
    "gw": "none",
    "rzp_key": "", "rzp_secret": "", "rzp_hook": "",
    "upig_key": "",
    "fam_base": "", "fam_path": "/api/check", "fam_method": "GET", "fam_key_param": "key", "fam_key": "",
    "fam_utr_param": "utr", "fam_paid_field": "status", "fam_paid_value": "success", "fam_amount_field": "",
    "welcome_img": "", "welcome_img_file": "", "welcome_btn": "🚀 OPEN TOURNAMENT APP",
    "txt_welcome": ("<blockquote><b>🏆 WELCOME TO {brand}</b></blockquote>\n"
                    "<blockquote><b>├── 🎮 Join paid &amp; free tournaments\n├── 🔑 Get Room ID &amp; password here\n"
                    "├── 💰 Instant prize in your wallet\n└── 💸 Easy UPI withdrawal</b></blockquote>\n"
                    "<b>Hey {name}, choose an option 👇</b>"),
    "txt_terms": ("<blockquote><b>📜 TERMS &amp; CONDITIONS</b></blockquote>\n"
                  "<blockquote><b>01.</b> You must be of legal age to play in your region.\n"
                  "<b>02.</b> Use your own correct in-game name. Wrong or fake names can be disqualified.\n"
                  "<b>03.</b> Cheating, hacking or teaming up is banned. No refund and wallet can be frozen.\n"
                  "<b>04.</b> Entry fee is not refunded once a match has started, except when the admin cancels it.\n"
                  "<b>05.</b> Withdrawals only from Winning balance and are paid to your UPI after admin approval.\n"
                  "<b>06.</b> Admin decision on results and disputes is final.</blockquote>"),
}
for _k, _v in (THEME.get("texts") or {}).items():
    if isinstance(_v, str) and _k in DEFAULTS:
        DEFAULTS[_k] = _v


def S(k):
    r = q1("SELECT v FROM settings WHERE k=?", (k,))
    return r["v"] if r else DEFAULTS.get(k, "")


def set_S(k, v):
    x("INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, v))


def fnum(k, d=0.0):
    try:
        return float(S(k))
    except ValueError:
        return d


def fm(v):
    v = round(float(v or 0), 2)
    return "₹" + (str(int(v)) if v == int(v) else "%.2f" % v)


def esc(t):
    return html.escape(str(t if t is not None else ""), quote=False)


def is_admin(uid):
    return uid in ADMINS


# ============================================================ TELEGRAM
def bad(res):
    return isinstance(res, dict) and "_err" in res


def tg(method, params=None, timeout=35):
    for _ in range(3):
        try:
            r = SESSION.post(API + "/" + method, json=params or {}, timeout=timeout)
            j = r.json()
        except (requests.RequestException, ValueError):
            time.sleep(1)
            continue
        if j.get("ok"):
            return j.get("result")
        ra = (j.get("parameters") or {}).get("retry_after")
        if ra and j.get("error_code") == 429:
            time.sleep(min(int(ra), 10))
            continue
        return {"_err": str(j.get("description", "error"))}
    return {"_err": "network error"}


def B(text, cb=None, url=None, style=None, web=None):
    b = {"text": text}
    if web:
        b["web_app"] = {"url": web}
    elif url:
        b["url"] = url
    else:
        b["callback_data"] = cb or "home"
    if style:
        b["style"] = style
    return b


def _strip_style(kb):
    return {"inline_keyboard": [[{k: v for k, v in b.items() if k != "style"} for b in row] for row in kb.get("inline_keyboard", [])]}


def plain(t):
    return html.unescape(re.sub(r"<[^>]+>", "", str(t)))


def call(method, p):
    """tg() with fallbacks: coloured buttons not accepted -> plain buttons; bad HTML -> plain text."""
    res = tg(method, p)
    if bad(res) and "not modified" not in res["_err"]:
        kb = p.get("reply_markup")
        if kb and re.search(r"(?i)button|style|reply markup", res["_err"]):
            p = dict(p)
            p["reply_markup"] = _strip_style(kb)
            res = tg(method, p)
        if bad(res) and re.search(r"(?i)parse entities|can't find end", res["_err"]):
            p = dict(p)
            p.pop("parse_mode", None)
            for f in ("text", "caption"):
                if f in p:
                    p[f] = plain(p[f])
            res = tg(method, p)
    return res


def cut(t, n=4000):
    t = str(t)
    return t if len(t) <= n else t[:n - 3] + "..."


def send(c, text, kb=None):
    p = {"chat_id": c, "text": cut(text), "parse_mode": "HTML", "disable_web_page_preview": True}
    if kb:
        p["reply_markup"] = {"inline_keyboard": kb}
    return call("sendMessage", p)


def send_photo(c, fid, cap, kb=None):
    p = {"chat_id": c, "photo": fid, "caption": cut(cap, 1000), "parse_mode": "HTML"}
    if kb:
        p["reply_markup"] = {"inline_keyboard": kb}
    return call("sendPhoto", p)


def show(c, mid, text, kb=None):
    """Edit the menu message in place (falls back to a fresh message)."""
    if not mid:
        return send(c, text, kb)
    p = {"chat_id": c, "message_id": mid, "text": cut(text), "parse_mode": "HTML", "disable_web_page_preview": True,
         "reply_markup": {"inline_keyboard": kb or []}}
    res = call("editMessageText", p)
    if bad(res):
        if "not modified" in res["_err"]:
            return None
        tg("deleteMessage", {"chat_id": c, "message_id": mid})
        return send(c, text, kb)
    return res


def ack(cid, text="", alert=False):
    tg("answerCallbackQuery", {"callback_query_id": cid, "text": text[:190], "show_alert": alert}, timeout=10)


def notify_admins(text, kb=None, photo=None):
    for a in ADMINS:
        if photo:
            send_photo(a, photo, text, kb)
        else:
            send(a, text, kb)


# ============================================================ STATE
def st_set(uid, s, data=None):
    x("INSERT INTO state(uid,s,data) VALUES(?,?,?) ON CONFLICT(uid) DO UPDATE SET s=excluded.s, data=excluded.data",
      (uid, s, json.dumps(data or {})))


def st_get(uid):
    r = q1("SELECT s, data FROM state WHERE uid=?", (uid,))
    if not r:
        return "", {}
    try:
        return r["s"], json.loads(r["data"] or "{}")
    except ValueError:
        return r["s"], {}


def st_clear(uid):
    x("DELETE FROM state WHERE uid=?", (uid,))


# ============================================================ USERS / WALLET
def ensure_user(fr):
    uid = fr["id"]
    name = ((fr.get("first_name") or "") + " " + (fr.get("last_name") or "")).strip()[:60] or "Player"
    with L:
        DB.execute("INSERT OR IGNORE INTO users(id,name,username,joined) VALUES(?,?,?,?)", (uid, name, fr.get("username") or "", now_s()))
        DB.execute("UPDATE users SET name=?, username=?, last_seen=? WHERE id=?", (name, fr.get("username") or "", now_s(), uid))
        DB.commit()
    return q1("SELECT * FROM users WHERE id=?", (uid,))


def txn(uid, kind, amt, note=""):
    DB.execute("INSERT INTO txns(uid,kind,amount,note,created) VALUES(?,?,?,?,?)", (uid, kind, round(amt, 2), note[:80], now_s()))


def spend(uid, amt):
    """Take amt from deposit balance first, then winning balance. Call while holding L."""
    u = DB.execute("SELECT dep, win FROM users WHERE id=?", (uid,)).fetchone()
    if not u or round(u["dep"] + u["win"], 2) < round(amt, 2):
        return False
    from_dep = min(u["dep"], amt)
    from_win = round(amt - from_dep, 2)
    DB.execute("UPDATE users SET dep=?, win=? WHERE id=?", (round(u["dep"] - from_dep, 2), round(u["win"] - from_win, 2), uid))
    return True


def balances(uid):
    u = q1("SELECT dep, win FROM users WHERE id=?", (uid,))
    return (u["dep"], u["win"]) if u else (0.0, 0.0)


# ============================================================ MENUS
STATUS = {"upcoming": "🕒 Upcoming", "live": "🔴 LIVE", "completed": "✅ Completed", "cancelled": "❌ Cancelled"}


def bt(key, default, style="primary"):
    o = (THEME.get("buttons") or {}).get(key)
    if isinstance(o, dict):
        return o.get("text") or default, o.get("style") or style
    return default, style


def app_url(path=""):
    base = (S("webapp_url") or RT["url"]).rstrip("/")
    return (base + path) if base else ""


def home(c, mid, uid, name=""):
    u = q1("SELECT name FROM users WHERE id=?", (uid,))
    nm = name or (u["name"] if u else "Player")
    text = S("txt_welcome").replace("{brand}", esc(S("brand"))).replace("{name}", esc(nm))
    sup = S("support").lstrip("@")

    def b(key, d, cb, st="primary"):
        t, s = bt(key, d, st)
        return B(t, cb, style=s)
    t_s, s_s = bt("sup", "📞 Support", "primary")
    kb = []
    if app_url():
        kb.append([B(S("welcome_btn") or "🚀 OPEN TOURNAMENT APP", web=app_url("/"), style="success")])
    kb += [[b("tour", "🎮 Tournaments", "g", "success"), b("mm", "🏆 My Matches", "mm")],
          [b("wallet", "💰 Wallet", "w", "success"), b("add", "➕ Add Money", "add", "success")],
          [b("wd", "💸 Withdraw", "wd"), b("pf", "👤 Profile", "pf")],
          [B(t_s, url="https://t.me/" + sup, style=s_s) if sup else B(t_s, "help", style=s_s), b("terms", "📜 Terms", "terms")]]
    if is_admin(uid):
        kb.append([B("🛠 Admin Panel", "adm", style="danger")])
    if not mid and S("welcome_img"):
        # welcome photo set from the admin panel: photo + caption (long text goes as a separate message)
        if len(text) <= 1000:
            r = send_photo(c, S("welcome_img"), text, kb)
            if r and not bad(r):
                return r
        else:
            r = send_photo(c, S("welcome_img"), "", None)
            if r and not bad(r):
                return show(c, None, text, kb)
    return show(c, mid, text, kb)


def back(cb="home", label="⬅️ Back"):
    return [B(label, cb, style="primary")]


def show_games(c, mid):
    gs = q("SELECT * FROM games WHERE active=1 ORDER BY id")
    if not gs:
        return show(c, mid, "<b>🎮 No games added yet.</b>\nPlease check again soon.", [back()])
    kb = []
    for i in range(0, len(gs), 2):
        kb.append([B("%s %s" % (g["emoji"], g["name"]), "gm:%d" % g["id"], style="success") for g in gs[i:i + 2]])
    kb.append(back())
    return show(c, mid, "<blockquote><b>🎮 CHOOSE A GAME</b></blockquote>", kb)


def filled(tid):
    return q1("SELECT COUNT(*) c FROM parts WHERE tid=?", (tid,))["c"]


def show_game(c, mid, gid):
    g = q1("SELECT * FROM games WHERE id=?", (gid,))
    if not g:
        return show_games(c, mid)
    ts = q("SELECT * FROM tournaments WHERE gid=? AND status IN ('upcoming','live') ORDER BY id DESC LIMIT 20", (gid,))
    if not ts:
        return show(c, mid, "<blockquote><b>%s %s</b></blockquote>\n<b>No tournament is open right now.</b>" % (g["emoji"], esc(g["name"])), [back("g")])
    kb = [[B("%s %s · %s · %d/%d" % ("🔴" if t["status"] == "live" else "🟢", t["title"][:22], fm(t["fee"]) if t["fee"] else "FREE", filled(t["id"]), t["slots"]),
             "t:%d" % t["id"], style="success" if t["status"] == "upcoming" else "danger")] for t in ts]
    kb.append(back("g"))
    return show(c, mid, "<blockquote><b>%s %s · TOURNAMENTS</b></blockquote>" % (g["emoji"], esc(g["name"])), kb)


def tour_text(t, uid=None, admin=False):
    g = q1("SELECT name, emoji FROM games WHERE id=?", (t["gid"],))
    n = filled(t["id"])
    txt = ("<blockquote><b>%s %s</b></blockquote>\n<blockquote><b>├── Game: %s\n├── Mode: %s\n├── Entry: %s\n├── Prize pool: %s\n├── Per kill: %s\n"
           "├── Slots: %d/%d\n├── Start: %s\n└── Status: %s</b></blockquote>") % (
        g["emoji"] if g else "🎮", esc(t["title"]), esc(g["name"]) if g else "-", esc(t["mode"]), fm(t["fee"]) if t["fee"] else "FREE",
        fm(t["pool"]), fm(t["per_kill"]), n, t["slots"], esc(t["start"]), STATUS.get(t["status"], t["status"]))
    mine = q1("SELECT * FROM parts WHERE tid=? AND uid=?", (t["id"], uid)) if uid else None
    if mine:
        txt += "\n✅ <b>You joined</b> · Slot #%d · <code>%s</code>" % (mine["slot"], esc(mine["ign"]))
        if t["room_id"] and t["status"] in ("upcoming", "live"):
            txt += "\n\n<blockquote><b>🔑 ROOM DETAILS\nRoom ID: <code>%s</code>\nPassword: <code>%s</code></b></blockquote>" % (esc(t["room_id"]), esc(t["room_pass"]))
        elif t["status"] in ("upcoming", "live"):
            txt += "\n<i>Room ID &amp; password will appear here before the match.</i>"
        if t["status"] == "completed":
            txt += "\n🏅 Your result: rank %s · kills %d · won <b>%s</b>" % (mine["rank"] or "-", mine["kills"], fm(mine["prize"]))
    if admin and t["room_id"]:
        txt += "\n\n🔑 Room: <code>%s</code> / <code>%s</code>" % (esc(t["room_id"]), esc(t["room_pass"]))
    return txt


def show_tour(c, mid, uid, tid):
    t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t:
        return show(c, mid, "❌ Tournament not found.", [back("g")])
    mine = q1("SELECT 1 FROM parts WHERE tid=? AND uid=?", (tid, uid))
    kb = []
    if t["status"] == "upcoming" and not mine:
        if filled(tid) >= t["slots"]:
            kb.append([B("🚫 Slots full", "t:%d" % tid, style="danger")])
        else:
            kb.append([B("✅ Join · %s" % (fm(t["fee"]) if t["fee"] else "FREE"), "jn:%d" % tid, style="success")])
    kb.append([B("👥 Participants", "tp:%d" % tid, style="primary"), B("🔄 Refresh", "t:%d" % tid, style="primary")])
    if t["status"] == "completed":
        kb.append([B("🏅 Results", "tr:%d" % tid, style="success")])
    kb.append(back("gm:%d" % t["gid"]))
    return show(c, mid, tour_text(t, uid), kb)


def show_parts(c, mid, tid, admin=False):
    t = q1("SELECT title FROM tournaments WHERE id=?", (tid,))
    ps = q("SELECT * FROM parts WHERE tid=? ORDER BY slot LIMIT 100", (tid,))
    lines = ["#%d · %s%s" % (p["slot"], esc(p["ign"]), (" · <code>%d</code>" % p["uid"]) if admin else "") for p in ps]
    body = "\n".join(lines) or "No players yet."
    return show(c, mid, "<blockquote><b>👥 PARTICIPANTS · %s</b></blockquote>\n%s" % (esc(t["title"]) if t else "", body),
                [back(("ato:%d" if admin else "t:%d") % tid)])


def show_results(c, mid, tid):
    t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    ps = q("SELECT * FROM parts WHERE tid=? AND (rank>0 OR prize>0) ORDER BY rank", (tid,))
    lines = ["#%d %s · kills %d · <b>%s</b>" % (p["rank"], esc(p["ign"]), p["kills"], fm(p["prize"])) for p in ps]
    return show(c, mid, "<blockquote><b>🏅 RESULTS · %s</b></blockquote>\n%s" % (esc(t["title"]) if t else "", "\n".join(lines) or "No result yet."), [back("t:%d" % tid)])


def show_my_matches(c, mid, uid):
    rows = q("SELECT t.id, t.title, t.status, p.prize FROM parts p JOIN tournaments t ON t.id=p.tid WHERE p.uid=? ORDER BY p.id DESC LIMIT 15", (uid,))
    if not rows:
        return show(c, mid, "<b>🏆 You have not joined any match yet.</b>", [[B("🎮 Browse Tournaments", "g", style="success")], back()])
    kb = [[B("%s %s%s" % ({"upcoming": "🕒", "live": "🔴", "completed": "✅", "cancelled": "❌"}.get(r["status"], "•"), r["title"][:26],
                          (" · " + fm(r["prize"])) if r["prize"] else ""), "t:%d" % r["id"], style="primary")] for r in rows]
    kb.append(back())
    return show(c, mid, "<blockquote><b>🏆 MY MATCHES</b></blockquote>", kb)


def show_wallet(c, mid, uid):
    d, w = balances(uid)
    txt = ("<blockquote><b>💰 MY WALLET</b></blockquote>\n<blockquote><b>├── Deposit balance: %s\n├── Winning balance: %s\n└── Total: %s</b></blockquote>\n"
           "<i>Entry fee is taken from Deposit first. Only Winning balance can be withdrawn.</i>") % (fm(d), fm(w), fm(d + w))
    return show(c, mid, txt, [[B("➕ Add Money", "add", style="success"), B("💸 Withdraw", "wd", style="primary")],
                              [B("🧾 History", "wh", style="primary")], back()])


def show_history(c, mid, uid):
    rows = q("SELECT * FROM txns WHERE uid=? ORDER BY id DESC LIMIT 15", (uid,))
    sign = {"deposit": "+", "prize": "+", "refund": "+", "adjust": "±", "join": "-", "withdraw": "-"}
    lines = ["%s%s %s · %s\n<i>%s</i>" % (sign.get(r["kind"], ""), fm(r["amount"]).replace("₹-", "₹"), r["kind"], esc(r["note"]), r["created"]) for r in rows]
    return show(c, mid, "<blockquote><b>🧾 LAST 15 TRANSACTIONS</b></blockquote>\n" + ("\n\n".join(lines) or "No transactions yet."), [back("w")])


def show_profile(c, mid, uid):
    u = q1("SELECT * FROM users WHERE id=?", (uid,))
    txt = ("<blockquote><b>👤 MY PROFILE</b></blockquote>\n<blockquote><b>├── Name: %s\n├── ID: <code>%d</code>\n├── Matches played: %d\n├── Matches won: %d\n"
           "├── Deposit: %s\n├── Winning: %s\n└── Joined: %s</b></blockquote>") % (
        esc(u["name"]), uid, u["played"], u["wins"], fm(u["dep"]), fm(u["win"]), esc(u["joined"]))
    return show(c, mid, txt, [back()])


# ============================================================ JOIN FLOW
def join_start(c, mid, uid, tid):
    t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t or t["status"] != "upcoming":
        return show(c, mid, "❌ This tournament is not open for joining.", [back("g")])
    if q1("SELECT 1 FROM parts WHERE tid=? AND uid=?", (tid, uid)):
        return show_tour(c, mid, uid, tid)
    if filled(tid) >= t["slots"]:
        return show(c, mid, "🚫 <b>Slots are full.</b>", [back("t:%d" % tid)])
    d, w = balances(uid)
    if round(d + w, 2) < t["fee"]:
        return show(c, mid, "❌ <b>Not enough balance.</b>\nEntry: <b>%s</b> · Your wallet: <b>%s</b>\nShort by <b>%s</b>." % (fm(t["fee"]), fm(d + w), fm(t["fee"] - d - w)),
                    [[B("➕ Add Money", "add", style="success")], back("t:%d" % tid)])
    saved = q1("SELECT name FROM ign WHERE uid=? AND gid=?", (uid, t["gid"]))
    kb = []
    if saved:
        kb.append([B("✅ Use: %s" % saved["name"][:25], "ju:%d" % tid, style="success")])
    kb.append(back("t:%d" % tid, "❌ Cancel"))
    st_set(uid, "ign", {"tid": tid})
    return show(c, mid, "<blockquote><b>🎮 JOIN · %s</b></blockquote>\n<b>Send your exact in-game name (IGN) / player ID now.</b>\nEntry: <b>%s</b>" % (esc(t["title"]), fm(t["fee"]) if t["fee"] else "FREE"), kb)


def join_confirm(c, mid, uid, tid, ign):
    t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t:
        return send(c, "❌ Tournament not found.", [back("g")])
    st_set(uid, "join_ok", {"tid": tid, "ign": ign})
    txt = "<blockquote><b>🧾 CONFIRM JOIN</b></blockquote>\nTournament: <b>%s</b>\nIGN: <code>%s</code>\nEntry fee: <b>%s</b>" % (esc(t["title"]), esc(ign), fm(t["fee"]) if t["fee"] else "FREE")
    kb = [[B("✅ Confirm & Pay", "jc:%d" % tid, style="success"), B("❌ Cancel", "t:%d" % tid, style="danger")]]
    return show(c, mid, txt, kb) if mid else send(c, txt, kb)


def do_join(uid, tid, ign):
    with L:
        t = DB.execute("SELECT * FROM tournaments WHERE id=?", (tid,)).fetchone()
        if not t or t["status"] != "upcoming":
            return "closed", 0
        if DB.execute("SELECT 1 FROM parts WHERE tid=? AND uid=?", (tid, uid)).fetchone():
            return "dup", 0
        n = DB.execute("SELECT COALESCE(MAX(slot),0) m FROM parts WHERE tid=?", (tid,)).fetchone()["m"]
        cnt = DB.execute("SELECT COUNT(*) c FROM parts WHERE tid=?", (tid,)).fetchone()["c"]
        if cnt >= t["slots"]:
            return "full", 0
        if not spend(uid, t["fee"]):
            return "funds", 0
        DB.execute("INSERT INTO parts(tid,uid,ign,slot,joined) VALUES(?,?,?,?,?)", (tid, uid, ign, n + 1, now_s()))
        if t["fee"]:
            txn(uid, "join", t["fee"], t["title"])
        DB.execute("UPDATE users SET played=played+1 WHERE id=?", (uid,))
        DB.execute("INSERT INTO ign(uid,gid,name) VALUES(?,?,?) ON CONFLICT(uid,gid) DO UPDATE SET name=excluded.name", (uid, t["gid"], ign))
        DB.commit()
        return "ok", n + 1


# ============================================================ MONEY FLOWS
UTR_RE = re.compile(r"^[A-Za-z0-9]{6,30}$")
UPI_RE = re.compile(r"^[A-Za-z0-9._\-]{2,}@[A-Za-z0-9]{2,}$")


def add_money_start(c, mid, uid):
    if not S("upi") and not S("qr"):
        return show(c, mid, "⚠️ <b>Add Money is not set up yet.</b>\nPlease contact support.", [back()])
    st_set(uid, "dep_amt")
    return show(c, mid, "<blockquote><b>➕ ADD MONEY</b></blockquote>\n<b>Send the amount you want to add</b> (minimum %s)." % fm(fnum("min_dep", 10)), [back("w", "❌ Cancel")])


def dep_pay_info(c, uid, amt):
    st_set(uid, "dep_pay", {"amt": amt})
    txt = ("<blockquote><b>💳 PAY %s</b></blockquote>\nUPI ID: <code>%s</code>\n\n1️⃣ Pay exactly <b>%s</b> by any UPI app.\n"
           "2️⃣ Tap <b>I have paid</b> and send the <b>UTR / transaction ID</b>.\n<i>Money is added after admin checks the payment.</i>") % (fm(amt), esc(S("upi") or "-"), fm(amt))
    kb = [[B("✅ I have paid", "dpaid", style="success")], back("w", "❌ Cancel")]
    if S("qr"):
        send_photo(c, S("qr"), txt, kb)
    else:
        send(c, txt, kb)


def dep_submit(c, uid, amt, utr, proof=""):
    utr = utr.strip().upper()
    if not UTR_RE.match(utr):
        return send(c, "❌ <b>Invalid UTR.</b> It is 6-30 letters/numbers. Send it again (or /cancel).")
    with L:
        if DB.execute("SELECT 1 FROM deposits WHERE utr=? AND status!='rejected'", (utr,)).fetchone():
            dup = True
        elif DB.execute("SELECT COUNT(*) c FROM deposits WHERE uid=? AND status='pending'", (uid,)).fetchone()["c"] >= 3:
            dup = None
        else:
            dup = False
            did = DB.execute("INSERT INTO deposits(uid,amount,utr,proof,created) VALUES(?,?,?,?,?)", (uid, amt, utr, proof, now_s())).lastrowid
            DB.commit()
    if dup:
        return send(c, "❌ <b>This UTR was already submitted.</b>")
    if dup is None:
        return send(c, "⏳ You already have 3 pending deposits. Please wait for approval.")
    st_clear(uid)
    u = q1("SELECT name, username FROM users WHERE id=?", (uid,))
    cap = "<blockquote><b>📥 NEW DEPOSIT #%d</b></blockquote>\nUser: %s (<code>%d</code>)\nAmount: <b>%s</b>\nUTR: <code>%s</code>" % (did, esc(u["name"]), uid, fm(amt), utr)
    notify_admins(cap, [[B("✅ Approve", "dp:a:%d" % did, style="success"), B("❌ Reject", "dp:r:%d" % did, style="danger")]], proof or None)
    return send(c, "✅ <b>Deposit request sent.</b>\nAmount: <b>%s</b> · UTR: <code>%s</code>\nWe will add it to your wallet after checking." % (fm(amt), utr), [back("home", "🏠 Menu")])


def dep_decide(did, approve):
    with L:
        d = DB.execute("SELECT * FROM deposits WHERE id=?", (did,)).fetchone()
        if not d or d["status"] not in ("pending", "awaiting"):
            return None
        if approve:
            DB.execute("UPDATE users SET dep=dep+? WHERE id=?", (d["amount"], d["uid"]))
            txn(d["uid"], "deposit", d["amount"], ("AUTO " if d["gw"] else "UPI ") + d["utr"])
        DB.execute("UPDATE deposits SET status=? WHERE id=?", ("approved" if approve else "rejected", did))
        DB.commit()
        return d


def wd_start(c, mid, uid):
    d, w = balances(uid)
    mn = fnum("min_wd", 50)
    if w < mn:
        return show(c, mid, "<blockquote><b>💸 WITHDRAW</b></blockquote>\nWinning balance: <b>%s</b>\nMinimum withdrawal: <b>%s</b>\n<i>Only winning balance can be withdrawn.</i>" % (fm(w), fm(mn)),
                    [[B("🎮 Play & Win", "g", style="success")], back()])
    st_set(uid, "wd_amt")
    return show(c, mid, "<blockquote><b>💸 WITHDRAW</b></blockquote>\nWinning balance: <b>%s</b>\n<b>Send the amount to withdraw</b> (min %s)." % (fm(w), fm(mn)), [back("w", "❌ Cancel")])


def wd_create(uid, amt, upi):
    with L:
        u = DB.execute("SELECT win FROM users WHERE id=?", (uid,)).fetchone()
        if not u or u["win"] < amt:
            return None
        if DB.execute("SELECT COUNT(*) c FROM withdrawals WHERE uid=? AND status='pending'", (uid,)).fetchone()["c"] >= 2:
            return -1
        DB.execute("UPDATE users SET win=? WHERE id=?", (round(u["win"] - amt, 2), uid))
        wid = DB.execute("INSERT INTO withdrawals(uid,amount,upi,created) VALUES(?,?,?,?)", (uid, amt, upi, now_s())).lastrowid
        txn(uid, "withdraw", amt, "request #%d" % wid)
        DB.commit()
        return wid


def wd_decide(wid, paid):
    with L:
        w = DB.execute("SELECT * FROM withdrawals WHERE id=?", (wid,)).fetchone()
        if not w or w["status"] != "pending":
            return None
        if not paid:
            DB.execute("UPDATE users SET win=win+? WHERE id=?", (w["amount"], w["uid"]))
            txn(w["uid"], "refund", w["amount"], "withdraw rejected #%d" % wid)
        DB.execute("UPDATE withdrawals SET status=? WHERE id=?", ("paid" if paid else "rejected", wid))
        DB.commit()
        return w


# ============================================================ ADMIN
def adm_home(c, mid):
    pd = q1("SELECT COUNT(*) c FROM deposits WHERE status='pending'")["c"]
    pw = q1("SELECT COUNT(*) c FROM withdrawals WHERE status='pending'")["c"]
    kb = [[B("🎮 Games", "ag", style="primary"), B("🏟 Tournaments", "at", style="success")],
          [B("📥 Deposits (%d)" % pd, "ad", style="success" if pd else "primary"), B("📤 Withdrawals (%d)" % pw, "aw", style="danger" if pw else "primary")],
          [B("👥 Users", "au", style="primary"), B("⚙️ Settings", "as", style="primary")],
          [B("📢 Broadcast", "ab", style="primary"), B("📊 Stats", "ast", style="primary")],
          back("home", "⬅️ Menu")]
    if app_url():
        kb.insert(0, [B("🚀 OPEN ADMIN APP (easy mode)", web=app_url("/#admin"), style="success")])
    return show(c, mid, "<blockquote><b>🛠 ADMIN PANEL · %s</b></blockquote>" % esc(S("brand")), kb)


def adm_games(c, mid):
    gs = q("SELECT * FROM games ORDER BY id")
    kb = [[B("🗑 %s %s" % (g["emoji"], g["name"]), "agd:%d" % g["id"], style="danger")] for g in gs]
    kb.append([B("➕ Add Game", "aga", style="success")])
    kb.append(back("adm"))
    return show(c, mid, "<blockquote><b>🎮 GAMES</b></blockquote>\n<i>Tap a game to delete it (only if it has no tournaments).</i>", kb)


def adm_tours(c, mid):
    ts = q("SELECT * FROM tournaments ORDER BY id DESC LIMIT 15")
    kb = [[B("➕ Create Tournament", "atn", style="success")]]
    kb += [[B("%s #%d %s" % ({"upcoming": "🕒", "live": "🔴", "completed": "✅", "cancelled": "❌"}.get(t["status"], "•"), t["id"], t["title"][:24]), "ato:%d" % t["id"], style="primary")] for t in ts]
    kb.append(back("adm"))
    return show(c, mid, "<blockquote><b>🏟 TOURNAMENTS</b></blockquote>", kb)


def adm_tour(c, mid, tid):
    t = q1("SELECT * FROM tournaments WHERE id=?", (tid,))
    if not t:
        return adm_tours(c, mid)
    kb = []
    if t["status"] in ("upcoming", "live"):
        kb.append([B("🔑 Set Room ID/Pass", "atroom:%d" % tid, style="success"), B("🏁 Enter Results", "atr:%d" % tid, style="success")])
        row = []
        if t["status"] == "upcoming":
            row.append(B("▶️ Go Live", "ats:%d:live" % tid, style="danger"))
        row.append(B("❌ Cancel & Refund", "atc:%d" % tid, style="danger"))
        kb.append(row)
    kb.append([B("👥 Participants", "atp:%d" % tid, style="primary"), B("🔄 Refresh", "ato:%d" % tid, style="primary")])
    kb.append(back("at"))
    return show(c, mid, tour_text(t, admin=True), kb)


def parse_new_tour(text):
    ln = [l.strip() for l in text.strip().splitlines() if l.strip()]
    if len(ln) < 7:
        return None, "Send all 7 lines (title, mode, entry fee, prize pool, per kill, slots, start time)."
    try:
        fee, pool, pk = float(ln[2].lstrip("₹")), float(ln[3].lstrip("₹")), float(ln[4].lstrip("₹"))
        slots = int(ln[5])
    except ValueError:
        return None, "Entry fee, prize pool, per kill and slots must be numbers."
    if min(fee, pool, pk) < 0 or not 2 <= slots <= 1000:
        return None, "Amounts cannot be negative and slots must be 2-1000."
    return {"title": ln[0][:40], "mode": ln[1][:20], "fee": fee, "pool": pool, "pk": pk, "slots": slots, "start": ln[6][:40]}, ""


def parse_results(text, t):
    rows, seen = [], set()
    for raw in text.strip().splitlines():
        if not raw.strip():
            continue
        parts = [p for p in re.split(r"[\s,|]+", raw.strip()) if p]
        try:
            slot, prize = int(parts[0].lstrip("#")), float(parts[1].lstrip("₹"))
            kills = int(parts[2]) if len(parts) > 2 else 0
        except (ValueError, IndexError):
            return None, "Wrong line: <code>%s</code>\nUse: slot prize kills" % esc(raw[:60])
        if slot in seen or not q1("SELECT 1 FROM parts WHERE tid=? AND slot=?", (t["id"], slot)) or prize < 0 or kills < 0:
            return None, "Bad or repeated slot #%d (slot must exist, no duplicates, no negatives)." % slot
        seen.add(slot)
        rows.append((slot, prize, kills))
    if not rows:
        return None, "Send at least one line."
    return rows, ""


def apply_results(tid, rows):
    with L:
        t = DB.execute("SELECT * FROM tournaments WHERE id=?", (tid,)).fetchone()
        if not t or t["status"] in ("completed", "cancelled"):
            return None
        out = []
        for rank, (slot, prize, kills) in enumerate(rows, 1):
            p = DB.execute("SELECT * FROM parts WHERE tid=? AND slot=?", (tid, slot)).fetchone()
            if not p:
                continue
            total = round(prize + kills * t["per_kill"], 2)
            DB.execute("UPDATE parts SET prize=?, kills=?, rank=? WHERE id=?", (total, kills, rank, p["id"]))
            if total > 0:
                DB.execute("UPDATE users SET win=win+? WHERE id=?", (total, p["uid"]))
                txn(p["uid"], "prize", total, t["title"])
            if rank == 1:
                DB.execute("UPDATE users SET wins=wins+1 WHERE id=?", (p["uid"],))
            out.append((p["uid"], p["ign"], rank, kills, total))
        DB.execute("UPDATE tournaments SET status='completed' WHERE id=?", (tid,))
        DB.commit()
        return out


def cancel_tour(tid):
    with L:
        t = DB.execute("SELECT * FROM tournaments WHERE id=?", (tid,)).fetchone()
        if not t or t["status"] in ("completed", "cancelled"):
            return None
        ps = DB.execute("SELECT uid FROM parts WHERE tid=?", (tid,)).fetchall()
        for p in ps:
            if t["fee"]:
                DB.execute("UPDATE users SET dep=dep+? WHERE id=?", (t["fee"], p["uid"]))
                txn(p["uid"], "refund", t["fee"], "cancelled: " + t["title"])
        DB.execute("UPDATE tournaments SET status='cancelled' WHERE id=?", (tid,))
        DB.commit()
        return [p["uid"] for p in ps], t


def adm_deposits(c, mid):
    ds = q("SELECT d.*, u.name FROM deposits d LEFT JOIN users u ON u.id=d.uid WHERE d.status='pending' ORDER BY d.id LIMIT 8")
    if not ds:
        return show(c, mid, "<b>📥 No pending deposits.</b>", [back("adm")])
    show(c, mid, "<blockquote><b>📥 PENDING DEPOSITS (%d shown)</b></blockquote>" % len(ds), [back("adm")])
    for d in ds:
        send(c, "<b>#%d</b> · %s (<code>%d</code>)\nAmount <b>%s</b> · UTR <code>%s</code>\n<i>%s</i>" % (d["id"], esc(d["name"]), d["uid"], fm(d["amount"]), esc(d["utr"]), d["created"]),
             [[B("✅ Approve", "dp:a:%d" % d["id"], style="success"), B("❌ Reject", "dp:r:%d" % d["id"], style="danger")]])


def adm_withdrawals(c, mid):
    ws = q("SELECT w.*, u.name FROM withdrawals w LEFT JOIN users u ON u.id=w.uid WHERE w.status='pending' ORDER BY w.id LIMIT 8")
    if not ws:
        return show(c, mid, "<b>📤 No pending withdrawals.</b>", [back("adm")])
    show(c, mid, "<blockquote><b>📤 PENDING WITHDRAWALS (%d shown)</b></blockquote>\n<i>Pay the UPI first, then tap Paid.</i>" % len(ws), [back("adm")])
    for w in ws:
        send(c, "<b>#%d</b> · %s (<code>%d</code>)\nAmount <b>%s</b>\nUPI: <code>%s</code>\n<i>%s</i>" % (w["id"], esc(w["name"]), w["uid"], fm(w["amount"]), esc(w["upi"]), w["created"]),
             [[B("✅ Paid", "wr:p:%d" % w["id"], style="success"), B("❌ Reject & refund", "wr:r:%d" % w["id"], style="danger")]])


def adm_user(c, mid, uid2):
    u = q1("SELECT * FROM users WHERE id=?", (uid2,))
    if not u:
        return send(c, "❌ User not found.", [back("adm")])
    txt = ("<blockquote><b>👤 USER %d</b></blockquote>\nName: %s %s\nDeposit: <b>%s</b> · Winning: <b>%s</b>\nPlayed %d · Won %d\nJoined: %s\nStatus: %s") % (
        uid2, esc(u["name"]), ("(@%s)" % esc(u["username"])) if u["username"] else "", fm(u["dep"]), fm(u["win"]), u["played"], u["wins"], esc(u["joined"]),
        "🚫 BANNED" if u["banned"] else "✅ active")
    kb = [[B("➕ Add balance", "uab:%d" % uid2, style="success"), B("➖ Deduct", "uad:%d" % uid2, style="danger")],
          [B("✅ Unban" if u["banned"] else "🚫 Ban", "ubn:%d" % uid2, style="primary")], back("adm")]
    return show(c, mid, txt, kb) if mid else send(c, txt, kb)


SET_KEYS = [("upi", "UPI ID"), ("qr", "UPI QR (photo)"), ("min_dep", "Min deposit"), ("min_wd", "Min withdraw"),
            ("support", "Support username"), ("brand", "Brand name"), ("txt_welcome", "Welcome text"), ("txt_terms", "Terms text")]


def adm_settings(c, mid):
    stored = {r["k"] for r in q("SELECT k FROM settings")}
    rows = []
    for k, label in SET_KEYS:
        v = S(k)
        if k == "qr":
            shown = "set ✅" if v else "—"
        elif k.startswith("txt_"):
            shown = "custom ✅" if k in stored else "default"
        else:
            shown = esc(v[:28] + ("…" if len(v) > 28 else "")) if v else "—"
        rows.append("• <b>%s:</b> %s" % (label, shown))
    kb = [[B("✏️ " + label, "set:" + k, style="primary")] for k, label in SET_KEYS]
    kb.append([B("🛠 Maintenance: %s" % ("ON" if S("maint") == "1" else "OFF"), "setm", style="danger" if S("maint") == "1" else "success")])
    kb.append(back("adm"))
    return show(c, mid, "<blockquote><b>⚙️ SETTINGS</b></blockquote>\n" + "\n".join(rows), kb)


def adm_stats(c, mid):
    g = lambda sql: q1(sql)[0] or 0
    txt = ("<blockquote><b>📊 STATS</b></blockquote>\nUsers: <b>%d</b> (banned %d)\nWallet total: <b>%s</b>\n"
           "Deposits approved: <b>%s</b> · pending %d\nWithdrawals paid: <b>%s</b> · pending %d\n"
           "Tournaments: upcoming %d · live %d · done %d · cancelled %d\nEntry fees collected: <b>%s</b>\nPrizes paid: <b>%s</b>") % (
        g("SELECT COUNT(*) FROM users"), g("SELECT COUNT(*) FROM users WHERE banned=1"), fm(g("SELECT SUM(dep+win) FROM users")),
        fm(g("SELECT SUM(amount) FROM deposits WHERE status='approved'")), g("SELECT COUNT(*) FROM deposits WHERE status='pending'"),
        fm(g("SELECT SUM(amount) FROM withdrawals WHERE status='paid'")), g("SELECT COUNT(*) FROM withdrawals WHERE status='pending'"),
        g("SELECT COUNT(*) FROM tournaments WHERE status='upcoming'"), g("SELECT COUNT(*) FROM tournaments WHERE status='live'"),
        g("SELECT COUNT(*) FROM tournaments WHERE status='completed'"), g("SELECT COUNT(*) FROM tournaments WHERE status='cancelled'"),
        fm(g("SELECT SUM(amount) FROM txns WHERE kind='join'")), fm(g("SELECT SUM(amount) FROM txns WHERE kind='prize'")))
    return show(c, mid, txt, [back("adm")])


def broadcast(c, html_text):
    ids = [r["id"] for r in q("SELECT id FROM users WHERE banned=0")]
    ok = fail = 0
    for i in ids:
        r = call("sendMessage", {"chat_id": i, "text": cut(html_text), "parse_mode": "HTML", "disable_web_page_preview": True})
        if bad(r):
            fail += 1
        else:
            ok += 1
        time.sleep(0.05)
    send(c, "📢 <b>Broadcast done.</b> Sent %d · Failed %d" % (ok, fail), [back("adm")])


# ============================================================ GATE
def gate(c, uid, u):
    if u and u["banned"] and not is_admin(uid):
        send(c, "🚫 <b>You are banned from this bot.</b>")
        return False
    if S("maint") == "1" and not is_admin(uid):
        send(c, "🛠 <b>Bot is under maintenance.</b>\nPlease try again later.")
        return False
    return True


# ============================================================ ROUTER (buttons)
ADMIN_KEYS = {"adm", "ag", "aga", "agd", "at", "atn", "atg", "ato", "atroom", "ats", "atr", "atrc", "atc", "atcc", "atp", "ad", "dp", "aw", "wr",
              "au", "uab", "uad", "ubn", "as", "set", "setm", "ab", "abc", "ast"}
KEEP_STATE = {"jc", "atrc", "abc", "wdc", "dpaid"}


def route(c, mid, uid, d, stt):
    a = d.split(":")
    k = a[0]
    arg = a[1] if len(a) > 1 else ""
    iarg = int(arg) if arg.lstrip("-").isdigit() else 0
    if k in ADMIN_KEYS and not is_admin(uid):
        return send(c, "❌ Admin only.")
    if d == "home":
        return home(c, mid, uid)
    if k == "g":
        return show_games(c, mid)
    if k == "gm":
        return show_game(c, mid, iarg)
    if k == "t":
        return show_tour(c, mid, uid, iarg)
    if k == "tp":
        return show_parts(c, mid, iarg)
    if k == "tr":
        return show_results(c, mid, iarg)
    if k == "jn":
        return join_start(c, mid, uid, iarg)
    if k == "ju":
        t = q1("SELECT gid FROM tournaments WHERE id=?", (iarg,))
        s = q1("SELECT name FROM ign WHERE uid=? AND gid=?", (uid, t["gid"])) if t else None
        return join_confirm(c, mid, uid, iarg, s["name"]) if s else show_tour(c, mid, uid, iarg)
    if k == "jc":
        s, data = stt
        if s != "join_ok" or data.get("tid") != iarg:
            return show(c, mid, "⌛ Session expired. Please try joining again.", [back("t:%d" % iarg)])
        st_clear(uid)
        res, slot = do_join(uid, iarg, data["ign"])
        msgs = {"closed": "❌ This tournament is not open any more.", "dup": "✅ You already joined this tournament.",
                "full": "🚫 Sorry, all slots just got filled.", "funds": "❌ Not enough balance."}
        if res != "ok":
            kb = [back("t:%d" % iarg)]
            if res == "funds":
                kb.insert(0, [B("➕ Add Money", "add", style="success")])
            return show(c, mid, msgs[res], kb)
        return show(c, mid, "🎉 <b>Joined successfully!</b>\nSlot <b>#%d</b> · IGN <code>%s</code>\nRoom ID &amp; password will be shown in the tournament page and sent here." % (slot, esc(data["ign"])),
                    [[B("🏟 Open Tournament", "t:%d" % iarg, style="success")], back("home", "🏠 Menu")])
    if k == "mm":
        return show_my_matches(c, mid, uid)
    if k == "w":
        return show_wallet(c, mid, uid)
    if k == "wh":
        return show_history(c, mid, uid)
    if k == "add":
        return add_money_start(c, mid, uid)
    if k == "dpaid":
        s, data = stt
        if s != "dep_pay":
            return show(c, mid, "⌛ Session expired. Start Add Money again.", [back("w")])
        st_set(uid, "dep_utr", data)
        return send(c, "<b>Send the UTR / transaction ID now.</b>\nYou can also send the payment <b>screenshot</b> with the UTR in the caption.", [back("w", "❌ Cancel")])
    if k == "wd":
        return wd_start(c, mid, uid)
    if k == "wdc":
        s, data = stt
        if s != "wd_ok":
            return show(c, mid, "⌛ Session expired.", [back("w")])
        st_clear(uid)
        wid = wd_create(uid, data["amt"], data["upi"])
        if wid is None:
            return show(c, mid, "❌ Not enough winning balance.", [back("w")])
        if wid == -1:
            return show(c, mid, "⏳ You already have 2 pending withdrawals. Wait for them to finish.", [back("w")])
        u = q1("SELECT name FROM users WHERE id=?", (uid,))
        notify_admins("<blockquote><b>📤 NEW WITHDRAWAL #%d</b></blockquote>\nUser: %s (<code>%d</code>)\nAmount: <b>%s</b>\nUPI: <code>%s</code>" % (wid, esc(u["name"]), uid, fm(data["amt"]), esc(data["upi"])),
                      [[B("✅ Paid", "wr:p:%d" % wid, style="success"), B("❌ Reject & refund", "wr:r:%d" % wid, style="danger")]])
        return show(c, mid, "✅ <b>Withdrawal requested.</b>\nAmount: <b>%s</b> · UPI: <code>%s</code>\nThe amount is held. You get a message when it is paid." % (fm(data["amt"]), esc(data["upi"])), [back("home", "🏠 Menu")])
    if k == "pf":
        return show_profile(c, mid, uid)
    if k == "terms":
        return show(c, mid, S("txt_terms"), [back()])
    if k == "help":
        return show(c, mid, "<b>ℹ️ Need help?</b>\nContact the admin of this bot.", [back()])
    # ---------------- admin ----------------
    if k == "adm":
        return adm_home(c, mid)
    if k == "ag":
        return adm_games(c, mid)
    if k == "aga":
        st_set(uid, "g_add")
        return show(c, mid, "<b>Send the game as:</b> <code>emoji name</code>\nExample: <code>🔥 Free Fire</code>", [back("ag", "❌ Cancel")])
    if k == "agd":
        if q1("SELECT 1 FROM tournaments WHERE gid=?", (iarg,)):
            return send(c, "❌ This game has tournaments, it cannot be deleted.", [back("ag")])
        x("DELETE FROM games WHERE id=?", (iarg,))
        return adm_games(c, mid)
    if k == "at":
        return adm_tours(c, mid)
    if k == "atn":
        gs = q("SELECT * FROM games WHERE active=1")
        if not gs:
            return show(c, mid, "❌ Add a game first.", [[B("➕ Add Game", "aga", style="success")], back("at")])
        kb = [[B("%s %s" % (g["emoji"], g["name"]), "atg:%d" % g["id"], style="success")] for g in gs]
        kb.append(back("at", "❌ Cancel"))
        return show(c, mid, "<b>Choose the game for the new tournament:</b>", kb)
    if k == "atg":
        st_set(uid, "t_new", {"gid": iarg})
        return show(c, mid, "<b>Send tournament details, one per line:</b>\n<code>Title\nMode (Solo/Duo/Squad)\nEntry fee\nPrize pool\nPer kill\nSlots\nStart time</code>\n\nExample:\n<code>Sunday Squad Rush\nSquad\n20\n500\n2\n48\nToday 8:00 PM</code>", [back("at", "❌ Cancel")])
    if k == "ato":
        return adm_tour(c, mid, iarg)
    if k == "atp":
        return show_parts(c, mid, iarg, admin=True)
    if k == "atroom":
        st_set(uid, "room", {"tid": iarg})
        return show(c, mid, "<b>Send Room ID and Password:</b> <code>RoomID | Password</code>\nPlayers who joined get it instantly.", [back("ato:%d" % iarg, "❌ Cancel")])
    if k == "ats":
        if len(a) > 2 and a[2] == "live":
            x("UPDATE tournaments SET status='live' WHERE id=? AND status='upcoming'", (iarg,))
            for p in q("SELECT uid FROM parts WHERE tid=?", (iarg,)):
                send(p["uid"], "🔴 <b>Your match is LIVE now!</b> Open the tournament for details.", [[B("🏟 Open", "t:%d" % iarg, style="success")]])
        return adm_tour(c, mid, iarg)
    if k == "atr":
        t = q1("SELECT * FROM tournaments WHERE id=?", (iarg,))
        if not t or t["status"] in ("completed", "cancelled"):
            return adm_tour(c, mid, iarg)
        st_set(uid, "res", {"tid": iarg})
        return show(c, mid, ("<b>🏁 Send results, one winner per line, 1st place first:</b>\n<code>slot prize kills</code>\n\nExample:\n<code>7 300 5\n12 150 3\n3 0 4</code>\n"
                             "Prize + kills × %s per kill is credited. Slot numbers are in Participants. Players not listed get nothing.") % fm(t["per_kill"]), [back("ato:%d" % iarg, "❌ Cancel")])
    if k == "atrc":
        s, data = stt
        if s != "res_ok" or data.get("tid") != iarg:
            return show(c, mid, "⌛ Session expired.", [back("ato:%d" % iarg)])
        st_clear(uid)
        out = apply_results(iarg, [tuple(r) for r in data["rows"]])
        if out is None:
            return show(c, mid, "❌ Results already done or tournament cancelled.", [back("ato:%d" % iarg)])
        t = q1("SELECT title FROM tournaments WHERE id=?", (iarg,))
        for puid, ign, rank, kills, total in out:
            send(puid, "🏆 <b>Result · %s</b>\nRank <b>#%d</b> · Kills <b>%d</b>\n%s" % (esc(t["title"]), rank, kills, ("💰 <b>%s</b> added to your Winning balance!" % fm(total)) if total else "Thanks for playing!"))
        for p in q("SELECT uid FROM parts WHERE tid=? AND rank=0", (iarg,)):
            send(p["uid"], "🏁 <b>Result is out for %s.</b> Check the tournament page." % esc(t["title"]))
        return show(c, mid, "✅ <b>Results saved.</b> %d winner(s) paid, tournament completed." % len(out), [back("at")])
    if k == "atc":
        return show(c, mid, "<b>⚠️ Cancel this tournament and refund every player's entry fee?</b>", [[B("✅ Yes, cancel & refund", "atcc:%d" % iarg, style="danger"), B("No", "ato:%d" % iarg, style="primary")]])
    if k == "atcc":
        r = cancel_tour(iarg)
        if r is None:
            return show(c, mid, "❌ Already completed or cancelled.", [back("at")])
        uids, t = r
        for u2 in uids:
            send(u2, "❌ <b>%s was cancelled.</b>%s" % (esc(t["title"]), ("\n💰 %s refunded to your Deposit balance." % fm(t["fee"])) if t["fee"] else ""))
        return show(c, mid, "✅ Cancelled. %d player(s) refunded." % len(uids), [back("at")])
    if k == "ad":
        return adm_deposits(c, mid)
    if k == "dp" and len(a) > 2:
        dep = dep_decide(int(a[2]), a[1] == "a")
        if not dep:
            return send(c, "ℹ️ Deposit #%s already handled." % a[2])
        if a[1] == "a":
            send(dep["uid"], "✅ <b>%s added to your wallet.</b> Good luck!" % fm(dep["amount"]), [[B("🎮 Play Now", "g", style="success")]])
        else:
            send(dep["uid"], "❌ <b>Your deposit of %s (UTR %s) was rejected.</b> Contact support if this is a mistake." % (fm(dep["amount"]), esc(dep["utr"])))
        return send(c, "%s Deposit #%s %s." % ("✅" if a[1] == "a" else "❌", a[2], "approved" if a[1] == "a" else "rejected"))
    if k == "aw":
        return adm_withdrawals(c, mid)
    if k == "wr" and len(a) > 2:
        w = wd_decide(int(a[2]), a[1] == "p")
        if not w:
            return send(c, "ℹ️ Withdrawal #%s already handled." % a[2])
        if a[1] == "p":
            send(w["uid"], "✅ <b>%s sent to your UPI</b> <code>%s</code>." % (fm(w["amount"]), esc(w["upi"])))
        else:
            send(w["uid"], "❌ <b>Withdrawal of %s rejected.</b> The amount is back in your Winning balance." % fm(w["amount"]))
        return send(c, "%s Withdrawal #%s %s." % ("✅" if a[1] == "p" else "❌", a[2], "marked paid" if a[1] == "p" else "rejected & refunded"))
    if k == "au":
        st_set(uid, "u_find")
        return show(c, mid, "<b>Send the user's Telegram ID</b> (number).", [back("adm", "❌ Cancel")])
    if k in ("uab", "uad"):
        st_set(uid, "u_amt", {"uid": iarg, "sign": 1 if k == "uab" else -1})
        return show(c, mid, "<b>Send the amount to %s</b> (Deposit balance)." % ("add" if k == "uab" else "deduct"), [back("adm", "❌ Cancel")])
    if k == "ubn":
        x("UPDATE users SET banned = 1 - banned WHERE id=?", (iarg,))
        return adm_user(c, mid, iarg)
    if k == "as":
        return adm_settings(c, mid)
    if k == "set":
        if arg == "qr":
            st_set(uid, "set_qr")
            return show(c, mid, "<b>Send your UPI QR as a photo.</b>", [back("as", "❌ Cancel")])
        st_set(uid, "set", {"key": arg})
        label = dict(SET_KEYS).get(arg, arg)
        return show(c, mid, "<b>Send the new value for %s.</b>%s" % (label, "\n<i>HTML tags like &lt;b&gt; are allowed.</i>" if arg.startswith("txt_") else ""), [back("as", "❌ Cancel")])
    if k == "setm":
        set_S("maint", "0" if S("maint") == "1" else "1")
        return adm_settings(c, mid)
    if k == "ab":
        st_set(uid, "bc")
        return show(c, mid, "<b>Send the broadcast message</b> (HTML allowed). It goes to every user.", [back("adm", "❌ Cancel")])
    if k == "abc":
        s, data = stt
        if s != "bc_ok":
            return show(c, mid, "⌛ Session expired.", [back("adm")])
        st_clear(uid)
        show(c, mid, "📢 Sending…", [])
        threading.Thread(target=broadcast, args=(c, data["html"]), daemon=True).start()
        return
    if k == "ast":
        return adm_stats(c, mid)
    return home(c, mid, uid)


# ============================================================ ROUTER (typed messages)
def num(text):
    try:
        v = float(text.strip().lstrip("₹").replace(",", ""))
        return round(v, 2) if v > 0 else None
    except ValueError:
        return None


def state_input(c, uid, s, data, msg):
    text = (msg.get("text") or "").strip()
    cap = (msg.get("caption") or "").strip()
    photo = msg["photo"][-1]["file_id"] if msg.get("photo") else ""
    if s == "ign":
        if not text or len(text) > 40:
            return send(c, "❌ Send your in-game name (max 40 characters).")
        return join_confirm(c, None, uid, data["tid"], text)
    if s == "dep_amt":
        v = num(text)
        mn = fnum("min_dep", 10)
        if v is None or v < mn or v > 100000:
            return send(c, "❌ Send a valid amount (minimum %s)." % fm(mn))
        return dep_pay_info(c, uid, v)
    if s == "dep_utr":
        return dep_submit(c, uid, data["amt"], text or cap, photo)
    if s == "wd_amt":
        v = num(text)
        d, w = balances(uid)
        mn = fnum("min_wd", 50)
        if v is None or v < mn or v > w:
            return send(c, "❌ Send an amount between %s and your winning balance %s." % (fm(mn), fm(w)))
        st_set(uid, "wd_upi", {"amt": v})
        return send(c, "<b>Now send your UPI ID</b> (example <code>name@upi</code>).", [back("w", "❌ Cancel")])
    if s == "wd_upi":
        if not UPI_RE.match(text):
            return send(c, "❌ Invalid UPI ID. Example: <code>name@okaxis</code>")
        st_set(uid, "wd_ok", {"amt": data["amt"], "upi": text})
        return send(c, "<blockquote><b>🧾 CONFIRM WITHDRAWAL</b></blockquote>\nAmount: <b>%s</b>\nUPI: <code>%s</code>" % (fm(data["amt"]), esc(text)),
                    [[B("✅ Confirm", "wdc", style="success"), B("❌ Cancel", "w", style="danger")]])
    if not is_admin(uid) or s in ("join_ok", "dep_pay", "wd_ok", "res_ok", "bc_ok"):
        st_clear(uid)
        return home(c, None, uid)
    if s == "g_add":
        parts = text.split(None, 1)
        if len(parts) < 2 or len(parts[1]) > 30:
            return send(c, "❌ Send like: <code>🔥 Free Fire</code>")
        x("INSERT INTO games(name,emoji) VALUES(?,?)", (parts[1].strip(), parts[0]))
        st_clear(uid)
        return send(c, "✅ Game added.", [[B("🎮 Games", "ag", style="primary")], back("adm")])
    if s == "t_new":
        v, err = parse_new_tour(text)
        if not v:
            return send(c, "❌ " + esc(err))
        tid = x("INSERT INTO tournaments(gid,title,mode,fee,pool,per_kill,slots,start,created) VALUES(?,?,?,?,?,?,?,?,?)",
                (data["gid"], v["title"], v["mode"], v["fee"], v["pool"], v["pk"], v["slots"], v["start"], now_s()))
        st_clear(uid)
        return send(c, "✅ <b>Tournament #%d created.</b> Players can join now." % tid, [[B("🏟 Manage", "ato:%d" % tid, style="success")], back("at")])
    if s == "room":
        rid, _, rpw = text.partition("|")
        if not rid.strip():
            return send(c, "❌ Send like: <code>RoomID | Password</code>")
        x("UPDATE tournaments SET room_id=?, room_pass=? WHERE id=?", (rid.strip()[:40], rpw.strip()[:40], data["tid"]))
        st_clear(uid)
        t = q1("SELECT title FROM tournaments WHERE id=?", (data["tid"],))
        n = 0
        for p in q("SELECT uid FROM parts WHERE tid=?", (data["tid"],)):
            send(p["uid"], "<blockquote><b>🔑 ROOM DETAILS · %s</b></blockquote>\nRoom ID: <code>%s</code>\nPassword: <code>%s</code>" % (esc(t["title"]), esc(rid.strip()), esc(rpw.strip())),
                 [[B("🏟 Open Tournament", "t:%d" % data["tid"], style="success")]])
            n += 1
        return send(c, "✅ Room saved and sent to %d player(s)." % n, [back("ato:%d" % data["tid"])])
    if s == "res":
        t = q1("SELECT * FROM tournaments WHERE id=?", (data["tid"],))
        rows, err = parse_results(text, t)
        if not rows:
            return send(c, "❌ " + err)
        lines, total = [], 0
        for i, (slot, prize, kills) in enumerate(rows, 1):
            p = q1("SELECT ign FROM parts WHERE tid=? AND slot=?", (t["id"], slot))
            amt = round(prize + kills * t["per_kill"], 2)
            total += amt
            lines.append("%d. #%d %s → <b>%s</b>" % (i, slot, esc(p["ign"]), fm(amt)))
        st_set(uid, "res_ok", {"tid": t["id"], "rows": rows})
        return send(c, "<blockquote><b>🏁 CONFIRM RESULTS</b></blockquote>\n%s\n\nTotal payout: <b>%s</b> (pool %s)" % ("\n".join(lines), fm(total), fm(t["pool"])),
                    [[B("✅ Confirm & pay", "atrc:%d" % t["id"], style="success"), B("❌ Cancel", "ato:%d" % t["id"], style="danger")]])
    if s == "u_find":
        if not text.isdigit():
            return send(c, "❌ Send the numeric Telegram ID.")
        st_clear(uid)
        return adm_user(c, None, int(text))
    if s == "u_amt":
        v = num(text)
        if v is None:
            return send(c, "❌ Send a valid amount.")
        with L:
            u = DB.execute("SELECT dep FROM users WHERE id=?", (data["uid"],)).fetchone()
            if not u:
                return send(c, "❌ User not found.")
            new = round(max(0.0, u["dep"] + data["sign"] * v), 2)
            DB.execute("UPDATE users SET dep=? WHERE id=?", (new, data["uid"]))
            txn(data["uid"], "adjust", abs(new - u["dep"]), "admin %s" % ("credit" if data["sign"] > 0 else "debit"))
            DB.commit()
        st_clear(uid)
        send(data["uid"], "ℹ️ Your wallet was %s by admin: <b>%s</b>." % ("credited" if data["sign"] > 0 else "debited", fm(v)))
        return adm_user(c, None, data["uid"])
    if s == "set":
        key = data.get("key")
        if key in ("min_dep", "min_wd"):
            v = num(text)
            if v is None:
                return send(c, "❌ Send a number.")
            text = str(v)
        elif key == "support":
            text = text.lstrip("@")
            if not re.match(r"^[A-Za-z0-9_]{4,32}$", text):
                return send(c, "❌ Send a Telegram username.")
        elif key == "upi" and not UPI_RE.match(text):
            return send(c, "❌ Invalid UPI ID.")
        elif not text or len(text) > 3500:
            return send(c, "❌ Send some text (max 3500 characters).")
        set_S(key, text)
        st_clear(uid)
        return send(c, "✅ Saved.", [[B("⚙️ Settings", "as", style="primary")]])
    if s == "set_qr":
        if not photo:
            return send(c, "❌ Send a photo.")
        set_S("qr", photo)
        st_clear(uid)
        return send(c, "✅ QR saved.", [[B("⚙️ Settings", "as", style="primary")]])
    if s == "bc":
        if not text:
            return send(c, "❌ Send text.")
        st_set(uid, "bc_ok", {"html": text})
        n = q1("SELECT COUNT(*) c FROM users WHERE banned=0")["c"]
        return send(c, "<b>Preview:</b>\n\n%s\n\nSend to <b>%d</b> users?" % (cut(text, 3000), n), [[B("✅ Send", "abc", style="success"), B("❌ Cancel", "adm", style="danger")]])


def handle_update(upd):
    if "callback_query" in upd:
        cq = upd["callback_query"]
        fr = cq["from"]
        uid = fr["id"]
        msg = cq.get("message") or {}
        c = (msg.get("chat") or {}).get("id", uid)
        mid = msg.get("message_id")
        d = cq.get("data", "")
        u = ensure_user(fr)
        if not gate(c, uid, u):
            return ack(cq["id"])
        ack(cq["id"])
        stt = st_get(uid)
        if d.split(":")[0] not in KEEP_STATE:
            st_clear(uid)
        return route(c, mid, uid, d, stt)
    msg = upd.get("message")
    if not msg or (msg.get("chat") or {}).get("type") != "private" or "from" not in msg:
        return
    fr = msg["from"]
    uid = fr["id"]
    c = msg["chat"]["id"]
    text = (msg.get("text") or "").strip()
    u = ensure_user(fr)
    if not gate(c, uid, u):
        return
    if text.startswith("/"):
        cmd = text.split()[0].split("@")[0].lower()
        st_clear(uid)
        if cmd in ("/start", "/menu"):
            return home(c, None, uid, u["name"])
        if cmd == "/admin":
            return adm_home(c, None) if is_admin(uid) else send(c, "❌ Admin only.")
        if cmd == "/cancel":
            return send(c, "✅ Cancelled.", [back("home", "🏠 Menu")])
        if cmd == "/help":
            return send(c, "<b>ℹ️ How it works</b>\n1. Add money to your wallet\n2. Pick a game and join a tournament\n3. Get Room ID &amp; password here\n4. Win, then withdraw to UPI", [back("home", "🏠 Menu")])
        return home(c, None, uid, u["name"])
    s, data = st_get(uid)
    if s:
        return state_input(c, uid, s, data, msg)
    return home(c, None, uid, u["name"])


def safe_handle(group):
    for upd in group:
        try:
            handle_update(upd)
        except Exception as e:
            log("handler error: %r" % (e,))


def set_menu_button(url):
    if url:
        tg("setChatMenuButton", {"menu_button": {"type": "web_app", "text": "🏆 PLAY", "web_app": {"url": url + "/"}}})


def on_tunnel_url(url):
    RT["url"] = url.rstrip("/")
    log("Mini App URL: %s" % RT["url"])
    if not S("webapp_url"):
        set_menu_button(RT["url"])
    notify_admins("<blockquote><b>🚀 MINI APP ONLINE</b></blockquote>\n<code>%s</code>" % esc(RT["url"]),
                  [[B("🚀 Open App", web=RT["url"] + "/", style="success")]])


def start_web_stack(me):
    """Mini App web server + Cloudflare tunnel + auto-payment checker."""
    try:
        import webapp
        import tunnel
    except Exception as e:  # keep the classic bot alive even if web part is broken
        log("web app disabled: %r" % (e,))
        return
    me_mod = sys.modules[__name__]
    port = webapp.start(me_mod, WEB_PORT)
    log("web app listening on 127.0.0.1:%d" % port)
    if S("webapp_url"):
        set_menu_button(S("webapp_url").rstrip("/"))
    if os.getenv("DISABLE_TUNNEL", "") != "1":
        tunnel.start(BASE, port, on_tunnel_url, log)
    elif RT["url"]:
        set_menu_button(RT["url"])


def main():
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN missing")
    if not ADMINS:
        log("WARNING: ADMIN_IDS is empty - nobody can open /admin")
    me = tg("getMe")
    if bad(me):
        raise SystemExit("Invalid BOT_TOKEN: %s" % me["_err"])
    tg("deleteWebhook", {"drop_pending_updates": True})
    start_web_stack(me)
    tg("setMyCommands", {"commands": [{"command": "start", "description": "Open the menu"}, {"command": "admin", "description": "Admin panel"},
                                      {"command": "help", "description": "How it works"}, {"command": "cancel", "description": "Cancel current action"}]})
    log("%s started: @%s admins=%s" % (S("brand"), me.get("username", ""), ADMINS))
    pool = ThreadPoolExecutor(max_workers=16)
    offset = 0
    while True:
        try:
            r = SESSION.post(API + "/getUpdates", json={"offset": offset, "timeout": 50, "allowed_updates": ["message", "callback_query"]}, timeout=65)
            j = r.json()
        except (requests.RequestException, ValueError):
            time.sleep(3)
            continue
        if not j.get("ok"):
            log("getUpdates: %s" % str(j)[:200])
            time.sleep(5)
            continue
        groups = {}
        for upd in j.get("result", []):
            offset = max(offset, upd["update_id"] + 1)
            uid = (upd.get("callback_query") or upd.get("message") or {}).get("from", {}).get("id", 0)
            groups.setdefault(uid, []).append(upd)
        for g in groups.values():
            pool.submit(safe_handle, g)


if __name__ == "__main__":
    main()
