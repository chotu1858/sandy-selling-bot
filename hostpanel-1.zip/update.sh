#!/usr/bin/env bash
# Run after copying new files:  bash update.sh
# Restarts ONLY the panel. Your data, keys, bots and panel.env are kept. Hosted bots keep running.
cd "$(dirname "$0")" || exit 1
[ -d venv ] || { echo "venv missing - run: bash install.sh"; exit 1; }
./venv/bin/pip install -q flask "python-telegram-bot[job-queue]" requests qrcode pillow
pkill -f "venv/bin/python app.py" 2>/dev/null || true
sleep 1
if [ "$(id -u)" = "0" ] && command -v systemctl >/dev/null 2>&1 && [ -f /etc/systemd/system/bothost.service ]; then
  systemctl restart bothost
else
  nohup ./venv/bin/python app.py > panel.log 2>&1 &
fi
sleep 3
tail -n 5 panel.log 2>/dev/null
echo
echo "Panel updated."
echo "Website : /        Buyer login : /login        Owner : /admin"
echo "Next: open /admin -> Settings and add your FMPay key + UPI ID."
