# -*- coding: utf-8 -*-
"""All HTML/CSS/JS for the panel (kept apart from app.py so the backend stays readable)."""
import re

DEFAULT_TAG = "Enter your details. Your bot goes live in seconds, no server needed."

# id: (name, bg, s1, s2, line, tx, mu, ac, red, glow-rgb)
_T = {
    "lime":   ("Lime Night",   "#07090f", "#0f1320", "#161c2f", "#232b43", "#eef1f8", "#8b93ab", "#c6ff3d", "#ff9aa4", "91,140,255"),
    "neon":   ("Neon Purple",  "#0a0614", "#130a24", "#1c1033", "#34205a", "#f3ecff", "#9b8bb8", "#b86bff", "#ff9ab8", "255,70,190"),
    "cyber":  ("Cyber Blue",   "#040b14", "#08162a", "#0d2140", "#163a63", "#e6f4ff", "#7f9bb8", "#22d3ee", "#ff9aa4", "40,110,255"),
    "gold":   ("Gold Luxury",  "#0b0905", "#17130a", "#221b0e", "#3d3218", "#fff6e0", "#a89878", "#ffc94d", "#ff9a8a", "255,140,40"),
    "rose":   ("Rose Fire",    "#0f0609", "#1c0b12", "#2a1019", "#4a1a2b", "#ffecf1", "#b88a99", "#ff4d7e", "#ffb3c4", "255,120,60"),
    "matrix": ("Matrix Green", "#020a04", "#07140a", "#0b1f0f", "#12381b", "#e4ffe9", "#74a37e", "#39ff7a", "#ff9aa4", "0,200,120"),
    "light":  ("Clean Light",  "#eef2fb", "#ffffff", "#f1f4fb", "#dbe2f2", "#0f172a", "#64708a", "#5b5bff", "#d0283a", "120,120,255"),
}
THEMES = {k: {"name": v[0], "bg": v[1], "s1": v[2], "s2": v[3], "line": v[4], "tx": v[5], "mu": v[6],
              "ac": v[7], "red": v[8], "glow": v[9]} for k, v in _T.items()}


def _rgb(hexcol: str) -> tuple:
    h = hexcol.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def theme_vars(theme_id: str, accent: str = "") -> dict:
    t = dict(THEMES.get(theme_id) or THEMES["lime"])
    if accent and re.fullmatch(r"#[0-9a-fA-F]{6}", accent):
        t["ac"] = accent
    r, g, b = _rgb(t["ac"])
    t["act"] = "#0b0f0a" if (0.299 * r + 0.587 * g + 0.114 * b) > 150 else "#ffffff"
    t["acrgb"] = f"{r},{g},{b}"
    return t


def theme_css(theme_id: str, accent: str = "") -> str:
    t = theme_vars(theme_id, accent)
    return ":root{" + ";".join(f"--{k}:{t[k]}" for k in
                                ("bg", "s1", "s2", "line", "tx", "mu", "ac", "act", "red", "glow", "acrgb")) + "}"


CSS = r"""
:root{--bg:#07090f;--s1:#0f1320;--s2:#161c2f;--line:#232b43;--tx:#eef1f8;--mu:#8b93ab;--ac:#c6ff3d;--act:#0b1200;--red:#ff9aa4;--glow:91,140,255;--acrgb:198,255,61;--amber:#ffb020}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;color:var(--tx);font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;-webkit-font-smoothing:antialiased}
body{min-height:100vh;padding:0 16px 40px;background:radial-gradient(90% 40% at 100% 0,rgba(var(--glow),.18),transparent 60%),radial-gradient(70% 34% at 0 10%,rgba(var(--acrgb),.10),transparent 62%),var(--bg)}
button,input,select,textarea{font:inherit;color:inherit}
.wrap{max-width:980px;margin:0 auto}
.top{display:flex;align-items:center;gap:10px;padding:16px 0;flex-wrap:wrap}
.logo{width:38px;height:38px;border-radius:12px;background:var(--ac);color:var(--act);display:grid;place-items:center;font-weight:900}
.top b{font-size:17px;flex:1;min-width:90px}
a.mini,.mini{border:1px solid var(--line);background:var(--s1);color:var(--mu);border-radius:11px;padding:8px 12px;font-size:12.5px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-block}
.card{background:var(--s1);border:1px solid var(--line);border-radius:20px;padding:16px;margin-bottom:14px}
h2{margin:0 0 12px;font-size:15px}
.inp{width:100%;border:1.5px solid var(--line);background:var(--s2);border-radius:13px;padding:13px;font-size:15px;font-weight:600;outline:0;margin-bottom:10px}
.inp:focus{border-color:var(--ac)}
textarea.inp{min-height:84px;resize:vertical}
.big{display:block;width:100%;text-align:center;text-decoration:none;border:0;border-radius:14px;padding:14px;background:var(--ac);color:var(--act);font-weight:800;font-size:15px;cursor:pointer}
.big.alt{background:var(--s2);color:var(--tx);border:1px solid var(--line);margin-bottom:10px}
.big:disabled{opacity:.5}
.msg{margin-top:10px;font-size:13px;font-weight:600;min-height:18px;line-height:1.5}
.msg.err{color:var(--red)}.msg.ok{color:var(--ac)}
.meta{color:var(--mu);font-size:12px;margin-bottom:8px;font-weight:600;line-height:1.5}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:14px}
@media(min-width:700px){.grid{grid-template-columns:repeat(4,1fr)}}
.stat{background:var(--s1);border:1px solid var(--line);border-radius:18px;padding:14px}
.stat small{display:block;color:var(--mu);font-size:11px;font-weight:700;letter-spacing:.8px;text-transform:uppercase}
.stat b{display:block;font-size:24px;margin-top:6px;font-variant-numeric:tabular-nums}
.stat.hot b{color:var(--ac)}.stat i{font-style:normal;color:var(--mu);font-size:12px}
.bots{display:grid;gap:12px}
@media(min-width:760px){.bots{grid-template-columns:1fr 1fr}}
.bot{background:var(--s1);border:1px solid var(--line);border-radius:20px;padding:15px}
.bh{display:flex;align-items:center;gap:10px;margin-bottom:12px}
.bh b{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.badge{font-size:11px;font-weight:800;border-radius:999px;padding:4px 10px}
.running{background:rgba(var(--acrgb),.16);color:var(--ac)}.stopped{background:rgba(139,147,171,.2);color:var(--mu)}
.crashed,.expired,.suspended{background:rgba(255,93,108,.16);color:var(--red)}
.mm{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}
.mm div{background:var(--s2);border-radius:12px;padding:9px}
.mm small{display:block;color:var(--mu);font-size:10.5px;font-weight:700}.mm b{font-size:15px}
.bar{height:6px;background:var(--s2);border-radius:9px;overflow:hidden;margin-bottom:12px}
.bar span{display:block;height:100%;background:var(--ac)}
.acts{display:flex;flex-wrap:wrap;gap:7px}
.acts button{border:1px solid var(--line);background:var(--s2);border-radius:10px;padding:8px 11px;font-size:12.5px;font-weight:700;cursor:pointer}
.acts .g{color:var(--ac)}.acts .r{color:var(--red)}
.row{display:flex;align-items:center;gap:8px;padding:9px 0;border-top:1px solid var(--line);font-size:13px;font-weight:600}
.row code{flex:1;font-size:13.5px;letter-spacing:.4px;word-break:break-all}.row span{color:var(--mu);font-size:12px}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.row3{display:grid;grid-template-columns:2fr 1fr 1fr;gap:10px}
pre{background:rgba(0,0,0,.28);border:1px solid var(--line);border-radius:12px;padding:12px;font-size:11.5px;line-height:1.5;max-height:55vh;overflow:auto;white-space:pre-wrap;word-break:break-all}
.modal{position:fixed;inset:0;background:rgba(0,0,0,.7);display:none;align-items:flex-start;justify-content:center;padding:16px;z-index:9;overflow:auto}
.modal.on{display:flex}.modal .card{width:100%;max-width:640px;margin:20px 0}
.toast{position:fixed;left:50%;bottom:24px;transform:translate(-50%,20px);background:#fff;color:#0b1200;padding:10px 16px;border-radius:12px;font-size:13px;font-weight:700;opacity:0;pointer-events:none;transition:.25s;z-index:20;max-width:90vw}
.toast.on{opacity:1;transform:translate(-50%,0)}
.hero{text-align:center;padding:22px 0 16px}.hero h1{margin:0 0 8px;font-size:28px;letter-spacing:-.5px}.hero p{margin:0;color:var(--mu);font-size:14px;line-height:1.55}
.plans{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:6px}
.plan{background:var(--s2);border:1.5px solid var(--line);border-radius:16px;padding:14px;text-align:center;cursor:pointer}
.plan:hover,.plan.on{border-color:var(--ac)}
.plan b{display:block;font-size:15px}.plan .pr{font-size:24px;font-weight:900;color:var(--ac);margin:6px 0}.plan small{color:var(--mu);font-weight:600}
.steps{color:var(--mu);font-size:12.5px;line-height:1.7;margin:4px 2px 14px}.steps b{color:var(--tx)}
.payrow{display:flex;gap:14px;align-items:center;margin-bottom:12px;flex-wrap:wrap}
.qr{width:150px;height:150px;border-radius:14px;background:#fff;padding:6px}
.amt{font-size:30px;font-weight:900;color:var(--ac);margin-bottom:8px}
.upi{display:flex;gap:8px;align-items:center}.upi code{font-size:14px;word-break:break-all}
.keyshow{font-size:22px;font-weight:900;letter-spacing:1px;text-align:center;padding:16px;background:var(--s2);border:1.5px dashed var(--ac);border-radius:14px;margin:10px 0;word-break:break-all;color:var(--ac)}
.sw{display:grid;grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:9px;margin-bottom:12px}
.sw button{border:2px solid var(--line);background:var(--s2);border-radius:14px;padding:10px;cursor:pointer;font-size:12px;font-weight:700}
.sw button.on{border-color:var(--ac)}.sw i{display:flex;height:22px;border-radius:7px;overflow:hidden;margin-bottom:7px}.sw i s{flex:1}
label.chk{display:flex;gap:10px;align-items:center;font-size:13.5px;font-weight:600;margin:6px 0 12px}
label.chk input{width:18px;height:18px;accent-color:var(--ac)}
.sec{margin:16px 0 8px;font-size:12px;letter-spacing:.8px;text-transform:uppercase;color:var(--mu);font-weight:800}
.warn{background:rgba(255,176,32,.12);border:1px solid rgba(255,176,32,.4);color:var(--amber);border-radius:14px;padding:11px 13px;font-size:13px;font-weight:600;margin-bottom:14px;line-height:1.5}
.tabs{display:flex;gap:8px;margin-bottom:14px}.tabs a{flex:1;text-align:center}
"""

HEAD = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>__TITLE__</title><style>""" + CSS + r"""__THEME__</style></head>"""

JS_COMMON = r"""
const $=i=>document.getElementById(i);
const esc=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const inr=n=>"₹"+Number(n||0).toLocaleString("en-IN",{maximumFractionDigits:2});
let _tt;function toast(s){const e=$("toast");e.textContent=s;e.classList.add("on");clearTimeout(_tt);_tt=setTimeout(()=>e.classList.remove("on"),2800)}
function copy(t){try{navigator.clipboard.writeText(t);toast("Copied")}catch(e){toast("Copy failed")}}
async function J(url,body,csrf){const h={"Content-Type":"application/json"};if(csrf)h["X-CSRF"]=csrf;
 try{const r=await fetch(url,{method:body===undefined?"GET":"POST",headers:h,body:body===undefined?undefined:JSON.stringify(body)});
 if(r.status===401&&csrf!==undefined){location.href=csrf_login;return {ok:false,message:"Login again."}}
 return await r.json()}catch(e){return {ok:false,message:"No connection. Try again."}}}
var csrf_login="/login";
"""

# ───────────────────────── shared payment box (landing + user renew) ─────────────────────────
PAYBOX = r"""
<div class="card" id="paybox" style="display:none">
<h2 id="pb_title">Pay and get your key</h2>
<div class="payrow"><img id="pb_qr" class="qr" alt="UPI QR" style="display:none"><div>
<div class="meta">Amount to pay</div><div class="amt" id="pb_amt"></div>
<div class="meta">UPI ID</div><div class="upi"><code id="pb_upi"></code><button class="mini" id="pb_copy" type="button">Copy</button></div></div></div>
<a class="big alt" id="pb_app" href="#">Pay with UPI app</a>
<div class="steps">Pay the <b>exact amount</b>, then paste the <b>UTR / transaction ID</b> from your payment app below.</div>
<input class="inp" id="pb_utr" placeholder="UTR / Transaction ID" autocomplete="off" autocapitalize="characters">
<button class="big" id="pb_go" type="button">Verify payment</button><div class="msg" id="pb_msg"></div></div>
<div class="card" id="keybox" style="display:none"><h2 id="kb_title">Payment received</h2>
<div id="kb_body"></div></div>
"""

PAYJS = r"""
var ORDER=null,PAYMODE_RENEW=false;
function lsGet(k){try{return localStorage.getItem(k)}catch(e){return null}}
function lsSet(k,v){try{v===null?localStorage.removeItem(k):localStorage.setItem(k,v)}catch(e){}}
function showOrder(o,renew){
 ORDER=o;$("keybox").style.display="none";
 if(o.status==="paid"){showPaid(o,renew);return}
 $("paybox").style.display="block";$("pb_amt").textContent=inr(o.amount);$("pb_upi").textContent=o.upi_id;
 $("pb_title").textContent="Pay for "+o.plan+" ("+o.days+" days)";
 $("pb_app").href=o.upi_link;
 if(o.qr){$("pb_qr").src=o.qr;$("pb_qr").style.display="block"}else $("pb_qr").style.display="none";
 $("pb_msg").textContent="";$("pb_utr").value="";
 $("paybox").scrollIntoView({behavior:"smooth",block:"start"});
}
function showPaid(o,renew){
 $("paybox").style.display="none";$("keybox").style.display="block";
 if(o.renew){$("kb_title").textContent="Plan extended";$("kb_body").innerHTML='<p class="meta">Your plan was extended by '+o.days+' days. Thank you!</p>';lsSet("bh_order",null);if(window.onRenewed)onRenewed();return}
 $("kb_title").textContent="Payment received. Here is your access key";
 $("kb_body").innerHTML='<div class="keyshow">'+esc(o.key)+'</div><button class="big alt" type="button" onclick="copy(\''+esc(o.key)+'\')">Copy key</button>'+
 '<a class="big" href="#launch" onclick="useKey(\''+esc(o.key)+'\')">Launch my bot now</a><div class="meta" style="margin-top:10px">Save this key. You can use it to login later at /login.</div>';
 $("keybox").scrollIntoView({behavior:"smooth",block:"start"});
}
async function startOrder(pid,renew){
 const j=await J("/api/order/create",{plan_id:pid,renew:!!renew});
 if(!j.ok){toast(j.message||"Could not create order");return}
 lsSet("bh_order",j.order.id);showOrder(j.order,renew);
}
$("pb_copy").onclick=()=>copy($("pb_upi").textContent);
$("pb_go").onclick=async()=>{
 if(!ORDER)return;const m=$("pb_msg");const u=$("pb_utr").value.trim();
 if(u.length<10){m.className="msg err";m.textContent="Enter the full UTR / transaction ID.";return}
 $("pb_go").disabled=true;$("pb_go").textContent="Verifying… (up to a minute)";m.className="msg";m.textContent="";
 const j=await J("/api/order/"+ORDER.id+"/verify",{utr:u});
 $("pb_go").disabled=false;$("pb_go").textContent="Verify payment";
 if(j.ok){showPaid(j.order)}else{m.className="msg err";m.textContent=j.message||"Payment not verified."}
};
async function resumeOrder(){
 const id=lsGet("bh_order");if(!id)return;
 const j=await J("/api/order/"+id);if(j.ok&&j.order&&(!j.order.renew||PAYMODE_RENEW))showOrder(j.order);else if(!j.ok)lsSet("bh_order",null);
}
"""

# ───────────────────────── landing ─────────────────────────
LANDING = HEAD + r"""<body><div class="wrap" style="max-width:520px">
<div class="top"><div class="logo">__LOGO__</div><b>__BRAND__</b><a class="mini" href="/login">Login</a></div>
<div class="hero"><h1>Launch your store bot</h1><p>__TAG__</p></div>

<div class="card" id="plans_card"><h2>1. Buy an access key</h2>
<div class="plans" id="plans"><div class="meta">Loading plans…</div></div>
<div class="meta" id="plans_note"></div></div>
""" + PAYBOX + r"""
<div class="card" id="form"><h2 id="launch">2. Launch your bot</h2>
<div class="steps"><b>•</b> Create a bot in @BotFather and copy its token<br><b>•</b> Get your numeric ID from @userinfobot<br><b>•</b> Paste everything below</div>
<input class="inp" id="key" placeholder="Access key  (XXXX-XXXX-XXXX-XXXX)" autocomplete="off" autocapitalize="characters">
<input class="inp" id="token" placeholder="Bot token" autocomplete="off" spellcheck="false">
<input class="inp" id="admin" placeholder="Admin Telegram ID" inputmode="numeric" autocomplete="off">
<button class="big" id="go" type="button">Launch my bot</button><div class="msg" id="msg"></div></div>

<div class="card" id="done" style="display:none;text-align:center"><h2 style="font-size:22px;color:var(--ac)">Your bot is live</h2>
<p id="dt" class="meta" style="font-size:14px"></p>
<a class="big" id="open" href="#">Open my bot</a><a class="big alt" style="margin-top:10px" href="/dashboard">Go to my dashboard</a></div>
<div class="meta" style="text-align:center" id="support"></div>
</div><div class="toast" id="toast"></div>
<script>""" + JS_COMMON + PAYJS + r"""
function useKey(k){$("key").value=k;$("token").focus()}
async function init(){
 const d=await J("/api/public");
 if(d.support){$("support").innerHTML='Need help? <a style="color:var(--ac)" href="'+esc(d.support)+'" target="_blank" rel="noopener">Contact support</a>'}
 if(!d.pay_ready||!d.plans.length){$("plans").innerHTML="";$("plans_note").textContent=d.plans.length?"Online payment is not set up yet. Ask the owner for an access key.":"Plans are not available right now. Ask the owner for an access key."}
 else $("plans").innerHTML=d.plans.map(p=>'<div class="plan" data-p="'+p.id+'"><b>'+esc(p.name)+'</b><div class="pr">'+inr(p.price)+'</div><small>'+(p.days>=36500?'Lifetime':p.days+' days')+'</small></div>').join("");
 resumeOrder();
}
document.addEventListener("click",e=>{const p=e.target.closest("[data-p]");if(p)startOrder(parseInt(p.dataset.p,10),false)});
$("go").onclick=async()=>{const m=$("msg");m.className="msg";m.textContent="";$("go").disabled=true;$("go").textContent="Launching…";
 const j=await J("/api/deploy",{key:$("key").value,token:$("token").value.trim(),admin:$("admin").value});
 if(j.ok){$("form").style.display="none";$("paybox").style.display="none";$("keybox").style.display="none";$("plans_card").style.display="none";$("done").style.display="block";
  $("open").href="https://t.me/"+j.username;$("open").textContent="Open @"+j.username;lsSet("bh_order",null);
  $("dt").textContent="Send /start to your bot, then open Admin Panel inside it to add products and payment settings. Plan: "+(j.days>=36500?"Lifetime":j.days+" days")+". Your key is your dashboard login."}
 else{m.className="msg err";m.textContent=j.message||"Something went wrong."}
 $("go").disabled=false;$("go").textContent="Launch my bot"};
init();
</script></body></html>"""

# ───────────────────────── user login ─────────────────────────
USER_LOGIN = HEAD + r"""<body><div class="wrap" style="max-width:400px;padding-top:10vh">
<div class="logo" style="margin:0 auto 18px;width:52px;height:52px;font-size:22px">__LOGO__</div>
<div class="card"><h2>__BRAND__ · My bot dashboard</h2>
<div class="meta">Login with the access key you used to launch your bot.</div>
<input class="inp" id="key" placeholder="Access key" autocomplete="off" autocapitalize="characters">
<button class="big" id="go" type="button">Login</button><div class="msg" id="msg"></div>
<div class="meta" style="margin-top:12px;text-align:center"><a style="color:var(--ac)" href="/">Buy a key or launch a bot</a></div></div></div>
<div class="toast" id="toast"></div>
<script>""" + JS_COMMON + r"""
$("go").onclick=async()=>{const m=$("msg");m.className="msg";$("go").disabled=true;
 const j=await J("/api/user/login",{key:$("key").value});
 if(j.ok)location.href="/dashboard";else{m.className="msg err";m.textContent=j.message||"Login failed."}$("go").disabled=false};
$("key").addEventListener("keydown",e=>{if(e.key==="Enter")$("go").click()});
</script></body></html>"""

# ───────────────────────── user dashboard ─────────────────────────
USER_DASH = HEAD + r"""<body><div class="wrap" style="max-width:560px">
<div class="top"><div class="logo">__LOGO__</div><b>__BRAND__</b><a class="mini" href="/logout">Logout</a></div>
<div id="susp"></div>
<div class="card" id="head"></div>
<div class="card"><h2>Control</h2><div class="acts" id="ctl"></div><div class="msg" id="cmsg"></div></div>

<div class="card"><h2>Bot token</h2><div class="meta">Paste a new token from @BotFather. If it is a different bot, your store data stays safe, but customers must start the new bot.</div>
<input class="inp" id="n_token" placeholder="New bot token" autocomplete="off" spellcheck="false"><button class="big" data-do="token">Change token</button></div>

<div class="card"><h2>Admin IDs</h2><div class="meta">Numeric Telegram IDs. Use commas for more than one.</div>
<input class="inp" id="n_admin" placeholder="Admin Telegram ID(s)" inputmode="numeric"><button class="big" data-do="admin">Save admin IDs</button></div>

<div class="card"><h2>Store details</h2>
<input class="inp" id="n_name" placeholder="Store name" maxlength="40"><input class="inp" id="n_support" placeholder="Support username (@name)" maxlength="33">
<button class="big" data-do="store">Save store details</button></div>

<div class="card"><h2>Renew your plan</h2>
<div class="meta">Have a new key? Paste it here.</div>
<input class="inp" id="n_key" placeholder="New access key" autocapitalize="characters" autocomplete="off"><button class="big alt" data-do="renew_key">Apply key</button>
<div class="meta" style="margin-top:6px">Or pay online:</div><div class="plans" id="plans"></div></div>
""" + PAYBOX + r"""
<div class="card"><h2>My data</h2><div class="acts"><button onclick="location.href='/api/user/export/users.csv'">Download users CSV</button><button onclick="location.href='/api/user/export/orders.csv'">Download orders CSV</button><button id="logb">View bot logs</button></div></div>
<div class="msg" id="msg"></div>
</div>
<div class="modal" id="lm"><div class="card"><h2>Logs</h2><pre id="lp"></pre><button class="big" id="lc" style="margin-top:12px">Close</button></div></div>
<div class="toast" id="toast"></div>
<script>const CSRF="__CSRF__";""" + JS_COMMON + PAYJS + r"""
var PLANS=[];PAYMODE_RENEW=true;
const U=(url,body)=>J(url,body,CSRF);
function fillEdit(d){$("n_admin").value=d.admin_ids;$("n_name").value=d.store_name||"";$("n_support").value=d.support||""}
function render(d){
 $("susp").innerHTML=d.suspended?'<div class="warn">This bot is suspended by the owner. Contact support.</div>':"";
 const left=d.expires?(d.days_left>=0?Math.ceil(d.days_left)+" days left":"expired"):"Lifetime";
 const pct=d.expires?Math.max(0,Math.min(100,d.days_left/d.plan_days*100)):100;
 $("head").innerHTML='<div class="bh"><b>@'+esc(d.username)+'</b><span class="badge '+d.status+'">'+d.status+'</span></div>'+
 '<div class="mm"><div><small>PLAN</small><b style="font-size:13px">'+left+'</b></div><div><small>USERS</small><b>'+d.users+'</b></div><div><small>ORDERS</small><b>'+d.orders+'</b></div>'+
 '<div><small>REVENUE</small><b>'+inr(d.revenue)+'</b></div><div><small>TODAY</small><b>'+inr(d.today)+'</b></div><div><small>DEPOSITS</small><b>'+inr(d.deposits)+'</b></div></div>'+
 '<div class="bar"><span style="width:'+pct+'%"></span></div><div class="meta">Expires: '+(d.expires?esc(d.expires)+" UTC":"never")+' · Key: '+esc(d.key)+'</div>';
 $("ctl").innerHTML='<button class="g" data-do="start">Start</button><button data-do="restart">Restart</button><button data-do="stop">Stop</button>';
}
async function load(first){const d=await U("/api/user/me");if(!d.ok)return;render(d.bot);if(first){fillEdit(d.bot);PLANS=d.plans;
 $("plans").innerHTML=d.plans.length&&d.pay_ready?d.plans.map(p=>'<div class="plan" data-p="'+p.id+'"><b>'+esc(p.name)+'</b><div class="pr">'+inr(p.price)+'</div><small>'+(p.days>=36500?'Lifetime':p.days+' days')+'</small></div>').join(""):'<div class="meta">Online renew is not available. Use a key.</div>'}}
window.onRenewed=()=>load(false);
document.addEventListener("click",async e=>{
 const p=e.target.closest("[data-p]");if(p){startOrder(parseInt(p.dataset.p,10),true);return}
 const b=e.target.closest("[data-do]");if(!b)return;const a=b.dataset.do;let body={};
 if(a==="token")body={token:$("n_token").value.trim()};
 if(a==="admin")body={admin:$("n_admin").value};
 if(a==="store")body={name:$("n_name").value,support:$("n_support").value};
 if(a==="renew_key")body={key:$("n_key").value};
 if(a==="token"&&!confirm("Change the bot token now? The bot will restart."))return;
 b.disabled=true;const j=await U("/api/user/"+a,body);b.disabled=false;
 const m=$("msg");m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";toast(j.message||"Done");
 if(j.ok){if(a==="token")$("n_token").value="";if(a==="renew_key")$("n_key").value="";load(a==="renew_key"||a==="token"||a==="admin"||a==="store")}});
$("logb").onclick=async()=>{const j=await U("/api/user/log");$("lp").textContent=j.log||j.message||"";$("lm").classList.add("on");$("lp").scrollTop=1e9};
$("lc").onclick=()=>$("lm").classList.remove("on");
load(true);setInterval(()=>load(false),10000);resumeOrder();
</script></body></html>"""

# ───────────────────────── owner login ─────────────────────────
ADMIN_LOGIN = HEAD + r"""<body><div class="wrap" style="max-width:380px;padding-top:12vh"><div class="logo" style="margin:0 auto 18px;width:52px;height:52px;font-size:22px">__LOGO__</div>
<div class="card"><h2>__BRAND__ · Owner login</h2><form method="post">__FORM__<div class="msg err">__ERR__</div></form></div></div></body></html>"""

FORM_PW = r"""<input class="inp" type="password" name="password" placeholder="Panel password" autofocus><button class="big">Login</button>"""
FORM_OTP = r"""<div class="meta">A 6-digit code was sent to your Telegram.</div><input class="inp" name="otp" placeholder="6-digit code" inputmode="numeric" maxlength="6" autocomplete="one-time-code" autofocus><button class="big">Verify</button>"""

# ───────────────────────── owner dashboard ─────────────────────────
ADMIN_DASH = HEAD + r"""<body><div class="wrap">
<div class="top"><div class="logo">__LOGO__</div><b>__BRAND__</b><a class="mini" href="/" target="_blank">Website</a><button class="mini" id="setb">Settings</button><button class="mini" id="rall">Restart all</button><a class="mini" href="/admin/logout">Logout</a></div>
<div id="alerts"></div>
<div class="grid" id="tot"></div>
<div class="meta" id="srv" style="margin:-4px 2px 14px"></div>

<div class="card"><h2>Revenue by bot</h2><div id="rev" class="meta">Loading…</div></div>

<div class="card"><h2>Plans (shown on your website)</h2><div id="plans"></div>
<div class="row3" style="margin-top:12px"><input class="inp" id="p_name" placeholder="Plan name (e.g. 30 Days)"><input class="inp" id="p_days" placeholder="Days" inputmode="numeric"><input class="inp" id="p_price" placeholder="Price ₹" inputmode="decimal"></div>
<button class="big" id="p_go">Add plan</button><div class="meta" style="margin-top:8px">Tip: use 36500 days for a Lifetime plan.</div></div>

<div class="card"><h2>Web orders (auto payment)</h2><div id="orders" class="meta">No orders yet.</div></div>

<div class="card"><h2>Host a bot (owner)</h2>
<input class="inp" id="o_token" placeholder="Bot token" autocomplete="off" spellcheck="false">
<div class="row2"><input class="inp" id="o_admin" placeholder="Admin Telegram ID" inputmode="numeric"><input class="inp" id="o_days" placeholder="Days" inputmode="numeric" value="__DEFDAYS__"></div>
<button class="big" id="o_go">Host bot now</button><div class="msg" id="o_msg"></div></div>

<div class="card"><h2>Access keys (manual)</h2>
<div class="row2"><input class="inp" id="k_days" placeholder="Plan days" inputmode="numeric" value="__DEFDAYS__"><input class="inp" id="k_count" placeholder="How many" inputmode="numeric" value="1"></div>
<input class="inp" id="k_note" placeholder="Note (buyer name, optional)"><button class="big" id="k_go">Create key(s)</button>
<div class="msg" id="k_msg"></div><div id="keys"></div></div>

<div class="card"><h2>Broadcast to all bot owners</h2><textarea class="inp" id="b_text" maxlength="1000" placeholder="Message sent on Telegram to every hosted bot's admin"></textarea>
<button class="big alt" id="b_go">Send broadcast</button></div>

<h2 style="margin:6px 4px 10px">Hosted bots</h2>
<div class="row2" style="margin-bottom:10px"><input class="inp" id="q" placeholder="Search @username or ID" style="margin:0"><select class="inp" id="fs" style="margin:0"><option value="">All status</option><option>running</option><option>stopped</option><option>crashed</option><option>expired</option><option>suspended</option></select></div>
<div class="bots" id="bots"></div>

<div class="card" style="margin-top:14px"><h2>Activity log</h2><div id="act" class="meta"></div></div>
</div>

<div class="modal" id="lm"><div class="card"><h2 id="lt">Logs</h2><pre id="lp"></pre><button class="big" id="lc" style="margin-top:12px">Close</button></div></div>

<div class="modal" id="sm"><div class="card"><h2>Settings</h2>
<div class="sec">Theme</div><div class="sw" id="sw"></div>
<div class="row2"><div><div class="meta">Accent colour (optional)</div><input class="inp" type="color" id="s_accent" style="padding:4px;height:46px"></div>
<div><div class="meta">&nbsp;</div><button class="big alt" id="s_accclr" type="button" style="padding:12px">Use theme colour</button></div></div>
<div class="sec">Brand</div>
<div class="row2"><input class="inp" id="s_brand" placeholder="Brand name" maxlength="40"><input class="inp" id="s_logo" placeholder="Logo letter / emoji" maxlength="4"></div>
<input class="inp" id="s_tag" placeholder="Tagline shown on website" maxlength="140">
<input class="inp" id="s_support" placeholder="Support link (@username or https://t.me/...)">

<div class="sec">Auto payment (FMPay)</div>
<input class="inp" id="s_fmkey" placeholder="FMPay API key" autocomplete="off">
<input class="inp" id="s_fmurl" placeholder="FMPay API URL">
<div class="row2"><input class="inp" id="s_upi" placeholder="Your UPI ID (name@bank)"><input class="inp" id="s_upiname" placeholder="Payee name"></div>

<div class="sec">Owner Telegram (alerts and 2-step login)</div>
<input class="inp" id="s_tgid" placeholder="Your numeric Telegram ID (from @userinfobot)" inputmode="numeric">
<input class="inp" id="s_tgtoken" placeholder="Alert bot token (any bot you own)" autocomplete="off">
<div class="meta">Start that bot once on Telegram first, then press Test.</div>
<button class="big alt" id="s_tgtest" type="button">Send test message</button>
<label class="chk"><input type="checkbox" id="s_alerts"> Send me Telegram alerts (new bot, payments, crashes, expiries)</label>
<label class="chk"><input type="checkbox" id="s_2fa"> Login needs Telegram code (2-step)</label>

<button class="big" id="s_save" type="button">Save settings</button><div class="msg" id="s_msg"></div>

<div class="sec">Change panel password</div>
<input class="inp" type="password" id="pw_old" placeholder="Current password"><input class="inp" type="password" id="pw_new" placeholder="New password (min 8)">
<button class="big alt" id="pw_go" type="button">Change password</button>
<div class="sec">Backup</div><a class="big alt" href="/admin/backup">Download database backup</a>
<button class="big alt" id="sc" style="margin-top:12px" type="button">Close</button></div></div>

<div class="toast" id="toast"></div>
<script>const CSRF="__CSRF__";""" + JS_COMMON + r"""
csrf_login="/admin/login";
const A=(u,b)=>J(u,b,CSRF);
let D=null,S=null,THEME="lime";
function stat(l,v,s,hot){return '<div class="stat'+(hot?' hot':'')+'"><small>'+l+'</small><b>'+v+'</b>'+(s?'<i>'+s+'</i>':'')+'</div>'}
function botCard(b){
 const left=b.expires?(b.days_left>=0?Math.ceil(b.days_left)+" days left":"expired"):"lifetime";
 return '<div class="bot"><div class="bh"><b>@'+esc(b.username)+'</b><span class="badge '+b.status+'">'+b.status+'</span></div>'+
 '<div class="mm"><div><small>REVENUE</small><b>'+inr(b.revenue)+'</b></div><div><small>USERS</small><b>'+b.users+'</b></div><div><small>ORDERS</small><b>'+b.orders+'</b></div>'+
 '<div><small>TODAY</small><b>'+inr(b.today)+'</b></div><div><small>DEPOSITS</small><b>'+inr(b.deposits)+'</b></div><div><small>PLAN</small><b style="font-size:12.5px">'+left+'</b></div></div>'+
 '<div class="meta">Admin ID: '+esc(b.admin_ids)+(b.key?' · key '+esc(b.key):'')+'</div>'+
 '<div class="acts"><button class="g" data-a="start" data-id="'+b.id+'">Start</button><button data-a="restart" data-id="'+b.id+'">Restart</button><button data-a="stop" data-id="'+b.id+'">Stop</button>'+
 '<button data-a="log" data-id="'+b.id+'">Logs</button><button data-a="extend" data-id="'+b.id+'">+ Days</button><button data-a="lifetime" data-id="'+b.id+'">Lifetime</button>'+
 '<button data-a="'+(b.suspended?'unsuspend':'suspend')+'" data-id="'+b.id+'">'+(b.suspended?'Unsuspend':'Suspend')+'</button>'+
 '<button class="r" data-a="delete" data-id="'+b.id+'" data-n="'+esc(b.username)+'">Delete</button></div></div>'}
function drawBots(){if(!D)return;const q=$("q").value.trim().toLowerCase().replace("@",""),fs=$("fs").value;
 const list=D.bots.filter(b=>(!fs||b.status===fs)&&(!q||String(b.username).toLowerCase().includes(q)||String(b.id)===q));
 $("bots").innerHTML=list.map(botCard).join("")||'<div class="meta">No bots found.</div>'}
function render(d){
 D=d;const t=d.totals;
 let al="";if(!d.pay_ready)al+='<div class="warn">Auto payment is not set up. Open Settings and add your FMPay key and UPI ID so buyers can pay on the website.</div>';
 if(d.pay_ready&&!d.plans.length)al+='<div class="warn">Add at least one plan below so buyers can purchase.</div>';
 $("alerts").innerHTML=al;
 $("tot").innerHTML=stat("Bot revenue",inr(t.revenue),"today "+inr(t.today),1)+stat("Key sales",inr(d.sales.total),"today "+inr(d.sales.today)+" · "+d.sales.count+" sold",1)+stat("Total bots",t.bots,t.running+" running")+stat("Users / orders",t.users.toLocaleString("en-IN")+" / "+t.orders.toLocaleString("en-IN"),"deposits "+inr(t.deposits));
 const s=d.server;$("srv").textContent=s?("Server · RAM "+s.ram+"% · load "+s.load+" · disk free "+s.disk_free+" GB"):"";
 const mx=Math.max(1,...d.bots.map(b=>b.revenue));
 $("rev").innerHTML=d.bots.length?d.bots.slice().sort((a,b)=>b.revenue-a.revenue).map(b=>'<div style="margin-bottom:10px"><div style="display:flex;justify-content:space-between;color:var(--tx);font-size:13px"><span>@'+esc(b.username)+'</span><b>'+inr(b.revenue)+'</b></div><div class="bar" style="margin:5px 0 0"><span style="width:'+(b.revenue/mx*100)+'%"></span></div></div>').join(""):"No bots yet.";
 $("plans").innerHTML=d.plans.map(p=>'<div class="row"><b style="flex:1">'+esc(p.name)+'</b><span>'+(p.days>=36500?'Lifetime':p.days+'d')+' · '+inr(p.price)+'</span><button class="mini" data-pt="'+p.id+'">'+(p.active?'On':'Off')+'</button><button class="mini" data-pd="'+p.id+'">✕</button></div>').join("")||'<div class="meta">No plans yet.</div>';
 $("orders").innerHTML=d.orders.length?d.orders.map(o=>'<div class="row"><code>'+esc(o.id.slice(0,8))+'</code><span>'+esc(o.plan_name)+' · '+inr(o.amount)+(o.bot_id?' · renew':'')+'</span><span class="badge '+(o.status==='paid'?'running':'stopped')+'">'+o.status+'</span></div>').join(""):"No orders yet.";
 drawBots();
 $("keys").innerHTML=d.keys.map(k=>'<div class="row"><code>'+esc(k.code)+'</code><span>'+k.days+'d'+(k.note?' · '+esc(k.note):'')+'</span>'+
  (k.used_by?'<span>used</span>':'<button class="mini" data-copy="'+esc(k.code)+'">Copy</button><button class="mini" data-kdel="'+esc(k.code)+'">✕</button>')+'</div>').join("");
 $("act").innerHTML=d.activity.map(a=>'<div class="row" style="font-weight:500"><span style="min-width:92px">'+esc(a.ts.slice(5,16))+'</span><span style="color:var(--tx);flex:1">'+esc(a.who)+': '+esc(a.action)+(a.detail?' · '+esc(a.detail):'')+'</span></div>').join("")||"Nothing yet.";
}
async function load(){const d=await A("/api/stats");if(d.ok)render(d)}
$("q").oninput=drawBots;$("fs").onchange=drawBots;
document.addEventListener("click",async e=>{
 const c=e.target.closest("[data-copy]");if(c){copy(c.dataset.copy);return}
 const kd=e.target.closest("[data-kdel]");if(kd){await A("/api/keys/"+kd.dataset.kdel+"/delete",{});load();return}
 const pt=e.target.closest("[data-pt]");if(pt){await A("/api/plans",{action:"toggle",id:+pt.dataset.pt});load();return}
 const pd=e.target.closest("[data-pd]");if(pd){if(confirm("Delete this plan?")){await A("/api/plans",{action:"delete",id:+pd.dataset.pd});load()}return}
 const b=e.target.closest("[data-a]");if(!b)return;const id=b.dataset.id,a=b.dataset.a;
 if(a==="log"){const j=await A("/api/bot/"+id+"/log");$("lt").textContent="Logs";$("lp").textContent=j.log||"";$("lm").classList.add("on");$("lp").scrollTop=1e9;return}
 let body={};
 if(a==="delete"&&!confirm("Delete @"+b.dataset.n+" and ALL its data (users, orders)? This cannot be undone."))return;
 if(a==="suspend"&&!confirm("Suspend @"+b.dataset.n+"? The bot stops and the user cannot start it."))return;
 if(a==="extend"){const v=prompt("Add how many days? (negative to remove)","30");if(!v)return;body={days:parseInt(v,10)}}
 b.disabled=true;const j=await A("/api/bot/"+id+"/"+a,body);toast(j.message||"Done");load()});
$("lc").onclick=()=>$("lm").classList.remove("on");
$("rall").onclick=async()=>{if(!confirm("Restart every hosted bot with the latest template?"))return;const j=await A("/api/restart_all",{});toast(j.message);load()};
$("o_go").onclick=async()=>{const m=$("o_msg");m.className="msg";m.textContent="Starting…";$("o_go").disabled=true;
 const j=await A("/api/deploy_owner",{token:$("o_token").value.trim(),admin:$("o_admin").value,days:parseInt($("o_days").value,10)||0});
 m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";if(j.ok){$("o_token").value="";$("o_admin").value=""}$("o_go").disabled=false;load()};
$("k_go").onclick=async()=>{const m=$("k_msg");const j=await A("/api/keys",{days:parseInt($("k_days").value,10),count:parseInt($("k_count").value,10),note:$("k_note").value});
 m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";load()};
$("p_go").onclick=async()=>{const j=await A("/api/plans",{action:"add",name:$("p_name").value,days:parseInt($("p_days").value,10),price:parseFloat($("p_price").value)});
 toast(j.message||"Done");if(j.ok){$("p_name").value=$("p_days").value=$("p_price").value=""}load()};
$("b_go").onclick=async()=>{const t=$("b_text").value.trim();if(!t)return;if(!confirm("Send this message to every bot owner?"))return;
 const j=await A("/api/broadcast",{text:t});toast(j.message);if(j.ok)$("b_text").value=""};

/* settings */
function applyTheme(id){THEME=id;const t=S.themes[id];if(!t)return;const r=document.documentElement.style;
 ["bg","s1","s2","line","tx","mu","ac","red","glow"].forEach(k=>r.setProperty("--"+k,t[k]));
 const ac=$("s_accent").dataset.set==="1"?$("s_accent").value:t.ac;applyAccent(ac);
 document.querySelectorAll("#sw button").forEach(b=>b.classList.toggle("on",b.dataset.t===id))}
function applyAccent(c){const r=document.documentElement.style;r.setProperty("--ac",c);
 const n=parseInt(c.slice(1),16),R=n>>16,G=(n>>8)&255,B=n&255;r.setProperty("--acrgb",R+","+G+","+B);
 r.setProperty("--act",(0.299*R+0.587*G+0.114*B)>150?"#0b0f0a":"#ffffff")}
$("s_accent").oninput=()=>{$("s_accent").dataset.set="1";applyAccent($("s_accent").value)};
$("s_accclr").onclick=()=>{$("s_accent").dataset.set="";applyTheme(THEME)};
$("sw").onclick=e=>{const b=e.target.closest("[data-t]");if(b)applyTheme(b.dataset.t)};
$("setb").onclick=async()=>{const d=await A("/api/settings");if(!d.ok)return;S=d;const v=d.values;
 $("sw").innerHTML=Object.entries(d.themes).map(([k,t])=>'<button data-t="'+k+'"><i><s style="background:'+t.bg+'"></s><s style="background:'+t.s2+'"></s><s style="background:'+t.ac+'"></s></i>'+esc(t.name)+'</button>').join("");
 $("s_accent").dataset.set=v.accent?"1":"";$("s_accent").value=v.accent||d.themes[v.theme||"lime"].ac;
 $("s_brand").value=v.brand;$("s_logo").value=v.logo;$("s_tag").value=v.tagline;$("s_support").value=v.support_link;
 $("s_fmkey").value="";$("s_fmkey").placeholder=v.fmpay_key_mask||"FMPay API key";$("s_fmurl").value=v.fmpay_url;$("s_upi").value=v.upi_id;$("s_upiname").value=v.upi_name;
 $("s_tgid").value=v.owner_tg;$("s_tgtoken").value="";$("s_tgtoken").placeholder=v.alert_token_mask||"Alert bot token (any bot you own)";
 $("s_alerts").checked=v.alerts_on==="1";$("s_2fa").checked=v.twofa==="1";
 THEME=v.theme||"lime";applyTheme(THEME);$("sm").classList.add("on")};
$("sc").onclick=()=>{$("sm").classList.remove("on");location.reload()};
$("s_save").onclick=async()=>{const m=$("s_msg");
 const body={theme:THEME,accent:$("s_accent").dataset.set==="1"?$("s_accent").value:"",brand:$("s_brand").value,logo:$("s_logo").value,tagline:$("s_tag").value,support_link:$("s_support").value,
  fmpay_key:$("s_fmkey").value.trim(),fmpay_url:$("s_fmurl").value,upi_id:$("s_upi").value,upi_name:$("s_upiname").value,owner_tg:$("s_tgid").value,alert_token:$("s_tgtoken").value.trim(),
  alerts_on:$("s_alerts").checked?"1":"0",twofa:$("s_2fa").checked?"1":"0"};
 const j=await A("/api/settings",body);m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||"";if(j.ok){toast("Saved");setTimeout(()=>location.reload(),700)}};
$("s_tgtest").onclick=async()=>{const m=$("s_msg");m.className="msg";m.textContent="Saving and sending…";
 const j=await A("/api/tgtest",{owner_tg:$("s_tgid").value,alert_token:$("s_tgtoken").value.trim()});m.className="msg "+(j.ok?"ok":"err");m.textContent=j.message||""};
$("pw_go").onclick=async()=>{const j=await A("/api/password",{old:$("pw_old").value,new:$("pw_new").value});toast(j.message);if(j.ok){$("pw_old").value=$("pw_new").value=""}};
load();setInterval(load,8000);
</script></body></html>"""
