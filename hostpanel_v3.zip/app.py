#!/usr/bin/env python3
"""
BOT HOST PANEL v2 - sell your store bot.
  Website      : buy an access key (auto UPI payment via FMPay) -> launch bot
  /login       : buyer dashboard (token / admin ID / store details / renew / logs / CSV)
  /admin       : owner dashboard (plans, orders, themes, settings, alerts, 2-step login, backup)
"""
import os
import re
import io
import csv
import sys
import time
import hmac
import html
import shutil
import signal
import base64
import hashlib
import secrets
import sqlite3
import tempfile
import threading
import subprocess
from pathlib import Path
from urllib.parse import quote
from datetime import datetime, timedelta, timezone

import requests
from flask import Flask, request, session, redirect, jsonify, Response, send_file

import ui

try:
    import qrcode
except ImportError:          # QR is optional; the UPI link + ID still work
    qrcode = None

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
BOTS = BASE / "bots"
TEMPLATE = BASE / "storebot_template.py"
DATA.mkdir(exist_ok=True)
BOTS.mkdir(exist_ok=True)
PANEL_DB = Path(os.getenv("PANEL_DB", str(DATA / "panel.db")))
IST_MIN = 330


def load_env(path: Path):
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


load_env(BASE / "panel.env")
PANEL_PASSWORD = os.getenv("PANEL_PASSWORD", "")
PANEL_HOST = os.getenv("PANEL_HOST", "0.0.0.0")
PANEL_PORT = int(os.getenv("PANEL_PORT", "8000"))
BRAND = os.getenv("BRAND", "Bot Host")
DEFAULT_DAYS = int(os.getenv("DEFAULT_DAYS", "30"))
FIRST_BOT_PORT = 9000
WARN_DAYS = 3

if not PANEL_PASSWORD or len(PANEL_PASSWORD) < 6:
    sys.exit("PANEL_PASSWORD missing (min 6 chars). Put it in panel.env:  PANEL_PASSWORD=yourpassword")

key_file = DATA / "secret.key"
if not key_file.exists():
    key_file.write_text(secrets.token_hex(32))
    os.chmod(key_file, 0o600)

app = Flask(__name__)
app.secret_key = key_file.read_text().strip()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  PERMANENT_SESSION_LIFETIME=timedelta(days=7), MAX_CONTENT_LENGTH=20_000)

_dblock = threading.Lock()


# ─────────────────────────── panel database ───────────────────────────
def pdb(sql: str, params=(), fetch=None):
    with _dblock:
        con = sqlite3.connect(PANEL_DB, timeout=20)
        con.row_factory = sqlite3.Row
        try:
            cur = con.execute(sql, params)
            if fetch == "one":
                r = cur.fetchone()
                return dict(r) if r else None
            if fetch == "all":
                return [dict(r) for r in cur.fetchall()]
            con.commit()
            return cur.lastrowid if fetch == "id" else cur.rowcount
        finally:
            con.close()


pdb("""CREATE TABLE IF NOT EXISTS bots (
    id INTEGER PRIMARY KEY AUTOINCREMENT, tg_id INTEGER UNIQUE, username TEXT, name TEXT,
    token TEXT NOT NULL, admin_ids TEXT NOT NULL, port INTEGER, pid INTEGER,
    desired INTEGER DEFAULT 1, expires_at TEXT, key_code TEXT, created_at TEXT)""")
pdb("""CREATE TABLE IF NOT EXISTS keys (
    code TEXT PRIMARY KEY, days INTEGER NOT NULL, note TEXT, created_at TEXT, used_by INTEGER, used_at TEXT)""")
pdb("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
pdb("""CREATE TABLE IF NOT EXISTS plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, days INTEGER NOT NULL,
    price REAL NOT NULL, active INTEGER DEFAULT 1)""")
pdb("""CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY, plan_id INTEGER, plan_name TEXT, days INTEGER, amount REAL,
    status TEXT DEFAULT 'pending', utr TEXT, key_code TEXT, bot_id INTEGER,
    attempts INTEGER DEFAULT 0, vstart REAL, created_at TEXT, paid_at TEXT, ip TEXT)""")
pdb("CREATE TABLE IF NOT EXISTS used_utrs (utr TEXT PRIMARY KEY, order_id TEXT, created_at TEXT)")
pdb("CREATE TABLE IF NOT EXISTS activity (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, who TEXT, action TEXT, detail TEXT)")


def _migrate():
    cols = {r["name"] for r in pdb("PRAGMA table_info(bots)", fetch="all")}
    for name, ddl in (("store_name", "TEXT"), ("support", "TEXT"), ("suspended", "INTEGER DEFAULT 0"),
                      ("warned", "TEXT"), ("plan_days", "INTEGER")):
        if name not in cols:
            pdb(f"ALTER TABLE bots ADD COLUMN {name} {ddl}")


_migrate()


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def ts(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def parse_ts(s):
    try:
        return datetime.strptime(s, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None


def is_expired(b) -> bool:
    e = parse_ts(b.get("expires_at"))
    return bool(e and e < now_utc())


# ─────────────────────────── settings ───────────────────────────
def sget(key: str, default: str = "") -> str:
    r = pdb("SELECT value FROM settings WHERE key = ?", (key,), "one")
    return r["value"] if r and r["value"] is not None else default


def sset(key: str, value: str):
    pdb("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value))


def brand() -> str:
    return sget("brand") or BRAND


def fm_conf():
    key = (sget("fmpay_key") or os.getenv("FMPAY_API_KEY", "")).strip()
    url = (sget("fmpay_url") or os.getenv("FMPAY_BASE_URL", "https://famapi-sas5.onrender.com")).strip().rstrip("/")
    upi = (sget("upi_id") or os.getenv("UPI_ID", "")).strip()
    name = (sget("upi_name") or brand())[:40]
    return key, url, upi, name


def public_url() -> str:
    """Public https address of this panel (the Cloudflare tunnel). Order: panel.env PUBLIC_URL ->
    owner setting 'public_url' -> the trycloudflare.com address found in the quick-tunnel log."""
    u = (os.getenv("PUBLIC_URL", "") or sget("public_url")).strip().rstrip("/")
    if not u:
        try:
            m = re.findall(r"https://[a-z0-9\-]+\.trycloudflare\.com", (BASE / "cloudflared.log").read_text(errors="ignore"))
            u = m[-1] if m else ""
        except OSError:
            u = ""
    return u if u.startswith("https://") else ""


def pay_ready() -> bool:
    key, url, upi, _ = fm_conf()
    return bool(key and url and upi)


def log_act(who: str, action: str, detail: str = ""):
    pdb("INSERT INTO activity (ts, who, action, detail) VALUES (?,?,?,?)", (ts(now_utc()), who, action, detail[:200]))
    pdb("DELETE FROM activity WHERE id < (SELECT MAX(id) FROM activity) - 400")


def hash_pw(pw: str, salt: str = "") -> str:
    salt = salt or secrets.token_hex(8)
    return salt + "$" + hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000).hex()


def check_pw(pw: str) -> bool:
    stored = sget("pw_hash")
    if stored and "$" in stored:
        salt = stored.split("$", 1)[0]
        return hmac.compare_digest(hash_pw(pw, salt).encode(), stored.encode())
    return hmac.compare_digest(pw.encode(), PANEL_PASSWORD.encode())


# ─────────────────────────── telegram helpers ───────────────────────────
def tg_call(token: str, method: str):
    r = requests.get(f"https://api.telegram.org/bot{token}/{method}", timeout=15)
    return r.json()


def tg_send(token: str, chat_id, text: str) -> bool:
    try:
        r = requests.post(f"https://api.telegram.org/bot{token}/sendMessage",
                          json={"chat_id": chat_id, "text": text, "disable_web_page_preview": True}, timeout=10)
        return bool(r.ok and r.json().get("ok"))
    except Exception:
        return False


def owner_ids():
    return [int(x) for x in re.findall(r"\d{5,15}", sget("owner_tg"))]


def notify_owner(text: str):
    if sget("alerts_on", "1") != "1":
        return
    token, ids = sget("alert_token"), owner_ids()
    if not token or not ids:
        return
    threading.Thread(target=lambda: [tg_send(token, i, text) for i in ids], daemon=True).start()


def notify_bot_admins(b, text: str):
    ids = [i for i in re.findall(r"\d+", b.get("admin_ids") or "")]
    threading.Thread(target=lambda: [tg_send(b["token"], i, text) for i in ids], daemon=True).start()


# ─────────────────────────── process manager ───────────────────────────
PROCS = {}
_fail_times = {}


def bot_dir(bid: int) -> Path:
    return BOTS / str(bid)


def pid_alive(pid) -> bool:
    if not pid:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    try:
        stat = Path(f"/proc/{pid}/stat").read_text()
        if stat.rsplit(")", 1)[1].split()[0] == "Z":
            return False
    except Exception:
        pass
    return True


def is_running(b) -> bool:
    p = PROCS.get(b["id"])
    if p is not None:
        if p.poll() is None:
            return True
        PROCS.pop(b["id"], None)
        return False
    pid = b.get("pid")
    if not pid_alive(pid):
        return False
    try:
        return os.readlink(f"/proc/{pid}/cwd") == str(bot_dir(b["id"]))
    except Exception:
        return True


def bot_setting(bid: int, key: str):
    f = bot_dir(bid) / "store.db"
    if not f.exists():
        return None
    try:
        con = sqlite3.connect(f"file:{f}?mode=ro", uri=True, timeout=3)
        r = con.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        con.close()
        return r[0] if r and r[0] else None
    except Exception:
        return None


def write_bot_setting(bid: int, key: str, value: str):
    f = bot_dir(bid) / "store.db"
    if not f.exists():
        return
    try:
        con = sqlite3.connect(f, timeout=8)
        con.execute("INSERT INTO settings (key, value) VALUES (?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, value))
        con.commit()
        con.close()
    except Exception:
        pass


def write_bot_files(b):
    d = bot_dir(b["id"])
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(d, 0o700)
    link = d / "storebot.py"
    if link.is_symlink() or link.exists():
        link.unlink()
    try:
        link.symlink_to(TEMPLATE)
    except OSError:
        link.write_bytes(TEMPLATE.read_bytes())
    sname = (b.get("store_name") or b.get("name") or "My Store")[:40].replace("\n", " ")
    sup = (b.get("support") or b.get("username") or "support").lstrip("@")
    env = d / ".env"
    env.write_text(
        f"BOT_TOKEN={b['token']}\nADMIN_IDS={b['admin_ids']}\nDB_NAME=store.db\nWEBAPP_PORT={b['port']}\n"
        f"STORE_NAME={sname}\nSUPPORT_USERNAME=@{sup}\nSEED_DEMO=0\n"
        + (f"WEBAPP_URL={public_url()}/pay/{b['id']}\n" if public_url() else ""), encoding="utf-8")
    os.chmod(env, 0o600)


def start_bot(b) -> bool:
    if is_running(b):
        return True
    if is_expired(b) or b.get("suspended"):
        return False
    write_bot_files(b)
    d = bot_dir(b["id"])
    log = open(d / "bot.log", "ab")
    env = {k: v for k, v in os.environ.items() if k in ("PATH", "HOME", "LANG", "LC_ALL", "TZ")}
    env["PYTHONUNBUFFERED"] = "1"
    p = subprocess.Popen([sys.executable, "storebot.py"], cwd=d, stdout=log, stderr=subprocess.STDOUT,
                         stdin=subprocess.DEVNULL, start_new_session=True, env=env)
    log.close()
    PROCS[b["id"]] = p
    pdb("UPDATE bots SET pid = ?, desired = 1 WHERE id = ?", (p.pid, b["id"]))
    return True


def stop_bot(b, keep_desired=False):
    if not keep_desired:
        pdb("UPDATE bots SET desired = 0 WHERE id = ?", (b["id"],))
    pid = (PROCS.get(b["id"]).pid if PROCS.get(b["id"]) else None) or b.get("pid")
    if pid and is_running(b):
        try:
            os.killpg(pid, signal.SIGTERM)
        except OSError:
            pass
        for _ in range(40):
            time.sleep(0.2)
            p = PROCS.get(b["id"])
            if p is not None:
                p.poll()
            if not pid_alive(pid) or (p is not None and p.poll() is not None):
                break
        else:
            try:
                os.killpg(pid, signal.SIGKILL)
            except OSError:
                pass
    PROCS.pop(b["id"], None)
    pdb("UPDATE bots SET pid = NULL WHERE id = ?", (b["id"],))


def restart_bot(bid: int):
    b = get_bot(bid)
    stop_bot(b, keep_desired=True)
    _fail_times[bid] = []
    pdb("UPDATE bots SET desired = 1 WHERE id = ?", (bid,))
    return start_bot(get_bot(bid))


def get_bot(bid: int):
    return pdb("SELECT * FROM bots WHERE id = ?", (bid,), "one")


def watchdog():
    """Every 10s: stop expired/suspended bots, restart crashed bots, send expiry notices."""
    flag = DATA / "restart_all.flag"
    while True:
        try:
            if flag.exists():      # update.sh asks for it: reload every bot with the new template
                flag.unlink()
                for b in pdb("SELECT * FROM bots WHERE desired = 1", fetch="all"):
                    if not (is_expired(b) or b.get("suspended")):
                        restart_bot(b["id"])
            for b in pdb("SELECT * FROM bots", fetch="all"):
                running = is_running(b)
                if b.get("suspended"):
                    if running:
                        stop_bot(b, keep_desired=True)
                    continue
                e = parse_ts(b["expires_at"])
                if e:
                    left = (e - now_utc()).total_seconds() / 86400
                    marker = b.get("warned") or ""
                    if left < 0 and marker != f"x:{b['expires_at']}":
                        pdb("UPDATE bots SET warned = ? WHERE id = ?", (f"x:{b['expires_at']}", b["id"]))
                        notify_bot_admins(b, "⛔ Your bot plan has expired and the bot is stopped. Renew it from the website dashboard.")
                        notify_owner(f"⛔ @{b['username']} plan expired.")
                    elif 0 <= left <= WARN_DAYS and marker != f"w:{b['expires_at']}":
                        pdb("UPDATE bots SET warned = ? WHERE id = ?", (f"w:{b['expires_at']}", b["id"]))
                        notify_bot_admins(b, f"⏰ Your bot plan ends in {max(1, round(left))} day(s). Renew it from the website dashboard to avoid downtime.")
                        notify_owner(f"⏰ @{b['username']} plan ends in {max(1, round(left))} day(s).")
                if is_expired(b):
                    if running:
                        stop_bot(b, keep_desired=True)
                    continue
                if b["desired"] and not running:
                    recent = [t for t in _fail_times.get(b["id"], []) if time.time() - t < 600]
                    if len(recent) >= 6:
                        pdb("UPDATE bots SET desired = 0 WHERE id = ?", (b["id"],))
                        _fail_times[b["id"]] = []
                        notify_owner(f"🔴 @{b['username']} keeps crashing and was stopped. Check its logs.")
                        continue
                    recent.append(time.time())
                    _fail_times[b["id"]] = recent
                    start_bot(b)
                lg = bot_dir(b["id"]) / "bot.log"
                try:
                    if lg.exists() and lg.stat().st_size > 5_000_000:
                        os.truncate(lg, 0)
                except OSError:
                    pass
        except Exception as ex:
            print("watchdog error:", ex, flush=True)
        time.sleep(10)


# ─────────────────────────── per-bot statistics ───────────────────────────
_stat_cache = {}


def bot_stats(bid: int) -> dict:
    c = _stat_cache.get(bid)
    if c and time.time() - c[0] < 4:
        return c[1]
    st = {"users": 0, "orders": 0, "revenue": 0.0, "today": 0.0, "today_orders": 0, "deposits": 0.0}
    f = bot_dir(bid) / "store.db"
    if f.exists():
        try:
            con = sqlite3.connect(f"file:{f}?mode=ro", uri=True, timeout=3)
            mod = f"+{IST_MIN} minutes"
            st["users"] = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            r = con.execute("SELECT COUNT(*), COALESCE(SUM(price),0) FROM orders WHERE status='completed'").fetchone()
            st["orders"], st["revenue"] = r[0], float(r[1])
            r = con.execute("SELECT COUNT(*), COALESCE(SUM(price),0) FROM orders WHERE status='completed' "
                            "AND DATE(created_at, ?) = DATE('now', ?)", (mod, mod)).fetchone()
            st["today_orders"], st["today"] = r[0], float(r[1])
            st["deposits"] = float(con.execute("SELECT COALESCE(SUM(amount),0) FROM transactions "
                                               "WHERE status='approved'").fetchone()[0])
            con.close()
        except Exception:
            pass
    _stat_cache[bid] = (time.time(), st)
    return st


def status_of(b) -> str:
    if b.get("suspended"):
        return "suspended"
    if is_expired(b):
        return "expired"
    if is_running(b):
        return "running"
    return "crashed" if b["desired"] else "stopped"


def bot_view(b) -> dict:
    s = bot_stats(b["id"])
    e = parse_ts(b["expires_at"])
    left = round((e - now_utc()).total_seconds() / 86400, 1) if e else None
    return {"id": b["id"], "username": b["username"], "name": b["name"], "status": status_of(b),
            "suspended": bool(b.get("suspended")), "admin_ids": b["admin_ids"], "created": b["created_at"],
            "expires": b["expires_at"], "days_left": left, "key": b["key_code"], **s}


def all_bots_view():
    return [bot_view(b) for b in pdb("SELECT * FROM bots ORDER BY id DESC", fetch="all")]


def server_stats():
    try:
        mem = {}
        for line in Path("/proc/meminfo").read_text().splitlines():
            k, v = line.split(":", 1)
            mem[k] = int(v.split()[0])
        ram = round(100 - mem["MemAvailable"] / mem["MemTotal"] * 100)
        du = shutil.disk_usage(BASE)
        return {"ram": ram, "load": round(os.getloadavg()[0], 2), "disk_free": round(du.free / 1e9, 1)}
    except Exception:
        return None


# ─────────────────────────── bot operations (shared by owner + user) ───────────────────────────
TOKEN_RE = re.compile(r"^\d{6,12}:[A-Za-z0-9_-]{30,50}$")
ADMIN_RE = re.compile(r"^\d{5,15}(,\d{5,15})*$")
SUPPORT_RE = re.compile(r"^@?[A-Za-z0-9_]{4,32}$")


def new_key() -> str:
    while True:
        code = "-".join(secrets.token_hex(2).upper() for _ in range(4))
        try:
            pdb("INSERT INTO keys (code, days, created_at) VALUES (?,?,?)", (code, 1, ts(now_utc())))
            return code
        except sqlite3.IntegrityError:
            continue


def create_bot(token: str, admin_ids: str, days: int, key_code=None):
    token = (token or "").strip()
    admin_ids = re.sub(r"\s+", "", admin_ids or "")
    if not TOKEN_RE.match(token):
        return False, "Bot token is not valid. Copy it again from @BotFather.", None
    if not ADMIN_RE.match(admin_ids):
        return False, "Admin ID must be numbers only (your Telegram user ID). Use commas for more than one.", None
    try:
        me = tg_call(token, "getMe")
    except Exception:
        return False, "Could not reach Telegram. Try again in a minute.", None
    if not me.get("ok"):
        return False, "Telegram rejected this token. Check it in @BotFather.", None
    info = me["result"]
    if pdb("SELECT id FROM bots WHERE tg_id = ?", (info["id"],), "one"):
        return False, "This bot is already hosted here.", None
    try:
        tg_call(token, "deleteWebhook")
    except Exception:
        pass
    port = FIRST_BOT_PORT + (pdb("SELECT COALESCE(MAX(id),0)+1 AS n FROM bots", fetch="one")["n"])
    expires = ts(now_utc() + timedelta(days=days)) if days and 0 < days < 36500 else None
    bid = pdb("INSERT INTO bots (tg_id, username, name, token, admin_ids, port, desired, expires_at, key_code, created_at, plan_days) "
              "VALUES (?,?,?,?,?,?,1,?,?,?,?)",
              (info["id"], info.get("username"), info.get("first_name"), token, admin_ids, port, expires,
               key_code, ts(now_utc()), days if expires else 36500), "id")
    b = get_bot(bid)
    start_bot(b)
    notify_owner(f"🆕 New bot hosted: @{info.get('username')} ({days if expires else 'lifetime'} days)")
    return True, f"@{info.get('username')} is live.", b


def change_token(b, token: str):
    token = (token or "").strip()
    if not TOKEN_RE.match(token):
        return False, "Bot token is not valid. Copy it again from @BotFather."
    if token == b["token"]:
        return False, "This is already your current token."
    try:
        me = tg_call(token, "getMe")
    except Exception:
        return False, "Could not reach Telegram. Try again in a minute."
    if not me.get("ok"):
        return False, "Telegram rejected this token. Check it in @BotFather."
    info = me["result"]
    other = pdb("SELECT id FROM bots WHERE tg_id = ? AND id != ?", (info["id"], b["id"]), "one")
    if other:
        return False, "This bot is already hosted by another account."
    try:
        tg_call(token, "deleteWebhook")
    except Exception:
        pass
    stop_bot(b, keep_desired=True)
    pdb("UPDATE bots SET token = ?, tg_id = ?, username = ?, name = ?, desired = 1 WHERE id = ?",
        (token, info["id"], info.get("username"), info.get("first_name"), b["id"]))
    nb = get_bot(b["id"])
    _fail_times[b["id"]] = []
    start_bot(nb)
    return True, f"Token changed. @{info.get('username')} is running."


def change_admin(b, admin_ids: str):
    admin_ids = re.sub(r"\s+", "", admin_ids or "")
    if not ADMIN_RE.match(admin_ids):
        return False, "Admin ID must be numbers only. Use commas for more than one."
    pdb("UPDATE bots SET admin_ids = ? WHERE id = ?", (admin_ids, b["id"]))
    restart_bot(b["id"])
    return True, "Admin IDs saved. Bot restarted."


def change_store(b, name: str, support: str):
    name = re.sub(r"\s+", " ", name or "").strip()
    support = (support or "").strip()
    if not 2 <= len(name) <= 40:
        return False, "Store name must be 2 to 40 characters."
    if support and not SUPPORT_RE.match(support):
        return False, "Support must look like @username."
    support = ("@" + support.lstrip("@")) if support else ""
    pdb("UPDATE bots SET store_name = ?, support = ? WHERE id = ?", (name, support, b["id"]))
    write_bot_setting(b["id"], "store_name", name)
    if support:
        write_bot_setting(b["id"], "support", support)
    restart_bot(b["id"])
    return True, "Store details saved. Bot restarted."


def extend_days(bid: int, days: int):
    b = get_bot(bid)
    if not b["expires_at"] and days > 0:
        return "Plan is already lifetime."
    if days >= 36500:                      # a Lifetime plan/key
        pdb("UPDATE bots SET expires_at = NULL, warned = NULL, plan_days = 36500 WHERE id = ?", (bid,))
        pdb("UPDATE bots SET desired = 1 WHERE id = ? AND suspended = 0", (bid,))
        start_bot(get_bot(bid))
        return "Lifetime plan set."
    e = parse_ts(b["expires_at"]) or now_utc()
    base = max(e, now_utc()) if days > 0 else e
    pdb("UPDATE bots SET expires_at = ?, warned = NULL WHERE id = ?", (ts(base + timedelta(days=days)), bid))
    nb = get_bot(bid)
    if not is_expired(nb) and not nb.get("suspended"):
        pdb("UPDATE bots SET desired = 1 WHERE id = ?", (bid,))
        _fail_times[bid] = []
        start_bot(get_bot(bid))
    return f"Plan changed by {days} day(s)."


# ─────────────────────────── security helpers ───────────────────────────
_login_fails = {}
_deploy_hits = {}
_user_fails = {}
_order_hits = {}
_verify_hits = {}


def client_ip() -> str:
    h = request.headers
    return (h.get("CF-Connecting-IP") or h.get("X-Forwarded-For") or request.remote_addr or "?").split(",")[0].strip()


def rate_ok(store: dict, ip: str, limit: int, window: int) -> bool:
    now = time.time()
    hits = [t for t in store.get(ip, []) if now - t < window]
    store[ip] = hits
    return len(hits) < limit


def authed() -> bool:
    return session.get("auth") is True


def csrf_ok(name="csrf") -> bool:
    t = request.headers.get("X-CSRF", "")
    return bool(t) and hmac.compare_digest(t, session.get(name, ""))


def guard():
    if not authed():
        return jsonify(ok=False, message="Please login again."), 401
    if request.method == "POST" and not csrf_ok("csrf"):
        return jsonify(ok=False, message="Session expired. Refresh the page."), 403
    return None


def uguard():
    """-> (bot, error_response)"""
    bid = session.get("ubot")
    b = get_bot(bid) if bid else None
    if not b:
        return None, (jsonify(ok=False, message="Please login again."), 401)
    if request.method == "POST" and not csrf_ok("ucsrf"):
        return None, (jsonify(ok=False, message="Session expired. Refresh the page."), 403)
    return b, None


@app.after_request
def headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    if not request.path.startswith("/pay/"):      # the Telegram Mini App may open inside a frame
        resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Cache-Control"] = "no-store"
    return resp


def page(tpl: str, title: str = "", **rep) -> Response:
    out = (tpl.replace("__THEME__", ui.theme_css(sget("theme", "lime"), sget("accent")))
              .replace("__TITLE__", html.escape(title or brand()))
              .replace("__BRAND__", html.escape(brand()))
              .replace("__LOGO__", html.escape(sget("logo") or "B"))
              .replace("__TAG__", html.escape(sget("tagline") or ui.DEFAULT_TAG)))
    for k, v in rep.items():
        out = out.replace(k, v)
    return Response(out, mimetype="text/html")


# ─────────────────────────── FMPay (auto UTR verification) ───────────────────────────
class FmPayError(Exception):
    pass


def _to_float(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def fmpay_verify(utr: str, amount: float) -> dict:
    """POST {base}/verify {utr, amount, api_key} -> {'ok', 'message', 'amount'}. Raises FmPayError on gateway trouble."""
    key, url, _upi, _n = fm_conf()
    try:
        resp = requests.post(f"{url}/verify", json={"utr": utr, "amount": round(float(amount), 2), "api_key": key},
                             headers={"X-API-Key": key, "Content-Type": "application/json"}, timeout=60)
    except requests.RequestException as e:
        raise FmPayError(f"network error: {e}")
    try:
        j = resp.json()
    except ValueError:
        raise FmPayError(f"non-JSON reply (HTTP {resp.status_code})")
    if not isinstance(j, dict):
        raise FmPayError("unexpected reply")
    msg = str(j.get("message") or j.get("error") or j.get("status") or "")
    if resp.status_code in (401, 403) or resp.status_code >= 500:
        raise FmPayError(msg or f"HTTP {resp.status_code}")
    ok = j.get("success") is True
    for k2 in ("verified", "found", "paid", "valid"):
        if k2 in j and not j[k2]:
            ok = False
    if str(j.get("status") or "").lower() in ("failed", "not_found", "notfound", "pending", "invalid", "error"):
        ok = False
    paid = _to_float(j.get("amount"))
    if ok and paid is not None and paid + 0.011 < float(amount):
        ok, msg = False, "Amount mismatch"
    return {"ok": ok, "message": msg, "amount": paid}


UTR_RE = re.compile(r"^[A-Za-z0-9]{10,30}$")


def qr_data_uri(text: str):
    if qrcode is None:
        return None
    try:
        bio = io.BytesIO()
        qrcode.make(text).save(bio, "PNG")
        return "data:image/png;base64," + base64.b64encode(bio.getvalue()).decode()
    except Exception:
        return None


def order_view(o: dict, with_pay=True) -> dict:
    out = {"id": o["id"], "plan": o["plan_name"], "days": o["days"], "amount": o["amount"], "status": o["status"],
           "renew": bool(o["bot_id"])}
    if o["status"] == "paid" and not o["bot_id"]:
        out["key"] = o["key_code"]
    if with_pay and o["status"] != "paid":
        _k, _u, upi, name = fm_conf()
        link = f"upi://pay?pa={quote(upi)}&pn={quote(name)}&am={o['amount']:.2f}&cu=INR&tn={quote('Order ' + o['id'][:6])}"
        out.update(upi_id=upi, upi_link=link, qr=qr_data_uri(link))
    return out


# ─────────────────────────── routes: public ───────────────────────────
@app.get("/")
def landing():
    return page(ui.LANDING)


@app.get("/api/public")
def api_public():
    plans = pdb("SELECT id, name, days, price FROM plans WHERE active = 1 ORDER BY price", fetch="all")
    sup = sget("support_link")
    return jsonify(ok=True, plans=plans, pay_ready=pay_ready(), support=sup)


@app.post("/api/order/create")
def api_order_create():
    ip = client_ip()
    if not rate_ok(_order_hits, ip, 12, 3600):
        return jsonify(ok=False, message="Too many attempts. Try again later."), 429
    if not pay_ready():
        return jsonify(ok=False, message="Online payment is not set up yet."), 400
    j = request.get_json(silent=True) or {}
    try:
        plan_id = int(j.get("plan_id"))
    except (TypeError, ValueError):
        return jsonify(ok=False, message="Choose a plan."), 400
    plan = pdb("SELECT * FROM plans WHERE id = ? AND active = 1", (plan_id,), "one")
    if not plan or plan["price"] <= 0:
        return jsonify(ok=False, message="This plan is not available."), 400
    bot_id = None
    if j.get("renew"):
        bid = session.get("ubot")
        if not bid or not get_bot(bid):
            return jsonify(ok=False, message="Please login to renew."), 401
        bot_id = bid
    _order_hits[ip].append(time.time())
    oid = secrets.token_hex(12)
    pdb("INSERT INTO orders (id, plan_id, plan_name, days, amount, status, bot_id, created_at, ip) VALUES (?,?,?,?,?,'pending',?,?,?)",
        (oid, plan["id"], plan["name"], plan["days"], round(plan["price"], 2), bot_id, ts(now_utc()), ip))
    return jsonify(ok=True, order=order_view(pdb("SELECT * FROM orders WHERE id = ?", (oid,), "one")))


@app.get("/api/order/<oid>")
def api_order_get(oid):
    o = pdb("SELECT * FROM orders WHERE id = ?", (oid[:40],), "one")
    if not o:
        return jsonify(ok=False, message="Order not found."), 404
    if o["bot_id"] and session.get("ubot") != o["bot_id"]:
        return jsonify(ok=False, message="Order not found."), 404
    return jsonify(ok=True, order=order_view(o))


def _release_utr(oid: str, back_to="pending", dec_attempt=False):
    pdb("DELETE FROM used_utrs WHERE order_id = ?", (oid,))
    pdb(f"UPDATE orders SET status = ?, vstart = NULL{', attempts = MAX(0, attempts - 1)' if dec_attempt else ''} "
        "WHERE id = ? AND status = 'verifying'", (back_to, oid))


@app.post("/api/order/<oid>/verify")
def api_order_verify(oid):
    ip = client_ip()
    if not rate_ok(_verify_hits, ip, 15, 3600):
        return jsonify(ok=False, message="Too many attempts. Try again in a while."), 429
    o = pdb("SELECT * FROM orders WHERE id = ?", (oid[:40],), "one")
    if not o or (o["bot_id"] and session.get("ubot") != o["bot_id"]):
        return jsonify(ok=False, message="Order not found."), 404
    if o["status"] == "paid":
        return jsonify(ok=True, order=order_view(o))
    if o["status"] == "verifying" and o["vstart"] and time.time() - o["vstart"] > 120:
        _release_utr(oid)                                   # a crashed verification must not lock the order
        o = pdb("SELECT * FROM orders WHERE id = ?", (oid,), "one")
    if o["status"] == "verifying":
        return jsonify(ok=False, message="Verification already running. Wait a moment."), 409
    if o["attempts"] >= 6:
        return jsonify(ok=False, message=f"Too many tries. Contact support with order ID {oid[:8]}."), 429
    if not pay_ready():
        return jsonify(ok=False, message="Online payment is not available right now."), 400
    utr = re.sub(r"\s+", "", str((request.get_json(silent=True) or {}).get("utr", ""))).upper()
    if not UTR_RE.match(utr):
        return jsonify(ok=False, message="That UTR looks wrong. Copy the full transaction ID."), 400
    _verify_hits[ip].append(time.time())
    # lock the order, then reserve the UTR (a UTR can pay for only one order, ever)
    if pdb("UPDATE orders SET status = 'verifying', attempts = attempts + 1, utr = ?, vstart = ? "
           "WHERE id = ? AND status = 'pending'", (utr, time.time(), oid)) == 0:
        return jsonify(ok=False, message="Verification already running. Wait a moment."), 409
    try:
        pdb("INSERT INTO used_utrs (utr, order_id, created_at) VALUES (?,?,?)", (utr, oid, ts(now_utc())))
    except sqlite3.IntegrityError:
        _release_utr(oid)
        return jsonify(ok=False, message="This UTR was already used for another order."), 400
    try:
        res = fmpay_verify(utr, o["amount"])
    except FmPayError:
        _release_utr(oid, dec_attempt=True)
        return jsonify(ok=False, message="Payment server is busy. Wait a minute and press Verify again."), 502
    except Exception:
        _release_utr(oid, dec_attempt=True)
        return jsonify(ok=False, message="Something went wrong. Try again."), 500
    if not res["ok"]:
        _release_utr(oid)
        m = re.sub(r"[^\w .,:;!?@₹()\-]", "", res["message"] or "")[:80]
        return jsonify(ok=False, message="Payment not found yet. Check the UTR and amount, wait a minute and try again." + (f" ({m})" if m else "")), 400
    # paid: finish in one go
    key_code = None
    if o["bot_id"]:
        b = get_bot(o["bot_id"])
        if b:
            extend_days(b["id"], o["days"])
            log_act("user", "renewed online", f"@{b['username']} +{o['days']}d")
    else:
        key_code = new_key()
        pdb("UPDATE keys SET days = ?, note = ? WHERE code = ?", (o["days"], f"web order {oid[:6]}", key_code))
    pdb("UPDATE orders SET status = 'paid', key_code = ?, paid_at = ?, vstart = NULL WHERE id = ?", (key_code, ts(now_utc()), oid))
    notify_owner(f"💰 Payment {o['amount']:.0f} INR received: {o['plan_name']}" + (" (renewal)" if o["bot_id"] else " (new key)"))
    return jsonify(ok=True, order=order_view(pdb("SELECT * FROM orders WHERE id = ?", (oid,), "one")))


@app.post("/api/deploy")
def api_deploy():
    ip = client_ip()
    if not rate_ok(_deploy_hits, ip, 8, 3600):
        return jsonify(ok=False, message="Too many attempts. Try again later."), 429
    _deploy_hits[ip].append(time.time())
    j = request.get_json(silent=True) or {}
    code = re.sub(r"\s+", "", str(j.get("key", ""))).upper()
    k = pdb("SELECT * FROM keys WHERE code = ?", (code,), "one")
    if not k or k["used_by"] is not None:
        return jsonify(ok=False, message="Access key is invalid or already used."), 400
    if pdb("UPDATE keys SET used_by = -1 WHERE code = ? AND used_by IS NULL", (code,)) == 0:
        return jsonify(ok=False, message="Access key is invalid or already used."), 400
    ok, msg, b = create_bot(j.get("token", ""), j.get("admin", ""), k["days"], code)
    if not ok:
        pdb("UPDATE keys SET used_by = NULL WHERE code = ? AND used_by = -1", (code,))
        return jsonify(ok=False, message=msg), 400
    pdb("UPDATE keys SET used_by = ?, used_at = ? WHERE code = ?", (b["id"], ts(now_utc()), code))
    session.clear()
    session.permanent = True
    session["ubot"], session["ucsrf"] = b["id"], secrets.token_hex(16)
    log_act("buyer", "launched bot", f"@{b['username']}")
    return jsonify(ok=True, message=msg, username=b["username"], days=k["days"])


# ─────────────────────────── Mini App pay pages of the hosted bots (through Cloudflare) ───────────────────────────
# https://<public-url>/pay/<bot id>/pay?tx=..  ->  the bot's own web server on 127.0.0.1:<bot port>
_PROXY_HITS = {}


@app.route("/pay/<int:bid>/", defaults={"rest": ""}, methods=["GET", "POST"])
@app.route("/pay/<int:bid>/<path:rest>", methods=["GET", "POST"])
def bot_pay_proxy(bid, rest):
    b = get_bot(bid)
    if not b or not b.get("port") or not is_running(b):
        return Response("This payment page is not available right now. Open it again from the bot in a minute.",
                        503, mimetype="text/plain")
    if rest not in ("pay", "logo", "health", "api/status", "api/verify"):
        return Response("Not found", 404, mimetype="text/plain")
    if not rate_ok(_PROXY_HITS, client_ip(), 120, 60):
        return Response("Too many requests. Wait a minute.", 429, mimetype="text/plain")
    _PROXY_HITS.setdefault(client_ip(), []).append(time.time())
    try:
        r = requests.request(request.method, f"http://127.0.0.1:{b['port']}/{rest}", params=request.args,
                             data=request.get_data() if request.method == "POST" else None,
                             headers={"Content-Type": request.headers.get("Content-Type", "application/json")},
                             timeout=120)
    except requests.RequestException:
        return Response("The bot is starting. Try again in a moment.", 502, mimetype="text/plain")
    out = Response(r.content, r.status_code, mimetype=(r.headers.get("Content-Type") or "text/plain").split(";")[0])
    out.headers["Content-Type"] = r.headers.get("Content-Type", "text/plain")
    out.headers["Cache-Control"] = r.headers.get("Cache-Control", "no-store")
    return out


@app.get("/api/public_url")
def api_public_url():
    if not authed():
        return jsonify(ok=False), 401
    return jsonify(ok=True, url=public_url())


# ─────────────────────────── routes: buyer dashboard ───────────────────────────
@app.get("/login")
def user_login_page():
    return page(ui.USER_LOGIN, "Login")


@app.post("/api/user/login")
def api_user_login():
    ip = client_ip()
    if not rate_ok(_user_fails, ip, 8, 600):
        return jsonify(ok=False, message="Too many wrong tries. Wait 10 minutes."), 429
    code = re.sub(r"\s+", "", str((request.get_json(silent=True) or {}).get("key", ""))).upper()
    k = pdb("SELECT * FROM keys WHERE code = ?", (code,), "one")
    b = get_bot(k["used_by"]) if k and k["used_by"] and k["used_by"] > 0 else None
    if not b:
        _user_fails[ip].append(time.time())
        return jsonify(ok=False, message="Key not found, or no bot is launched with it yet.")
    session.clear()
    session.permanent = True
    session["ubot"], session["ucsrf"] = b["id"], secrets.token_hex(16)
    return jsonify(ok=True)


@app.get("/logout")
def user_logout():
    session.pop("ubot", None)
    session.pop("ucsrf", None)
    return redirect("/login")


@app.get("/dashboard")
def user_dashboard():
    if not get_bot(session.get("ubot") or 0):
        return redirect("/login")
    return page(ui.USER_DASH, "My dashboard", __CSRF__=session["ucsrf"])


def user_me(b):
    v = bot_view(b)
    v["store_name"] = bot_setting(b["id"], "store_name") or b.get("store_name") or b.get("name") or ""
    v["support"] = bot_setting(b["id"], "support") or b.get("support") or ""
    v["plan_days"] = max(1, b.get("plan_days") or DEFAULT_DAYS)
    return v


@app.get("/api/user/me")
def api_user_me():
    b, err = uguard()
    if err:
        return err
    plans = pdb("SELECT id, name, days, price FROM plans WHERE active = 1 ORDER BY price", fetch="all")
    return jsonify(ok=True, bot=user_me(b), plans=plans, pay_ready=pay_ready())


@app.post("/api/user/<action>")
def api_user_action(action):
    b, err = uguard()
    if err:
        return err
    j = request.get_json(silent=True) or {}
    if action in ("start", "stop", "restart", "token", "admin", "store") and b.get("suspended"):
        return jsonify(ok=False, message="This bot is suspended by the owner. Contact support.")
    if action == "start":
        if is_expired(b):
            return jsonify(ok=False, message="Plan expired. Renew it first.")
        _fail_times[b["id"]] = []
        start_bot(b)
        return jsonify(ok=True, message="Started.")
    if action == "stop":
        stop_bot(b)
        return jsonify(ok=True, message="Stopped.")
    if action == "restart":
        if is_expired(b):
            return jsonify(ok=False, message="Plan expired. Renew it first.")
        restart_bot(b["id"])
        return jsonify(ok=True, message="Restarted.")
    if action in ("token", "admin", "store"):
        if not rate_ok(_user_fails, f"act{b['id']}", 10, 600):
            return jsonify(ok=False, message="Too many changes. Wait a few minutes."), 429
        _user_fails[f"act{b['id']}"].append(time.time())
        if action == "token":
            ok, msg = change_token(b, j.get("token", ""))
        elif action == "admin":
            ok, msg = change_admin(b, j.get("admin", ""))
        else:
            ok, msg = change_store(b, j.get("name", ""), j.get("support", ""))
        if ok:
            log_act("user", f"changed {action}", f"@{get_bot(b['id'])['username']}")
        return jsonify(ok=ok, message=msg)
    if action == "renew_key":
        ip = client_ip()
        if not rate_ok(_user_fails, ip, 8, 600):
            return jsonify(ok=False, message="Too many wrong tries. Wait 10 minutes."), 429
        code = re.sub(r"\s+", "", str(j.get("key", ""))).upper()
        k = pdb("SELECT * FROM keys WHERE code = ?", (code,), "one")
        if not k or k["used_by"] is not None:
            _user_fails[ip].append(time.time())
            return jsonify(ok=False, message="Key is invalid or already used.")
        if not b["expires_at"]:
            return jsonify(ok=False, message="Your plan is already lifetime.")
        if pdb("UPDATE keys SET used_by = ?, used_at = ? WHERE code = ? AND used_by IS NULL", (b["id"], ts(now_utc()), code)) == 0:
            return jsonify(ok=False, message="Key is invalid or already used.")
        extend_days(b["id"], k["days"])
        log_act("user", "renewed with key", f"@{b['username']} +{k['days']}d")
        return jsonify(ok=True, message=f"Plan extended by {k['days']} days.")
    return jsonify(ok=False, message="Unknown action."), 400


@app.get("/api/user/log")
def api_user_log():
    b, err = uguard()
    if err:
        return err
    return jsonify(ok=True, log=read_log(b["id"]))


def read_log(bid: int) -> str:
    f = bot_dir(bid) / "bot.log"
    if not f.exists():
        return "(no log yet)"
    with open(f, "rb") as fh:
        fh.seek(0, 2)
        fh.seek(max(0, fh.tell() - 9000))
        txt = fh.read().decode("utf-8", "replace")
    txt = re.sub(r"bot\d+:[A-Za-z0-9_-]+", "bot<token>", txt)
    return "\n".join(txt.splitlines()[-70:])


def _csv_cell(v):
    s = "" if v is None else str(v)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s


@app.get("/api/user/export/<kind>.csv")
def api_user_export(kind):
    b, err = uguard()
    if err:
        return err
    queries = {
        "users": ("SELECT telegram_id, username, first_name, balance, total_orders, banned, created_at FROM users",
                  ["telegram_id", "username", "first_name", "balance", "total_orders", "banned", "created_at"]),
        "orders": ("SELECT order_id, user_id, plan_name, price, status, created_at FROM orders",
                   ["order_id", "user_id", "plan_name", "price", "status", "created_at"]),
    }
    if kind not in queries:
        return jsonify(ok=False, message="Unknown export."), 404
    f = bot_dir(b["id"]) / "store.db"
    rows = []
    if f.exists():
        try:
            con = sqlite3.connect(f"file:{f}?mode=ro", uri=True, timeout=5)
            rows = con.execute(queries[kind][0]).fetchall()
            con.close()
        except Exception:
            rows = []
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(queries[kind][1])
    for r in rows:
        w.writerow([_csv_cell(c) for c in r])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename={kind}-{b['username']}.csv"})


# ─────────────────────────── routes: owner ───────────────────────────
def _send_otp() -> bool:
    code = f"{secrets.randbelow(1_000_000):06d}"
    token, ids = sget("alert_token"), owner_ids()
    if not token or not ids:
        return False
    sent = any([tg_send(token, i, f"🔐 {brand()} owner login code: {code}\nValid for 5 minutes. Do not share it.") for i in ids])
    if sent:
        session["pre"] = {"h": hashlib.sha256((code + app.secret_key).encode()).hexdigest(), "exp": time.time() + 300, "tries": 0}
    return sent


def _login_done():
    session.clear()
    session.permanent = True
    session["auth"] = True
    session["csrf"] = secrets.token_hex(16)
    log_act("owner", "login", client_ip())
    return redirect("/admin")


@app.route("/admin/login", methods=["GET", "POST"])
def login():
    err, form = "", ui.FORM_PW
    if request.method == "POST":
        ip = client_ip()
        if not rate_ok(_login_fails, ip, 6, 600):
            err = "Too many wrong tries. Wait 10 minutes."
        elif "otp" in request.form:
            pre = session.get("pre")
            if not pre or time.time() > pre["exp"]:
                session.pop("pre", None)
                err = "Code expired. Login again."
            else:
                pre["tries"] += 1
                session["pre"] = pre
                h = hashlib.sha256((request.form.get("otp", "").strip() + app.secret_key).encode()).hexdigest()
                if hmac.compare_digest(h, pre["h"]):
                    return _login_done()
                _login_fails[ip].append(time.time())
                err = "Wrong code."
                form = ui.FORM_OTP
                if pre["tries"] >= 4:
                    session.pop("pre", None)
                    err, form = "Too many wrong codes. Login again.", ui.FORM_PW
        elif check_pw(request.form.get("password", "")):
            twofa = sget("twofa") == "1" and sget("tg_verified") == "1" and os.getenv("PANEL_2FA", "on") != "off"
            if not twofa:
                return _login_done()
            if _send_otp():
                form = ui.FORM_OTP
            else:
                err = "Could not send the Telegram code. Try again, or set PANEL_2FA=off in panel.env to bypass."
        else:
            _login_fails[ip].append(time.time())
            err = "Wrong password."
    return page(ui.ADMIN_LOGIN, "Owner login", __FORM__=form, __ERR__=html.escape(err))


@app.get("/admin/logout")
def logout():
    session.pop("auth", None)
    session.pop("csrf", None)
    return redirect("/admin/login")


@app.get("/admin")
def dashboard():
    if not authed():
        return redirect("/admin/login")
    return page(ui.ADMIN_DASH, "Dashboard", __CSRF__=session["csrf"], __DEFDAYS__=str(DEFAULT_DAYS))


@app.get("/api/stats")
def api_stats():
    g = guard()
    if g:
        return g
    bots = all_bots_view()
    tot = {"bots": len(bots), "running": sum(1 for b in bots if b["status"] == "running"),
           "users": sum(b["users"] for b in bots), "orders": sum(b["orders"] for b in bots),
           "revenue": sum(b["revenue"] for b in bots), "today": sum(b["today"] for b in bots),
           "deposits": sum(b["deposits"] for b in bots)}
    keys = pdb("SELECT code, days, note, created_at, used_by FROM keys ORDER BY created_at DESC LIMIT 60", fetch="all")
    plans = pdb("SELECT * FROM plans ORDER BY price", fetch="all")
    orders = pdb("SELECT id, plan_name, amount, status, bot_id, created_at FROM orders ORDER BY created_at DESC LIMIT 20", fetch="all")
    s = pdb("SELECT COUNT(*) AS n, COALESCE(SUM(amount),0) AS t FROM orders WHERE status = 'paid'", fetch="one")
    today = ts(now_utc() + timedelta(minutes=IST_MIN))[:10]
    st = pdb("SELECT COALESCE(SUM(amount),0) AS t FROM orders WHERE status = 'paid' "
             "AND DATE(paid_at, ?) = ?", (f"+{IST_MIN} minutes", today), "one")
    sales = {"count": s["n"], "total": s["t"], "today": st["t"]}
    act = pdb("SELECT ts, who, action, detail FROM activity ORDER BY id DESC LIMIT 30", fetch="all")
    return jsonify(ok=True, totals=tot, bots=bots, keys=keys, plans=plans, orders=orders, sales=sales,
                   activity=act, pay_ready=pay_ready(), server=server_stats())


@app.post("/api/bot/<int:bid>/<action>")
def api_bot_action(bid, action):
    g = guard()
    if g:
        return g
    b = get_bot(bid)
    if not b:
        return jsonify(ok=False, message="Bot not found."), 404
    j = request.get_json(silent=True) or {}
    if action == "start":
        if is_expired(b):
            return jsonify(ok=False, message="Plan expired. Extend it first.")
        if b.get("suspended"):
            return jsonify(ok=False, message="Bot is suspended. Unsuspend it first.")
        _fail_times[bid] = []
        start_bot(b)
        return jsonify(ok=True, message="Started.")
    if action == "stop":
        stop_bot(b)
        return jsonify(ok=True, message="Stopped.")
    if action == "restart":
        restart_bot(bid)
        return jsonify(ok=True, message="Restarted.")
    if action == "extend":
        try:
            days = int(j.get("days", 30))
        except (TypeError, ValueError):
            return jsonify(ok=False, message="Enter days as a number."), 400
        if not -3650 <= days <= 3650 or days == 0:
            return jsonify(ok=False, message="Days must be between -3650 and 3650."), 400
        msg = extend_days(bid, days)
        log_act("owner", "extend", f"@{b['username']} {days}d")
        return jsonify(ok=True, message=msg)
    if action == "lifetime":
        pdb("UPDATE bots SET expires_at = NULL, desired = 1, plan_days = 36500 WHERE id = ?", (bid,))
        start_bot(get_bot(bid))
        log_act("owner", "lifetime", f"@{b['username']}")
        return jsonify(ok=True, message="Lifetime plan set.")
    if action == "suspend":
        pdb("UPDATE bots SET suspended = 1 WHERE id = ?", (bid,))
        stop_bot(get_bot(bid), keep_desired=True)
        log_act("owner", "suspend", f"@{b['username']}")
        return jsonify(ok=True, message="Suspended.")
    if action == "unsuspend":
        pdb("UPDATE bots SET suspended = 0, desired = 1 WHERE id = ?", (bid,))
        _fail_times[bid] = []
        start_bot(get_bot(bid))
        log_act("owner", "unsuspend", f"@{b['username']}")
        return jsonify(ok=True, message="Unsuspended.")
    if action == "delete":
        stop_bot(b)
        pdb("DELETE FROM bots WHERE id = ?", (bid,))
        shutil.rmtree(bot_dir(bid), ignore_errors=True)
        log_act("owner", "delete", f"@{b['username']}")
        return jsonify(ok=True, message="Bot deleted.")
    return jsonify(ok=False, message="Unknown action."), 400


@app.get("/api/bot/<int:bid>/log")
def api_bot_log(bid):
    g = guard()
    if g:
        return g
    return jsonify(ok=True, log=read_log(bid))


@app.post("/api/deploy_owner")
def api_deploy_owner():
    g = guard()
    if g:
        return g
    j = request.get_json(silent=True) or {}
    try:
        days = int(j.get("days", DEFAULT_DAYS))
    except (TypeError, ValueError):
        days = DEFAULT_DAYS
    ok, msg, b = create_bot(j.get("token", ""), j.get("admin", ""), days)
    if ok:
        log_act("owner", "hosted bot", f"@{b['username']}")
    return jsonify(ok=ok, message=msg), (200 if ok else 400)


@app.post("/api/keys")
def api_keys():
    g = guard()
    if g:
        return g
    j = request.get_json(silent=True) or {}
    try:
        days = int(j.get("days", DEFAULT_DAYS))
        count = max(1, min(int(j.get("count", 1)), 50))
    except (TypeError, ValueError):
        return jsonify(ok=False, message="Days and count must be numbers."), 400
    if not 1 <= days <= 36500:
        return jsonify(ok=False, message="Days must be 1 to 36500."), 400
    note = str(j.get("note", ""))[:60]
    made = []
    for _ in range(count):
        code = new_key()
        pdb("UPDATE keys SET days = ?, note = ? WHERE code = ?", (days, note, code))
        made.append(code)
    log_act("owner", "created keys", f"{count} x {days}d")
    return jsonify(ok=True, message=f"{count} key(s) created.", codes=made)


@app.post("/api/keys/<code>/delete")
def api_key_delete(code):
    g = guard()
    if g:
        return g
    pdb("DELETE FROM keys WHERE code = ? AND used_by IS NULL", (code.upper(),))
    return jsonify(ok=True, message="Key removed.")


@app.post("/api/plans")
def api_plans():
    g = guard()
    if g:
        return g
    j = request.get_json(silent=True) or {}
    act = j.get("action")
    if act == "add":
        name = re.sub(r"\s+", " ", str(j.get("name", ""))).strip()[:30]
        try:
            days, price = int(j.get("days")), round(float(j.get("price")), 2)
        except (TypeError, ValueError):
            return jsonify(ok=False, message="Enter days and price as numbers."), 400
        if not name or not 1 <= days <= 36500 or not 1 <= price <= 100000:
            return jsonify(ok=False, message="Name needed, days 1-36500, price 1-100000."), 400
        pdb("INSERT INTO plans (name, days, price) VALUES (?,?,?)", (name, days, price))
        return jsonify(ok=True, message="Plan added.")
    try:
        pid = int(j.get("id"))
    except (TypeError, ValueError):
        return jsonify(ok=False, message="Bad plan."), 400
    if act == "toggle":
        pdb("UPDATE plans SET active = 1 - active WHERE id = ?", (pid,))
        return jsonify(ok=True, message="Updated.")
    if act == "delete":
        pdb("DELETE FROM plans WHERE id = ?", (pid,))
        return jsonify(ok=True, message="Plan deleted.")
    return jsonify(ok=False, message="Unknown action."), 400


@app.post("/api/restart_all")
def api_restart_all():
    g = guard()
    if g:
        return g
    n = 0
    for b in pdb("SELECT * FROM bots WHERE desired = 1", fetch="all"):
        if is_expired(b) or b.get("suspended"):
            continue
        restart_bot(b["id"])
        n += 1
    return jsonify(ok=True, message=f"{n} bot(s) restarted with the latest template.")


_last_broadcast = [0.0]


@app.post("/api/broadcast")
def api_broadcast():
    g = guard()
    if g:
        return g
    text = str((request.get_json(silent=True) or {}).get("text", "")).strip()[:1000]
    if not text:
        return jsonify(ok=False, message="Write a message first.")
    if time.time() - _last_broadcast[0] < 60:
        return jsonify(ok=False, message="Wait a minute between broadcasts.")
    _last_broadcast[0] = time.time()
    targets = [(b["token"], i) for b in pdb("SELECT * FROM bots", fetch="all") if not is_expired(b)
               for i in re.findall(r"\d+", b["admin_ids"])]

    def run():
        for tok, cid in targets:
            tg_send(tok, cid, f"📢 {brand()}:\n\n{text}")
            time.sleep(0.05)
    threading.Thread(target=run, daemon=True).start()
    log_act("owner", "broadcast", f"{len(targets)} recipients")
    return jsonify(ok=True, message=f"Sending to {len(targets)} admin(s).")


# ── settings ──
def _mask(v: str) -> str:
    return ("••••" + v[-4:]) if v else ""


@app.get("/api/settings")
def api_settings_get():
    g = guard()
    if g:
        return g
    key, url, upi, name = fm_conf()
    v = {"theme": sget("theme", "lime"), "accent": sget("accent"), "brand": sget("brand") or BRAND,
         "logo": sget("logo"), "tagline": sget("tagline"), "support_link": sget("support_link"),
         "fmpay_key_mask": _mask(key), "fmpay_url": url, "upi_id": upi, "upi_name": sget("upi_name"),
         "owner_tg": sget("owner_tg"), "alert_token_mask": _mask(sget("alert_token")),
         "alerts_on": sget("alerts_on", "1"), "twofa": sget("twofa", "0")}
    return jsonify(ok=True, values=v, themes=ui.THEMES)


@app.post("/api/tgtest")
def api_tgtest():
    g = guard()
    if g:
        return g
    j = request.get_json(silent=True) or {}
    tok = (j.get("alert_token") or sget("alert_token")).strip()
    ids = [int(x) for x in re.findall(r"\d{5,15}", j.get("owner_tg") or sget("owner_tg"))]
    if not TOKEN_RE.match(tok) or not ids:
        return jsonify(ok=False, message="Enter your numeric Telegram ID and a valid bot token first.")
    if tg_send(tok, ids[0], f"✅ {brand()}: test message. Alerts and 2-step login will work."):
        sset("alert_token", tok)
        sset("owner_tg", ",".join(map(str, ids)))
        sset("tg_verified", "1")
        return jsonify(ok=True, message="Test sent and saved. Check Telegram, then tick the options and Save.")
    return jsonify(ok=False, message="Could not send. Open that bot in Telegram, press Start, and check the ID.")


@app.post("/api/settings")
def api_settings_set():
    g = guard()
    if g:
        return g
    j = request.get_json(silent=True) or {}

    def clean(k, n):
        return re.sub(r"[\r\n\t]+", " ", str(j.get(k, ""))).strip()[:n]

    theme = clean("theme", 20)
    if theme not in ui.THEMES:
        return jsonify(ok=False, message="Unknown theme.")
    accent = clean("accent", 7)
    if accent and not re.fullmatch(r"#[0-9a-fA-F]{6}", accent):
        return jsonify(ok=False, message="Accent colour is invalid.")
    brand_v = clean("brand", 40)
    if not brand_v:
        return jsonify(ok=False, message="Brand name cannot be empty.")
    support = clean("support_link", 120)
    if support.startswith("@") and re.fullmatch(r"@[A-Za-z0-9_]{4,32}", support):
        support = "https://t.me/" + support[1:]
    if support and not re.match(r"^https://[^\s]+$", support):
        return jsonify(ok=False, message="Support link must be @username or an https:// link.")
    fmurl = clean("fmpay_url", 200).rstrip("/")
    if fmurl and not re.match(r"^https?://[^\s]+$", fmurl):
        return jsonify(ok=False, message="FMPay URL must start with http:// or https://")
    upi = clean("upi_id", 60)
    if upi and not re.fullmatch(r"[\w.\-]{2,}@[\w.\-]{2,}", upi):
        return jsonify(ok=False, message="UPI ID looks wrong. Example: name@bank")
    owner_tg = ",".join(re.findall(r"\d{5,15}", clean("owner_tg", 80)))
    fmkey, altok = clean("fmpay_key", 200), clean("alert_token", 80)
    if altok and not TOKEN_RE.match(altok):
        return jsonify(ok=False, message="Alert bot token is not valid.")
    changed_tg = (owner_tg != sget("owner_tg")) or (altok and altok != sget("alert_token"))
    twofa = "1" if j.get("twofa") == "1" else "0"
    if changed_tg:
        sset("tg_verified", "0")
    if twofa == "1" and not changed_tg and sget("tg_verified") != "1":
        return jsonify(ok=False, message="Press 'Send test message' successfully before turning on 2-step login.")
    if twofa == "1" and changed_tg:
        twofa = "0"
    for k, v in (("theme", theme), ("accent", accent), ("brand", brand_v), ("logo", clean("logo", 4)),
                 ("tagline", clean("tagline", 140)), ("support_link", support), ("fmpay_url", fmurl),
                 ("upi_id", upi), ("upi_name", clean("upi_name", 40)), ("owner_tg", owner_tg),
                 ("alerts_on", "1" if j.get("alerts_on") == "1" else "0"), ("twofa", twofa)):
        sset(k, v)
    if fmkey and not fmkey.startswith("•"):
        sset("fmpay_key", fmkey)
    if altok:
        sset("alert_token", altok)
    log_act("owner", "settings saved")
    extra = "" if twofa == j.get("twofa") else " (Test the Telegram message first, then turn on 2-step login.)"
    return jsonify(ok=True, message="Saved." + extra)


@app.post("/api/password")
def api_password():
    g = guard()
    if g:
        return g
    j = request.get_json(silent=True) or {}
    if not check_pw(str(j.get("old", ""))):
        return jsonify(ok=False, message="Current password is wrong.")
    new = str(j.get("new", ""))
    if len(new) < 8:
        return jsonify(ok=False, message="New password must be at least 8 characters.")
    sset("pw_hash", hash_pw(new))
    log_act("owner", "password changed")
    return jsonify(ok=True, message="Password changed.")


@app.get("/admin/backup")
def admin_backup():
    if not authed():
        return redirect("/admin/login")
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
    tmp.close()
    with _dblock:
        src = sqlite3.connect(PANEL_DB)
        dst = sqlite3.connect(tmp.name)
        src.backup(dst)
        dst.close()
        src.close()
    data = Path(tmp.name).read_bytes()
    os.unlink(tmp.name)
    log_act("owner", "backup downloaded")
    return Response(data, mimetype="application/octet-stream",
                    headers={"Content-Disposition": f"attachment; filename=panel-backup-{now_utc().strftime('%Y%m%d-%H%M')}.db"})


def main():
    if not TEMPLATE.exists():
        sys.exit("storebot_template.py is missing next to app.py")
    threading.Thread(target=watchdog, daemon=True).start()
    print(f"Public URL (Cloudflare): {public_url() or 'NOT SET - Mini App pay page off, QR photo is used'}", flush=True)
    print(f"Panel running on http://{PANEL_HOST}:{PANEL_PORT}   (owner: /admin)", flush=True)
    from werkzeug.serving import make_server
    srv = make_server(PANEL_HOST, PANEL_PORT, app, threaded=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
