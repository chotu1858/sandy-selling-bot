#!/usr/bin/env python3
"""PANDA AUDIO BOT - HostPanel script powered by PandaAPI (by SANDY).

Players send a voice / audio / video; pick a preset (godmode, titan, nuclear, dj, voice ...) or tune
gain / loudness / bass / treble / clarity / echo / pitch with buttons; the bot returns the processed audio.
Environment from HostPanel: BOT_TOKEN, ADMIN_IDS, STORE_NAME, SUPPORT_USERNAME, DB_NAME, THEME_FILE
"""
import os
import re
import sys
import json
import time
import html
import shutil
import sqlite3
import tempfile
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor

import requests

BASE = os.path.dirname(os.path.abspath(__file__))          # bot folder (.env lives here)
sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))   # script folder with the PandaAPI package

from PandaAPI import PRESETS, RANGES, DEFAULT_EFFECTS, vc_presets, vc_ffmpeg_filter   # noqa: E402


def load_env(path):
    try:
        for line in open(path, encoding="utf-8").read().splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
    except OSError:
        pass


load_env(os.path.join(BASE, ".env"))
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMINS = {int(x) for x in os.getenv("ADMIN_IDS", "").replace(" ", "").split(",") if x.isdigit()}
BRAND = os.getenv("STORE_NAME", "") or "Panda Audio Bot"
SUPPORT = os.getenv("SUPPORT_USERNAME", "").strip().lstrip("@")
DB_FILE = os.path.join(BASE, os.getenv("DB_NAME", "store.db"))
API = "https://api.telegram.org/bot" + BOT_TOKEN
FILE_API = "https://api.telegram.org/file/bot" + BOT_TOKEN
SESSION = requests.Session()
MAX_MB = 20            # Telegram bots can download files up to 20 MB
MAX_SEC = 15 * 60      # longest input accepted
JOBS = threading.Semaphore(2)     # at most 2 ffmpeg jobs at once on the server

try:
    THEME = json.load(open(os.getenv("THEME_FILE", ""), encoding="utf-8"))
    if not isinstance(THEME, dict):
        THEME = {}
except Exception:
    THEME = {}

DEFAULT_WELCOME = ("<blockquote><b>🎧 {brand}</b></blockquote>\n<blockquote><b>├── 🎤 Send a voice, audio or video\n"
                   "├── 🎚 Pick a preset or tune it yourself\n└── 🔊 Get the boosted audio back</b></blockquote>\n<b>Hey {name}, send me a file 👇</b>")


def log(m):
    print("[%s] %s" % (time.strftime("%H:%M:%S"), m), flush=True)


def esc(t):
    return html.escape(str(t if t is not None else ""), quote=False)


# ------------------------------------------------------------------ database
DB = sqlite3.connect(DB_FILE, check_same_thread=False, timeout=30)
DB.row_factory = sqlite3.Row
L = threading.RLock()
with L:
    DB.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT, joined TEXT DEFAULT CURRENT_TIMESTAMP, uses INTEGER DEFAULT 0)")
    DB.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
    DB.commit()


def touch_user(fr):
    name = ((fr.get("first_name") or "") + " " + (fr.get("last_name") or "")).strip()[:60] or "friend"
    with L:
        DB.execute("INSERT OR IGNORE INTO users(id, name) VALUES(?, ?)", (fr["id"], name))
        DB.execute("UPDATE users SET name=? WHERE id=?", (name, fr["id"]))
        DB.commit()
    return name


def bump(uid):
    with L:
        DB.execute("UPDATE users SET uses = uses + 1 WHERE id=?", (uid,))
        DB.commit()


# ------------------------------------------------------------------ telegram
def tg(method, params=None, files=None, timeout=60):
    for _ in range(3):
        try:
            if files:
                r = SESSION.post(API + "/" + method, data=params or {}, files=files, timeout=timeout)
            else:
                r = SESSION.post(API + "/" + method, json=params or {}, timeout=timeout)
            j = r.json()
        except (requests.RequestException, ValueError):
            time.sleep(1)
            continue
        if j.get("ok"):
            return j.get("result")
        ra = (j.get("parameters") or {}).get("retry_after")
        if ra and j.get("error_code") == 429:
            time.sleep(min(int(ra), 10))
            continue
        return {"_err": str(j.get("description", "error"))}
    return {"_err": "network error"}


def bad(r):
    return isinstance(r, dict) and "_err" in r


def send(chat, text, kb=None):
    p = {"chat_id": chat, "text": text[:4000], "parse_mode": "HTML", "disable_web_page_preview": True}
    if kb:
        p["reply_markup"] = {"inline_keyboard": kb}
    return tg("sendMessage", p)


def edit(chat, mid, text, kb=None):
    p = {"chat_id": chat, "message_id": mid, "text": text[:4000], "parse_mode": "HTML",
         "reply_markup": {"inline_keyboard": kb or []}}
    r = tg("editMessageText", p)
    if bad(r) and "not modified" not in r["_err"]:
        return send(chat, text, kb)
    return r


def btn(text, cb):
    return {"text": text, "callback_data": cb}


# ------------------------------------------------------------------ audio
def ffmpeg_exe():
    p = shutil.which("ffmpeg")
    if p:
        return p
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


PRESET_EMO = {"godmode": "👑", "titan": "🗿", "nuclear": "☢️", "bambam": "🥁", "james": "🎤", "heavy": "🔩",
              "dj": "🎛", "fight": "🥊", "voice": "🗣", "phonemic": "📞", "default": "♻️"}
KEYS = ["gain", "loudness", "bass", "treble", "clarity", "echo", "pitch"]
KEY_EMO = {"gain": "🔊", "loudness": "📢", "bass": "🥁", "treble": "✨", "clarity": "💎", "echo": "🌊", "pitch": "🎼"}
STEP = 100

LAST = {}      # uid -> {"fid": file_id, "name": str, "dur": int}
CUSTOM = {}    # uid -> effect config
BUSY = set()


def process(src, cfg, out):
    """Apply PandaAPI's ffmpeg filter chain; returns (ok, error text)."""
    ff = ffmpeg_exe()
    if not ff:
        return False, "ffmpeg is not available on the server."
    filt = "aresample=48000," + vc_ffmpeg_filter(cfg=cfg)
    cmd = [ff, "-y", "-hide_banner", "-loglevel", "error", "-i", src, "-vn", "-af", filt,
           "-ar", "48000", "-ac", "2", "-c:a", "libmp3lame", "-b:a", "192k", out]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=240)
    except subprocess.TimeoutExpired:
        return False, "Processing took too long."
    if r.returncode != 0 or not os.path.isfile(out):
        return False, (r.stderr or "ffmpeg failed")[-200:]
    return True, ""


def cfg_of(uid):
    return CUSTOM.setdefault(uid, dict(DEFAULT_EFFECTS))


def welcome(name):
    t = THEME.get("welcome") if isinstance(THEME.get("welcome"), str) and THEME.get("welcome") else DEFAULT_WELCOME
    return t.replace("{brand}", esc(BRAND)).replace("{name}", esc(name))


def home_kb():
    kb = [[btn("🎚 Presets", "pl"), btn("ℹ️ Help", "help")]]
    if SUPPORT:
        kb.append([{"text": "📞 Support", "url": "https://t.me/" + SUPPORT}])
    return kb


def preset_kb():
    names = vc_presets()
    rows, row = [], []
    for n in names:
        row.append(btn("%s %s" % (PRESET_EMO.get(n, "🎵"), n.title()), "p:" + n))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([btn("🎛 Custom mix", "c")])
    return rows


def custom_text_kb(uid):
    c = cfg_of(uid)
    lines = ["<blockquote><b>🎛 CUSTOM MIX</b></blockquote>"]
    kb = []
    for k in KEYS:
        v = int(float(c.get(k, 0)))
        lines.append("%s <b>%s</b>: <code>%d</code> / %d" % (KEY_EMO[k], k.title(), v, RANGES[k][1]))
        kb.append([btn("➖", "cm:%s" % k), btn("%s %s" % (KEY_EMO[k], k.title()), "cn"), btn("➕", "cp:%s" % k)])
    lines.append("↔️ <b>Swap channels</b>: %s" % ("ON" if c.get("swap") else "off"))
    kb.append([btn("↔️ Swap L/R", "cs"), btn("♻️ Reset", "cr")])
    kb.append([btn("▶️ PROCESS", "go:custom")])
    kb.append([btn("⬅️ Presets", "pl")])
    return "\n".join(lines), kb


def have_file(uid):
    return uid in LAST


def ask_preset(chat, uid):
    f = LAST[uid]
    send(chat, "<blockquote><b>🎚 CHOOSE EFFECT</b></blockquote>\nFile: <b>%s</b>\nPick a preset or build a custom mix 👇" % esc(f["name"]), preset_kb())


def run_job(chat, uid, label, cfg):
    f = LAST.get(uid)
    if not f:
        return send(chat, "Send me a voice / audio / video first 🎤")
    if uid in BUSY:
        return send(chat, "⏳ Your previous file is still processing.")
    BUSY.add(uid)
    try:
        note = send(chat, "⏳ <b>Processing</b> with <b>%s</b>…" % esc(label))
        with JOBS:
            tmp = tempfile.mkdtemp(prefix="panda_")
            try:
                info = tg("getFile", {"file_id": f["fid"]})
                if bad(info) or not info.get("file_path"):
                    return send(chat, "❌ Could not download your file (max %d MB)." % MAX_MB)
                src = os.path.join(tmp, "in.bin")
                with SESSION.get(FILE_API + "/" + info["file_path"], stream=True, timeout=120) as r, open(src, "wb") as fh:
                    for chunk in r.iter_content(1 << 16):
                        fh.write(chunk)
                out = os.path.join(tmp, "out.mp3")
                ok, err = process(src, cfg, out)
                if not ok:
                    log("ffmpeg error: %s" % err)
                    return send(chat, "❌ Could not process this file.\n<code>%s</code>" % esc(err[-120:]))
                with open(out, "rb") as fh:
                    res = tg("sendAudio", {"chat_id": chat, "title": ("%s - %s" % (label, BRAND))[:60], "performer": "PandaAPI",
                                           "caption": "✅ <b>%s</b>" % esc(label), "parse_mode": "HTML"},
                             files={"audio": ("%s.mp3" % re.sub(r"[^A-Za-z0-9_-]+", "_", label), fh, "audio/mpeg")}, timeout=180)
                if bad(res):
                    return send(chat, "❌ Upload failed: %s" % esc(res["_err"]))
                bump(uid)
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
        if not bad(note) and note:
            tg("deleteMessage", {"chat_id": chat, "message_id": note.get("message_id")})
        send(chat, "Want another effect on the same file?", [[btn("🎚 Presets", "pl"), btn("🎛 Custom", "c")]])
    finally:
        BUSY.discard(uid)


# ------------------------------------------------------------------ handlers
def on_media(chat, uid, msg):
    m = msg.get("voice") or msg.get("audio") or msg.get("video_note") or msg.get("video") or msg.get("document")
    if not m:
        return False
    mime = (m.get("mime_type") or "")
    if msg.get("document") and not (mime.startswith("audio/") or mime.startswith("video/")):
        send(chat, "❌ Send an audio, voice or video file.")
        return True
    if (m.get("file_size") or 0) > MAX_MB * 1024 * 1024:
        send(chat, "❌ File is too big. Max %d MB." % MAX_MB)
        return True
    if (m.get("duration") or 0) > MAX_SEC:
        send(chat, "❌ File is too long. Max %d minutes." % (MAX_SEC // 60))
        return True
    LAST[uid] = {"fid": m["file_id"], "name": m.get("file_name") or m.get("title") or ("voice note" if msg.get("voice") else "your file"), "dur": m.get("duration") or 0}
    ask_preset(chat, uid)
    return True


def on_callback(cq):
    uid, chat = cq["from"]["id"], (cq.get("message") or {}).get("chat", {}).get("id", cq["from"]["id"])
    mid = (cq.get("message") or {}).get("message_id")
    d = cq.get("data", "")
    tg("answerCallbackQuery", {"callback_query_id": cq["id"]}, timeout=10)
    k, _, arg = d.partition(":")
    if k == "pl":
        if not have_file(uid):
            return send(chat, "Send me a voice / audio / video first 🎤")
        return edit(chat, mid, "<blockquote><b>🎚 CHOOSE EFFECT</b></blockquote>\nFile: <b>%s</b>" % esc(LAST[uid]["name"]), preset_kb())
    if k == "help":
        return edit(chat, mid, ("<blockquote><b>ℹ️ HOW IT WORKS</b></blockquote>\n1. Send a voice, audio or video (max %d MB, %d min)\n2. Pick a preset or a custom mix\n"
                                "3. Get the processed MP3 back\n\n<i>Tip: godmode/titan/nuclear are very loud, lower your volume first.</i>") % (MAX_MB, MAX_SEC // 60), [[btn("⬅️ Back", "home")]])
    if k == "home":
        return edit(chat, mid, welcome(cq["from"].get("first_name", "friend")), home_kb())
    if k == "p":
        if arg not in PRESETS:
            return
        return threading.Thread(target=run_job, args=(chat, uid, arg.title(), dict(PRESETS[arg])), daemon=True).start()
    if k == "c":
        t, kb = custom_text_kb(uid)
        return edit(chat, mid, t, kb)
    if k == "cn":
        return
    if k in ("cp", "cm"):
        c = cfg_of(uid)
        lo, hi = RANGES[arg]
        c[arg] = max(lo, min(hi, float(c.get(arg, 0)) + (STEP if k == "cp" else -STEP)))
    elif k == "cs":
        c = cfg_of(uid)
        c["swap"] = 0 if c.get("swap") else 1
    elif k == "cr":
        CUSTOM[uid] = dict(DEFAULT_EFFECTS)
    elif k == "go":
        return threading.Thread(target=run_job, args=(chat, uid, "Custom mix", dict(cfg_of(uid))), daemon=True).start()
    else:
        return
    t, kb = custom_text_kb(uid)
    edit(chat, mid, t, kb)


def on_message(msg):
    fr = msg.get("from")
    if not fr or msg["chat"].get("type") != "private":
        return
    uid, chat = fr["id"], msg["chat"]["id"]
    name = touch_user(fr)
    text = (msg.get("text") or "").strip()
    if text.startswith("/"):
        cmd, _, rest = text.partition(" ")
        cmd = cmd.split("@")[0].lower()
        if cmd in ("/start", "/menu", "/help"):
            return send(chat, welcome(name), home_kb())
        if cmd == "/presets":
            return ask_preset(chat, uid) if have_file(uid) else send(chat, "Send me a voice / audio / video first 🎤")
        if uid in ADMINS and cmd == "/stats":
            with L:
                n = DB.execute("SELECT COUNT(*), COALESCE(SUM(uses),0) FROM users").fetchone()
            return send(chat, "<blockquote><b>📊 STATS</b></blockquote>\nUsers: <b>%d</b>\nFiles processed: <b>%d</b>\nffmpeg: <b>%s</b>" % (n[0], n[1], "ok" if ffmpeg_exe() else "MISSING"))
        if uid in ADMINS and cmd == "/broadcast":
            if not rest.strip():
                return send(chat, "Use: <code>/broadcast your message</code>")
            with L:
                ids = [r["id"] for r in DB.execute("SELECT id FROM users")]
            ok = 0
            for i in ids:
                if not bad(send(i, rest.strip())):
                    ok += 1
                time.sleep(0.05)
            return send(chat, "📢 Sent to %d / %d users." % (ok, len(ids)))
        return send(chat, welcome(name), home_kb())
    if on_media(chat, uid, msg):
        return
    send(chat, welcome(name), home_kb())


def safe(fn, *a):
    try:
        fn(*a)
    except Exception as e:
        log("handler error: %r" % (e,))


def main():
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN missing")
    me = tg("getMe")
    if bad(me):
        raise SystemExit("Invalid BOT_TOKEN: %s" % me["_err"])
    tg("deleteWebhook", {"drop_pending_updates": True})
    tg("setMyCommands", {"commands": [{"command": "start", "description": "Open the menu"}, {"command": "presets", "description": "Choose an effect"}]})
    log("%s started: @%s admins=%s ffmpeg=%s" % (BRAND, me.get("username", ""), sorted(ADMINS), bool(ffmpeg_exe())))
    pool = ThreadPoolExecutor(max_workers=16)
    offset = 0
    while True:
        try:
            r = SESSION.post(API + "/getUpdates", json={"offset": offset, "timeout": 50, "allowed_updates": ["message", "callback_query"]}, timeout=65)
            j = r.json()
        except (requests.RequestException, ValueError):
            time.sleep(3)
            continue
        if not j.get("ok"):
            log("getUpdates: %s" % str(j)[:200])
            time.sleep(5)
            continue
        for u in j.get("result", []):
            offset = max(offset, u["update_id"] + 1)
            if "callback_query" in u:
                pool.submit(safe, on_callback, u["callback_query"])
            elif "message" in u:
                pool.submit(safe, on_message, u["message"])


if __name__ == "__main__":
    main()
