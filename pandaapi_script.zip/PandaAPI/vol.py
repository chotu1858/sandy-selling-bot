"""Central audio-effect controls for PandaAPI.

Edit this file to tune the supported ranges and DSP strength.
All public effect values use a simple 0-1000 scale.
"""

EFFECT_RANGES = {
    "gain": (0, 1000),
    "loudness": (0, 1000),
    "bass": (0, 1000),
    "treble": (0, 1000),
    "clarity": (0, 1000),
    "echo": (0, 1000),
    "pitch": (0, 1000),
    "swap": (0, 1),
}

# Maximum DSP strength at value 1000.
# Change these numbers to tune the sound without touching the DSP code.
DSP_LIMITS = {
    "gain_db": 30.0,
    "loudness_db": 15.0,
    "bass_db": 20.0,
    "treble_db": 15.0,
    "clarity_db": 12.0,
    "warm_db": 5.0,
    "excitation": 0.45,
    "echo_mix": 0.60,
    "echo_feedback": 0.45,
    "echo_delay_1_ms": 180,
    "echo_delay_2_ms": 360,
}

DEFAULT_EFFECTS = {
    "gain": 0,
    "loudness": 0,
    "bass": 0,
    "treble": 0,
    "clarity": 0,
    "echo": 0,
    "pitch": 0,
    "swap": 0,
    "muted": False,
    "_v": 12,
}

EFFECT_KEYS = tuple(EFFECT_RANGES.keys())


def clamp_effect(name, value):
    lo, hi = EFFECT_RANGES.get(name, (0, 1000))
    try:
        return max(lo, min(hi, float(value)))
    except (TypeError, ValueError):
        return lo


def make_defaults():
    return dict(DEFAULT_EFFECTS)
