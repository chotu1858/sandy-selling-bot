from __future__ import annotations

import asyncio
import json
import logging
import math
import time
from pathlib import Path
from typing import Dict, Optional, Set, Tuple

from ..vol import DEFAULT_EFFECTS, EFFECT_RANGES, DSP_LIMITS, clamp_effect

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    _HAS_NUMPY = False

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Ranges & defaults
# ---------------------------------------------------------------------------
# All user-controllable effect values use a 0-1000 scale.
# swap remains a boolean-style 0-1 switch.
RANGES = dict(EFFECT_RANGES)
CONFIG_VERSION = 11

PRESETS = {
    # ── God-tier — koi tik nahi sakta ──────────────────────────────────────
    "godmode":  {"gain": 1000, "loudness": 1000, "bass": 1000, "pitch": 0, "treble": 950, "clarity": 980, "echo": 0, "muted": False},
    "titan":    {"gain": 850, "loudness": 900, "bass": 900, "pitch": 0, "treble": 900, "clarity": 950, "echo": 0, "muted": False},
    "nuclear":  {"gain": 700, "loudness": 800, "bass": 800, "pitch": 0, "treble": 850, "clarity": 920, "echo": 0, "muted": False},
    # ── Standard ────────────────────────────────────────────────────────────
    "bambam":   {"gain": 95,  "loudness": 90,  "bass": 100, "pitch": 350, "treble": 250, "clarity": 500,  "echo": 0,  "muted": False},
    "james":    {"gain": 100, "loudness": 100, "bass": 90,  "pitch": 0,  "treble": 450, "clarity": 650,  "echo": 0,  "muted": False},
    "heavy":    {"gain": 85,  "loudness": 80,  "bass": 95,  "pitch": 30, "treble": 20,  "clarity": 45,  "echo": 0,  "muted": False},
    "dj":       {"gain": 90,  "loudness": 85,  "bass": 90,  "pitch": 0,  "treble": 400, "clarity": 600,  "echo": 0,  "muted": False},
    "fight":    {"gain": 75,  "loudness": 60,  "bass": 80,  "pitch": 0,  "treble": 250, "clarity": 500,  "echo": 0,  "muted": False},
    "voice":    {"gain": 55,  "loudness": 70,  "bass": 20,  "pitch": 0,  "treble": 350, "clarity": 700,  "echo": 0,  "muted": False},
    "phonemic": dict(DEFAULT_EFFECTS),
    "default":  dict(DEFAULT_EFFECTS),
}


# ---------------------------------------------------------------------------
# DSP helpers  — extended for god-tier gain/loudness/bass
# ---------------------------------------------------------------------------
def _dsp_params(cfg: Dict) -> Dict:
    def f(key): return max(0.0, float(cfg.get(key, 0) or 0))
    g, loud = f("gain"), f("loudness")
    bass, treble, clarity = f("bass"), f("treble"), f("clarity")

    # Normalize every 0-1000 effect to the DSP ranges.
    g_n = min(g, 1000.0) / 1000.0
    loud_n = min(loud, 1000.0) / 1000.0
    bass_n = min(bass, 1000.0) / 1000.0
    treble_n = min(treble, 1000.0) / 1000.0
    clarity_n = min(clarity, 1000.0) / 1000.0
    pre_db = g_n * DSP_LIMITS["gain_db"] + loud_n * DSP_LIMITS["loudness_db"]
    t = ((g_n + loud_n) / 2.0) ** 0.5

    def _safe(db): return min(db, 9000.0)

    bass_scale  = bass_n
    return {
        "dry":        g <= 0 and loud <= 0 and bass <= 0 and treble <= 0 and clarity <= 0,
        "vol":        10 ** (_safe(pre_db) / 20.0),
        "bass_db":    bass_scale * DSP_LIMITS["bass_db"],
        "treble_db":  treble_n * DSP_LIMITS["treble_db"],
        "clarity_db": clarity_n * DSP_LIMITS["clarity_db"],
        "attack_ms":  0.2 + 0.6 * bass_scale,
        "warm_db":    bass_scale * DSP_LIMITS["warm_db"],
        "exc":        DSP_LIMITS["excitation"] * bass_scale,
        "ratio":      2.0 + 4.0 * t,            # was 150
        "comp_thr":   max(1e-7, 0.12 * math.exp(-1.2 * t)),
        "makeup_db":  _safe(6.0 * t),            # was 120
        "drive":      1.0 + 1.5 * t,            # was 80
        "echo":       f("echo"),
        "pitch":      f("pitch"),
        "muted":      bool(cfg.get("muted", False)),
    }


class _OnePole:
    def __init__(self, fc, fs):
        self.a = math.exp(-2.0 * math.pi * fc / fs)
        self.y = 0.0
        lam = -math.log(self.a)
        self.S = int(max(16, min(8192, 200.0 / lam)))
        k = np.arange(self.S, dtype=np.float64)
        self.apow = self.a ** k
        self.ainv = self.a ** (-k)

    def process(self, x):
        n, out, a, y0, i = x.shape[0], np.empty(x.shape[0], np.float64), self.a, self.y, 0
        while i < n:
            m = min(self.S, n - i)
            seg = x[i:i + m]
            y = self.apow[:m] * (a * y0 + (1.0 - a) * np.cumsum(seg * self.ainv[:m]))
            out[i:i + m] = y
            y0 = float(y[-1])
            i += m
        self.y = y0
        return out


class _PitchShifter:
    def __init__(self, channels, window=1920):
        self.W, self.H = int(window), int(window) + 2
        self.hist = np.zeros((int(window) + 2, channels), dtype=np.float64)
        self.phase = 0.0

    def feed(self, x):
        self.hist = np.concatenate((self.hist, x), axis=0)[-self.H:] if x.shape[0] < self.H else x[-self.H:].copy()

    def process(self, x, ratio):
        n, W, H = x.shape[0], self.W, self.H
        ext = np.concatenate((self.hist, x), axis=0)
        i = np.arange(n)
        d1 = (self.phase + i * (1.0 - ratio)) % W
        d2 = (d1 + W / 2.0) % W
        out = np.zeros_like(x)
        last = ext.shape[0] - 1
        for d in (d1, d2):
            pos = (H + i) - d
            p0 = np.floor(pos).astype(np.int64)
            fr = (pos - p0)[:, None]
            a, b = ext[np.clip(p0, 0, last)], ext[np.clip(p0 + 1, 0, last)]
            w = (np.sin(np.pi * d / W) ** 2)[:, None]
            out += w * (a * (1.0 - fr) + b * fr)
        self.phase = (self.phase + n * (1.0 - ratio)) % W
        self.hist = ext[-H:].copy()
        return out


class LiveEQ:
    """
    Full DSP chain — EQ + compressor + lookahead limiter + pitch + echo.
    Extended for god-tier amplification (gain 0-400, loudness 0-200, bass 0-200).
    Input/output: int16 numpy array or raw bytes.
    """
    BLOCK = 48
    CEIL  = 0.9999   # tighter ceiling for cleaner godmode

    def __init__(self, sample_rate=48000, channels=2):
        if not _HAS_NUMPY:
            raise ImportError("pip install numpy")
        self.fs, self.channels = sample_rate, max(1, int(channels))
        self.muted = self._dry = self.swap = False
        self.vol = self.bass_g = self.treble_g = self.clarity_g = self.warm_g = 1.0
        self.exc = self.echo_m = 0.0
        self.pitch_f = 1.0
        self.comp_ratio, self.comp_thr, self.makeup, self.drive = 4.0, 0.35, 1.0, 1.0
        self._ps = _PitchShifter(self.channels)
        self._echo_buf = np.zeros((2400, self.channels), dtype=np.float32)
        fs = float(sample_rate)
        self._chains = [
            {k: _OnePole(fc, fs) for k, fc in
             [("dc",30.),("b1",55.),("b2",55.),("hi",5500.),("ph",5500.),("pl",800.),("wl",420.),("wm",75.),("ex",160.)]}
            for _ in range(self.channels)
        ]
        B = self.BLOCK
        self._att_c = math.exp(-B / (fs * 0.003))  # faster attack for godmode
        self._rel_c = math.exp(-B / (fs * 0.060))
        self._rel_l = math.exp(-B / (fs * 0.004))
        self._env = 0.0
        self._g_lim = 1.0
        self.configure(dict(DEFAULT_EFFECTS))

    def configure(self, cfg: Dict):
        p = _dsp_params(cfg or {})
        self.muted   = p["muted"]
        self.echo_m  = p["echo"] / 1000.0
        self.pitch_f = 2 ** ((p["pitch"] / 1000.0) * 0.7)
        self.swap    = bool(float((cfg or {}).get("swap", 0) or 0) >= 1)
        if self.echo_m <= 0.0: self._echo_buf.fill(0)
        self._dry = p["dry"]
        if self._dry:
            self.vol = self.bass_g = self.treble_g = self.clarity_g = self.warm_g = 1.0
            self.exc = 0.0
            return
        self.vol       = p["vol"]
        self.bass_g    = 10 ** (p["bass_db"]    / 20.0)
        self.treble_g  = 10 ** (p["treble_db"]  / 20.0)
        self.clarity_g = 10 ** (p["clarity_db"] / 20.0)
        self.warm_g    = 10 ** (p["warm_db"]    / 20.0)
        self.exc       = p["exc"]
        self._att_c    = math.exp(-self.BLOCK / (float(self.fs) * max(0.1, p["attack_ms"]) / 1000.0))
        self.comp_ratio, self.comp_thr = p["ratio"], p["comp_thr"]
        self.makeup = 10 ** (min(p["makeup_db"], 9000.0) / 20.0)
        self.drive  = p["drive"]

    def _block_peaks(self, a, nb, pad):
        ap = np.abs(a)
        if pad: ap = np.concatenate((ap, np.zeros((pad, ap.shape[1]))), axis=0)
        return ap.reshape(nb, self.BLOCK, ap.shape[1]).max(axis=(1, 2))

    def _dynamics(self, y):
        n, B = y.shape[0], self.BLOCK
        nb = (n + B - 1) // B
        pad = nb * B - n
        idx = np.arange(n)
        peak = self._block_peaks(y, nb, pad)
        thr, inv_r, env, att, rel = self.comp_thr, 1.0/self.comp_ratio, self._env, self._att_c, self._rel_c
        gc = np.ones(nb)
        for i in range(nb):
            p = float(peak[i])
            c = att if p > env else rel
            env = c * env + (1.0 - c) * p
            if env > thr: gc[i] = (thr + (env - thr) * inv_r) / env
        self._env = env
        centers = (np.arange(nb) + 0.5) * B
        y = y * np.interp(idx, centers, gc)[:, None]
        d = self.drive
        # double tanh stage for godmode saturation
        y = np.tanh(np.tanh(y * self.makeup * d) * 1.5) * (1.0 / (math.tanh(d) * 1.5 + 1e-9))
        p2  = self._block_peaks(y, nb, pad)
        req = np.minimum(1.0, self.CEIL / np.maximum(p2, 1e-9))
        la  = req.copy()
        if nb > 1: la[:-1] = np.minimum(req[:-1], req[1:])
        g = min(self._g_lim, float(req[0]))
        G = np.empty(nb + 1); G[0] = g
        for i in range(nb):
            g = min(float(la[i]), 1.0 - (1.0 - g) * self._rel_l)
            G[i + 1] = g
        self._g_lim = g
        return np.clip(y * np.interp(idx, np.arange(nb+1)*B, G)[:, None], -0.9999, 0.9999)

    def process_int16(self, pcm: np.ndarray) -> np.ndarray:
        if self.muted or pcm is None or pcm.size == 0:
            return np.zeros(0 if pcm is None else pcm.shape, dtype=np.int16)
        if self._dry and self.echo_m <= 0.0 and self.pitch_f <= 1.04:
            if self.swap and self.channels == 2 and pcm.size >= 2:
                return np.ascontiguousarray(pcm.astype(np.int16).reshape(-1, 2)[:, ::-1]).reshape(pcm.shape)
            return pcm.astype(np.int16, copy=False)
        shape, flat, C = pcm.shape, pcm.reshape(-1), self.channels
        nfr = flat.size // C
        if nfr == 0: return pcm.astype(np.int16, copy=False)
        used = nfr * C
        x = np.nan_to_num(flat[:used].astype(np.float64).reshape(nfr, C) * (1.0/32768.0))
        if self.pitch_f > 1.04: x = self._ps.process(x, 1.0/self.pitch_f)
        else: self._ps.feed(x)
        if not self._dry:
            for c in range(C):
                ch, xc = self._chains[c], x[:, c]
                xc   = xc - ch["dc"].process(xc)
                low  = ch["b2"].process(ch["b1"].process(xc))
                high = xc - ch["hi"].process(xc)
                band = ch["ph"].process(xc) - ch["pl"].process(xc)
                warm = ch["wl"].process(xc) - ch["wm"].process(xc)
                lowb = (self.bass_g - 1.0) * low
                exc  = self.exc * (np.tanh(12.0*lowb) - ch["ex"].process(np.tanh(12.0*lowb))) if self.exc > 0 else 0.0
                x[:, c] = (xc + lowb + (self.treble_g-1.0)*high + (self.clarity_g-1.0)*band + (self.warm_g-1.0)*warm + exc) * self.vol
        if self.echo_m > 0.0:
            delay, mix = self._echo_buf.shape[0], self.echo_m * DSP_LIMITS["echo_mix"]
            tmp = np.concatenate((self._echo_buf, x), axis=0)
            x = x + mix * tmp[:nfr]
            self._echo_buf = tmp[-delay:].copy()
        x = self._dynamics(x) if not self._dry else np.clip(x, -0.9999, 0.9999)
        if self.swap and C == 2: x = x[:, ::-1]
        out = np.rint(np.clip(x, -1.0, 1.0) * 32767.0).astype(np.int16).reshape(-1)
        if used != flat.size: out = np.concatenate((out, flat[used:].astype(np.int16)))
        return out.reshape(shape)

    def process_bytes(self, pcm_bytes: bytes) -> bytes:
        return self.process_int16(np.frombuffer(pcm_bytes, dtype=np.int16)).tobytes()


class AudioEffects:
    @staticmethod
    def get_default_effects() -> Dict:
        return dict(DEFAULT_EFFECTS)

    @staticmethod
    def is_legacy_config(cfg: Dict) -> bool:
        if not cfg: return False
        if "level" in cfg and "loudness" not in cfg: return True
        if int(cfg.get("_v", 0) or 0) < CONFIG_VERSION: return True
        return False

    @staticmethod
    def merge_config(stored: Dict) -> Dict:
        defaults = AudioEffects.get_default_effects()
        if not stored or AudioEffects.is_legacy_config(stored): return defaults
        out = dict(defaults)
        for k in defaults:
            if k in stored: out[k] = stored[k]
        return out

    @staticmethod
    def list_presets() -> list:
        return list(PRESETS.keys())

    @staticmethod
    def get_preset(name: str) -> Dict:
        return dict(PRESETS.get(name, PRESETS["default"]))

    @staticmethod
    def build_ffmpeg_filter(cfg: Dict = None, **kwargs) -> str:
        return vc_ffmpeg_filter(cfg=cfg, **kwargs)


# ---------------------------------------------------------------------------
# VCBridge
# ---------------------------------------------------------------------------
class VCBridge:
    def __init__(self, client, self_user_id: int = 0, mtproto=None, is_owner: bool = True):
        self.client = client
        self.mtproto = mtproto
        self.self_user_id = int(self_user_id or 0)
        self.is_owner = is_owner
        self.config = AudioEffects.get_default_effects()
        self.eq = LiveEQ()
        self.active_bridges: Dict[int, dict] = {}
        self._handler_registered = False
        self._bound_client_id = None
        self._was_admin_muted: Set[int] = set()
        self._mute_lock = asyncio.Lock()
        self._fwd_count = self._drop_count = self._rx_count = 0
        self._last_join_error = ""
        self._register_handlers()
        self.sync_effects()

    def sync_effects(self):
        self.eq.configure(self.config)
        self.eq.muted = bool(self.config.get("muted", False))

    async def update_effects(self, chat_id: int, preset: str = None, **kwargs) -> bool:
        if preset:
            self.config.update(AudioEffects.get_preset(preset))
        for k, v in kwargs.items():
            if k in RANGES:
                self.config[k] = clamp_effect(k, v)
            elif k == "muted":
                self.config[k] = bool(v)
        self.sync_effects()
        self._save_config()
        return True

    def _save_config(self, path: str = "bridge_config.json"):
        try:
            p = Path(path)
            data = json.loads(p.read_text()) if p.exists() else {}
            data["effects"] = self.config
            p.write_text(json.dumps(data, indent=2))
        except Exception: pass

    def load_config(self, path: str = "bridge_config.json") -> Dict:
        try:
            data = json.loads(Path(path).read_text())
            stored = data.get("effects", {})
            self.config = AudioEffects.merge_config(stored)
            self.sync_effects()
            return self.config
        except Exception:
            return self.config

    def _register_handlers(self):
        if self._handler_registered and self._bound_client_id == id(self.client): return
        if self.client is None: return
        bridge = self
        try:
            from pytgcalls import filters as fl
            from pytgcalls.types import Direction, Device

            @self.client.on_update(fl.stream_frame(Direction.INCOMING, Device.MICROPHONE))
            async def _on_audio(_, update):
                await bridge._forward_frames(update)
        except Exception as e:
            logger.warning("[VCBridge] handler: %s", e)
        self._handler_registered = True
        self._bound_client_id = id(self.client)

    async def _forward_frames(self, update):
        self._rx_count += 1
        if self.config.get("muted") or self.eq.muted: return
        chat_id = int(getattr(update, "chat_id", 0) or 0)
        info = self.active_bridges.get(chat_id)
        if not info or info.get("mode") == "solo": return
        source_id, target_id = int(info["source_id"]), int(info["target_id"])
        if chat_id != source_id or target_id == source_id: return
        if not update.frames: return
        try:
            raw = bytes(update.frames[0].frame)
            samples = np.frombuffer(raw, dtype=np.int16).copy()
            if samples.size < 2: return
            out = self.eq.process_int16(samples)
            if out is None or out.size < 2: return
            from pytgcalls.types import Device
            await self.client.send_frame(target_id, Device.MICROPHONE, out.tobytes())
            self._fwd_count += 1
        except Exception as e:
            err = str(e).lower()
            if any(x in err for x in ("external","notincall","not in","connectionnotfound")): return
            if self._fwd_count < 5 or int(time.time()) % 10 == 0:
                logger.warning("[VCBridge] forward: %s", e)

    async def start_bridge(self, source_id: int, target_id: int) -> Tuple[bool, str]:
        try:
            from pytgcalls.types import ExternalMedia, MediaStream, RecordStream
            from pytgcalls.types.raw import AudioParameters
            AUDIO = AudioParameters(bitrate=48000, channels=2)
            self.config["muted"] = False
            self.eq.muted = False
            self.sync_effects()
            try:
                await self.client.play(source_id, MediaStream(ExternalMedia.AUDIO, AUDIO))
            except Exception as e:
                if "already" not in str(e).lower(): return False, f"Source join failed: {e}"
            try:
                await self.client.record(source_id, RecordStream(True, AUDIO))
            except Exception as e:
                if "already" not in str(e).lower(): logger.warning("[VCBridge] record: %s", e)
            if target_id != source_id:
                try:
                    await self.client.play(target_id, MediaStream(ExternalMedia.AUDIO, AUDIO))
                except Exception as e:
                    if "already" not in str(e).lower(): return False, f"Target join failed: {e}"
            info = {"source_id": source_id, "target_id": target_id, "mode": "oneway", "started_at": time.time()}
            self.active_bridges[source_id] = info
            if target_id != source_id: self.active_bridges[target_id] = info
            self.sync_effects()
            return True, ""
        except Exception as e:
            self._last_join_error = str(e)[:200]
            return False, str(e)[:200]

    async def join_vc_only(self, chat_id: int) -> bool:
        try:
            from pytgcalls.types import ExternalMedia, MediaStream, RecordStream
            from pytgcalls.types.raw import AudioParameters
            AUDIO = AudioParameters(bitrate=48000, channels=2)
            await self.client.play(chat_id, MediaStream(ExternalMedia.AUDIO, AUDIO))
            await self.client.record(chat_id, RecordStream(True, AUDIO))
            self.active_bridges[chat_id] = {"source_id": chat_id, "target_id": chat_id, "mode": "solo", "started_at": time.time()}
            return True
        except Exception as e:
            if "already" in str(e).lower(): return True
            self._last_join_error = str(e)[:200]
            return False

    async def stop_bridge(self, chat_id: int) -> bool:
        info = self.active_bridges.pop(chat_id, None)
        if info:
            for cid in {int(info["source_id"]), int(info["target_id"])}:
                self.active_bridges.pop(cid, None)
                try: await self.client.leave_call(cid)
                except Exception: pass
        return info is not None

    async def stop_all_bridges(self) -> int:
        count = 0
        for cid in list(self.active_bridges):
            if await self.stop_bridge(cid): count += 1
        return count

    async def set_muted(self, muted: bool) -> bool:
        async with self._mute_lock:
            self.config["muted"] = bool(muted)
            self.eq.muted = bool(muted)
            self.sync_effects()
            self._save_config()
        return True

    def get_bridge_info(self, chat_id: int) -> Optional[dict]:
        return self.active_bridges.get(chat_id)

    def get_last_error(self) -> str:
        return self._last_join_error


# ---------------------------------------------------------------------------
# Standalone helpers
# ---------------------------------------------------------------------------
def vc_presets() -> list:
    return list(PRESETS.keys())


def vc_preset_info(preset: str) -> dict:
    p = PRESETS.get(preset)
    if not p: return {"success": False, "error": f"Unknown preset. Available: {vc_presets()}"}
    return {"preset": preset, "settings": p, "success": True}


def vc_ffmpeg_filter(preset: str = None, cfg: dict = None, **kwargs) -> str:
    c = dict(PRESETS.get(preset, {}) if preset else (cfg or DEFAULT_EFFECTS))
    c.update({k: v for k, v in kwargs.items() if v is not None})
    swap = float(c.get("swap", 0) or 0) >= 1
    if not any(float(c.get(k, 0) or 0) for k in ("gain","loudness","bass","treble","clarity","echo","pitch")):
        return "pan=stereo|c0=c1|c1=c0" if swap else "anull"
    p = _dsp_params(c)
    if p["muted"]: return "volume=0"
    parts = [
        "highpass=f=30",
        f"bass=g={p['bass_db']:.1f}:f=90:w=0.6",
        f"equalizer=f=3500:t=q:w=1.0:g={p['clarity_db']:.1f}",
        f"treble=g={p['treble_db']:.1f}:f=7000:w=0.6",
        f"volume={p['vol']:.4f}",
    ]
    if p["echo"] > 0:
        d1 = max(0.25, min(0.65, p["echo"] / 1500.0))
        parts.append(f"aecho=0.8:0.9:160|320:{d1:.2f}|{d1*0.6:.2f}")
    if p["pitch"] > 0:
        factor = 2 ** ((p["pitch"] / 1000.0) * 0.7)
        parts.append(f"asetrate={48000.0/factor:.0f},aresample=48000,atempo={factor:.4f}")
    parts += [
        f"acompressor=threshold={p['comp_thr']:.4f}:ratio={p['ratio']:.1f}:attack={max(1,p['attack_ms']):.0f}:release=80:makeup={10**(min(p['makeup_db'],60)/20.0):.2f}",
        "asoftclip=type=tanh",
        "asoftclip=type=tanh",   # double tanh for godmode
        "alimiter=limit=0.999:attack=1:release=30",
    ]
    if swap: parts.append("pan=stereo|c0=c1|c1=c0")
    return ",".join(parts)


def vc_process(pcm_bytes: bytes, preset: str = None,
               sample_rate: int = 48000, channels: int = 2, **kwargs) -> bytes:
    if not _HAS_NUMPY: raise ImportError("pip install numpy")
    cfg = dict(PRESETS.get(preset, DEFAULT_EFFECTS) if preset else DEFAULT_EFFECTS)
    cfg.update({k: v for k, v in kwargs.items() if v is not None})
    eq = LiveEQ(sample_rate=sample_rate, channels=channels)
    eq.configure(cfg)
    return eq.process_bytes(pcm_bytes)
