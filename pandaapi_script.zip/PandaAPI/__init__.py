from .modules.vc import (
    AudioEffects,
    LiveEQ,
    VCBridge,
    PRESETS,
    RANGES,
    DEFAULT_EFFECTS,
    vc_process,
    vc_ffmpeg_filter,
    vc_presets,
    vc_preset_info,
)

__version__ = "2.0.0"
__all__ = [
    "AudioEffects", "LiveEQ", "VCBridge",
    "PRESETS", "RANGES", "DEFAULT_EFFECTS",
    "vc_process", "vc_ffmpeg_filter", "vc_presets", "vc_preset_info",
]
