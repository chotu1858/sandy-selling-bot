# PandaAPI

**Python utility hub by SANDY**

---

## Install

```bash
pip3 install PandaAPI numpy --break-system-package
              OR
pip install PandaAPI numpy 
```

---

## VC Module — Telegram Voice Chat Audio Engine

PandaAPI ka VC module Telegram bots ke liye full audio DSP chain provide karta hai — real-time EQ, compressor, limiter, pitch shift, echo, aur live VC bridging.

### Import

```python
from PandaAPI import (
    AudioEffects,   # effect config manager
    LiveEQ,         # real-time DSP processor
    VCBridge,       # pytgcalls VC bridge
    PRESETS,        # built-in audio presets dict
    RANGES,         # valid range per effect key
    DEFAULT_EFFECTS,# default effect values
    vc_process,     # one-shot PCM bytes processor
    vc_ffmpeg_filter,# ffmpeg -af filter string builder
    vc_presets,     # list of preset names
    vc_preset_info, # info dict for one preset
)
```

---

### DEFAULT_EFFECTS

```python
from PandaAPI import DEFAULT_EFFECTS
print(DEFAULT_EFFECTS)
# {
#   "gain": 0, "loudness": 0, "bass": 0,
#   "treble": 0, "clarity": 0, "echo": 0,
#   "pitch": 0, "swap": 0, "muted": False
# }
```

---

### RANGES

```python
from PandaAPI import RANGES
print(RANGES)
# {
#   "gain":     (0, 400),
#   "loudness": (0, 200),
#   "bass":     (0, 200),
#   "treble":   (0, 100),
#   "clarity":  (0, 100),
#   "echo":     (0, 100),
#   "pitch":    (0, 100),
#   "swap":     (0, 1),
# }
```

---

### PRESETS

Built-in presets — `godmode`, `titan`, `nuclear`, `bambam`, `james`, `heavy`, `dj`, `fight`, `voice`, `phonemic`, `default`

```python
from PandaAPI import PRESETS, vc_presets, vc_preset_info

# list all presets
print(vc_presets())
# ['godmode', 'titan', 'nuclear', 'bambam', 'james', 'heavy', 'dj', 'fight', 'voice', 'phonemic', 'default']

# info for one preset
info = vc_preset_info("godmode")
print(info)
# {"preset": "godmode", "settings": {"gain": 400, "loudness": 200, ...}, "success": True}

# use preset values directly
preset_cfg = PRESETS["bambam"]
```

---

### AudioEffects

Effect config manager — defaults, presets, config merge.

```python
from PandaAPI import AudioEffects

# get clean default config
config = AudioEffects.get_default_effects()

# get a preset config
preset = AudioEffects.get_preset("godmode")

# merge stored config with defaults (handles old versions)
merged = AudioEffects.merge_config(stored_config)

# list all presets
names = AudioEffects.list_presets()

# build ffmpeg filter string from config
filt = AudioEffects.build_ffmpeg_filter(config)
```

---

### LiveEQ — Real-time PCM Processor

Full DSP chain: bass boost → treble → clarity EQ → volume → echo → pitch → compressor → limiter.

```python
from PandaAPI import LiveEQ

eq = LiveEQ(sample_rate=48000, channels=2)

# configure with effect values
eq.configure({
    "gain": 100,
    "loudness": 80,
    "bass": 60,
    "treble": 40,
    "clarity": 50,
    "echo": 0,
    "pitch": 0,
    "muted": False,
})

# process raw int16 PCM bytes
processed_bytes = eq.process_bytes(raw_pcm_bytes)

# or process numpy int16 array
import numpy as np
samples = np.frombuffer(raw_pcm_bytes, dtype=np.int16).copy()
out = eq.process_int16(samples)
```

---

### VCBridge — pytgcalls VC Bridge

Source VC se audio capture karo → EQ apply karo → target VC mein send karo.

```python
from PandaAPI import VCBridge
from pytgcalls import PyTgCalls
from pyrogram import Client

app = Client("assistant", api_id=..., api_hash=..., session_string=...)
vc  = PyTgCalls(app)

await app.start()
await vc.start()

bridge = VCBridge(vc, mtproto=app)

# source VC join karo (record only)
ok = await bridge.join_vc_only(SOURCE_CHAT_ID)

# source → target one-way bridge start karo
ok, err = await bridge.start_bridge(SOURCE_CHAT_ID, TARGET_CHAT_ID)

# effects update karo live
await bridge.update_effects(SOURCE_CHAT_ID, gain=200, bass=100)

# preset apply karo
await bridge.update_effects(SOURCE_CHAT_ID, preset="godmode")

# mute/unmute
await bridge.set_muted(True)
await bridge.set_muted(False)

# bridge info
info = bridge.get_bridge_info(SOURCE_CHAT_ID)

# bridge band karo
await bridge.stop_bridge(SOURCE_CHAT_ID)

# sab bridges band karo
await bridge.stop_all_bridges()
```

---

### vc_ffmpeg_filter — ffmpeg -af string

File play karte waqt ffmpeg se effects apply karo.

```python
from PandaAPI import vc_ffmpeg_filter

# config dict se filter banao
filt = vc_ffmpeg_filter(cfg={"gain": 150, "bass": 80, "loudness": 100})
# returns: "highpass=f=30,bass=g=...,volume=...,acompressor=...,alimiter=..."

# preset se filter banao
filt = vc_ffmpeg_filter(preset="godmode")

# ffmpeg mein use karo
import subprocess
subprocess.run([
    "ffmpeg", "-i", "input.mp3",
    "-af", filt,
    "-ar", "48000", "-ac", "2",
    "output.wav"
])
```

---

### vc_process — One-shot PCM Processing

```python
from PandaAPI import vc_process

# raw PCM bytes process karo
out = vc_process(
    pcm_bytes,
    preset="bambam",         # ya cfg= dict
    sample_rate=48000,
    channels=2,
)

# custom values ke saath
out = vc_process(pcm_bytes, gain=200, bass=100, loudness=150)
```

---

### Bot Script mein Full Example

```python
from pyrogram import Client, filters
from pyrogram.types import Message
from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream, ExternalMedia
from pytgcalls.types.raw import AudioParameters
from PandaAPI import AudioEffects, VCBridge, vc_ffmpeg_filter, vc_presets

import subprocess, os

app = Client("bot", api_id=API_ID, api_hash=API_HASH, session_string=SESSION)
vc  = PyTgCalls(app)

config = AudioEffects.get_default_effects()   # sab 0 se start
bridge = VCBridge(vc, mtproto=app)

await app.start()
await vc.start()

# --- Join VC ---
@app.on_message(filters.command("joinvc"))
async def join_vc(client, message: Message):
    ok = await bridge.join_vc_only(message.chat.id)
    await message.reply("✅ Joined" if ok else "❌ Failed")

# --- Live Bridge source → target ---
@app.on_message(filters.command("bridge"))
async def start_bridge(client, message: Message):
    target = int(message.command[1])
    ok, err = await bridge.start_bridge(message.chat.id, target)
    await message.reply(f"✅ Bridge ON" if ok else f"❌ {err}")

# --- Play audio file with effects ---
@app.on_message(filters.command("play"))
async def play_audio(client, message: Message):
    rpl = message.reply_to_message
    path = await rpl.download()

    # ffmpeg se effects apply karo
    filt = vc_ffmpeg_filter(cfg=config)
    out  = f"/tmp/fx_{message.id}.wav"
    subprocess.run(["ffmpeg", "-y", "-i", path, "-af", filt,
                    "-ar", "48000", "-ac", "2", out])

    stream = MediaStream(out, AudioParameters(bitrate=48000, channels=2))
    await vc.play(message.chat.id, stream)
    await message.reply("✅ Playing")

# --- Set effect ---
@app.on_message(filters.command("gain"))
async def set_gain(client, message: Message):
    val = int(message.command[1])
    config["gain"] = val
    bridge.config = config
    bridge.sync_effects()
    await message.reply(f"✅ Gain: {val}")

# --- Apply preset ---
@app.on_message(filters.command("preset"))
async def set_preset(client, message: Message):
    name = message.command[1]
    await bridge.update_effects(message.chat.id, preset=name)
    await message.reply(f"✅ Preset: {name}")
    # available: {', '.join(vc_presets())}

# --- Stop ---
@app.on_message(filters.command("stop"))
async def stop(client, message: Message):
    await bridge.stop_bridge(message.chat.id)
    await message.reply("✅ Stopped")
```

---

## Effect Ranges

| Key       | Min | Max | Notes                    |
|-----------|-----|-----|--------------------------|
| gain      | 0   | 400 | Extended headroom        |
| loudness  | 0   | 200 | Extended headroom        |
| bass      | 0   | 200 | Extended headroom        |
| treble    | 0   | 100 |                          |
| clarity   | 0   | 100 |                          |
| echo      | 0   | 100 |                          |
| pitch     | 0   | 100 |                          |
| swap      | 0   | 1   | Stereo channel swap      |
| muted     | bool|     | True = silence           |

---

## Presets Quick Reference

| Preset   | Gain | Loudness | Bass | Notes              |
|----------|------|----------|------|--------------------|
| godmode  | 400  | 200      | 200  | Max everything     |
| titan    | 350  | 180      | 180  | Near godmode       |
| nuclear  | 280  | 160      | 160  | Heavy              |
| bambam   | 95   | 90       | 100  | Pitched up         |
| james    | 100  | 100      | 90   | Clean loud         |
| dj       | 90   | 85       | 90   | Club sound         |
| fight    | 75   | 60       | 80   | VC fight mode      |
| voice    | 55   | 70       | 20   | Clear voice        |
| default  | 0    | 0        | 0    | All off            |

---

## Requirements

- Python >= 3.8
- numpy
- py-tgcalls (for VCBridge)
- pyrogram (for VCBridge)

---

**Made by SANDY**
