# PandaAPI v1.0.20 (hostpanel script)

Original library: PandaAPI by PANDA (@ll_PANDA_BBY_ll) - MIT License.
Files in `PandaAPI/` are the original, unmodified release.

Packaged for hostpanel by Sandy.

Install deps on the VPS:
    pip3 install numpy requests beautifulsoup4
    pip3 install "PandaAPI[full]"   # for pytgcalls/pyrogram VC features
